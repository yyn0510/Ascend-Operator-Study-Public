"""Detached, serial, auditable cloud batch with package restoration and light export."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
import zipfile

HERE=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');temp.replace(p)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()

def verify_package():
    for name,d in read(HERE/'PACKAGE_MANIFEST.json').items():
        path=(HERE/name).resolve()
        if not path.is_relative_to(HERE) or sha(path)!=d['sha256']:raise ValueError('Package file changed: '+name)

def stages(plan):
    """Pure planning; no host libraries imported by the controller."""
    if plan['stage']=='A':
        return ['environment_and_model_hashes','backup_installed_package','CLIP_native_dev_and_eval',
                'wrapper_controls_vision_text_both','two_fixed_GELU_builds_and_original_cases',
                'per_candidate_dev_gate_then_scope_diagnosis_and_eval','three_fresh_process_timing_sessions',
                'restore_original_package','export_results']
    return ['environment_and_all_model_hashes','backup_installed_package',
            'native_and_wrapper_dev_preflight_for_existing_and_new_hosts',
            '32_frozen_candidates_build_original_cases_real_input_gates',
            'fixed_representative_small_forward_pilots_only','restore_original_package','export_results']

class Batch:
    def __init__(self,a):
        self.a=a;self.plan=read(HERE/'plan.json');self.out=HERE/'results'/a.run_id
        self.out.mkdir(parents=True,exist_ok=False)
        self.state={'status':'running','stage':self.plan['stage'],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    'steps':[],'eligibility':{},'restoration':'not_needed','error':None}
        self.persist()
    def persist(self):save(self.out/'batch_status.json',self.state)
    def task(self,name,action,allow_failure=False,**kwargs):
        cfg={'package':str(HERE),'output':str(self.out/name),'device':self.a.device_id,'model_root':str(self.a.model_root.resolve()),
             'plan':str(HERE/'plan.json'),'runtime':str(self.out/'runtime.json'),'batch_root':str(self.out),**kwargs}
        request=self.out/'requests'/(name+'.json');save(request,cfg)
        log=self.out/'logs'/(name+'.log');log.parent.mkdir(exist_ok=True)
        step={'name':name,'action':action,'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        self.state['steps'].append(step);self.persist();print('START',name,flush=True)
        with log.open('x',encoding='utf-8') as stream:
            process=subprocess.Popen([sys.executable,'-u',str(HERE/'workers.py'),action,str(request)],stdout=stream,stderr=subprocess.STDOUT,
                                     stdin=subprocess.DEVNULL,cwd=HERE,start_new_session=True,env=dict(os.environ,PYTHONPATH=str(HERE/'harness'),PYTHONUNBUFFERED='1'))
            start=time.monotonic()
            try:
                while process.poll() is None:
                    if time.monotonic()-start>self.a.timeout:raise TimeoutError(name)
                    time.sleep(1)
            except BaseException:
                try:os.killpg(process.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    try:os.killpg(process.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    process.wait()
                step['status']='interrupted';self.persist();raise
        step.update(status='completed' if process.returncode==0 else 'failed',returncode=process.returncode,
                    seconds=round(time.monotonic()-start,2));self.persist();print(step['status'].upper(),name,flush=True)
        if process.returncode and not allow_failure:raise RuntimeError('Review step '+name+' in '+str(log))
        return Path(cfg['output']) if process.returncode==0 else None
    def build(self,row):
        self.state['restoration']='required';self.persist()
        name='build_'+row['candidate_id']
        result=self.task(name,'build',allow_failure=True,candidate=row['candidate_id'])
        if result is None:
            self.state['eligibility'][row['candidate_id']]={'eligible':False,'stage':'build_failed'};self.persist();return None
        result=self.task('benchmark_'+row['candidate_id'],'benchmark',allow_failure=True,candidate=row['candidate_id'],receipt=str(result/'receipt.json'))
        if result is None:return None
        report=read(result/'precision_status.json')
        if not report['full_correct']:
            self.state['eligibility'][row['candidate_id']]={'stage':'original_benchmark','eligible':False,'details':report};self.persist();return None
        return self.out/name/'receipt.json'
    def install(self,row,receipt,tag):
        self.state['restoration']='required';self.persist()
        self.task('install_'+tag,'install',candidate=row['candidate_id'],receipt=str(receipt))
    def execute(self):
        self.task('preflight','preflight')
        self.task('backup','backup')
        if self.plan['stage']=='A':self.run_a()
        else:self.run_b()
    def run_a(self):
        native_dev=self.task('native_dev','clip',host='clip',mode='native',split='dev',capture=True)
        native_eval=None
        for scope in ('vision','text','both'):
            self.task('wrapper_'+scope,'clip',host='clip',mode='wrapper',scope=scope,split='dev',baseline=str(native_dev))
        for row in self.plan['candidates']:
            receipt=self.build(row)
            if receipt is None:continue
            cid=row['candidate_id'];self.install(row,receipt,cid)
            gate=self.task('gate_'+cid,'gate',host='clip',candidate=cid,receipt=str(receipt),captures=str(native_dev/'captures/gelu'))
            verdict=read(gate/'eligibility.json');self.state['eligibility'][cid]=verdict;self.persist()
            if not verdict['eligible']:continue
            if native_eval is None:native_eval=self.task('native_eval','clip',host='clip',mode='native',split='eval')
            for scope in ('vision','text','both'):
                dev=self.task('dev_'+scope+'_'+cid,'clip',host='clip',mode='candidate',scope=scope,candidate=cid,receipt=str(receipt),split='dev',baseline=str(native_dev),diagnostics=True)
                self.task('eval_'+scope+'_'+cid,'clip',host='clip',mode='candidate',scope=scope,candidate=cid,receipt=str(receipt),split='eval',baseline=str(native_eval))
                self.task('compare_'+scope+'_'+cid,'compare_clip',baseline=str(native_eval),actual=str(self.out/('eval_'+scope+'_'+cid)))
                for session in range(3):
                    self.task(f'timing_{session}_{scope}_{cid}','clip_timing',host='clip',mode='candidate',scope=scope,candidate=cid,receipt=str(receipt),session=session)
    def run_b(self):
        captures={};native={}
        for host in ('qwen3b','qwen7b','internvl','clip','quick_clip'):
            action='clip' if host in ('clip','quick_clip') else 'generative'
            native[host]=self.task('native_'+host,action,host=host,mode='native',split='dev',limit=11 if action=='clip' else 10,capture=True)
            captures[host]=native[host]/'captures'
            for op,host_list in self.plan['operator_hosts'].items():
                if host in host_list:
                    self.task('wrapper_'+host+'_'+op,action,host=host,operator=op,mode='wrapper',split='dev',limit=11 if action=='clip' else 10,baseline=str(native[host]))
            if action=='generative':
                self.task('docvqa_'+host,action,host=host,mode='native',dataset='docvqa',split='dev',limit=20)
        for row in self.plan['candidates']:
            receipt=self.build(row)
            if receipt is None:continue
            cid=row['candidate_id'];op=row['operator']
            for host in self.plan['operator_hosts'][op]:
                self.install(row,receipt,host+'_'+cid)
                gate=self.task('gate_'+host+'_'+cid,'gate',allow_failure=True,host=host,candidate=cid,receipt=str(receipt),captures=str(captures[host]/op))
                key=host+'/'+cid
                if gate is None:
                    self.task('health_after_'+host+'_'+cid,'health')
                    self.state['eligibility'][key]={'eligible':False,'stage':'candidate_execution_failure'};self.persist();continue
                verdict=read(gate/'eligibility.json');self.state['eligibility'][key]=verdict;self.persist()
                if verdict['eligible'] and cid in self.plan['pilot_representatives'][op]:
                    action='clip' if host in ('clip','quick_clip') else 'generative'
                    pilot=self.task('pilot_'+host+'_'+cid,action,allow_failure=True,host=host,mode='candidate',candidate=cid,receipt=str(receipt),split='dev',limit=5)
                    self.state['eligibility'][key]['integration_pilot']='completed' if pilot else 'failed_requires_review';self.persist()
                    if pilot is None:self.task('health_after_pilot_'+host+'_'+cid,'health')
    def finish(self):
        try:
            if self.state['restoration']=='required':
                self.task('restore_original_package','restore');self.state['restoration']='verified'
        except BaseException as e:
            self.state['restoration']='FAILED_requires_manual_review';self.state['error_restore']=repr(e);self.state['status']='stopped_requires_review'
        self.state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();self.persist()
        lines=['# 批次结果',f"状态：{self.state['status']}",f"包恢复：{self.state['restoration']}",'',
               'B包只作预检，不提供新增宿主的正式任务或速度结论。候选失败、未测和环境错误分别保留。',
               '完整张量和wheel留在云端；此返回包包括日志、配置、预测、排名和逐项状态。']
        (self.out/'SUMMARY.md').write_text('\n'.join(lines),encoding='utf-8')
        target=self.a.export_dir.resolve()/(self.a.run_id+'_results.zip');temporary=target.with_suffix('.zip.part')
        if target.exists() or temporary.exists():raise FileExistsError('Result archive exists')
        members={};omitted=[]
        for path in self.out.rglob('*'):
            if not path.is_file() or '_restore' in path.parts:continue
            if path.suffix not in ('.json','.jsonl','.md','.txt','.log'):continue
            if path.stat().st_size>100*1024*1024:omitted.append(str(path));continue
            members['batch/'+path.relative_to(self.out).as_posix()]=path
        for name in ('plan.json','PACKAGE_MANIFEST.json','run_cloud.py','workers.py','cloud_helpers.py','README.md'):
            members['provenance/'+name]=HERE/name
        with zipfile.ZipFile(temporary,'x',zipfile.ZIP_DEFLATED) as z:
            for name,path in members.items():z.write(path,name)
            z.writestr('EXPORT_MANIFEST.json',json.dumps({n:sha(p) for n,p in members.items()},indent=2));z.writestr('OMITTED.json',json.dumps(omitted))
        temporary.rename(target);print('BATCH_STATUS:',self.state['status'],'\nDOWNLOAD:',target,flush=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--model-root',type=Path,required=True);parser.add_argument('--export-dir',type=Path,required=True)
    parser.add_argument('--run-id',default='extension_'+read(HERE/'plan.json')['stage']+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+str(os.getpid()))
    parser.add_argument('--device-id',type=int,default=0);parser.add_argument('--timeout',type=int,default=14400)
    parser.add_argument('--background',action='store_true');parser.add_argument('--plan',action='store_true');a=parser.parse_args()
    if a.plan:print(json.dumps(stages(read(HERE/'plan.json')),ensure_ascii=False,indent=2));return
    if os.name!='posix':raise RuntimeError('Cloud execution requires Linux Ascend; no CPU fallback')
    verify_package();a.export_dir.mkdir(parents=True,exist_ok=True)
    if a.background:
        log=a.export_dir/(a.run_id+'.console.log')
        with log.open('x',encoding='utf-8') as f:
            cmd=[sys.executable,'-u',str(HERE/'run_cloud.py'),*[s for s in sys.argv[1:] if s!='--background']]
            if '--run-id' not in sys.argv:cmd+=['--run-id',a.run_id]
            child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,cwd=HERE)
        save(a.export_dir/(a.run_id+'.pid.json'),{'pid':child.pid,'script':str(HERE/'run_cloud.py'),'run_id':a.run_id,'stage':read(HERE/'plan.json')['stage']})
        print('BACKGROUND_PID:',child.pid,'\nLOG:',log,'\nDOWNLOAD_WHEN_FINISHED:',a.export_dir/(a.run_id+'_results.zip'));return
    import fcntl
    lockfiles=[Path('/mnt/workspace/.v3_transfer.lock'),Path('/mnt/workspace/v3_model_transfer/.transfer_batch.lock')]
    handles=[]
    try:
        for path in lockfiles:
            if not path.parent.exists():continue
            f=path.open('a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);handles.append(f)
        def stop(*unused):raise KeyboardInterrupt('Termination requested')
        signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
        batch=Batch(a)
        try:
            batch.execute();batch.state['status']='completed_with_candidate_records'
        except BaseException as e:
            batch.state['status']='stopped_requires_review';batch.state['error']=repr(e)
            (batch.out/'exception.txt').write_text(traceback.format_exc(),encoding='utf-8')
        finally:batch.finish()
    finally:
        for f in handles:f.close()
if __name__=='__main__':main()
