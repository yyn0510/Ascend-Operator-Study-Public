"""Portable runtime checks, explicit adapters and installed-package rollback."""
from contextlib import contextmanager
import csv
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile
from run_cloud import read,save,sha

HERE=Path(__file__).resolve().parent
SEED=20261018

def bootstrap(stage):
    """Install missing pinned helpers only; never replace Torch/torch_npu."""
    core={n:importlib.metadata.version(n) for n in ('torch','torch-npu')}
    required={'transformers':'4.51.3','accelerate':'1.6.0','safetensors':'0.8.0','tokenizers':'0.21.4',
              'huggingface-hub':'0.36.2','einops':'0.8.1','build':'1.2.2.post1','ninja':'1.11.1.4'}
    if stage=='B':required.update({'timm':'0.9.16','torchvision':'0.22.1','sentencepiece':'0.2.1','protobuf':'5.29.5'})
    missing=[]
    for name,version in required.items():
        try:installed=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:missing.append(name+'=='+version);continue
        if name in ('transformers','torchvision') and installed.split('+')[0]!=version:
            raise RuntimeError('Existing '+name+' differs; preserve environment and return result for review')
    if missing:subprocess.run([sys.executable,'-m','pip','install','--no-deps',*missing],check=True)
    # Remaining common dependencies may already be supplied by the CANN image.
    for package,module in [('regex','regex'),('requests','requests'),('PyYAML','yaml'),('packaging','packaging'),('tqdm','tqdm'),('psutil','psutil'),
                           ('pyproject-hooks==1.2.0','pyproject_hooks'),('wheel==0.45.1','wheel'),('attrs','attrs'),('decorator','decorator'),
                           ('cloudpickle','cloudpickle'),('ml-dtypes','ml_dtypes'),('ruamel.yaml==0.18.10','ruamel'),
                           ('scipy==1.15.3','scipy'),('pandas==2.2.3','pandas'),('python-dateutil==2.9.0.post0','dateutil'),
                           ('pytz==2025.2','pytz'),('tzdata==2025.2','tzdata'),('Pillow==12.2.0','PIL')]:
        if importlib.util.find_spec(module) is None:
            subprocess.run([sys.executable,'-m','pip','install','--no-deps',package],check=True)
    if core!={n:importlib.metadata.version(n) for n in core}:raise ValueError('Core environment changed')

def initialize(c):
    import torch,torch_npu
    from host import environment
    torch.set_num_threads(4);torch.manual_seed(SEED);torch.npu.set_device(c['device']);torch.npu.config.allow_internal_format=False
    env=environment(c['device'])
    runtime=read(c['runtime'])
    if env!=runtime['environment']:raise ValueError('Environment changed within batch')
    if sha(c['plan'])!=runtime['plan_sha256']:raise ValueError('Batch plan changed')
    if c.get('candidate'):
        from common import verify_loaded
        return verify_loaded(c['candidate'],candidate(c)['operator'],c['receipt'])
    return None

def candidate(c):
    rows=read(HERE/'harness/candidates.json')
    return next(r for r in rows if r['candidate_id']==c['candidate'])

def modelpath(c):
    plan=read(c['plan']);desc=plan['models'][c['host']]
    return Path(c['model_root'])/desc['folder']

def backup(c):
    import importlib.util
    out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    spec=importlib.util.find_spec('cann_bench')
    if spec is None:save(out/'backup.json',{'installed':False});return
    root=Path(spec.origin).parent.resolve()
    dist=importlib.metadata.distribution('cann-bench');meta=Path(dist._path)
    if Path(dist.locate_file('cann_bench/__init__.py')).resolve()!=root/'__init__.py':raise ValueError('Installed distribution and import path differ; stop before modifying packages')
    wheeltext=(meta/'WHEEL').read_text(encoding='utf-8')
    tag=next(s.split(':',1)[1].strip() for s in wheeltext.splitlines() if s.startswith('Tag:'))
    name='cann_bench-'+dist.version+'-'+tag+'.whl';wheel=out/name
    members={}
    for p in root.rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:members['cann_bench/'+p.relative_to(root).as_posix()]=p.read_bytes()
    for p in meta.iterdir():
        if p.is_file() and p.name!='RECORD':members[meta.name+'/'+p.name]=p.read_bytes()
    import base64
    buf=io.StringIO();writer=csv.writer(buf,lineterminator='\n')
    for name,data in members.items():writer.writerow([name,'sha256='+base64.urlsafe_b64encode(hashlib.sha256(data).digest()).decode().rstrip('='),len(data)])
    writer.writerow([meta.name+'/RECORD','','']);members[meta.name+'/RECORD']=buf.getvalue().encode()
    with zipfile.ZipFile(wheel,'x',zipfile.ZIP_DEFLATED) as z:
        for name,data in members.items():z.writestr(name,data)
    save(out/'backup.json',{'installed':True,'wheel':str(wheel),'wheel_sha256':sha(wheel),
                           'package_files':{n:hashlib.sha256(v).hexdigest() for n,v in members.items() if n.startswith('cann_bench/')}})

def restore(c):
    description=read(Path(c['batch_root'])/'backup/backup.json')
    if description['installed']:
        if sha(description['wheel'])!=description['wheel_sha256']:raise ValueError('Backup wheel changed')
        subprocess.run([sys.executable,'-m','pip','install','--force-reinstall','--no-deps',description['wheel']],check=True)
        probe="import importlib.util,json,hashlib,pathlib,sys; p=pathlib.Path(importlib.util.find_spec('cann_bench').origin).parent; d=json.load(open(sys.argv[1])); assert all(hashlib.sha256((p/pathlib.PurePosixPath(n).relative_to('cann_bench')).read_bytes()).hexdigest()==h for n,h in d['package_files'].items()); print('RESTORED_IDENTITY_VERIFIED')"
        subprocess.run([sys.executable,'-c',probe,str(Path(c['batch_root'])/'backup/backup.json')],check=True,cwd=c['output'])
    else:
        subprocess.run([sys.executable,'-m','pip','uninstall','-y','cann-bench'],check=True)
        subprocess.run([sys.executable,'-c',"import importlib.util; assert importlib.util.find_spec('cann_bench') is None"],check=True,cwd=c['output'])
    save(Path(c['output'])/'restoration.json',{'verified':True,'previously_installed':description['installed']})

def targets(model,host,operator):
    if operator=='foreach_norm':return []
    result=[]
    for name,module in model.named_modules():
        if operator=='gelu' and host in ('clip','quick_clip') and name.endswith('mlp.activation_fn'):result.append(name)
        elif operator=='sigmoid' and host=='quick_clip' and type(module).__name__=='QuickGELUActivation':result.append(name)
        elif operator=='gelu' and host.startswith('qwen') and name=='visual.merger.mlp.1':result.append(name)
        elif operator=='swi_glu' and host.startswith('qwen') and name.startswith('model.layers.') and hasattr(module,'gate_proj'):result.append(name)
        elif operator=='swi_glu' and host=='internvl' and name.startswith('language_model.model.layers.') and hasattr(module,'gate_up_proj'):result.append(name)
    if not result:raise ValueError('No reviewed targets for '+host+'/'+operator)
    return result

def core_values(module,x,host):
    import torch
    if host=='internvl':packed=module.gate_up_proj(x)
    else:packed=torch.cat((module.gate_proj(x),module.up_proj(x)),dim=-1)
    gate,up=packed.chunk(2,dim=-1)
    return packed,torch.nn.functional.silu(gate)*up

@contextmanager
def patch(model,c,operator,diagnostic=None,count=True):
    import torch
    from transformers.models.clip import modeling_clip
    from clip_adapter import rowwise_foreach_norm
    mode=c['mode'];host=c['host'];counts={};original=[]
    if mode=='native':yield counts;return
    fn=None
    if mode=='candidate':
        import cann_bench
        fn=getattr(cann_bench,operator)
    norm_original=modeling_clip._get_vector_norm
    try:
        if operator=='foreach_norm':
            def norm(x):
                if count:counts['rowwise_norm']=counts.get('rowwise_norm',0)+1
                return rowwise_foreach_norm(x,fn if fn else lambda xs,p:[norm_original(v).reshape(()) for v in xs])
            modeling_clip._get_vector_norm=norm
        else:
            names=targets(model,host,operator)
            if host in ('clip','quick_clip'):
                names=[n for n in names if c.get('scope','both')=='both' or n.startswith(c['scope']+'_model.')]
            modules=dict(model.named_modules())
            for name in names:
                module=modules[name];old=module.forward;inherited='forward' not in vars(module);original.append((module,old,inherited))
                def forward(x,_name=name,_module=module,_old=old):
                    if count:counts[_name]=counts.get(_name,0)+1
                    if operator=='gelu':value=fn(x,'tanh') if fn else _old(x)
                    elif operator=='sigmoid':value=x*(fn(1.702*x) if fn else torch.sigmoid(1.702*x))
                    else:
                        packed,native=core_values(_module,x,host)
                        value=_module.down_proj(fn(packed,-1) if fn else native)
                    if diagnostic is not None:diagnostic(_name,x,value,_old)
                    return value
                module.forward=forward
        yield counts
        if count and (not counts or any(v<=0 for v in counts.values())):raise ValueError('Target bypassed')
    finally:
        for module,old,inherited in original:
            if inherited:delattr(module,'forward')
            else:module.forward=old
        modeling_clip._get_vector_norm=norm_original

class Captures:
    def __init__(self,model,c):
        self.c=c;self.root=Path(c['output'])/'captures';self.records={};self.handles=[];self.saved=set();self.total=0
        host=c['host']
        ops=['sigmoid'] if host=='quick_clip' else ['gelu','foreach_norm'] if host=='clip' else ['swi_glu'] if host=='internvl' else ['gelu','swi_glu']
        self.modules={}
        for op in ops:
            if op=='foreach_norm':continue
            names=targets(model,host,op)
            if len(names)>3:
                if host=='clip' or host=='quick_clip':
                    names=[n for n in names if any(f'.layers.{i}.' in n for i in (0,6,11))]
                else:names=[names[0],names[len(names)//2],names[-1]]
            for name in names:
                module=dict(model.named_modules())[name]
                self.handles.append(module.register_forward_hook(lambda m,a,y,op=op,name=name:self.capture(op,name,m,a[0],y)))
        self.norm_original=None
        if 'foreach_norm' in ops:
            from transformers.models.clip import modeling_clip
            self.norm_original=modeling_clip._get_vector_norm
            def norm(x):
                value=self.norm_original(x);self.capture('foreach_norm','rowwise_norm',None,x,value);return value
            modeling_clip._get_vector_norm=norm
    def capture(self,op,name,module,x,y):
        import torch
        phase='decode' if op=='swi_glu' and x.shape[-2]==1 else 'prefill'
        # First three norm batch occurrences include both modalities; retain rows separately.
        key=(op,name,phase) if op=='swi_glu' else (op,name,tuple(x.shape))
        if key in self.saved:return
        if op=='foreach_norm' and len(self.records.get(op,[]))>=6:return
        if op=='gelu' and self.c['host'].startswith('qwen') and len(self.records.get(op,[]))>=3:return
        if op=='swi_glu':
            x,ref=core_values(module,x,self.c['host'])
            from completion_utils import metrics
            if not metrics(module.down_proj(ref),y)['exact_equal']:raise ValueError('Captured projection replay differs from actual MLP output')
        elif op=='sigmoid':
            parent=x;ref=torch.sigmoid(1.702*x);x=1.702*x
            if not torch.equal(parent*ref,y):raise ValueError('QuickGELU decomposition control differs')
        else:ref=y
        blob={'input':x.detach().cpu(),'reference':ref.detach().cpu()}
        if op=='sigmoid':blob.update(parent_input=parent.detach().cpu(),parent_reference=y.detach().cpu())
        size=sum(v.numel()*v.element_size() for v in blob.values())
        if self.total+size>536870912:raise ValueError('Capture budget exceeded; review instead of silently dropping input classes')
        self.total+=size;self.saved.add(key)
        folder=self.root/op;folder.mkdir(parents=True,exist_ok=True);filename=f'{len(self.records.get(op,[])):04d}.pt'
        torch.save(blob,folder/filename)
        self.records.setdefault(op,[]).append({'file':filename,'sha256':sha(folder/filename),'module':name,'shape':list(x.shape),'dtype':str(x.dtype),'phase':phase})
    def close(self):
        for h in self.handles:h.remove()
        if self.norm_original is not None:
            from transformers.models.clip import modeling_clip
            modeling_clip._get_vector_norm=self.norm_original
        for op,rows in self.records.items():save(self.root/op/'index.json',{'records':rows,'bytes_total_all_ops':self.total,
                'host':self.c['host'],'mode':self.c['mode'],'plan_sha256':sha(self.c['plan']),'runtime_sha256':sha(self.c['runtime'])})
