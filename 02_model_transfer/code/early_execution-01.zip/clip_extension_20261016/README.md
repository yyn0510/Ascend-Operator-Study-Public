# OpenCLIP一键可行性批次

这是第一阶段，不计算正式检索成绩，不做性能测量。使用云端既有AI2D dev中12个不同图像组和原问题文本，校准新宿主的真实输入。

自动执行：环境与权重核验→原生捕获→原生重复及GELU/范数包装对照→四个原生成候选分别构建、安装、20例原基准复核→真实输入准入→合格候选的12图像模型输出对比。两份GELU与两份ForeachNorm独立运行，不组合替换，不改生成代码，不自动选择备选。

无需安装新依赖或升级环境。要求原/mnt/workspace/v3_model_transfer和auto_formal_001仍在；它们只读取，复用旧锁防止同时安装同名wheel。所有新构建和张量留在独立results/auto_clip_screen_001目录。

主程序：python /mnt/workspace/v3_clip_extension/run_extension_batch.py --background

日志：/mnt/workspace/v3_model_transfer/results/auto_clip_screen_001.console.log

完成或异常后下载：/mnt/workspace/gitCode/cann/cann-learning-hub/build/auto_clip_screen_001_results.zip

候选不准入会记录并跳过，不自动放宽阈值；原生、环境或包装对照异常则立即停止。请返回结果包，不覆盖原目录重跑。原基准使用--no-perf，其评分0警告不代表精度未通过，以20例精度结果为准。

返回包不含模型权重、图片、捕获张量或wheel，这些留在云端完整目录。weights另包上传，不放入实验脚本包。CPU本地检查不能替代NPU准入。
