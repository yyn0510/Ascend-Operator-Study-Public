"""Compare captured native outputs to one installed candidate on NPU."""
import argparse
import json
from pathlib import Path
from run_npu import environment,save

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--inputs',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--operator',choices=['gelu','swi_glu'],required=True)
    p.add_argument('--candidate-id',required=True)
    p.add_argument('--rtol',type=float,required=True)
    p.add_argument('--atol',type=float,required=True)
    p.add_argument('--approximate',choices=['none','tanh'],default='none')
    a=p.parse_args()
    if a.atol<0 or a.rtol<0: raise ValueError('Negative tolerance')
    if a.output.exists(): raise FileExistsError(a.output)
    a.output.mkdir(parents=True)
    save(a.output/'environment.json',environment())
    import torch,cann_bench
    files=sorted(a.inputs.glob('*.pt'))
    if not files: raise ValueError('No captured inputs')
    results=[]
    with torch.inference_mode():
        for f in files:
            row={'input':f.name,'passed':False}
            try:
                data=torch.load(f,map_location='cpu',weights_only=True)
                if data['operator']!=a.operator: raise ValueError('Captured operator mismatch')
                xs=[x.to('npu:0') for x in data['inputs']]
                ref=data['reference'].to('npu:0')
                if a.operator=='gelu': y=cann_bench.gelu(xs[0],a.approximate)
                else: y=cann_bench.swi_glu(torch.cat(xs,dim=-1),-1)
                torch.npu.synchronize()
                if y.shape!=ref.shape or y.dtype!=ref.dtype: raise ValueError('Shape/dtype mismatch')
                x,yc=ref.cpu().float(),y.cpu().float()
                special=bool(torch.equal(torch.isnan(x),torch.isnan(yc)) and
                    torch.equal(torch.isposinf(x),torch.isposinf(yc)) and torch.equal(torch.isneginf(x),torch.isneginf(yc)))
                finite=torch.isfinite(x)&torch.isfinite(yc)
                diff=(x[finite]-yc[finite]).abs()
                relative=diff/x[finite].abs().clamp_min(1e-12)
                row.update(module=data['module'],shape=list(ref.shape),dtype=str(ref.dtype),
                    max_abs=float(diff.max()) if diff.numel() else 0.,mean_abs=float(diff.mean()) if diff.numel() else 0.,
                    max_relative=float(relative.max()) if relative.numel() else 0.,special_values_match=special,
                    passed=special and bool(torch.allclose(x,yc,rtol=a.rtol,atol=a.atol,equal_nan=True)))
            except Exception as e: row['error']=f'{type(e).__name__}: {e}'
            results.append(row)
    save(a.output/'replay.json',{'candidate_id':a.candidate_id,'rtol':a.rtol,'atol':a.atol,
         'passed':sum(r['passed'] for r in results),'total':len(results),'inputs':results})
    if not all(r['passed'] for r in results): raise SystemExit(2)

if __name__=='__main__': main()
