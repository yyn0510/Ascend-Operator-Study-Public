"""NPU-only experiment runner, prepared offline; requires server validation."""
import argparse
import importlib.metadata
import json
import platform
import re
import time
import types
from pathlib import Path

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def environment():
    info = {'python': platform.python_version(), 'platform': platform.platform()}
    for package in ['torch', 'torch-npu', 'transformers', 'Pillow']:
        try: info[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError: info[package] = None
    import torch
    import torch_npu  # registers torch.npu
    if not torch.npu.is_available():
        raise RuntimeError('Ascend NPU unavailable; CPU execution is not a deployment result')
    info['device'] = torch.npu.get_device_name(0)
    info['device_count'] = torch.npu.device_count()
    return info

def targets(model, op):
    named = dict(model.named_modules())
    if op == 'gelu':
        paths = [n for n,m in named.items() if n.endswith('visual.merger.mlp.1') and type(m).__name__ == 'GELU']
    else:
        paths = [n for n,m in named.items() if type(m).__name__ == 'Qwen2MLP'
                 and all(hasattr(m,a) for a in ('gate_proj','up_proj','down_proj','act_fn'))]
    if not paths:
        raise RuntimeError(f'No verified {op} targets; inspect installed model implementation')
    return paths

def install(model, op, mode, capture, limit):
    import torch
    kernel = None
    if mode == 'candidate':
        import cann_bench
        kernel = getattr(cann_bench, op)  # no fallback
    named = dict(model.named_modules())
    paths = targets(model, op)
    counters = {n:0 for n in paths}
    saved = [0]
    def record(name, inputs, output):
        if capture and saved[0] < limit:
            save_idx = saved[0]; saved[0] += 1
            torch.save({'module':name,'operator':op,'inputs':[x.detach().cpu() for x in inputs],
                        'reference':output.detach().cpu()}, capture/f'{save_idx:04d}.pt')
    for name in paths:
        module = named[name]
        if op == 'gelu':
            old = module.forward
            approximate = module.approximate
            def forward(self,x,_name=name,_old=old,_approx=approximate):
                counters[_name] += 1
                y = kernel(x,_approx) if mode=='candidate' else _old(x)
                record(_name,[x],y)
                return y
        else:
            activation_name = type(module.act_fn).__name__.lower()
            if 'silu' not in activation_name:
                raise RuntimeError(f'{name}: expected SiLU, got {activation_name}')
            def forward(self,x,_name=name):
                counters[_name] += 1
                gate,up = self.gate_proj(x), self.up_proj(x)
                if mode=='baseline':
                    y = self.act_fn(gate)*up
                else:
                    packed = torch.cat((gate,up),dim=-1)
                    if mode=='candidate': y = kernel(packed,-1)
                    else:
                        a,b = packed.chunk(2,dim=-1)
                        y = self.act_fn(a)*b
                record(_name,[gate,up],y)
                return self.down_proj(y)
        module.forward = types.MethodType(forward,module)
    return paths,counters

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--model-path',type=Path)
    p.add_argument('--samples',type=Path)
    p.add_argument('--split',choices=['dev','eval'],default='dev')
    p.add_argument('--operator',choices=['gelu','swi_glu'],default='gelu')
    p.add_argument('--mode',choices=['baseline','wrapper','candidate'],default='baseline')
    p.add_argument('--candidate-id')
    p.add_argument('--capture',action='store_true')
    p.add_argument('--capture-limit',type=int,default=20)
    p.add_argument('--max-new-tokens',type=int,default=16)
    p.add_argument('--environment-only',action='store_true')
    args=p.parse_args()
    if args.output.exists(): raise FileExistsError(args.output)
    args.output.mkdir(parents=True)
    try:
        env=environment(); save(args.output/'environment.json',env)
        if args.environment_only: return
        if not args.model_path or not args.samples: raise ValueError('Need local model path and sample JSONL')
        if args.mode=='candidate':
            manifest=Path(__file__).parent/'candidates.json'
            if not manifest.exists(): raise ValueError('Run from the exported bundle containing candidates.json')
            selected=[r for r in json.loads(manifest.read_text(encoding='utf-8')) if r['candidate_id']==args.candidate_id]
            if len(selected)!=1 or selected[0]['operator']!=args.operator:
                raise ValueError('Candidate ID/operator mismatch')
            import cann_bench
            import hashlib
            binary=Path(cann_bench._C.__file__)
            save(args.output/'loaded_candidate.json',{'selection':selected[0], 'binary':str(binary),
                'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
                'note':'Binary hash recorded; install the matching isolated build before this run.'})
        if args.capture and (args.split!='dev' or args.mode!='baseline'):
            raise ValueError('Capture only baseline/dev, outside performance measurement')
        import torch
        from PIL import Image
        from transformers import AutoProcessor,Qwen2_5_VLForConditionalGeneration
        torch.manual_seed(20261014)
        model=Qwen2_5_VLForConditionalGeneration.from_pretrained(str(args.model_path),
              torch_dtype=torch.bfloat16,attn_implementation='eager',local_files_only=True).to('npu:0').eval()
        processor=AutoProcessor.from_pretrained(str(args.model_path),local_files_only=True)
        capture=args.output/'inputs' if args.capture else None
        if capture: capture.mkdir()
        paths,counters=install(model,args.operator,args.mode,capture,args.capture_limit)
        save(args.output/'configuration.json',{'arguments':{k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()},
             'targets':paths,'model_config':model.config.to_dict(),'measurement':'quality only; timings include hooks and are diagnostic'})
        seen=set(); rows=[]
        for line in args.samples.read_text(encoding='utf-8').splitlines():
            if not line.strip(): continue
            r=json.loads(line)
            if r['id'] in seen: raise ValueError('Duplicate sample ID')
            seen.add(r['id'])
            if r['split']==args.split: rows.append(r)
        if not rows: raise ValueError('No selected samples')
        with (args.output/'predictions.jsonl').open('x',encoding='utf-8') as f:
            for r in rows:
                result={'id':r['id'],'answer':r['answer'],'status':'failed'}
                try:
                    img=Path(r['image'])
                    if not img.is_absolute(): img=args.samples.parent/img
                    with Image.open(img) as image:
                        prompt=r['question']+'\n'+'\n'.join(f'{chr(65+i)}. {x}' for i,x in enumerate(r['choices']))+'\nAnswer with one option letter only.'
                        messages=[{'role':'user','content':[{'type':'image'},{'type':'text','text':prompt}]}]
                        text=processor.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
                        inputs=processor(text=[text],images=[image.convert('RGB')],return_tensors='pt').to('npu:0')
                    torch.npu.synchronize(); start=time.perf_counter()
                    with torch.inference_mode():
                        generated=model.generate(**inputs,max_new_tokens=args.max_new_tokens,do_sample=False)
                    torch.npu.synchronize()
                    result['diagnostic_seconds']=time.perf_counter()-start
                    text=processor.batch_decode(generated[:,inputs.input_ids.shape[1]:],skip_special_tokens=True)[0].strip()
                    match=re.fullmatch(r'([A-Z])[.。]?',text)
                    prediction=match.group(1) if match and match.group(1) in [chr(65+i) for i in range(len(r['choices']))] else None
                    result.update(status='success',text=text,prediction=prediction,correct=prediction==r['answer'])
                except Exception as exc:
                    result['error']=f'{type(exc).__name__}: {exc}'
                f.write(json.dumps(result,ensure_ascii=False)+'\n'); f.flush()
        save(args.output/'calls.json',counters)
        if not sum(counters.values()): raise RuntimeError('Target kernels were never called')
        save(args.output/'status.json',{'status':'completed','note':'See per-sample failures; completion is not correctness certification'})
    except Exception as exc:
        save(args.output/'status.json',{'status':'failed','error':f'{type(exc).__name__}: {exc}'})
        raise

if __name__=='__main__': main()
