# V3 真实模型验证：本地准备包

目标：IJCV。范围：Qwen2.5-VL-3B-Instruct，GELU/SwiGLU各两份候选。原始V3归档和公共脚手架不修改。

## 已准备与待验证

| 内容 | 状态 |
|---|---|
| 四份候选来源与20个源码文件哈希 | 本地可核查 |
| 四个独立构建工程、可上传ZIP | 本地可生成 |
| 指定位置替换、输入采集、数值回放、质量结果记录 | 脚本已准备，NPU行为未验证 |
| 预测评分和配对统计 | 本地可验证；正式数据协议未冻结 |
| 权重、AI2D图像与答案、环境配置 | 待平台可用后准备 |
| 性能脚本、算子/模块/整模型重复计时 | 下一步准备；当前诊断耗时不能用于论文性能结论 |

固定的源码依据是 Transformers v4.51.3：视觉 `visual.merger.mlp.1` 的GELU，以及语言侧 `Qwen2MLP` 的门控计算。脚本按名字和结构检查目标，找不到即报错。服务器实际依赖版本先核对；版本改变时必须重新检查目标实现，不能直接假设兼容。

## 本地使用

在本目录执行：

```powershell
python prepare.py
python prepare.py --export bundle_20261014
```

导出目录存在时拒绝覆盖。导出包包含四个独立工程和候选来源。每个工程仅注册一个候选，不能同时加载同名算子的多个版本。每次换候选要安装对应构建，并启动新Python进程；保存构建日志、wheel哈希和已加载二进制哈希。

包内源代码保留原始实现。公共构建文件来自现有脚手架的独立副本，shell换行为LF；未验证实际SoC和编译器映射，不能称为已经适配CANNLab。

## 数据输入约定

AI2D下载/转换脚本尚未准备。先核对数据许可证、公开划分和原任务协议，再生成UTF-8 JSONL，每行：

```json
{"id":"ai2d_example_id","split":"dev","image":"images/example.png","question":"Question text","choices":["choice 1","choice 2","choice 3","choice 4"],"answer":"B"}
```

这是格式说明，不是真实样例。image相对JSONL所在目录解析；answer统一转换为A/B/C等选项字母，不能把原始数值索引不经检查直接写入。dev与eval共享清单时ID必须唯一，并检查图像/原题来源无重叠。只靠不同ID不能证明无数据泄漏。

本地检查数据：`python prepare.py --samples samples.jsonl`。它检查必要字段、答案范围、重复ID及图片是否存在，无法确认答案本身正确。

## 后续在CANNLab的执行入口

以下是待环境确认后使用的入口，不需要现在执行。权重必须事先下载到服务器本地，不在脚本中自动联网。

```bash
python run_npu.py --environment-only --output results/env
# 在指定候选的 projects/<candidate_id> 中，核对SoC后构建：
bash build.sh --install
python run_npu.py --model-path /path/to/Qwen2.5-VL-3B-Instruct --samples samples.jsonl --split dev --operator gelu --mode baseline --capture --output results/gelu_dev
```

SwiGLU同样先采集原模型dev输入。每个张量文件保存原始输入与宿主原计算结果；GELU保存激活输入，SwiGLU保存gate/up两路投影输出。默认最多保存20次调用，用于最小闭环，后续按真实输入分布调整采集范围，不把它当作充分覆盖。

安装候选后做回放：

```bash
python replay_npu.py --inputs results/gelu_dev/inputs --operator gelu --candidate-id Grok_4_6_gelu_001_R4 --rtol <开发阶段固定值> --atol <开发阶段固定值> --output results/gelu_replay
```

误差门槛没有预设为任意通用值，必须根据宿主语义与开发检查确定。`candidate-id`用于记录来源，数值回放前需要确认所安装包对应这份源码。

真实输入验证通过后跑质量评估：

```bash
python run_npu.py --model-path /path/to/model --samples samples.jsonl --split eval --operator gelu --mode baseline --output results/gelu_baseline
python run_npu.py --model-path /path/to/model --samples samples.jsonl --split eval --operator gelu --mode wrapper --output results/gelu_wrapper
python run_npu.py --model-path /path/to/model --samples samples.jsonl --split eval --operator gelu --mode candidate --candidate-id Grok_4_6_gelu_001_R4 --output results/gelu_grok
python score.py --baseline results/gelu_baseline/predictions.jsonl --candidate results/gelu_grok/predictions.jsonl --output results/gelu_comparison.json
```

所有结果目录拒绝覆盖。每次模型运行从头加载权重，候选错误不会回退到原算子。SwiGLU参考包装使用同样的拼接/切分和宿主原激活，生成实现与宿主的内部升精度差异由数值回放检查。包装模式用于解释适配影响，不是另一个生成候选。

质量入口采用固定选择题提示、贪心解码、严格字母解析；失败和无效答案保留分母。这是准备中的协议，不声称等同于官方AI2D或其他框架分数。正式运行前以dev确认答案映射和解析规则，冻结后统一执行。

当前输出的`diagnostic_seconds`包含Python计数钩子；采集运行还包含CPU拷贝。它只能诊断运行，不能当作NPU性能测试。性能评估必须关闭采集/诊断、预热并按固定工作负载重复测量，后续单独实现。

相关方案：[V3为主体的讨论版](../../文档/实验方案/V3为主体的补充实验方案-讨论版.md)。
