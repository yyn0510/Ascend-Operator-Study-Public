"""Strict option-letter quality and paired bootstrap; no NPU dependency."""
import argparse
import json
import random
from pathlib import Path

def read(path):
    rows=[json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
    ids=[r['id'] for r in rows]
    if not rows or len(set(ids))!=len(ids): raise ValueError('Empty/duplicate predictions')
    return {r['id']:r for r in rows}

def compare(baseline,candidate):
    if baseline.keys()!=candidate.keys(): raise ValueError('Paired samples must match exactly')
    ids=sorted(baseline)
    for i in ids:
        if baseline[i]['answer']!=candidate[i]['answer']: raise ValueError('Ground-truth mismatch')
    def correct(r):
        return int(r['status']=='success' and r.get('prediction')==r['answer'])
    diff=[correct(candidate[i])-correct(baseline[i]) for i in ids]
    rng=random.Random(20261014)
    boot=sorted(sum(rng.choices(diff,k=len(diff)))/len(diff) for _ in range(2000))
    return {'samples':len(ids),'baseline_accuracy':sum(correct(r) for r in baseline.values())/len(ids),
      'candidate_accuracy':sum(correct(r) for r in candidate.values())/len(ids),
      'accuracy_difference':sum(diff)/len(diff),'paired_bootstrap_95pct':[boot[49],boot[1949]],
      'answer_flip_fraction':sum(baseline[i].get('prediction')!=candidate[i].get('prediction') for i in ids)/len(ids),
      'candidate_failed':sum(r['status']!='success' for r in candidate.values()),
      'candidate_invalid_answer':sum(r['status']=='success' and r.get('prediction') is None for r in candidate.values())}

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--candidate',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    result=compare(read(a.baseline),read(a.candidate))
    with a.output.open('x',encoding='utf-8') as f: json.dump(result,f,ensure_ascii=False,indent=2)
    print(json.dumps(result,ensure_ascii=False))
