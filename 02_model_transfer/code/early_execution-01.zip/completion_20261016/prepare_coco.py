"""Prepare an immutable COCO2017-val 100-dev/1000-eval retrieval subset."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import time
import urllib.request
import zipfile

BASE='https://s3.amazonaws.com/images.cocodataset.org/'
SEED=20261016

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');tmp.replace(path)

def download(url,path):
    path=Path(path)
    if path.is_file():return
    path.parent.mkdir(parents=True,exist_ok=True)
    part=path.with_suffix(path.suffix+'.part')
    for attempt in range(5):
        try:
            offset=part.stat().st_size if part.exists() else 0
            req=urllib.request.Request(url,headers={'User-Agent':'CANN-Bench-research','Range':f'bytes={offset}-'} if offset else {'User-Agent':'CANN-Bench-research'})
            with urllib.request.urlopen(req,timeout=90) as r:
                append=offset>0 and r.status==206
                if append and not r.headers.get('Content-Range','').startswith(f'bytes {offset}-'):raise ValueError('Invalid range response')
                expected=r.headers.get('Content-Length');count=0
                with part.open('ab' if append else 'wb') as f:
                    for b in iter(lambda:r.read(1024*1024),b''):f.write(b);count+=len(b)
                if expected and count!=int(expected):raise IOError('Truncated download')
            part.replace(path);return
        except Exception:
            if attempt==4:raise
            time.sleep(min(2**attempt,15))

def select(annotation):
    by={}
    for a in annotation['annotations']:by.setdefault(a['image_id'],[]).append({'id':a['id'],'text':a['caption']})
    images={r['id']:r for r in annotation['images']}
    if len(images)!=5000 or set(images)!=set(by):raise ValueError('Expected official 5000-image COCO2017 validation annotations')
    if any(len(by[i])<5 for i in images):raise ValueError('Expected at least five captions per image')
    ids=sorted(images,key=lambda i:hashlib.sha256(f'cann-transfer-coco:{SEED}:{i}'.encode()).hexdigest())[:1100]
    return [{'image_id':i,'split':'dev' if n<100 else 'eval','image':'images/'+images[i]['file_name'],'captions':sorted(by[i],key=lambda a:a['id'])} for n,i in enumerate(ids)]

def verify(root):
    root=Path(root);m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
    if sha(root/'samples.json')!=m['samples_sha256']:raise ValueError('COCO sample manifest changed')
    rows=json.loads((root/'samples.json').read_text(encoding='utf-8'))
    if len(rows)!=1100 or {s:sum(r['split']==s for r in rows) for s in ('dev','eval')}!={'dev':100,'eval':1000}:raise ValueError('Wrong COCO split counts')
    if len({r['image_id'] for r in rows})!=1100 or len({r['image_sha256'] for r in rows})!=1100:raise ValueError('Repeated COCO image identity')
    for r in rows:
        p=(root/r['image']).resolve()
        if not p.is_relative_to(root.resolve()) or sha(p)!=r['image_sha256'] or len(r['captions'])<5:raise ValueError('COCO data integrity failed')
    return m

def prepare(root):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    if (root/'manifest.json').exists():return verify(root)
    archive=root/'cache/annotations_trainval2017.zip';print('DOWNLOAD official COCO annotations (253 MB)',flush=True)
    download(BASE+'annotations/annotations_trainval2017.zip',archive)
    with zipfile.ZipFile(archive) as z:data=z.read('annotations/captions_val2017.json')
    annotation=json.loads(data);rows=select(annotation)
    def one(row):
        p=root/row['image'];download(BASE+'val2017/'+p.name,p)
        from PIL import Image
        with Image.open(p) as im:im.verify()
        return {**row,'image_sha256':sha(p),'source_url':BASE+'val2017/'+p.name}
    completed=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        for n,row in enumerate(pool.map(one,rows),1):
            completed.append(row)
            if n%50==0:print(f'COCO IMAGES {n}/1100',flush=True)
    save(root/'samples.json',completed)
    manifest={'source':'COCO2017 validation; all original captions (at least five per image)','source_page':'https://cocodataset.org/#download','annotation_url':BASE+'annotations/annotations_trainval2017.zip','annotation_archive_sha256':sha(archive),'captions_val2017_sha256':hashlib.sha256(data).hexdigest(),'selection_seed':SEED,'selection':'SHA256(cann-transfer-coco:seed:image_id), ascending; first100 dev, next1000 eval; no outcome selection','samples_sha256':sha(root/'samples.json'),'dev_images':100,'dev_captions':sum(len(r['captions']) for r in rows if r['split']=='dev'),'eval_images':1000,'eval_captions':sum(len(r['captions']) for r in rows if r['split']=='eval'),'note':'Fixed internal 1000-image retrieval subset, not official full-5000 or Karpathy test protocol; pretrained data contamination not assessed'}
    save(root/'manifest.json',manifest);return verify(root)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();print(json.dumps(prepare(a.output),indent=2))
