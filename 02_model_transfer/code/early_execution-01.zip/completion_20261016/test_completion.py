"""Offline tests of retrieval protocol, actual HF adapter routes and export safety."""
import contextlib
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from completion_utils import retrieval,retrieval_pair,metrics,timings_summary,sha,save,read
from completion_workers import clip_patch,validate_calls,clip_batches
from prepare_coco import select

class RetrievalTests(unittest.TestCase):
    def test_perfect_unequal_corpus(self):
        import numpy as np
        a=np.eye(3,dtype=np.float32);b=np.repeat(a,5,axis=0)
        rows,summary=retrieval(a,b,[10,11,12],list(range(15)),[10]*5+[11]*5+[12]*5)
        self.assertEqual(len(rows),18)
        self.assertTrue(all(v==1 for d in summary.values() for v in d.values()))
        result=retrieval_pair(rows,rows,replicates=100)
        self.assertEqual(result['text_to_image']['queries'],15)
        self.assertEqual(result['text_to_image']['image_groups'],3)
        self.assertEqual(result['image_to_text']['recall']['R@1']['paired_image_group_bootstrap_95pct_pp'],[0.,0.])
    def test_ties_and_zero_recall(self):
        import numpy as np
        a=np.array([[1.,0.],[0.,1.]],dtype=np.float32)
        rank,summary=retrieval(a,a[::-1],[2,3],[99,98],[2,3])
        self.assertEqual(summary['image_to_text']['R@1'],0.)
        rank,_=retrieval(np.ones((2,2)),np.ones((2,2)),[2,3],[99,98],[2,3])
        self.assertEqual(rank[0]['top10'],[99,98]);self.assertEqual(rank[1]['rank'],2)
    def test_identity_mismatch(self):
        import numpy as np
        with self.assertRaises(ValueError):retrieval(np.eye(2),np.eye(2),[1,1],[3,4],[1,1])
        with self.assertRaises(ValueError):retrieval_pair([{'direction':'a','query_id':1}],[{'direction':'a','query_id':2}],100)
    def test_nonfinite(self):
        import torch,numpy as np
        with self.assertRaises(ValueError):metrics(torch.tensor([float('nan')]),torch.ones(1))
        with self.assertRaises(ValueError):retrieval(np.array([[float('inf')]]),np.ones((1,1)),[1],[1],[1])
    def test_expected_denominator(self):
        import torch
        self.assertFalse(metrics(torch.tensor([1.0162]),torch.tensor([1.]))['passed'])
        self.assertTrue(metrics(torch.tensor([1.015]),torch.tensor([1.]))['passed'])
    def test_timing_blocks(self):
        rs=[{'workload':'a','phase':'x','mode':mode,'milliseconds_per_call':v} for mode,v in [('native',2.),('wrapper',3.),('candidate',1.)] for _ in range(3)]
        report=timings_summary(rs);self.assertEqual(report['aggregate'][1]['geometric_mean_speedup'],2.)
        with self.assertRaises(ValueError):timings_summary(rs[:-1])

class AdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import torch
        from transformers import CLIPModel,CLIPConfig
        torch.set_num_threads(2);torch.manual_seed(11)
        cfg=CLIPConfig(text_config={'vocab_size':32,'hidden_size':32,'intermediate_size':64,'num_hidden_layers':12,'num_attention_heads':4,'max_position_embeddings':77,'hidden_act':'gelu','eos_token_id':2,'pad_token_id':0},vision_config={'hidden_size':32,'intermediate_size':64,'num_hidden_layers':12,'num_attention_heads':4,'image_size':32,'patch_size':16,'hidden_act':'gelu'},projection_dim=16)
        cls.model=CLIPModel(cfg).eval();cls.inp={'input_ids':torch.randint(3,32,(5,9)),'attention_mask':torch.ones(5,9,dtype=torch.long),'pixel_values':torch.randn(2,3,32,32)}
    def test_actual_forward_unequal_norm_and_restore(self):
        import torch
        from transformers.models.clip import modeling_clip
        original=modeling_clip._get_vector_norm
        with torch.inference_mode():
            baseline=self.model(**self.inp)
            with clip_patch(self.model,{'mode':'wrapper','operator':'foreach_norm'}) as calls:actual=self.model(**self.inp)
        validate_calls({'mode':'wrapper','operator':'foreach_norm'},calls,1)
        self.assertEqual([r['shape'][0] for r in calls['norm']],[2,5])
        self.assertIs(modeling_clip._get_vector_norm,original)
        self.assertTrue(torch.equal(actual.image_embeds,baseline.image_embeds));self.assertTrue(torch.equal(actual.text_embeds,baseline.text_embeds))
    def test_candidate_gelu_uses_tanh_all24_layers(self):
        import torch
        from transformers.models.clip.modeling_clip import CLIPMLP
        seen=[];fake=types.ModuleType('cann_bench')
        def gelu(x,mode):seen.append(mode);return torch.nn.functional.gelu(x,approximate=mode)
        fake.gelu=gelu
        originals=[m.activation_fn for m in self.model.modules() if isinstance(m,CLIPMLP)]
        with patch.dict(sys.modules,{'cann_bench':fake}),torch.inference_mode(),clip_patch(self.model,{'mode':'candidate','operator':'gelu'}) as calls:self.model(**self.inp)
        validate_calls({'mode':'candidate','operator':'gelu'},calls,1)
        self.assertEqual(seen,['tanh']*24)
        self.assertEqual(originals,[m.activation_fn for m in self.model.modules() if isinstance(m,CLIPMLP)])
    def test_candidate_norm_forward_and_no_timed_logging(self):
        import torch
        fake=types.ModuleType('cann_bench');lengths=[]
        def norm(xs,p):lengths.append(len(xs));return [torch.linalg.vector_norm(v,ord=p) for v in xs]
        fake.foreach_norm=norm
        with patch.dict(sys.modules,{'cann_bench':fake}),torch.inference_mode(),clip_patch(self.model,{'mode':'candidate','operator':'foreach_norm'},counters=False) as calls:
            output=self.model(**self.inp)
        self.assertEqual(lengths,[2,5]);self.assertEqual(calls['norm'],[]);self.assertEqual(list(output.logits_per_image.shape),[2,5])
    def test_restore_after_exception(self):
        from transformers.models.clip import modeling_clip
        orig=modeling_clip._get_vector_norm
        with self.assertRaises(RuntimeError):
            with clip_patch(self.model,{'mode':'wrapper','operator':'foreach_norm'}):raise RuntimeError('test')
        self.assertIs(modeling_clip._get_vector_norm,orig)

class DataAndExportTests(unittest.TestCase):
    def test_complete_orchestration_without_npu(self):
        from run_completion_batch import CompletionBatch
        from completion_utils import GELU,NORM
        class Fake(CompletionBatch):
            def __init__(self,root):
                self.out=root;self.state={'eligibility':{}};self.events=[]
                self.p={'harnesses':dict(ai2d='h1',mmstar='h2'),'qwen_host_protocols':dict(ai2d='p1',mmstar='p2'),'qwen_datasets':dict(ai2d='d1',mmstar='d2')}
                self.a=types.SimpleNamespace(qwen_model=root/'qwen',clip_model=root/'clip')
            def task(self,name,action,**cfg):
                self.events.append((name,action,cfg))
                # Validate every dispatched worker request has its required fields.
                required={'qwen':('model','harness','host_protocol','samples','mode','split','output'),'clip':('model','mode','split','operator','output'),'qwen_timing':('model','host_protocol','samples','gate','receipt'),'clip_timing':('model','gate','receipt'),'operator_timing':('gate','captures','receipt'),'score_qwen':('harness','samples','baseline','candidate_output')}
                if not all(k in cfg for k in required[action]):raise AssertionError((action,cfg))
                if action=='clip' and not cfg.get('probe'):
                    out=Path(cfg['output']);out.mkdir(parents=True)
                    for r in [{'direction':'image_to_text','query_id':1,'group_id':1,'rank':1,'top10':[2]},{'direction':'text_to_image','query_id':2,'group_id':1,'rank':1,'top10':[1]}]:
                        with (out/'ranks.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(r)+'\n')
            def install(self,cid,tag):return {'candidate':cid,'operator':'gelu' if cid in GELU else 'foreach_norm','receipt':'receipt'}
            def eligible(self,label,cfg,captures):self.state['eligibility'][label]={'eligible':True};return Path('gate')
        with tempfile.TemporaryDirectory(dir=HERE,prefix='test-plan-') as t:
            batch=Fake(Path(t))
            with patch('run_completion_batch.retrieval_pair',return_value={}):batch.clip_runs();batch.qwen_runs()
            self.assertEqual(len(batch.state['eligibility']),8)
            self.assertEqual(sum(a=='qwen_timing' for _,a,_ in batch.events),2)
            self.assertEqual(sum(a=='clip_timing' for _,a,_ in batch.events),4)
            self.assertEqual(sum(a=='qwen' and c['split']=='eval' for _,a,c in batch.events),6)
            self.assertEqual(sum(a=='clip' and c['split']=='eval' for _,a,c in batch.events),5)
    def test_selection_preserves_extra_captions(self):
        data={'images':[{'id':i,'file_name':f'{i}.jpg'} for i in range(5000)],'annotations':[{'id':i*10+j,'image_id':i,'caption':str(j)} for i in range(5000) for j in range(6)]}
        a=select(data);b=select(data)
        self.assertEqual(a,b);self.assertEqual(len(a),1100);self.assertTrue(all(len(r['captions'])==6 for r in a));self.assertEqual(sum(r['split']=='dev' for r in a),100)
    def test_driver_packages_on_failure_without_tensor_export(self):
        from run_completion_batch import CompletionBatch
        import argparse,zipfile
        with tempfile.TemporaryDirectory(dir=HERE,prefix='test-export-') as t:
            root=Path(t);(root/'upload/model').mkdir(parents=True);(root/'data').mkdir();save(root/'data/manifest.json',{});save(root/'data/samples.json',[])
            a=argparse.Namespace(root=root,output=Path('results/stopped'),data=root/'data',qwen_model=root/'upload/model',timeout=1)
            batch=CompletionBatch(a);batch.state['status']='stopped_requires_review';batch.state['error']='test failure';(batch.out/'large.pt').write_bytes(b'not exported');batch.package()
            with zipfile.ZipFile(root/'upload/stopped_results.zip') as z:
                self.assertIn('batch/batch_status.json',z.namelist());self.assertFalse(any(n.endswith('.pt') for n in z.namelist()))
                m=json.loads(z.read('EXPORT_MANIFEST.json'));self.assertTrue(all(__import__('hashlib').sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in m.items()))

if __name__=='__main__':unittest.main(verbosity=2)
