"""Fresh-process workers for fixed semantic-aligned supplemental experiments."""
import contextlib
from pathlib import Path
import random
import sys
import time
from completion_utils import GELU,NORM,SEED,TOL,append,fp,metrics,read,rows,save,sha,retrieval,timings_summary

def frozen(c):
    sys.path.insert(0,c['harness'])
    import torch
    import torch_npu
    from host import environment
    torch.set_num_threads(4);torch.manual_seed(SEED);torch.npu.set_device(c['device']);torch.npu.config.allow_internal_format=False
    p=read(c['protocol'])
    if p['fingerprint']!=fp({k:v for k,v in p.items() if k!='fingerprint'}):raise ValueError('Frozen protocol changed')
    if environment(c['device'])!=p['environment']:raise ValueError('Environment changed')
    for name,h in p['package_code_sha256'].items():
        if sha(Path(__file__).parent/name)!=h:raise ValueError('Batch code changed')
    for name,h in p['external_files_sha256'].items():
        if sha(name)!=h:raise ValueError('External input/code changed: '+name)
    identity=None
    if c.get('candidate'):
        from common import verify_loaded
        identity=verify_loaded(c['candidate'],c['operator'],c['receipt'])
    return p,identity

def check_gate(c,identity):
    g=read(c['gate'])
    if not g['eligible'] or g['identity']['binary_sha256']!=identity['binary_sha256'] or g['protocol_sha256']!=sha(c['protocol']) or g['operator']!=c['operator']:raise ValueError('Missing or incompatible successful gate')

def qwen_patch(model,c,diagnostics=True):
    from host import PatchSession,discover
    kernel=None
    if c['mode']=='candidate':
        import cann_bench
        # Deliberate new condition: original generated source, existing tanh branch.
        kernel=lambda x,requested:cann_bench.gelu(x,'tanh')
    return PatchSession(model,discover(model,'gelu'),'gelu',c['mode'],kernel,diagnostics)

def qwen(c):
    import torch
    p,identity=frozen(c)
    from host import load_host,inputs_for
    from common import load_rows,parse_answer,verify_data,verify_model
    hostp=read(c['host_protocol']);verify_model(hostp,c['model']);verify_data(hostp,c['samples'])
    if identity:check_gate(c,identity)
    data=[r for r in load_rows(c['samples']) if r['split']==c['split']]
    if c.get('limit'):data=data[:c['limit']]
    out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    save(out/'run.json',{'protocol_sha256':sha(c['protocol']),'host_protocol_sha256':sha(c['host_protocol']),'samples_sha256':sha(c['samples']),'split':c['split'],'mode':c['mode'],'identity':identity,'gelu_host_requested':'none','gelu_host_effective':'tanh (verified current runtime)','candidate_mode':'tanh' if identity else None})
    model,processor=load_host(hostp,c['model'],f'npu:{c["device"]}')
    patch=qwen_patch(model,c);captures=[];total_bytes=0;current={}
    handle=None
    if c.get('capture'):
        from host import discover
        module=dict(model.named_modules())[discover(model,'gelu')[0]]
        def hook(m,args,value):
            nonlocal total_bytes
            if len(captures)>=10:return
            x=args[0];size=(x.numel()+value.numel())*x.element_size()
            if total_bytes+size>512*1024*1024:raise ValueError('Unexpected GELU capture size; do not silently omit')
            path=out/'captures'/f'{len(captures):04d}.pt';path.parent.mkdir(exist_ok=True)
            torch.save({'input':x.detach().cpu(),'reference':value.detach().cpu()},path);total_bytes+=size
            captures.append({'file':path.name,'sha256':sha(path),'operator':'gelu','shape':list(x.shape),'dtype':str(x.dtype),'phase':'vision','module':discover(model,'gelu')[0],'sample_id':current['id'],'group_id':current['group_id']})
        handle=module.register_forward_hook(hook)
    try:
        with torch.inference_mode():
            for i,row in enumerate(data):
                current.update(id=row['id'],group_id=row['group_id'])
                inp=inputs_for(row,c['samples'],processor,hostp,f'npu:{c["device"]}')
                generated=model.generate(**inp,max_new_tokens=hostp['decode']['max_new_tokens'],do_sample=False,use_cache=True)
                torch.npu.synchronize();text=processor.batch_decode(generated[:,inp.input_ids.shape[1]:],skip_special_tokens=True)[0].strip();pred=parse_answer(text,len(row['choices']))
                append(out/'predictions.jsonl',{'id':row['id'],'group_id':row['group_id'],'answer':row['answer'],'status':'success','text':text,'prediction':pred,'correct':pred==row['answer']})
                if (i+1)%50==0:print('QWEN QUESTIONS',i+1,'/',len(data),flush=True)
        if c['mode']!='native' and (not patch.counters or any(v==0 for v in patch.counters.values())):raise ValueError('Missing Qwen target calls')
        save(out/'calls.json',patch.counters)
        if captures:
            if len(captures)!=10:raise ValueError('Expected ten Qwen captures')
            save(out/'captures/index.json',{'protocol_sha256':sha(c['protocol']),'records':captures})
        if c.get('baseline'):
            base=rows(Path(c['baseline'])/'predictions.jsonl');actual=rows(out/'predictions.jsonl')
            if c.get('limit'):base=base[:c['limit']]
            if [r['id'] for r in base]!=[r['id'] for r in actual]:raise ValueError('Qwen control sample mismatch')
            if any(a['text']!=b['text'] or a['prediction']!=b['prediction'] for a,b in zip(base,actual)):raise ValueError('Qwen repeat/wrapper changes answers')
            save(out/'control.json',{'passed':True,'samples':len(base),'raw_text_changes':0})
        save(out/'status.json',{'status':'completed','samples':len(data),'runtime_failures':0})
    finally:
        if handle:handle.remove()
        patch.close()

def clip_setup(c):
    import torch
    from transformers import CLIPModel,CLIPProcessor
    p,identity=frozen(c)
    # Both checkpoints/processor files are pinned in the top-level frozen protocol.
    for name,h in p['clip_model_files_sha256'].items():
        if sha(Path(c['model'])/name)!=h:raise ValueError('CLIP model changed')
    model=CLIPModel.from_pretrained(c['model'],torch_dtype=torch.bfloat16,attn_implementation='eager',local_files_only=True).to(f'npu:{c["device"]}').eval()
    processor=CLIPProcessor.from_pretrained(c['model'],local_files_only=True,use_fast=False)
    if model.config.text_config.hidden_act!='gelu' or model.config.vision_config.hidden_act!='gelu':raise ValueError('Unexpected CLIP activation')
    return p,identity,model,processor

def clip_batches(c,processor,probes=False):
    from PIL import Image
    import torch
    root=Path(c['data']);data=[r for r in read(root/'samples.json') if r['split']==c['split']]
    if c.get('limit'):data=data[:c['limit']]
    batches=[(data[i:i+8],None) for i in range(0,len(data),8)]
    if probes:
        # 8 images/40 texts, tail3/15, extra1/2 (unequal modality counts).
        data=data[:11];batches=[(data[:8],None),(data[8:],None),(data[:1],2)]
    for i,(batch,text_limit) in enumerate(batches):
        images=[]
        for r in batch:
            path=root/r['image']
            if sha(path)!=r['image_sha256']:raise ValueError('COCO image changed')
            with Image.open(path) as im:images.append(im.convert('RGB'))
        captions=[(r['image_id'],cap) for r in batch for cap in r['captions']]
        if text_limit:captions=captions[:text_limit]
        inp=processor(images=images,text=[cap['text'] for _,cap in captions],padding='max_length',max_length=77,truncation=True,return_tensors='pt')
        hashes={k:{'shape':list(v.shape),'sha256':__import__('hashlib').sha256(v.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()} for k,v in inp.items()}
        inp={k:v.to(device=f'npu:{c["device"]}',dtype=torch.bfloat16) if v.is_floating_point() else v.to(f'npu:{c["device"]}') for k,v in inp.items()}
        yield i,batch,captions,inp,hashes

@contextlib.contextmanager
def clip_patch(model,c,counters=True):
    import torch
    from transformers.models.clip import modeling_clip
    from clip_adapter import rowwise_foreach_norm
    stats={'gelu':{},'norm':[]};original=modeling_clip._get_vector_norm;old=[]
    implementation=None
    if c['mode']=='candidate':
        import cann_bench
        implementation=getattr(cann_bench,c['operator'])
    if c['mode']!='native' and c['operator']=='gelu':
        from transformers.models.clip.modeling_clip import CLIPMLP
        for name,module in list(model.named_modules()):
            if not isinstance(module,CLIPMLP):continue
            previous=module.activation_fn
            class Activation(torch.nn.Module):
                def __init__(self,key,orig):super().__init__();self.key=key;self.original=orig
                def forward(self,x):
                    if counters:stats['gelu'][self.key]=stats['gelu'].get(self.key,0)+1
                    return implementation(x,'tanh') if c['mode']=='candidate' else self.original(x)
            old.append((module,previous));module.activation_fn=Activation(name,previous)
        if len(old)!=24:raise ValueError('Expected 24 CLIP GELU targets')
    if c['mode']!='native' and c['operator']=='foreach_norm':
        def norm(x):
            if counters:stats['norm'].append({'shape':list(x.shape),'dtype':str(x.dtype),'side':'image' if len(stats['norm'])%2==0 else 'text'})
            fn=implementation if c['mode']=='candidate' else lambda xs,p:[original(v).reshape(()) for v in xs]
            return rowwise_foreach_norm(x,fn)
        modeling_clip._get_vector_norm=norm
    try:yield stats
    finally:
        for module,previous in old:module.activation_fn=previous
        modeling_clip._get_vector_norm=original

def validate_calls(c,stats,batches):
    if c['mode']=='native':return
    if c['operator']=='gelu':
        if len(stats['gelu'])!=24 or any(v!=batches for v in stats['gelu'].values()):raise ValueError('CLIP GELU bypassed')
    elif len(stats['norm'])!=2*batches:raise ValueError('CLIP norm bypassed')

def clip(c):
    import torch
    from transformers.models.clip import modeling_clip
    p,identity,model,processor=clip_setup(c)
    if identity:check_gate(c,identity)
    out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    captures=[];handles=[];original=modeling_clip._get_vector_norm;current={};byte_count=0
    def capture(operator,module,x,value):
        nonlocal byte_count
        size=(x.numel()+value.numel())*x.element_size();byte_count+=size
        if byte_count>512*1024*1024:raise ValueError('CLIP capture budget exceeded; review rather than truncate')
        path=out/'captures'/operator/f'{len(captures):04d}.pt';path.parent.mkdir(parents=True,exist_ok=True)
        torch.save({'input':x.detach().cpu(),'reference':value.detach().cpu()},path)
        captures.append({'operator':operator,'module':module,'file':path.name,'sha256':sha(path),'shape':list(x.shape),'dtype':str(x.dtype),'batch':current['batch'],'image_ids':current['images'],'phase':'vision' if module.startswith('vision') else 'text' if module.startswith('text') else 'feature_norm'})
    if c.get('capture'):
        for name,module in model.named_modules():
            if name in p['clip_capture_modules']:
                handles.append(module.register_forward_hook(lambda m,a,v,name=name:capture('gelu',name,a[0],v)))
        if len(handles)!=6:raise ValueError('Missing CLIP capture targets')
        def norm(x):
            v=original(x);capture('foreach_norm','image_feature_norm' if x.shape[0]==len(current['images']) else 'text_feature_norm',x,v);return v
        modeling_clip._get_vector_norm=norm
    reference=torch.load(Path(c['baseline'])/'features.pt',weights_only=True,map_location='cpu') if c.get('baseline') else None
    image_features=[];text_features=[];ids=[];caption_ids=[];owners=[];batch_outputs=[];drift=[];count=0
    try:
        with clip_patch(model,c) as stats,torch.inference_mode():
            for i,batch,caps,inp,hashes in clip_batches(c,processor,probes=c.get('probe',False)):
                current.update(batch=i,images=[r['image_id'] for r in batch])
                value=model(**inp);values={k:getattr(value,k).detach().cpu() for k in ('image_embeds','text_embeds','logits_per_image','logits_per_text')}
                if not all(bool(torch.isfinite(v).all()) for v in values.values()):raise ValueError('Nonfinite CLIP outputs')
                if reference:
                    ref=reference['batches'][i]
                    if hashes!=ref['inputs']:raise ValueError('CLIP inputs differ')
                    checks={k:metrics(v,ref['values'][k]) for k,v in values.items()}
                    if c['mode'] in ('native','wrapper') and not all(s['exact_equal'] for s in checks.values()):raise ValueError('CLIP native repeat/wrapper changes outputs')
                    drift.append({'batch':i,'checks':checks})
                batch_outputs.append({'inputs':hashes,'values':values})
                image_features.append(values['image_embeds']);text_features.append(values['text_embeds']);ids.extend(r['image_id'] for r in batch);owners.extend(o for o,cap in caps);caption_ids.extend(cap['id'] for o,cap in caps);count+=1
                print('CLIP BATCH',count,'images',len(ids),'texts',len(owners),flush=True)
            validate_calls(c,stats,count);save(out/'calls.json',stats)
        features={'batches':batch_outputs,'image':torch.cat(image_features),'text':torch.cat(text_features),'image_ids':ids,'caption_ids':caption_ids,'owners':owners}
        torch.save(features,out/'features.pt')
        if c.get('capture'):
            for op in ('gelu','foreach_norm'):save(out/'captures'/op/'index.json',{'protocol_sha256':sha(c['protocol']),'records':[r for r in captures if r['operator']==op]})
        save(out/'drift.json',drift)
        if not c.get('probe'):
            rank,summary=retrieval(features['image'].float().numpy(),features['text'].float().numpy(),ids,caption_ids,owners)
            for row in rank:append(out/'ranks.jsonl',row)
            save(out/'retrieval.json',{'images':len(ids),'captions':len(owners),'metrics':summary,'protocol_sha256':sha(c['protocol']),'split':c['split'],'ranking':'CPU FP32 dot product of native normalized BF16 forward embeddings; stable tie by corpus index; no extra renormalization or logit_scale'})
        save(out/'run.json',{'protocol_sha256':sha(c['protocol']),'identity':identity,'mode':c['mode'],'operator':c['operator'],'batches':count,'probe':c.get('probe',False),'capture_bytes':byte_count})
        save(out/'status.json',{'status':'completed','images':len(ids),'texts':len(owners),'batches':count})
    finally:
        modeling_clip._get_vector_norm=original
        for h in handles:h.remove()

def capture_functions(c,x):
    import torch
    import cann_bench
    if c['operator']=='gelu':
        return {'native':lambda:torch.nn.functional.gelu(x,approximate='none'),'wrapper':lambda:torch.nn.functional.gelu(x,approximate='none'),'candidate':lambda:cann_bench.gelu(x,'tanh')}
    from transformers.models.clip import modeling_clip
    from clip_adapter import rowwise_foreach_norm
    original=modeling_clip._get_vector_norm
    return {'native':lambda:original(x),'wrapper':lambda:rowwise_foreach_norm(x,lambda xs,p:[original(v).reshape(()) for v in xs]),'candidate':lambda:rowwise_foreach_norm(x,cann_bench.foreach_norm)}

def gate(c):
    import torch
    p,identity=frozen(c);directory=Path(c['captures']);index=read(directory/'index.json')
    if index['protocol_sha256']!=sha(c['protocol']) or not index['records']:raise ValueError('Wrong/empty capture contract')
    out=Path(c['output']);out.mkdir(parents=True,exist_ok=False);report=[]
    with torch.inference_mode():
        for row in index['records']:
            path=directory/row['file']
            if sha(path)!=row['sha256']:raise ValueError('Capture changed')
            data=torch.load(path,weights_only=True,map_location='cpu');x=data['input'].to(f'npu:{c["device"]}')
            values={k:fn() for k,fn in capture_functions(c,x).items()}
            checks={k:metrics(v,data['reference']) for k,v in values.items()}
            if not checks['native']['exact_equal'] or not checks['wrapper']['exact_equal']:raise ValueError('Capture replay control changed')
            item={'capture':row,'checks':checks}
            if c['operator']=='foreach_norm':
                normalized={k:metrics(x/v,x/values['native']) for k,v in values.items()}
                if not normalized['wrapper']['exact_equal']:raise ValueError('Normalized wrapper changes captured features')
                item['normalized_features']=normalized
            report.append(item);save(out/'replay.json',report)
    passed=sum(r['checks']['candidate']['passed'] and r.get('normalized_features',{'candidate':{'passed':True}})['candidate']['passed'] for r in report)
    save(out/'eligibility.json',{'eligible':passed==len(report),'passed':passed,'total':len(report),'identity':identity,'operator':c['operator'],'candidate_mode':'tanh' if c['operator']=='gelu' else None,'protocol_sha256':sha(c['protocol']),'tolerance':TOL})

def operator_timing(c):
    import torch
    p,identity=frozen(c)
    from benchmark_npu import timed
    check_gate(c,identity);directory=Path(c['captures']);index=read(directory/'index.json');out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    records=[];rng=random.Random(SEED)
    # First <=12 predetermined native dev captures, independent of candidate outputs.
    selected=index['records'][:12];save(out/'workloads.json',selected)
    with torch.inference_mode():
        for row in selected:
            path=directory/row['file']
            if sha(path)!=row['sha256']:raise ValueError('Timing capture changed')
            x=torch.load(path,weights_only=True,map_location='cpu')['input'].to(f'npu:{c["device"]}');functions=capture_functions(c,x)
            if c['operator']=='foreach_norm':functions={name:(lambda fn=fn:x/fn()) for name,fn in functions.items()}
            ref=functions['native']()
            if not all(metrics(fn(),ref)['passed'] for fn in functions.values()):raise ValueError('Full-path numerical gate fails before timing')
            for block in range(3):
                order=list(functions);rng.shuffle(order)
                for mode in order:
                    r={'workload':row['file'],'phase':'norm_adapter_stack_divide' if c['operator']=='foreach_norm' else 'gelu_full_call','mode':mode,'block':block,**timed(functions[mode],10,50)};records.append(r);append(out/'timings.jsonl',r)
    save(out/'summary.json',timings_summary(records));save(out/'identity.json',identity)

def clip_timing(c):
    import torch
    p,identity,model,processor=clip_setup(c)
    from benchmark_npu import timed
    check_gate(c,identity);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    records=[];rng=random.Random(SEED)
    with torch.inference_mode():
        for i,batch,caps,inp,hashes in clip_batches(c,processor,probes=True):
            with clip_patch(model,c) as stats:model(**inp);torch.npu.synchronize()
            validate_calls(c,stats,1)
            for block in range(3):
                order=['native','wrapper','candidate'];rng.shuffle(order)
                for mode in order:
                    with clip_patch(model,{**c,'mode':mode},counters=False):
                        r={'workload':str(i),'phase':'clip_forward_on_preprocessed_npu_inputs','mode':mode,'block':block,'images':len(batch),'texts':len(caps),'inputs':hashes,**timed(lambda:model(**inp),3,10)}
                    records.append(r);append(out/'timings.jsonl',r)
    save(out/'summary.json',timings_summary(records));save(out/'identity.json',identity)

def qwen_timing(c):
    p,identity=frozen(c);check_gate(c,identity)
    import argparse
    import torch
    import cann_bench
    import benchmark_npu as b
    hostp=read(c['host_protocol']);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    a=argparse.Namespace(model_path=Path(c['model']),samples=Path(c['samples']),operator='gelu',device_id=c['device'],output=out)
    # Existing timing implementation keeps native fixed tokens, fresh KV caches,
    # randomized native/wrapper/candidate blocks and no timed diagnostic counters.
    with torch.inference_mode():records=b.model_benchmark(a,hostp,lambda x,requested:cann_bench.gelu(x,'tanh'))
    save(out/'summary.json',timings_summary(records));save(out/'identity.json',identity)

def dispatch(action,c):
    return {'qwen':qwen,'clip':clip,'gate':gate,'operator_timing':operator_timing,'clip_timing':clip_timing,'qwen_timing':qwen_timing}[action](c)
