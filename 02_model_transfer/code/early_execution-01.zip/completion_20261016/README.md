# 一键完成当前剩余补充实验

本批沿用云端既有权重、环境和已编译候选，不安装新依赖，不修改生成源码。既有实验和结果目录保留。

## 运行内容

| 部分 | 内容 |
|---|---|
| CLIP正式任务 | 固定OpenCLIP检查点在Transformers CLIPModel中的实现；Grok/Kimi GELU各自单独替换，DeepSeek/Grok ForeachNorm各自单独替换 |
| 检索数据 | COCO2017 val固定100张dev、1000张eval，全部原始描述；分别500、5002条文本，图像不跨dev/eval |
| 检索指标 | 全局图到文、文到图R@1/5/10，逐查询排名、top10、配对图像组bootstrap区间 |
| Qwen GELU重做 | 同两份GELU，在AI2D和既有过滤MMStar子集上完成dev及正式比较；dev包含原生重复、包装对照和候选重复 |
| 性能 | CLIP四候选的局部完整调用与模型前向；Qwen两份GELU的局部调用、模型prefill和固定token decode |
| 既有SwiGLU | 沿用已完成的正式实验，本批不重复 |

GELU使用**原生成源码已有的tanh分支**，匹配当前NPU宿主的有效计算公式。宿主配置仍请求none；这一新条件会明确写入协议，旧none比较不被覆盖。没有手工改写或优化内核，没有放宽误差标准。

## 你只需要做两步

1. 将同目录三个文件上传到之前的`build`目录：`completion_20261016.zip`、`completion_coco_20261016.zip`、`start_completion.py`。模型权重不用重新上传。
2. 在CANNLab终端执行：

```bash
python /mnt/workspace/gitCode/cann/cann-learning-hub/build/start_completion.py
```

看到`BACKGROUND_PID`表示已启动。后台运行，无需逐条操作；保持实例运行，避免与其他实验并行使用同一NPU或安装同名算子包。

随时查看最近进度：

```bash
tail -n 25 /mnt/workspace/v3_model_transfer/results/auto_completion_001.console.log
```

完成或异常停止后下载并发回：

```text
/mnt/workspace/gitCode/cann/cann-learning-hub/build/auto_completion_001_results.zip
```

返回包包含概要、冻结协议、完整日志、准入和调用记录、逐题答案、逐查询检索排名、配对统计及原始计时。图片、模型、wheel、中间张量和特征缓存留在云端，避免返回包过大。批次最后恢复运行前安装的候选并核对身份。

## 固定边界

- 所有候选独立替换，不做联合替换；不强求两宿主×三算子的完整组合。
- 包装和环境异常停止并打包；候选数值不准入记录后跳过，其他合格候选继续，不临时换候选。
- 模型前向输出的归一化特征用于检索；不改用绕开范数替换位置的特征提取接口。检查图像和文本两侧调用、不等量图文及尾批。
- 检索使用BF16模型输出转CPU FP32做完整候选库点积，不额外归一化；相同分数按固定候选索引排序。不将内部1000图像子集称为官方完整5000图像或Karpathy测试成绩。
- 范数准入同时检查范数和归一化后的特征。计时包含拆行、列表组织、候选、stack、除法；模型计时使用预处理好的NPU输入，不包含磁盘读取或tokenization，不叫纯内核耗时。
- 本地检查验证统计和接入流程；真实NPU兼容性、任务质量和性能仍以本批实际结果为准。
- 依赖原云端`auto_formal_001`、`auto_followup_001`、`auto_clip_screen_001`、`gelu_semantics_001`及其harness、wheel和原始数据仍在；缺失会停止并留下日志。不会静默重新生成候选。

数据来自[COCO官方发布](https://cocodataset.org/#download)，使用其官方S3存储桶的HTTPS路径，来源和每张图像哈希见数据清单。选取完全依据固定哈希排序，与模型结果无关。
