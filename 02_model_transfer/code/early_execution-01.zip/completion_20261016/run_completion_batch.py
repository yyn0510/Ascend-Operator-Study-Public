"""One detached batch: aligned GELU/Qwen plus CLIP GELU/ForeachNorm retrieval and timing."""
import argparse
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback
import zipfile
from completion_utils import GELU,NORM,SEED,TOL,fp,read,rows,save,sha,retrieval_pair
from run_transfer_batch import Batch,ensure_benchmark

HERE=Path(__file__).resolve().parent

def preflight(c):
    sys.path.insert(0,c['harness'])
    import torch
    import torch_npu
    import cann_bench
    from host import environment,record_device_status
    from common import model_inventory,verify_model,verify_data
    from prepare_coco import verify
    old=Path(c['old']);out=Path(c['output']);formal=old/'results/auto_formal_001';clip=old/'results/auto_clip_screen_001';follow=old/'results/auto_followup_001';semantic=old/'results/gelu_semantics_001'
    if read(formal/'batch_status.json')['status'] not in ('completed','completed_with_ineligible_candidates'):raise ValueError('Previous formal batch incomplete')
    if read(semantic/'batch_status.json')['status']!='completed':raise ValueError('Semantic diagnosis incomplete')
    if read(clip/'batch_status.json')['status'] not in ('completed','completed_with_ineligible_candidates'):raise ValueError('CLIP screening incomplete')
    # Recheck the diagnostic fixed 37 records in the archived server summaries.
    if not (semantic/'protocol.json').is_file():raise ValueError('GELU diagnostic protocol missing')
    env=environment(c['device']);qhost=read(formal/'protocol.frozen.json')
    if env!=qhost['environment'] or env!=read(clip/'protocol.pilot.json')['environment']:raise ValueError('Runtime differs from verified earlier batches')
    verify_model(qhost,c['qwen_model'])
    mmrun=read(follow/'mmstar_native_eval/run.json');mmprotocol=follow/'mmstar_protocol.frozen.json';mmdata=Path(mmrun['samples_path'])
    protocols={'ai2d':formal/'protocol.frozen.json','mmstar':mmprotocol}
    data={'ai2d':old/'data/ai2d_100dev_1000eval/samples.jsonl','mmstar':mmdata}
    harnesses={'ai2d':formal/'harness','mmstar':follow/'mmstar_harness','clip':clip/'harness'}
    external={}
    for key,pr in protocols.items():
        verify_data(read(pr),data[key]);external[str(pr)]=sha(pr);external[str(data[key])]=sha(data[key])
        for name,h in read(pr)['runner_sha256'].items():
            path=harnesses[key]/name
            if sha(path)!=h:raise ValueError('Prior runner modified: '+str(path))
            external[str(path)]=h
    clip_p=read(clip/'protocol.pilot.json')
    for n,h in clip_p['model_files_sha256'].items():
        if sha(Path(c['clip_model'])/n)!=h:raise ValueError('CLIP checkpoint changed')
    from transformers.models.clip import modeling_clip
    if sha(modeling_clip.__file__)!=clip_p['upstream_source_sha256']:raise ValueError('CLIP upstream source changed')
    external[str(Path(modeling_clip.__file__).resolve())]=sha(modeling_clip.__file__)
    for name in ('common.py','host.py','benchmark_npu.py','numerics.py','score.py'):
        path=harnesses['clip']/name;external[str(path)]=sha(path)
    manifest=verify(c['data']);external[str(Path(c['data'])/'samples.json')]=sha(Path(c['data'])/'samples.json');external[str(Path(c['data'])/'manifest.json')]=sha(Path(c['data'])/'manifest.json')
    candidates={}
    for cid in GELU+NORM:
        receipt=clip/('build_'+cid)/'receipt.json';r=read(receipt)
        if r['candidate_id']!=cid or sha(r['wheel'])!=r['wheel_sha256']:raise ValueError('Wheel identity mismatch')
        op='gelu' if cid in GELU else 'foreach_norm'
        benchmark=ensure_benchmark(clip/('verify_'+cid))
        candidates[cid]={'operator':op,'receipt':str(receipt),'harness':str(harnesses['clip']),'benchmark':benchmark,'receipt_sha256':sha(receipt)}
        external[str(receipt)]=sha(receipt);external[benchmark['report']]=benchmark['sha256']
    # Capture the actually installed package for restoration, from explicit formal builds only.
    current=sha(cann_bench._C.__file__);restore=None
    for cid,desc in candidates.items():
        if read(desc['receipt'])['binary_sha256']==current:restore=desc|{'candidate':cid}
    for cid in ('Kimi_K3_swi_glu_003_R5','DeepSeek_V4_1_Flash_swi_glu_002_R4'):
        # Previous dev builds are the fixed locations used by the formal batch.
        for path in [old/'results/auto_dev_001'/('build_'+cid)/'receipt.json',old/'results/build_kimi_swiglu_001/receipt.json']:
            if path.is_file():
                r=read(path)
                if r['candidate_id']==cid and r['binary_sha256']==current:restore={'candidate':cid,'operator':'swi_glu','receipt':str(path),'harness':str(formal/'harness')}
    if restore is None:raise ValueError('Current installed binary not among explicit known candidates; stop before installations')
    p={'schema_version':1,'state':'frozen','seed':SEED,'environment':env,'condition':'effective-tanh-aligned GELU; unchanged generated sources; explicit candidate tanh vs host requested none/effective tanh','tolerance':TOL,'candidate_ids':GELU+NORM,'candidate_receipts':candidates,'qwen_model':c['qwen_model'],'clip_model':c['clip_model'],'clip_model_files_sha256':clip_p['model_files_sha256'],'qwen_model_files_sha256':model_inventory(c['qwen_model']),'qwen_host_protocols':{k:str(v) for k,v in protocols.items()},'qwen_datasets':{k:str(v) for k,v in data.items()},'harnesses':{k:str(v) for k,v in harnesses.items()},'external_files_sha256':external,'package_code_sha256':{p.name:sha(p) for p in HERE.glob('*.py')},'coco_manifest':manifest,'clip_capture_modules':clip_p['capture_gelu_modules'],'retrieval':{'image_batch':8,'text_batch':'all original captions of image batch; unequal modality counts','processor':'max_length=77,padding=max_length,truncation=True,use_fast=False','features':'CLIPModel.forward normalized image_embeds/text_embeds; BF16 then CPU FP32, no additional normalization','scores':'CPU FP32 full-corpus dot product; omit positive logit_scale','tie_break':'descending score, ascending fixed corpus index','metrics':['image_to_text R@1/5/10','text_to_image R@1/5/10'],'inference_scope':'Transformers4.51.3 CLIPModel, pinned OpenCLIP checkpoint; not all OpenCLIP runtimes','dev_captures':'first11 selected dev images, batches8+3; extra1image/2texts','bootstrap':'5000 paired query-image cluster resamples, fixed corpus; descriptive CI, no equivalence claim'},'performance':{'blocks':3,'operator_warmup':10,'operator_iterations':50,'clip_warmup':3,'clip_iterations':10,'qwen':'reuse frozen 30-dev workload timing settings, fresh KV and native fixed tokens','scope':'preprocessed NPU inputs to outputs; includes adapters; excludes image reading/tokenization; no hardware-only claim'},'stop_rules':'infrastructure/native/wrapper/identity exceptions stop for review; numerical candidate ineligibility recorded with no fallback or threshold change; all other eligible candidates continue','prior_semantic_protocol_sha256':sha(semantic/'protocol.json')}
    p['fingerprint']=fp(p);save(c['protocol'],p);save(out/'restore.json',restore);record_device_status(out)

class CompletionBatch(Batch):
    def __init__(self,a):
        self.a=a;self.root=a.root.resolve();self.out=(self.root/a.output).resolve()
        if not self.out.is_relative_to(self.root/'results'):raise ValueError('Unsafe result directory')
        self.out.mkdir(parents=True,exist_ok=False);self.protocol=self.out/'protocol.frozen.json'
        self.state={'status':'running','steps':[],'eligibility':{},'comparisons':{},'error':None,'restoration':'not_needed','started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};self.save()
    def task(self,name,action,**cfg):
        config={'old':str(self.root),'harness':str(self.root/'results/auto_clip_screen_001/harness'),'protocol':str(self.protocol),'device':self.a.device_id,'data':str(self.a.data.resolve()),'qwen_model':str(self.a.qwen_model.resolve()),'clip_model':str(self.a.clip_model.resolve()),**cfg}
        path=self.out/'requests'/(name+'.json');save(path,config)
        self.command(name,[sys.executable,HERE/'run_completion_batch.py','--worker',action,'--request',path])
    def install(self,cid,tag):
        d=self.p['candidate_receipts'][cid];r=read(d['receipt'])
        if sha(r['wheel'])!=r['wheel_sha256']:raise ValueError('Wheel changed')
        self.state['restoration']='required';self.save()
        self.command('install_'+tag,[sys.executable,'-m','pip','install','--force-reinstall','--no-deps',r['wheel']])
        return {'candidate':cid,'operator':d['operator'],'receipt':d['receipt']}
    def eligible(self,label,cfg,captures):
        out=self.out/('gate_'+label)
        self.task('gate_'+label,'gate',**cfg,captures=str(captures),output=str(out))
        g=read(out/'eligibility.json');self.state['eligibility'][label]=g;self.save()
        return out/'eligibility.json' if g['eligible'] else None
    def qwen_config(self,dataset):
        return {'harness':self.p['harnesses'][dataset],'host_protocol':self.p['qwen_host_protocols'][dataset],'model':str(self.a.qwen_model.resolve()),'samples':self.p['qwen_datasets'][dataset],'operator':'gelu'}
    def quality_qwen(self,name,config,**extra):
        out=self.out/name;self.task(name,'qwen',**config,output=str(out),**extra);return out
    def qwen_runs(self):
        from completion_utils import rows
        for dataset in ('ai2d','mmstar'):
            cfg=self.qwen_config(dataset)
            native=self.quality_qwen('qwen_'+dataset+'_native_dev10',cfg,mode='native',split='dev',limit=10,capture=True)
            for mode in ('native','wrapper'):
                self.quality_qwen('qwen_'+dataset+'_'+mode+'_control',cfg,mode=mode,split='dev',limit=10,baseline=str(native))
            eligible=[]
            for cid in GELU:
                candidate=self.install(cid,'qwen_'+dataset+'_gate_'+cid)
                g=self.eligible('qwen_'+dataset+'_'+cid,cfg|candidate,native/'captures')
                if g:
                    dev=self.quality_qwen('qwen_'+dataset+'_dev_'+cid,cfg|candidate,mode='candidate',split='dev',gate=str(g))
                    self.quality_qwen('qwen_'+dataset+'_repeat10_'+cid,cfg|candidate,mode='candidate',split='dev',limit=10,gate=str(g),baseline=str(dev))
                    eligible.append((cid,g))
            if not eligible:continue
            baseline=self.quality_qwen('qwen_'+dataset+'_native_eval',cfg,mode='native',split='eval')
            for cid,g in eligible:
                candidate=self.install(cid,'qwen_'+dataset+'_formal_'+cid)
                output=self.quality_qwen('qwen_'+dataset+'_eval_'+cid,cfg|candidate,mode='candidate',split='eval',gate=str(g))
                # Current worker sets only local supplemental semantics; use original fixed-denominator scorer function.
                self.task('score_qwen_'+dataset+'_'+cid,'score_qwen',harness=cfg['harness'],baseline=str(baseline),candidate_output=str(output),samples=cfg['samples'],output=str(self.out/'comparisons'/('qwen_'+dataset+'_'+cid+'.json')))
                if dataset=='ai2d':
                    self.task('qwen_timing_'+cid,'qwen_timing',**(cfg|candidate),mode='candidate',gate=str(g),output=str(self.out/('qwen_timing_'+cid)))
                    self.task('qwen_operator_timing_'+cid,'operator_timing',**(cfg|candidate),gate=str(g),captures=str(native/'captures'),output=str(self.out/('qwen_operator_timing_'+cid)))
    def clip_runs(self):
        cfg={'model':str(self.a.clip_model.resolve()),'split':'dev','operator':'gelu'}
        native=self.out/'clip_native_probe'
        self.task('clip_native_probe','clip',**cfg,mode='native',probe=True,capture=True,output=str(native))
        for op,mode in [('gelu','native'),('gelu','wrapper'),('foreach_norm','wrapper')]:
            self.task('clip_control_'+op+'_'+mode,'clip',**(cfg|{'operator':op}),mode=mode,probe=True,baseline=str(native),output=str(self.out/('clip_control_'+op+'_'+mode)))
        eligible=[]
        for cid in GELU+NORM:
            candidate=self.install(cid,'clip_gate_'+cid);g=self.eligible('clip_'+cid,candidate,native/'captures'/candidate['operator'])
            if g:
                self.task('clip_candidate_probe_'+cid,'clip',**(cfg|candidate),mode='candidate',probe=True,gate=str(g),baseline=str(native),output=str(self.out/('clip_candidate_probe_'+cid)))
                eligible.append((cid,g))
        if not eligible:return
        # Actual retrieval path on dev precedes held-out evaluation; no candidate selection by recall.
        for split in ('dev','eval'):
            baseline=self.out/('clip_native_'+split)
            self.task('clip_native_'+split,'clip',**(cfg|{'split':split}),mode='native',output=str(baseline))
            if split=='dev':
                for op in ('gelu','foreach_norm'):
                    self.task('clip_wrapper_dev_'+op,'clip',**(cfg|{'operator':op}),mode='wrapper',baseline=str(baseline),output=str(self.out/('clip_wrapper_dev_'+op)))
            for cid,g in eligible:
                candidate=self.install(cid,'clip_'+split+'_'+cid);output=self.out/('clip_'+split+'_'+cid)
                self.task('clip_'+split+'_'+cid,'clip',**(cfg|candidate|{'split':split}),mode='candidate',gate=str(g),output=str(output))
                result=retrieval_pair(rows(baseline/'ranks.jsonl'),rows(output/'ranks.jsonl'));save(self.out/'comparisons'/('clip_'+split+'_'+cid+'.json'),result)
        for cid,g in eligible:
            candidate=self.install(cid,'clip_timing_'+cid)
            self.task('clip_model_timing_'+cid,'clip_timing',**(cfg|candidate),mode='candidate',gate=str(g),output=str(self.out/('clip_model_timing_'+cid)))
            self.task('clip_operator_timing_'+cid,'operator_timing',**candidate,gate=str(g),captures=str(native/'captures'/candidate['operator']),output=str(self.out/('clip_operator_timing_'+cid)))
    def run(self):
        self.task('preflight','preflight',output=str(self.out));self.p=read(self.protocol)
        # Second host first, so the new task evidence is captured before long Qwen reruns.
        self.clip_runs();self.qwen_runs()
        self.state['status']='completed' if all(g['eligible'] for g in self.state['eligibility'].values()) else 'completed_with_ineligible_candidates';self.save()
    def restore(self):
        if self.state['restoration']!='required':return
        d=read(self.out/'restore.json');r=read(d['receipt'])
        if sha(r['wheel'])!=r['wheel_sha256']:raise ValueError('Restore wheel changed')
        self.command('restore_original_package',[sys.executable,'-m','pip','install','--force-reinstall','--no-deps',r['wheel']])
        self.task('verify_restored_identity','identity',**{k:d[k] for k in ('harness','candidate','operator','receipt')},output=str(self.out/'restored_identity.json'))
        self.state['restoration']='restored_and_verified';self.save()
    def package(self):
        self.state['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());self.save()
        lines=['# 当前剩余补充实验批次',f'状态：{self.state["status"]}',f'恢复：{self.state["restoration"]}','','GELU为新建的有效tanh语义对齐条件；历史none比较不被覆盖。CLIP为Transformers实现的固定OpenCLIP检查点。COCO为固定1000图像内部检索子集，不是官方完整5000图像成绩。','','|准入对象|通过/总数|准入|','|---|---:|---|']
        for key,g in self.state['eligibility'].items():lines.append(f'|{key}|{g["passed"]}/{g["total"]}|{g["eligible"]}|')
        lines+=['','## 任务质量（仅已完成输出）','','|条件|样本|原生|候选|差值（百分点）|','|---|---:|---:|---:|---:|']
        for path in sorted((self.out/'comparisons').glob('qwen_*.json')):
            r=read(path);lines.append(f'|{path.stem}|{r["samples"]}|{100*r["baseline_accuracy"]:.4f}%|{100*r["candidate_accuracy"]:.4f}%|{r["difference_percentage_points"]:.4f}|')
        lines+=['','|CLIP条件/方向|指标|原生|候选|差值（百分点）|','|---|---|---:|---:|---:|']
        for path in sorted((self.out/'comparisons').glob('clip_eval_*.json')):
            r=read(path)
            for direction in ('image_to_text','text_to_image'):
                for metric,v in r[direction]['recall'].items():lines.append(f'|{path.stem}/{direction}|{metric}|{100*v["native"]:.4f}%|{100*v["candidate"]:.4f}%|{v["difference_percentage_points"]:.4f}|')
        lines+=['','## 性能描述统计','','|输出目录/阶段|对照模式|工作负载数|原生耗时/该路径耗时（几何平均）|','|---|---|---:|---:|']
        for path in sorted(self.out.glob('*timing*/summary.json')):
            for r in read(path)['aggregate']:lines.append(f'|{path.parent.name}/{r["phase"]}|{r["mode"]}|{r["workloads"]}|{r["geometric_mean_speedup"]:.4f}×|')
        lines+=['','完整日志、协议、逐题预测、检索排名、配对统计与原始计时见子目录。','输入图片、模型权重、捕获张量、特征缓存与wheel不放入返回包，仍在云端。','若状态为stopped_requires_review，请返回此结果包分析，不原地覆盖重跑。']
        (self.out/'SUMMARY.md').write_text('\n'.join(lines),encoding='utf-8')
        members={};omitted=[]
        for path in self.out.rglob('*'):
            if not path.is_file() or '__pycache__' in path.parts:continue
            if path.suffix not in ('.json','.jsonl','.md','.log','.txt'):continue
            if path.stat().st_size>40*1024*1024:omitted.append(str(path));continue
            members['batch/'+path.relative_to(self.out).as_posix()]=path
        for path in HERE.glob('*.py'):members['provenance/'+path.name]=path
        for name in ('PACKAGE_MANIFEST.json','README.md','LOCAL_VALIDATION.json'):
            if (HERE/name).exists():members['provenance/'+name]=HERE/name
        for name in ('manifest.json','samples.json'):members['coco_data/'+name]=self.a.data.resolve()/name
        manifest={name:{'sha256':sha(path),'bytes':path.stat().st_size} for name,path in members.items()}
        archive=self.a.qwen_model.resolve().parent/(self.out.name+'_results.zip');tmp=archive.with_suffix('.zip.part')
        if archive.exists() or tmp.exists():raise FileExistsError('Refusing result overwrite')
        import json
        with zipfile.ZipFile(tmp,'x',zipfile.ZIP_DEFLATED) as z:
            for name,path in sorted(members.items()):z.write(path,name)
            z.writestr('EXPORT_MANIFEST.json',json.dumps(manifest,indent=2));z.writestr('OMITTED_FILES.json',json.dumps(omitted))
        tmp.rename(archive);print('BATCH_STATUS:',self.state['status'],'\nDOWNLOAD:',archive,flush=True)

def worker(action,c):
    if action=='preflight':return preflight(c)
    if action=='identity':
        sys.path.insert(0,c['harness']);from common import verify_loaded
        save(c['output'],verify_loaded(c['candidate'],c['operator'],c['receipt']));return
    if action=='score_qwen':
        sys.path.insert(0,c['harness']);from score import read as predictions,compare
        from common import load_rows
        expected={r['id']:r for r in load_rows(c['samples']) if r['split']=='eval'}
        save(c['output'],compare(predictions(Path(c['baseline'])/'predictions.jsonl'),predictions(Path(c['candidate_output'])/'predictions.jsonl'),expected));return
    from completion_workers import dispatch
    return dispatch(action,c)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path('/mnt/workspace/v3_model_transfer'))
    p.add_argument('--qwen-model',type=Path,default=Path('/mnt/workspace/gitCode/cann/cann-learning-hub/build/Qwen2.5-VL-3B-Instruct'))
    p.add_argument('--clip-model',type=Path,default=Path('/mnt/workspace/gitCode/cann/cann-learning-hub/build/CLIP-ViT-B-32-laion2B-s34B-b79K'))
    p.add_argument('--data',type=Path,default=HERE/'data/coco2017_retrieval_100dev_1000eval')
    p.add_argument('--output',type=Path,default=Path('results/auto_completion_001'))
    p.add_argument('--device-id',type=int,default=0);p.add_argument('--timeout',type=int,default=14400)
    p.add_argument('--background',action='store_true');p.add_argument('--plan',action='store_true');p.add_argument('--worker',help=argparse.SUPPRESS);p.add_argument('--request',type=Path,help=argparse.SUPPRESS);a=p.parse_args()
    if a.worker:worker(a.worker,read(a.request));return 0
    if a.plan:
        print('CLIP: native/repeat/wrappers, 3 dev probe batches, 4 fixed candidate gates, dev+1000-image retrieval, operator+model timing. Qwen: GELU tanh, 2 candidates, AI2D+MMStar dev/control/gate/eval, AI2D operator+model timing. Existing SwiGLU not repeated.');return 0
    if os.name!='posix':raise RuntimeError('Actual batch requires Linux Ascend; local --plan only')
    for name,info in read(HERE/'PACKAGE_MANIFEST.json').items():
        path=(HERE/name).resolve()
        if not path.is_relative_to(HERE) or sha(path)!=info['sha256'] or path.stat().st_size!=info['bytes']:raise ValueError('Package modified: '+name)
    out=(a.root.resolve()/a.output).resolve()
    if not out.is_relative_to(a.root.resolve()/'results'):raise ValueError('Unsafe output')
    if a.background:
        if out.exists():raise FileExistsError(out)
        console=out.with_suffix('.console.log');console.parent.mkdir(parents=True,exist_ok=True)
        with console.open('x',encoding='utf-8') as f:
            child=subprocess.Popen([sys.executable,'-u',str(HERE/'run_completion_batch.py'),*[s for s in sys.argv[1:] if s!='--background']],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,cwd=HERE,start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1'))
        print(f'BACKGROUND_PID: {child.pid}\nLOG: {console}\nDOWNLOAD_WHEN_FINISHED: {a.qwen_model.resolve().parent/(out.name+"_results.zip")}');return 0
    import fcntl
    with (a.root.resolve()/'.transfer_batch.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('Another experiment is active; no concurrent wheel installs') from None
        batch=CompletionBatch(a);code=0
        def stop(signum,frame):raise KeyboardInterrupt(f'Received signal {signum}')
        signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
        try:batch.run()
        except BaseException:
            batch.state.update(status='stopped_requires_review',error=traceback.format_exc());print(batch.state['error'],flush=True);code=1
        finally:
            try:batch.restore()
            except BaseException:batch.state.update(status='stopped_requires_review',restoration='failed_requires_review',restoration_error=traceback.format_exc());code=1
            batch.package()
        return code
if __name__=='__main__':raise SystemExit(main())
