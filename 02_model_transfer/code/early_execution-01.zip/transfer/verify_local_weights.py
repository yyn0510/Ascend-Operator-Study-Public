"""Verify official model files and safetensors structure without loading a model."""
import argparse
import collections
import json
import math
import struct
from pathlib import Path
from common import HERE, read_json, save
from prepare_model import valid


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-path', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    root = args.model_path.resolve()
    source = read_json(HERE / 'model_source.api.json')
    files = []
    for entry in source['siblings']:
        if entry['rfilename'] == '.gitattributes':
            continue
        file = root / entry['rfilename']
        if not valid(file, entry):
            raise ValueError(f'Missing or invalid official file: {entry["rfilename"]}')
        files.append({'file': entry['rfilename'], 'bytes': file.stat().st_size,
                      'hash_type': 'sha256' if entry.get('lfs') else 'git_blob_sha1',
                      'expected_hash': entry['lfs']['sha256'] if entry.get('lfs') else entry['blobId']})
        print(f'Verified {entry["rfilename"]}', flush=True)
    index = read_json(root / 'model.safetensors.index.json')
    tensors, dtype_counts, payload_bytes = {}, collections.Counter(), 0
    widths = {'BF16': 2, 'F16': 2, 'F32': 4, 'F64': 8, 'I64': 8, 'I32': 4,
              'I16': 2, 'I8': 1, 'U8': 1, 'BOOL': 1}
    for name in sorted(set(index['weight_map'].values())):
        with (root / name).open('rb') as stream:
            header_len = struct.unpack('<Q', stream.read(8))[0]
            if not 2 <= header_len <= 100 * 1024 * 1024:
                raise ValueError('Unexpected safetensors header length')
            header = json.loads(stream.read(header_len))
        data_size = (root / name).stat().st_size - 8 - header_len
        spans = []
        for key, value in header.items():
            if key == '__metadata__':
                continue
            if key in tensors or index['weight_map'].get(key) != name:
                raise ValueError('Tensor index/shard mismatch')
            start, end = value['data_offsets']
            expected_size = math.prod(value['shape']) * widths[value['dtype']]
            if end - start != expected_size or not 0 <= start <= end <= data_size:
                raise ValueError('Tensor shape/dtype/byte-range mismatch')
            tensors[key] = name
            dtype_counts[value['dtype']] += 1
            spans.append((start, end))
        previous = 0
        for start, end in sorted(spans):
            if start != previous:
                raise ValueError('Noncontiguous or overlapping tensor payload')
            previous = end
        if previous != data_size:
            raise ValueError('Unindexed shard payload')
        payload_bytes += data_size
    if tensors != index['weight_map'] or payload_bytes != index['metadata']['total_size']:
        raise ValueError('Incomplete global tensor index')
    save(args.report, {'status': 'verified', 'model': source['id'], 'revision': source['sha'],
         'directory': str(root), 'official_files': files,
         'total_file_bytes': sum(f['bytes'] for f in files), 'tensor_count': len(tensors),
         'tensor_dtypes': dict(dtype_counts), 'tensor_payload_bytes': payload_bytes,
         'model_loaded_or_inference_run': False, 'included_in_upload_zip': False})
    print(json.dumps({'status': 'verified', 'tensor_count': len(tensors),
                      'payload_bytes': payload_bytes, 'report': str(args.report)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
