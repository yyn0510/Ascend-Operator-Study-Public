"""Offline preparation. Standard library only; never changes V3 archives."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import zipfile
from common import load_rows

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT / '文档/实验方案/候选算子筛选'
IDS = ['Grok_4_6_gelu_001_R4', 'Kimi_K3_gelu_002_R3',
       'Kimi_K3_swi_glu_003_R5', 'DeepSeek_V4_1_Flash_swi_glu_002_R4']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def candidates():
    rows = json.loads((SOURCE / '推荐候选.json').read_text(encoding='utf-8'))
    indexed = {r['candidate_id']: r for r in rows}
    result = [indexed[i] for i in IDS]
    for r in result:
        if r['passed_cases'] != 20 or r['total_cases'] != 20 or r['source']['source_issue']:
            raise ValueError(f"Invalid candidate: {r['candidate_id']}")
        base = SOURCE / '推荐源码' / r['candidate_id']
        for rel, expected in r['source']['source_files'].items():
            path = base / rel
            if not path.resolve().is_relative_to(base.resolve()) or digest(path) != expected:
                raise ValueError(f'Source hash mismatch: {path}')
    return result

def export(out, dataset=None):
    rows = candidates()
    archive = out.with_suffix('.zip')
    if out.exists() or archive.exists():
        raise FileExistsError(f'Refusing to overwrite: {out}')
    out.mkdir(parents=True)
    skeleton = ROOT / 'examples/direct_launch_example'
    def ignore(directory, names):
        excluded = {'build', 'dist', '__pycache__', '.git', 'tests', 'test.sh', 'build_and_test.sh'}
        if Path(directory).resolve() == (skeleton / 'csrc/ops').resolve():
            excluded |= {'add', 'sqrt'}
        return [n for n in names if n in excluded or n.endswith(('.egg-info', '.pyc', '.so'))]
    for r in rows:
        target = out / 'projects' / r['candidate_id']
        shutil.copytree(skeleton, target, ignore=ignore)
        original = (skeleton / 'cann_bench/__init__.py').read_text(encoding='utf-8-sig')
        prefix = original.split('# Direct function calls:', 1)
        if len(prefix) != 2:
            raise ValueError('Skeleton export marker missing')
        base = SOURCE / '推荐源码' / r['candidate_id']
        for rel in r['source']['source_files']:
            if rel.endswith('.append'):
                text = (base / rel).read_text(encoding='utf-8')
                (target / 'cann_bench/__init__.py').write_text(prefix[0].rstrip() + '\n\n' + text, encoding='utf-8')
            else:
                dst = target / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(base / rel, dst)
                assert digest(dst) == r['source']['source_files'][rel]
        (target / 'selection.json').write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding='utf-8')
    portable = [{k: r[k] for k in ['candidate_id','model','operator','trajectory','selected_round',
                                  'score','passed_cases','total_cases','avg_speedup','source']} for r in rows]
    (out / 'candidates.json').write_text(json.dumps(portable, ensure_ascii=False, indent=2), encoding='utf-8')
    for name in ['common.py', 'host.py', 'capture.py', 'numerics.py', 'run_npu.py',
                 'replay_npu.py', 'benchmark_npu.py', 'build_candidate.py', 'verify_benchmark.py',
                 'review_failure.py', 'prepare_protocol.py', 'prepare_model.py', 'prepare_ai2d.py',
                 'score.py', 'verify_bundle.py', 'protocol.template.json', 'model_source.api.json', 'README.md',
                 'CANNLab操作指南.md', 'requirements-model.txt', 'requirements-data.txt']:
        shutil.copyfile(HERE / name, out / name)
    # Exact copies, never modify tasks/src in the project. No historical runs/tokens.
    original = out / 'original_benchmark'
    shutil.copytree(ROOT / 'src/kernel_eval', original / 'src/kernel_eval',
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for operator in ('gelu', 'swi_glu'):
        shutil.copytree(ROOT / 'tasks/level1' / operator, original / 'tasks/level1' / operator,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for name in ['pyproject.toml', 'requirements.txt', 'LICENSE', 'VERSION']:
        shutil.copyfile(ROOT / name, original / name)
    if dataset:
        samples = dataset / 'samples.jsonl'
        load_rows(samples)
        shutil.copytree(dataset, out / 'data/ai2d_100dev_1000eval')
    # Linux shell scripts in the isolated copies need LF; original skeleton is unchanged.
    for script in out.rglob('*.sh'):
        script.write_bytes(script.read_bytes().replace(b'\r\n',b'\n'))
    files = {p.relative_to(out).as_posix(): digest(p) for p in sorted(out.rglob('*')) if p.is_file()}
    (out / 'files.sha256.json').write_text(json.dumps(files, ensure_ascii=False, indent=2), encoding='utf-8')
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file():
                z.write(p, p.relative_to(out))
    return archive

def validate_samples(path):
    return load_rows(path)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--export', type=Path)
    parser.add_argument('--samples', type=Path)
    parser.add_argument('--dataset', type=Path, help='Include the prepared dataset directory in upload ZIP')
    args = parser.parse_args()
    rows = candidates()
    print(json.dumps({'checked_candidates': len(rows), 'source_files': 20}, ensure_ascii=False))
    if args.samples:
        print(json.dumps({'checked_samples': len(validate_samples(args.samples))}))
    if args.export:
        print(export(args.export.resolve(), args.dataset.resolve() if args.dataset else None))
