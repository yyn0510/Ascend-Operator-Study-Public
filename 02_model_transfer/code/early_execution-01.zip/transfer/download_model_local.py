"""Local-only ranged download helper. Does not modify the experimental upload ZIP."""
import argparse
import concurrent.futures
import json
import time
import urllib.request
from pathlib import Path
from common import HERE, read_json, save, sha256
from prepare_model import valid

CHUNK = 16 * 1024 * 1024


def fetch_chunk(url, start, end, directory):
    target = directory / f'{start:012d}-{end:012d}.chunk'
    receipt = target.with_suffix('.sha256')
    size = end - start + 1
    if target.is_file() and target.stat().st_size == size and receipt.is_file():
        if sha256(target) == receipt.read_text().strip():
            return target
    for attempt in range(5):
        partial = target.with_suffix('.part')
        try:
            request = urllib.request.Request(
                url + f'?download=true&range_start={start}',
                headers={'Range': f'bytes={start}-{end}', 'Accept-Encoding': 'identity'})
            with urllib.request.urlopen(request, timeout=45) as response:
                expected = f'bytes {start}-{end}/'
                if response.status != 206 or not response.headers.get('Content-Range', '').startswith(expected):
                    raise ValueError('Server did not honor the exact requested byte range')
                with partial.open('wb') as out:
                    remaining = size
                    while remaining:
                        block = response.read(min(1024 * 1024, remaining))
                        if not block:
                            raise ValueError('Incomplete ranged response')
                        out.write(block)
                        remaining -= len(block)
            partial.replace(target)
            receipt.write_text(sha256(target), encoding='ascii')
            return target
        except Exception as exc:
            if attempt == 4:
                raise RuntimeError(f'Chunk {start}-{end} failed: {type(exc).__name__}: {exc}') from exc
            time.sleep(min(2 ** attempt, 8))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    source = read_json(HERE / 'model_source.api.json')
    a.output = a.output.resolve()
    a.output.mkdir(parents=True, exist_ok=True)
    if read_json(a.output / 'download_source.json') != source:
        raise ValueError('Destination must contain the matching prepared model metadata')
    for row in source['siblings']:
        name = row['rfilename']
        if not name.endswith('.safetensors'):
            continue
        target = a.output / name
        if valid(target, row):
            print(f'Already verified {name}', flush=True)
            continue
        if target.exists():
            raise ValueError('Existing complete weight has a different hash')
        directory = a.output.parent / '.download_chunks' / row['lfs']['sha256']
        directory.mkdir(parents=True, exist_ok=True)
        ranges = [(start, min(start + CHUNK, row['size']) - 1) for start in range(0, row['size'], CHUNK)]
        url = f'https://huggingface.co/{source["id"]}/resolve/{source["sha"]}/{name}'
        print(f'Downloading {name}: {row["size"]} bytes, {len(ranges)} ranges', flush=True)
        done, last_print, started = 0, 0., time.monotonic()
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            futures = {pool.submit(fetch_chunk, url, start, end, directory): end - start + 1
                       for start, end in ranges}
            for future in concurrent.futures.as_completed(futures):
                future.result()
                done += futures[future]
                now = time.monotonic()
                if now - last_print >= 10 or done == row['size']:
                    print(json.dumps({'file': name, 'completed_bytes': done, 'total_bytes': row['size'],
                         'percent': round(100 * done / row['size'], 1),
                         'elapsed_seconds': round(now - started, 1)}), flush=True)
                    last_print = now
        assembled = target.with_suffix('.assembling')
        with assembled.open('wb') as out:
            for start, end in ranges:
                part = directory / f'{start:012d}-{end:012d}.chunk'
                with part.open('rb') as stream:
                    while block := stream.read(1024 * 1024):
                        out.write(block)
        if not valid(assembled, row):
            raise ValueError(f'Full official SHA256 verification failed: {name}')
        assembled.rename(target)
        print(f'Official SHA256 verified: {name}', flush=True)
        # Remove only this helper's exact generated files, within its checked cache root.
        cache_root = (a.output.parent / '.download_chunks').resolve()
        if not directory.resolve().is_relative_to(cache_root):
            raise ValueError('Chunk cleanup path escaped the intended cache')
        for start, end in ranges:
            part = directory / f'{start:012d}-{end:012d}.chunk'
            for file in (part, part.with_suffix('.sha256'), part.with_suffix('.part')):
                if file.is_file():
                    file.unlink()
        if not any(directory.iterdir()):
            directory.rmdir()
    save(a.output / 'download_status.json', {'metadata_only': False, 'revision': source['sha'],
         'all_weights_verified': all(valid(a.output / r['rfilename'], r) for r in source['siblings']
                                     if r['rfilename'].endswith('.safetensors'))})


if __name__ == '__main__':
    main()
