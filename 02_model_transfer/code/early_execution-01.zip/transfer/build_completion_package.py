"""Build verified offline uploads for the remaining supplemental experiments."""
import hashlib
import json
import os
from pathlib import Path
import py_compile
import shutil
import subprocess
import sys
import zipfile

EXP=Path(__file__).resolve().parent;PACKAGE=EXP/'completion_20261016';DATA=EXP/'data/coco2017_retrieval_100dev_1000eval'
sys.path.insert(0,str(PACKAGE))
from completion_utils import save,sha
from prepare_coco import verify

def main():
    if (EXP/'completion_package_receipt.json').exists():raise FileExistsError('Refusing to overwrite a completed delivery')
    data=verify(DATA)
    for p in PACKAGE.glob('*.py'):py_compile.compile(str(p),doraise=True)
    result=subprocess.run([sys.executable,str(PACKAGE/'test_completion.py')],cwd=PACKAGE,capture_output=True,text=True,encoding='utf-8',env=dict(os.environ,PYTHONIOENCODING='utf-8'))
    (PACKAGE/'LOCAL_TESTS.log').write_text(result.stdout+result.stderr,encoding='utf-8')
    if result.returncode:raise RuntimeError(result.stdout+result.stderr)
    save(PACKAGE/'LOCAL_VALIDATION.json',{'passed':True,'tests':13,'checks':'CPU actual HF CLIP forward with unequal modalities, 24 GELU targets and tanh forwarding, both norm calls, timed-counter removal, restoration, retrieval ranks/ties/groups, fixed expected denominator, nonfinite rejection, timing blocks, complete orchestration, failure export hashes','npu_execution':'not tested locally; requires uploaded batch','dataset_verified':data,'source_sha256':{p.name:sha(p) for p in PACKAGE.glob('*.py')}})
    manifest={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in PACKAGE.iterdir() if p.is_file() and p.name!='PACKAGE_MANIFEST.json'}
    save(PACKAGE/'PACKAGE_MANIFEST.json',manifest)
    scripts=EXP/'completion_20261016.zip';datazip=EXP/'completion_coco_20261016.zip'
    pending=scripts.with_suffix('.zip.building')
    with zipfile.ZipFile(pending,'x',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(PACKAGE.iterdir()):
            if p.is_file():z.write(p,p.name)
    pending.replace(scripts)
    if not datazip.exists():
        with zipfile.ZipFile(datazip,'x',zipfile.ZIP_STORED) as z:
            for name in ('manifest.json','samples.json'):z.write(DATA/name,'data/'+DATA.name+'/'+name)
            for p in sorted((DATA/'images').glob('*.jpg')):z.write(p,'data/'+DATA.name+'/images/'+p.name)
    for archive in (scripts,datazip):
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:raise ValueError('Corrupt upload ZIP')
    with zipfile.ZipFile(scripts) as z:
        for n,v in manifest.items():
            if hashlib.sha256(z.read(n)).hexdigest()!=v['sha256']:raise ValueError('Script ZIP mismatch')
    with zipfile.ZipFile(datazip) as z:
        for r in json.loads((DATA/'samples.json').read_text(encoding='utf-8')):
            if hashlib.sha256(z.read('data/'+DATA.name+'/'+r['image'])).hexdigest()!=r['image_sha256']:raise ValueError('Data ZIP mismatch')
    launcher='''"""Verify two uploads, extract safely, and start the detached remaining-experiments batch."""
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import zipfile

HASHES=__HASHES__
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def extract(archive,target):
    target.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for member in z.infolist():
            path=(target/member.filename).resolve()
            if member.is_dir() or not path.is_relative_to(target.resolve()):raise ValueError('Unexpected ZIP path')
            if path.exists():
                with z.open(member) as source:
                    h=hashlib.sha256()
                    for b in iter(lambda:source.read(1024*1024),b''):h.update(b)
                if sha(path)!=h.hexdigest():raise FileExistsError('Refusing to overwrite different file: '+str(path))
                continue
            path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.extracting')
            with z.open(member) as source,tmp.open('xb') as output:
                for b in iter(lambda:source.read(1024*1024),b''):output.write(b)
            tmp.rename(path)
def main():
    if os.name!='posix':raise RuntimeError('Run this launcher on the CANNLab Linux NPU instance')
    upload=Path(__file__).resolve().parent
    for name,h in HASHES.items():
        print('VERIFY UPLOAD:',name,flush=True)
        if not (upload/name).is_file():raise FileNotFoundError('Upload missing: '+str(upload/name))
        if sha(upload/name)!=h:raise ValueError('Incomplete or modified upload: '+name)
    target=Path('/mnt/workspace/v3_completion_001')
    for name in HASHES:extract(upload/name,target)
    subprocess.run([sys.executable,str(target/'run_completion_batch.py'),'--qwen-model',str(upload/'Qwen2.5-VL-3B-Instruct'),'--clip-model',str(upload/'CLIP-ViT-B-32-laion2B-s34B-b79K'),'--background'],check=True)
if __name__=='__main__':main()
'''
    launcher=launcher.replace('__HASHES__',repr({p.name:sha(p) for p in (scripts,datazip)}))
    upload=EXP/'上传_剩余实验_20261016';upload.mkdir(exist_ok=True)
    (upload/'start_completion.py').write_text(launcher,encoding='utf-8');py_compile.compile(str(upload/'start_completion.py'),doraise=True)
    for p in (scripts,datazip):shutil.copyfile(p,upload/p.name)
    save(EXP/'completion_package_receipt.json',{'upload_directory':str(upload),'script_files':len(manifest)+1,'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in upload.iterdir() if p.is_file()},'local_tests_passed':13,'npu_status':'pending user execution'})
    print(json.dumps(json.loads((EXP/'completion_package_receipt.json').read_text(encoding='utf-8')),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
