"""Verify both uploads, extract safely, and start the detached NPU pilot."""
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import zipfile

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def extract(archive,directory):
    directory.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for member in z.infolist():
            p=(directory/member.filename).resolve()
            if not p.is_relative_to(directory.resolve()) or member.is_dir():raise ValueError('Unexpected ZIP path')
            if p.exists():
                with z.open(member) as f:
                    h=hashlib.sha256()
                    for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
                if sha(p)!=h.hexdigest():raise FileExistsError('Existing different file; refusing overwrite: '+str(p))
                continue
            p.parent.mkdir(parents=True,exist_ok=True)
            tmp=p.with_suffix(p.suffix+'.extracting')
            with z.open(member) as source,tmp.open('wb') as output:
                for b in iter(lambda:source.read(1024*1024),b''):output.write(b)
            tmp.rename(p)
if __name__=='__main__':
    if os.name!='posix':raise RuntimeError('Run this launcher on the Linux NPU server')
    upload=Path(__file__).resolve().parent
    required={'clip_extension_20261016.zip': 'df32f3ecf0c7c3853f022f0336d00aebda747f720da9864b221d98fe4fe0a352', 'clip_weights_20261016.zip': '0510347cdb3cdc1975a05b77acebc03747326828b5c581a082ad5f100939221c'}
    for name,expected in required.items():
        p=upload/name
        if not p.is_file():raise FileNotFoundError('Upload missing: '+str(p))
        print('VERIFY UPLOAD:',name,flush=True)
        if sha(p)!=expected:raise ValueError('Incomplete or changed upload: '+name)
    target=Path('/mnt/workspace/v3_clip_extension')
    extract(upload/'clip_extension_20261016.zip',target)
    extract(upload/'clip_weights_20261016.zip',upload)
    subprocess.run([sys.executable,str(target/'run_extension_batch.py'),'--model-path',str(upload/'CLIP-ViT-B-32-laion2B-s34B-b79K'),'--background'],check=True)
