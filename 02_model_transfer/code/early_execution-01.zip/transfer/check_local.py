"""Check preparation artifacts, software tests, and an optional exported bundle."""
import argparse
import ast
import json
import subprocess
import sys
import zipfile
from pathlib import Path
from common import load_rows, read_json, save, sha256
from prepare import candidates

HERE = Path(__file__).resolve().parent


def check_bundle(bundle):
    hashes = read_json(bundle / 'files.sha256.json')
    for rel, expected in hashes.items():
        if sha256(bundle / rel) != expected:
            raise ValueError(f'Bundle file changed: {rel}')
    with zipfile.ZipFile(bundle.with_suffix('.zip')) as z:
        if z.testzip() is not None:
            raise ValueError('Broken ZIP')
        import hashlib
        for rel, expected in hashes.items():
            if hashlib.sha256(z.read(rel)).hexdigest() != expected:
                raise ValueError(f'ZIP differs: {rel}')
        if any('/ops/add/' in n or '/ops/sqrt/' in n for n in z.namelist()):
            raise ValueError('Unexpected example operators included')
    return len(hashes)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bundle', type=Path)
    p.add_argument('--report', type=Path)
    a = p.parse_args()
    files = list(HERE.glob('*.py')) + list((HERE / 'local_tests').glob('*.py'))
    for file in files:
        ast.parse(file.read_text(encoding='utf-8'), filename=str(file))
    selected = candidates()
    data = HERE / 'data/ai2d_100dev_1000eval/samples.jsonl'
    rows = load_rows(data)
    dataset = {split: {'questions': sum(r['split'] == split for r in rows),
                      'image_groups': len({r['group_id'] for r in rows if r['split'] == split})}
               for split in ('dev', 'eval')}
    tests = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', str(HERE / 'local_tests'), '-v'],
                           cwd=HERE, capture_output=True, text=True, encoding='utf-8')
    print(tests.stdout + tests.stderr)
    if tests.returncode:
        raise SystemExit(tests.returncode)
    result = {'status': 'passed', 'candidate_count': len(selected), 'source_files': 20,
              'python_files_syntax_checked': len(files), 'dataset': dataset,
              'samples_sha256': sha256(data), 'software_tests': (tests.stdout + tests.stderr).strip(),
              'bundle_files_checked': check_bundle(a.bundle) if a.bundle else None,
              'npu_execution': 'not tested', 'real_model_inference': 'not tested',
              'original_v3_archives': 'read only, unchanged by these preparation commands'}
    if a.report:
        save(a.report, result)
    print(json.dumps({k: v for k, v in result.items() if k != 'software_tests'}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
