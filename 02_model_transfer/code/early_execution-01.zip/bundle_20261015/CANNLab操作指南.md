# CANNLab上机操作指南

本指南对应2026-10-15更新的准备包。代码经过本地软件测试，**没有完成NPU编译、真实模型推理或NPU性能验证**。平台可用后按顺序联调，不把本地测试结果当成实验结果。

## 1. 上传与环境确认

上传 `bundle_20261015.zip`，解压后进入含 `run_npu.py` 的包根目录。包已包含四个候选工程、原20例任务及评测框架副本、100题开发集和1000题正式子集。

先执行 `python verify_bundle.py` 检查上传是否完整；这一步不需要torch或NPU。

先记录环境，不直接安装或升级torch/CANN：

```bash
python run_npu.py --environment-only --output results/environment_001
python -m pip show torch torch-npu transformers torchvision
npu-smi info
```

确认CANN、驱动、torch、torch_npu组合可用，再按需要安装模型依赖：

```bash
python -m pip install -r requirements-model.txt
```

此文件不固定torch或torch_npu；其依赖解析仍需检查，安装前先看平台现有环境。参考宿主实现为Transformers 4.51.3；若平台必须使用其他版本，重新核查模块、激活公式、生成接口及依赖，不能直接替换版本号后继续正式实验。原20例评测可能还需要 `original_benchmark/pyproject.toml` 中的非torch依赖，应在环境确认后按缺项补齐，避免直接安装整份文件而升级NPU运行栈。

环境信息确认后再确定 `--soc` 的准确编译目标。指南中的 `<确认后的SoC>` 是待替换参数，不要照抄，更不要只凭“A3”字样猜编译值。

## 2. 下载固定权重，运行原模型

权重没有打入ZIP，也没有在本地Windows下载。官方revision已固定在 `model_source.api.json`，服务器执行：

```bash
python prepare_model.py --output models/Qwen2.5-VL-3B-Instruct
```

下载支持权重分片续传，校验官方LFS SHA256；普通配置和分词器文件校验Git blob哈希。已有完整文件哈希不符时停止，不覆盖。需要网络；网络受限时可以在其他位置下载相同revision再搬运，并用同一命令核对文件。

先检查模型实际模块路径：

```bash
python run_npu.py --protocol protocol.template.json --model-path models/Qwen2.5-VL-3B-Instruct --inspect --output results/host_inventory_001
```

再跑1题、10题原生开发推理，均使用完整样本清单加数量限制，不用pilot文件冻结正式协议：

```bash
python run_npu.py --protocol protocol.template.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --max-samples 1 --mode native --output results/native_dev1
python run_npu.py --protocol protocol.template.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --max-samples 10 --mode native --output results/native_dev10
```

检查 `predictions.jsonl` 的图文回答和字母解析。原生模式不改写forward、不安装调用计数钩子。此阶段是开发检查，不能公布为正式任务分数。

## 3. 第一份GELU的编译和原20例

候选先使用 `Grok_4_6_gelu_001_R4`：

```bash
python build_candidate.py --candidate-id Grok_4_6_gelu_001_R4 --soc <确认后的SoC> --output results/build_grok_gelu
python verify_benchmark.py --candidate-id Grok_4_6_gelu_001_R4 --operator gelu --receipt results/build_grok_gelu/receipt.json --output results/cases_grok_gelu
```

构建脚本只操作已导出的独立工程，保留原生成内核。它记录源码、wheel和已安装扩展二进制之间的关系，并用新进程验证导入身份。原20例调用原评测框架的已安装包模式，不重新构建，不提交云端平台任务。

实际通过数查看 `cases_grok_gelu/reports/` 的原始报告；退出码为0本身不代表20/20。失败时保留报告，先判断工具链/接口问题还是候选问题，不自动修改生成算法。

## 4. 采集原模型真实输入，做数值回放

```bash
python run_npu.py --protocol protocol.template.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --max-samples 10 --operator gelu --mode native --capture --output results/capture_gelu
```

采集运行会安装诊断钩子，但不改写原计算。GELU保留实际激活输入输出；SwiGLU保留原生gate/up投影输出和down_proj真正收到的张量。默认采集早/中/晚三个语言层，区分prefill和decode，受文件数及总字节上限约束。检查 `inputs/coverage.json` 和 `index.jsonl`，被预算截断不能称为覆盖完成。

编辑一份开发协议，如 `protocol.dev.json`，保留模板，并根据dtype和开发检查填写 `tolerances`。格式如下，其中数值须由开发验证确定，不能为了候选通过随意放宽：

```json
{"gelu": {"bfloat16": {"atol": "填写开发阶段确定的数值", "rtol": "填写开发阶段确定的数值"}}, "swi_glu": {}}
```

这是结构示例，字符串占位符不能直接运行。实际值必须为非负有限数。GELU近似模式从采集张量的属性读取，不能用另一种近似替代。

```bash
python replay_npu.py --protocol protocol.dev.json --inputs results/capture_gelu/inputs --operator gelu --candidate-id Grok_4_6_gelu_001_R4 --receipt results/build_grok_gelu/receipt.json --output results/replay_grok_gelu_dev
python run_npu.py --protocol protocol.dev.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --max-samples 10 --operator gelu --mode wrapper --output results/wrapper_gelu_dev10
python run_npu.py --protocol protocol.dev.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --max-samples 10 --operator gelu --mode candidate --candidate-id Grok_4_6_gelu_001_R4 --receipt results/build_grok_gelu/receipt.json --output results/grok_gelu_dev10
```

比较原生、包装和候选开发结果。单个候选失败时保留失败，不更换候选名单。

## 5. 扩展到SwiGLU和其余候选

另一个GELU及两个SwiGLU的固定ID见README。每次换候选都重新安装对应wheel并启动新Python进程，不能在同一进程加载同名内核的多个版本。

SwiGLU首先采集全语言层范围中的早/中/晚层实际输入：

```bash
python run_npu.py --protocol protocol.dev.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --max-samples 10 --operator swi_glu --mode native --capture --output results/capture_swiglu
```

编译、原20例、回放流程与GELU相同，operator改为 `swi_glu`。开发接入可以加 `--scope first` 先只替换第一层；正式前必须检查全语言层范围。SwiGLU只替换门控乘法，前后线性层保留。拼接开销由包装对照和性能脚本体现。

## 6. 冻结正式协议

正式前在开发协议中填好两个算子的实际dtype误差门槛；检查开发集覆盖、模块列表、数据清单和接入对照。所有候选使用相同宿主和同算子门槛。

```bash
python run_npu.py --protocol protocol.dev.json --model-path models/Qwen2.5-VL-3B-Instruct --inspect --output results/host_inventory_final
python prepare_protocol.py --template protocol.dev.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --inventory results/host_inventory_final/inventory.json --model-revision 66285546d2b821cf421d4f5eb2576359d3770cd3 --output protocol.frozen.json
```

冻结记录权重/分词器/处理器文件哈希、环境、精确模块列表、脚本哈希、数据清单及误差门槛。冻结后任何改动需产生独立实验版本，不直接编辑原冻结文件。`quality_margin_percentage_points` 可留空，此时只报告差值和区间，不作非劣性/等价判断。

用冻结协议对每份候选重新执行真实输入回放，确认与同一模型、数据和环境对应。示例：

```bash
python replay_npu.py --protocol protocol.frozen.json --inputs results/capture_gelu/inputs --operator gelu --candidate-id Grok_4_6_gelu_001_R4 --receipt results/build_grok_gelu/receipt.json --output results/replay_grok_gelu_frozen
```

采集来自完整 `samples.jsonl` 的开发子集。若冻结前更改dtype、图像处理或其他参考设置，需要重新采集，旧采集不能混用。

## 7. 正式质量评估

运行一次共用原生基线，再运行通过前置检查的候选：

```bash
python run_npu.py --protocol protocol.frozen.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --split eval --mode native --output results/native_eval
python run_npu.py --protocol protocol.frozen.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --split eval --operator gelu --mode candidate --candidate-id Grok_4_6_gelu_001_R4 --receipt results/build_grok_gelu/receipt.json --replay-report results/replay_grok_gelu_frozen/replay.json --output results/grok_gelu_eval
python score.py --baseline results/native_eval/predictions.jsonl --candidate results/grok_gelu_eval/predictions.jsonl --samples data/ai2d_100dev_1000eval/samples.jsonl --output results/grok_gelu_quality.json
```

其余候选同样执行。正式评估不允许数量限制或第一层范围。评分检查完整1000题，不会用少量完成题冒充全任务。区间按图像分组的配对bootstrap计算；一图多题保留题目级准确率。答案解析失败记错误，单列数量。

## 8. 中断和执行错误怎么处理

每题结果及时保存。异常样例写入 `errors.jsonl` 后停止，避免设备错误连续污染后续题目。先读日志分类：

```bash
python review_failure.py --run results/grok_gelu_eval --kind infrastructure --reason "根据日志填写平台中断的证据"
```

环境恢复后，用原来完全相同的运行命令加 `--resume`，已成功完成的题不重复，平台中断题重试。若证据表明是实现问题，分类改为 `implementation`，该题保存为失败并计入分母，续跑时跳过。已分类的记录不覆盖。进程被直接杀死且没有错误记录时，同配置加 `--resume` 即可；若末行损坏，程序会报错，先保留原文件并检查，不能静默删行。

## 9. 独立性能测量

每份候选单独运行。算子计时自动在同一批张量上交替测原计算、包装和候选：

```bash
python benchmark_npu.py --kind operator --protocol protocol.frozen.json --operator gelu --candidate-id Grok_4_6_gelu_001_R4 --receipt results/build_grok_gelu/receipt.json --replay-report results/replay_grok_gelu_frozen/replay.json --inputs results/capture_gelu/inputs --output results/grok_gelu_operator_perf
python benchmark_npu.py --kind model --protocol protocol.frozen.json --operator gelu --candidate-id Grok_4_6_gelu_001_R4 --receipt results/build_grok_gelu/receipt.json --replay-report results/replay_grok_gelu_frozen/replay.json --model-path models/Qwen2.5-VL-3B-Instruct --samples data/ai2d_100dev_1000eval/samples.jsonl --output results/grok_gelu_model_perf
```

开发阶段可显式加 `--development-only` 使用未冻结协议，其结果不混入正式表。

计时关闭采集和诊断计数，包含Python发射、包装和实际拼接成本，采用NPU同步的墙钟耗时，**不声称是纯硬件kernel耗时**。完整模型分别测prefill和固定token的decode；decode每次使用新KV cache，prefill准备在decode计时外。各模式消费相同原生token序列，避免输出长度或token变化混淆比较。该手动decode路径仍须上机核对位置编码和cache行为。

数据预处理和CPU到NPU输入搬运在计时外；prefill包含视觉处理、语言前向及输出投影；decode包含逐步模型调用和相同的生成输入准备。目标计算与完整模型均输出每工作负载、每重复块的原始值及中位数/波动。大幅波动时先查共享设备干扰，不只挑最快一次。

正式结果至少保存：环境、配置、源码/wheel/二进制身份、原20例报告、回放报告、逐题预测、质量比较、原始计时和汇总。任何减速或失败按实记录。
