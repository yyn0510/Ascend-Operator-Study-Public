# V3真实模型补充实验：本地准备包

更新：2026-10-15。范围：Qwen2.5-VL-3B-Instruct，GELU/SwiGLU各两份固定候选。保留V3原始归档和公共评测框架。

**当前已完成本地数据、脚本和打包准备；NPU编译、真实宿主推理及性能行为尚未验证。** 这是一套待上机联调的准备包，不是已经取得真实模型结果的实验包。

本地20项软件测试通过，包含随机极小Qwen网络的模块接入/生成接口及真实处理器检查；这些测试不使用正式权重，也不执行生成的Ascend C内核。核查记录见源码目录的 `local_validation_20261015.json` 和打包后检查报告。

## 先看什么

- 上机顺序及命令：[CANNLab操作指南](CANNLab操作指南.md)。首次只跑原模型和一份GELU。
- 总体范围：[分阶段实施规划](../../文档/实验方案/真实模型补充实验-分阶段实施规划.md)（源码目录内可用；上传包以本说明和操作指南为准）。
- 实验设置：[协议模板](protocol.template.json)。模板是draft；实际环境、模块范围和误差门槛需开发检查后冻结。

## 已准备的内容

| 内容 | 本地状态 | 还需NPU确认 |
|---|---|---|
| 四份固定源码、20个源码文件 | 来源和哈希可核查 | 当前工具链能否编译 |
| 四个独立构建工程 | 可导出，保留原生成算法 | SoC目标、安装和二进制加载 |
| AI2D | 100题开发集＋1000题正式子集，图像隔离 | 原模型推理及答案解析行为 |
| 原生/包装/候选三路径 | 小张量测试 | 实际模块位置、实际dtype/shape和数值误差 |
| 采集与回放 | 原生中间张量采集、分层/阶段限额、哈希索引 | 实际输入覆盖和误差门槛 |
| 质量评估 | 固定分母、完整样本检查、图像分组配对区间 | 真实预测 |
| 独立性能入口 | 预热、同步、重复块、固定token和新cache | 实际NPU计时、cache和位置编码行为 |
| 固定模型来源 | 官方revision与文件校验清单；小配置已核查 | 权重下载与宿主加载 |

## 四份固定候选

| ID | 原平台精度 | 原平台分数 | 原基准加速比 |
|---|---:|---:|---:|
| `Grok_4_6_gelu_001_R4` | 20/20 | 63.631 | 0.481× |
| `Kimi_K3_gelu_002_R3` | 20/20 | 62.500 | 0.442× |
| `Kimi_K3_swi_glu_003_R5` | 20/20 | 79.883 | 1.701× |
| `DeepSeek_V4_1_Flash_swi_glu_002_R4` | 20/20 | 78.651 | 1.609× |

四份均取自已有筛选结果，不根据真实任务结果更换。Kimi GELU使用已核对哈希的实际提交工程，原文本差异保留在来源记录中。上述加速比不代表相对Qwen原实现的加速。

## 数据来源和口径

下载[AI2D公开整理版](https://huggingface.co/datasets/lmms-lab-encoder/ai2d)，revision为 `c83a9b9692933aff8349157c88a413df9d02c4e5`；两个Parquet分片均按发布方LFS SHA256校验。原项目见[AI2图表理解数据集](https://prior.allenai.org/projects/diagram-understanding)。

该整理版只有test划分，共3088题。本准备从中保留100题开发、1000题评估，属于**内部固定子集比较，不是官方完整测试成绩**。按解码后的RGB像素和尺寸识别到814组图像；开发100题来自27组，正式1000题来自256组，两边无相同像素图像。近重复但像素不同的图无法通过此检查排除。

文件在 `data/ai2d_100dev_1000eval/`：

- `samples.jsonl`：完整固定清单，含split、group_id、图像哈希、选项、答案及发布版行号。
- `pilot10.jsonl`：10题开发联调清单；正式冻结和采集仍使用完整samples清单加 `--max-samples 10`。
- `dataset_manifest.json`：版本、分片哈希、抽样种子、保留图像组和转换说明。
- `answer_mapping_audit.json`：10题原始索引到字母的映射抽查材料。
- `images/`：转为RGB后无损PNG保存；没有缩放或叠加标注。

源答案是从0开始的数字字符串，转换为A/B/C等字母，保留选项顺序。正式区间按图像组重采样，准确率仍按题计算。原生/候选用相同提示、输入处理和贪心规则；运行失败与无效答案不会从分母删除。

## 脚本入口

| 文件 | 用途 |
|---|---|
| `prepare.py` | 核对四候选、导出独立工程和完整ZIP |
| `prepare_ai2d.py` | 下载固定AI2D分片并转换；已有PNG/JSONL时不需pyarrow |
| `prepare_model.py` | 在服务器下载固定revision的权重/处理器；分片续传和校验 |
| `prepare_protocol.py` | 开发检查后冻结环境、权重、模块、数据、脚本和门槛 |
| `build_candidate.py` | 构建并安装一份候选，记录源码/wheel/加载二进制身份 |
| `verify_benchmark.py` | 用原评测框架副本复跑原20例，不提交云端任务 |
| `run_npu.py` | 环境、模块清点、开发采集及质量预测；支持同配置续跑 |
| `replay_npu.py` | 对比真实原生张量与包装/候选输出 |
| `benchmark_npu.py` | 独立算子及整模型计时；包含适配与Python发射成本 |
| `review_failure.py` | 依据日志区分实现错误与平台中断，保留审查记录 |
| `score.py` | 检查完整样本配对、评分及图像分组置信区间 |
| `check_local.py` | 本地软件、数据和打包完整性检查 |

真正原生模式不改写forward。采集模式仅在开发阶段安装hook。SwiGLU采集原生gate/up及down_proj实际输入，其参考语义与V3 golden中的FP32升精度计算分别保留；原20例和宿主回放是两项独立检查。

模型侧只替换指定计算，GELU保留前后线性层；SwiGLU保留gate/up/down投影。两路拼接等接入开销计入实际性能，不改写原生成内核来争取通过。

## 本地检查和导出

在源码目录执行：

```powershell
# 本机隔离依赖只为本地小张量/Parquet测试；不会放进Linux上传包。
$env:PYTHONPATH = Join-Path (Get-Location) '.local_deps'
python check_local.py --report local_validation_20261015.json
python prepare.py --samples data/ai2d_100dev_1000eval/samples.jsonl
python prepare.py --export bundle_20261015 --dataset data/ai2d_100dev_1000eval
python check_local.py --bundle bundle_20261015 --report local_validation_bundle_20261015.json
```

导出拒绝覆盖旧目录或ZIP。新包包含数据和原评测任务/框架副本，不含原始历史实验、访问凭据、Windows依赖或模型权重。`files.sha256.json`核对每个导出文件。旧 `bundle_20261014` 保留，它不适用本版命令。

质量脚本不输出正式性能数据。性能脚本采用NPU同步墙钟耗时，关闭采集与诊断计数，分别测目标计算、prefill和固定原生token的decode；不是纯硬件kernel计时，不替代任务准确率评估。
