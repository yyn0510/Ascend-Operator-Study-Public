/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void sigmoid_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileLength)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileLength * sizeof(T));
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileLength * sizeof(T));

    AscendC::TQue<AscendC::QuePosition::VECCALC, PIPELINE_DEPTH> floatQueue1;
    AscendC::TQue<AscendC::QuePosition::VECCALC, PIPELINE_DEPTH> floatQueue2;
    if constexpr (!std::is_same<T, float>::value) {
        pipe.InitBuffer(floatQueue1, PIPELINE_DEPTH, tileLength * sizeof(float));
        pipe.InitBuffer(floatQueue2, PIPELINE_DEPTH, tileLength * sizeof(float));
    }

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - AscendC::GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    if (currentBlockLength <= 0) return;

    int64_t elementNumPerTile = tileLength;
    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();
        if constexpr (std::is_same<T, float>::value) {
            AscendC::Sigmoid(yLocal, xLocal, elementNumPerTile);
        } else {
            auto f1 = floatQueue1.AllocTensor<float>();
            auto f2 = floatQueue2.AllocTensor<float>();
            AscendC::Cast(f1, xLocal, AscendC::RoundMode::CAST_NONE, elementNumPerTile);
            AscendC::Sigmoid(f2, f1, elementNumPerTile);
            AscendC::Cast(yLocal, f2, AscendC::RoundMode::CAST_RINT, elementNumPerTile);
            floatQueue1.FreeTensor(f1);
            floatQueue2.FreeTensor(f2);
        }
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailTileElementNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();
        if constexpr (std::is_same<T, float>::value) {
            AscendC::Sigmoid(yLocal, xLocal, tailTileElementNum);
        } else {
            auto f1 = floatQueue1.AllocTensor<float>();
            auto f2 = floatQueue2.AllocTensor<float>();
            AscendC::Cast(f1, xLocal, AscendC::RoundMode::CAST_NONE, tailTileElementNum);
            AscendC::Sigmoid(f2, f1, tailTileElementNum);
            AscendC::Cast(yLocal, f2, AscendC::RoundMode::CAST_RINT, tailTileElementNum);
            floatQueue1.FreeTensor(f1);
            floatQueue2.FreeTensor(f2);
        }
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    int64_t ubBytesPerElem;
    if (dtypeSize == 4) {
        ubBytesPerElem = 16 + 8;
    } else {
        ubBytesPerElem = 24 + 8;
    }
    int64_t tileLength = ubSize / ubBytesPerElem;
    tileLength = (tileLength / 32) * 32;
    if (tileLength < 256) tileLength = 256;
    return std::make_tuple(numBlocks, blockLength, tileLength);
}

extern "C" {
void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileLength, void* stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileLength);
}
void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileLength, void* stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileLength);
}
void launch_sigmoid_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileLength, void* stream)
{
    sigmoid_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileLength);
}
}
