/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file sigmoid_kernel.cpp
 * \brief Sigmoid kernel, tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t UB_RESERVED = 2048;
constexpr static int64_t TILE_ALIGN = 256;
constexpr static int64_t MIN_ELEMS_PER_CORE = 512;
constexpr static float SIGMOID_CLIP = 87.0f;

__aicore__ inline void SigmoidFp32(const AscendC::LocalTensor<float> &dst, const AscendC::LocalTensor<float> &src,
                                   const AscendC::LocalTensor<float> &tmpA, const AscendC::LocalTensor<float> &tmpB,
                                   uint32_t count)
{
    AscendC::Maxs(dst, src, -SIGMOID_CLIP, count);
    AscendC::Mins(dst, dst, SIGMOID_CLIP, count);
    AscendC::Muls(dst, dst, -1.0f, count);
    AscendC::Exp(dst, dst, count);
    AscendC::Adds(dst, dst, 1.0f, count);
    AscendC::Reciprocal(tmpA, dst, count);
    AscendC::Mul(tmpB, dst, tmpA, count);
    AscendC::Muls(tmpB, tmpB, -1.0f, count);
    AscendC::Adds(tmpB, tmpB, 2.0f, count);
    AscendC::Mul(tmpA, tmpA, tmpB, count);
    AscendC::Mul(tmpB, dst, tmpA, count);
    AscendC::Muls(tmpB, tmpB, -1.0f, count);
    AscendC::Adds(tmpB, tmpB, 2.0f, count);
    AscendC::Mul(dst, tmpA, tmpB, count);
}

template <typename T>
__aicore__ inline uint32_t GetWorkBytes(uint32_t tileLen)
{
    return 2 * tileLen * static_cast<uint32_t>(sizeof(float));
}

template <>
__aicore__ inline uint32_t GetWorkBytes<half>(uint32_t tileLen)
{
    (void)tileLen;
    return 32;
}

template <>
__aicore__ inline uint32_t GetWorkBytes<bfloat16_t>(uint32_t tileLen)
{
    return 2 * tileLen * static_cast<uint32_t>(sizeof(float));
}

template <typename T>
__aicore__ inline void DoSigmoid(const AscendC::LocalTensor<T> &dst, const AscendC::LocalTensor<T> &src,
                                 AscendC::TBuf<AscendC::TPosition::VECCALC> &workBuf, uint32_t tileLen, uint32_t count)
{
    auto tmpA = workBuf.Get<float>();
    auto tmpB = tmpA[tileLen];
    SigmoidFp32(dst, src, tmpA, tmpB, count);
}

template <>
__aicore__ inline void DoSigmoid<half>(const AscendC::LocalTensor<half> &dst, const AscendC::LocalTensor<half> &src,
                                       AscendC::TBuf<AscendC::TPosition::VECCALC> &workBuf, uint32_t tileLen,
                                       uint32_t count)
{
    (void)workBuf;
    (void)tileLen;
    AscendC::Sigmoid(dst, src, count);
}

template <>
__aicore__ inline void DoSigmoid<bfloat16_t>(const AscendC::LocalTensor<bfloat16_t> &dst,
                                             const AscendC::LocalTensor<bfloat16_t> &src,
                                             AscendC::TBuf<AscendC::TPosition::VECCALC> &workBuf, uint32_t tileLen,
                                             uint32_t count)
{
    auto tmp1 = workBuf.Get<float>();
    auto tmp2 = tmp1[tileLen];
    AscendC::Cast(tmp1, src, AscendC::RoundMode::CAST_NONE, count);
    AscendC::Sigmoid(tmp2, tmp1, count);
    AscendC::Cast(dst, tmp2, AscendC::RoundMode::CAST_RINT, count);
}

template <typename T>
class KernelSigmoid {
public:
    __aicore__ inline KernelSigmoid() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
    {
        this->tileSize_ = tileSize;
        this->tileLen_ = tileSize / static_cast<uint32_t>(sizeof(T));
        this->alignNum_ = 32 / static_cast<uint32_t>(sizeof(T));
        if (this->alignNum_ == 0) {
            this->alignNum_ = 1;
        }
        if (this->tileLen_ == 0) {
            this->tileLen_ = this->alignNum_;
        }

        int64_t blockIdx = AscendC::GetBlockIdx();
        int64_t currentBlockLength = totalLength - blockIdx * blockLength;
        if (currentBlockLength > blockLength) {
            currentBlockLength = blockLength;
        }
        if (currentBlockLength < 0) {
            currentBlockLength = 0;
        }
        this->blockElem_ = currentBlockLength;

        pipe_.InitBuffer(inQueueX_, PIPELINE_DEPTH, tileSize);
        pipe_.InitBuffer(outQueueY_, PIPELINE_DEPTH, tileSize);
        uint32_t workBytes = GetWorkBytes<T>(this->tileLen_);
        if (workBytes < 32) {
            workBytes = 32;
        }
        pipe_.InitBuffer(workBuf_, workBytes);

        xGm_.SetGlobalBuffer((__gm__ T *)x + blockIdx * blockLength, currentBlockLength);
        yGm_.SetGlobalBuffer((__gm__ T *)y + blockIdx * blockLength, currentBlockLength);
    }

    __aicore__ inline void Process()
    {
        if (blockElem_ <= 0 || tileLen_ == 0) {
            return;
        }
        int64_t tileNum = blockElem_ / static_cast<int64_t>(tileLen_);
        int64_t tail = blockElem_ - tileNum * static_cast<int64_t>(tileLen_);

        if (tileNum > 0) {
            CopyIn(0, static_cast<int64_t>(tileLen_));
        }
        for (int64_t i = 0; i < tileNum; ++i) {
            if (i + 1 < tileNum) {
                CopyIn((i + 1) * static_cast<int64_t>(tileLen_), static_cast<int64_t>(tileLen_));
            } else if (tail > 0) {
                CopyIn(tileNum * static_cast<int64_t>(tileLen_), tail);
            }
            Compute(tileLen_);
            CopyOut(i * static_cast<int64_t>(tileLen_), static_cast<int64_t>(tileLen_));
        }
        if (tail > 0) {
            if (tileNum == 0) {
                CopyIn(0, tail);
            }
            Compute(AlignCount(static_cast<uint32_t>(tail)));
            CopyOut(tileNum * static_cast<int64_t>(tileLen_), tail);
        }
    }

private:
    __aicore__ inline uint32_t AlignCount(uint32_t count)
    {
        uint32_t aligned = count;
        if (alignNum_ > 0) {
            aligned = (count + alignNum_ - 1) / alignNum_ * alignNum_;
        }
        if (aligned > tileLen_) {
            aligned = tileLen_;
        }
        return aligned;
    }

    __aicore__ inline void CopyIn(int64_t offset, int64_t elemNum)
    {
        auto xLocal = inQueueX_.AllocTensor<T>();
        uint32_t count = static_cast<uint32_t>(elemNum);
        uint32_t aligned = AlignCount(count);
        uint8_t rightPad = 0;
        bool needPad = false;
        if (aligned > count) {
            needPad = true;
            rightPad = static_cast<uint8_t>(aligned - count);
        }
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elemNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{needPad, 0, rightPad, static_cast<T>(0)};
        AscendC::DataCopyPad(xLocal, xGm_[offset], copyParams, padParams);
        inQueueX_.EnQue(xLocal);
    }

    __aicore__ inline void Compute(uint32_t count)
    {
        auto xLocal = inQueueX_.DeQue<T>();
        auto yLocal = outQueueY_.AllocTensor<T>();
        DoSigmoid<T>(yLocal, xLocal, workBuf_, tileLen_, count);
        outQueueY_.EnQue(yLocal);
        inQueueX_.FreeTensor(xLocal);
    }

    __aicore__ inline void CopyOut(int64_t offset, int64_t elemNum)
    {
        auto yLocal = outQueueY_.DeQue<T>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elemNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm_[offset], yLocal, copyParams);
        outQueueY_.FreeTensor(yLocal);
    }

    AscendC::TPipe pipe_;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX_;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBuf_;
    AscendC::GlobalTensor<T> xGm_;
    AscendC::GlobalTensor<T> yGm_;
    int64_t blockElem_ = 0;
    uint32_t tileLen_ = 0;
    uint32_t tileSize_ = 0;
    uint32_t alignNum_ = 8;
};

template <typename T>
__global__ __aicore__ void sigmoid_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    KernelSigmoid<T> op;
    op.Init(x, y, totalLength, blockLength, tileSize);
    op.Process();
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength, int64_t ubDivisor, int64_t elemSize)
{
    if (ubDivisor < 4) {
        ubDivisor = 4;
    }
    if (elemSize < 2) {
        elemSize = 2;
    }

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 192 * 1024;
    }
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t alignElem = 32 / elemSize;
    if (alignElem < 1) {
        alignElem = 1;
    }

    int64_t numBlocks = 1;
    if (totalLength > 0) {
        numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
        if (numBlocks <= 0) {
            numBlocks = 1;
        }
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    blockLength = (blockLength + alignElem - 1) / alignElem * alignElem;

    int64_t usable = static_cast<int64_t>(ubSize) - UB_RESERVED;
    if (usable < TILE_ALIGN * ubDivisor) {
        usable = TILE_ALIGN * ubDivisor;
    }
    int64_t tileSize = (usable / ubDivisor / TILE_ALIGN) * TILE_ALIGN;
    if (tileSize < TILE_ALIGN) {
        tileSize = TILE_ALIGN;
    }
    int64_t minTile = alignElem * elemSize;
    if (minTile < 32) {
        minTile = 32;
    }
    if (tileSize < minTile) {
        tileSize = minTile;
    }
    int64_t maxTile = blockLength * elemSize;
    if (maxTile < minTile) {
        maxTile = minTile;
    }
    maxTile = (maxTile + TILE_ALIGN - 1) / TILE_ALIGN * TILE_ALIGN;
    if (tileSize > maxTile) {
        tileSize = maxTile;
    }
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                                 uint32_t tileSize, void *stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                                uint32_t tileSize, void *stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                                uint32_t tileSize, void *stream)
{
    sigmoid_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
