/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file sigmoid_kernel.cpp
 * \brief Sigmoid kernel, host tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t MIN_ELEMS_PER_CORE = 4096;

// ---------------- Kernel: bfloat16 path (compute in float32) ----------------
__global__ __aicore__ void sigmoid_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                               int64_t blockLength, int64_t tileElemNum)
{
    using T = bfloat16_t;
    using CT = float;
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileElemNum * sizeof(T));
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileElemNum * sizeof(T));
    AscendC::TBuf<AscendC::TPosition::VECCALC> fxBuf, t1Buf;
    pipe.InitBuffer(fxBuf, tileElemNum * sizeof(CT));
    pipe.InitBuffer(t1Buf, tileElemNum * sizeof(CT));

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - blockLength * AscendC::GetBlockIdx();
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    if (currentBlockLength <= 0) return;

    int64_t tileNum = currentBlockLength / tileElemNum;
    int64_t tailElemNum = currentBlockLength - tileNum * tileElemNum;
    int64_t totalTiles = tileNum + (tailElemNum > 0 ? 1 : 0);

    auto fx = fxBuf.Get<CT>();
    auto t1 = t1Buf.Get<CT>();

    for (int64_t i = 0; i < totalTiles; ++i) {
        int64_t offset = i * tileElemNum;
        int64_t num = (i < tileNum) ? tileElemNum : tailElemNum;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(num * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        // fx = (float)x; t1 = -fx; fx = exp(t1); t1 = fx + 1; fx = 1 / t1
        AscendC::Cast(fx, xLocal, AscendC::RoundMode::CAST_NONE, num);
        AscendC::Muls(t1, fx, -1.0f, num);
        AscendC::Exp(fx, t1, num);
        AscendC::Adds(t1, fx, 1.0f, num);
        AscendC::Reciprocal(fx, t1, num);

        auto yLocal = outQueueY.AllocTensor<T>();
        AscendC::Cast(yLocal, fx, AscendC::RoundMode::CAST_RINT, num);
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

// ---------------- Kernel: float32 / float16 path ----------------
template <typename T>
__global__ __aicore__ void sigmoid_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                          int64_t blockLength, int64_t tileElemNum)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileElemNum * sizeof(T));
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileElemNum * sizeof(T));
    AscendC::TBuf<AscendC::TPosition::VECCALC> t1Buf, t2Buf, oneBuf;
    pipe.InitBuffer(t1Buf, tileElemNum * sizeof(T));
    pipe.InitBuffer(t2Buf, tileElemNum * sizeof(T));
    pipe.InitBuffer(oneBuf, tileElemNum * sizeof(T));

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - blockLength * AscendC::GetBlockIdx();
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    if (currentBlockLength <= 0) return;

    int64_t tileNum = currentBlockLength / tileElemNum;
    int64_t tailElemNum = currentBlockLength - tileNum * tileElemNum;
    int64_t totalTiles = tileNum + (tailElemNum > 0 ? 1 : 0);

    auto t1 = t1Buf.Get<T>();
    auto t2 = t2Buf.Get<T>();
    auto one = oneBuf.Get<T>();

    for (int64_t i = 0; i < totalTiles; ++i) {
        int64_t offset = i * tileElemNum;
        int64_t num = (i < tileNum) ? tileElemNum : tailElemNum;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(num * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        // t1 = -x; t2 = exp(t1); t1 = t2 + 1; one = 1; y = one / t1
        AscendC::Muls(t1, xLocal, (T)-1.0f, num);
        AscendC::Exp(t2, t1, num);
        AscendC::Adds(t1, t2, (T)1.0f, num);
        AscendC::Duplicate(one, (T)1.0f, num);
        auto yLocal = outQueueY.AllocTensor<T>();
        AscendC::Div(yLocal, one, t1, num);
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

// ---------------- Host tiling ----------------
// bytesPerElem: total UB bytes consumed per element (queues + temp buffers)
//   float32: 2*4 (in) + 2*4 (out) + 3*4 (temp) = 28
//   float16: 2*2 + 2*2 + 3*2 = 14
//   bfloat16: 2*2 + 2*2 + 2*4 = 16
std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength, int64_t bytesPerElem)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    if (bytesPerElem < 1) bytesPerElem = 1;

    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) numBlocks = coreNum;
    if (numBlocks < 1) numBlocks = 1;

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    if (blockLength < 1) blockLength = 1;

    int64_t usableUb = (int64_t)ubSize * 7 / 8;
    int64_t tileElemNum = usableUb / bytesPerElem;
    if (tileElemNum > blockLength) tileElemNum = blockLength;
    if (tileElemNum < 1) tileElemNum = 1;

    return std::make_tuple(numBlocks, blockLength, tileElemNum);
}

// ---------------- Launch wrappers ----------------
extern "C" {

void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                 int64_t blockLength, int64_t tileElemNum, void *stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElemNum);
}

void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                int64_t blockLength, int64_t tileElemNum, void *stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElemNum);
}

void launch_sigmoid_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                    int64_t blockLength, int64_t tileElemNum, void *stream)
{
    sigmoid_kernel_bf16<<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElemNum);
}

}
