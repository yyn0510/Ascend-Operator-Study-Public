/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file sigmoid_plugin.cpp
 * \brief Sigmoid API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/sigmoid_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("sigmoid(Tensor x) -> Tensor");
}

torch::Tensor sigmoid_meta(const torch::Tensor &x)
{
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("sigmoid", sigmoid_meta);
}

torch::Tensor sigmoid_npu(const torch::Tensor &x)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto x_in = x.contiguous();
    auto y = torch::empty_like(x_in);
    int64_t totalLength = x_in.numel();
    if (totalLength == 0) {
        return y;
    }
    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    int64_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_sigmoid_tiling_params(totalLength);
    auto x_ptr = (GM_ADDR)x_in.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();
    auto st = x_in.scalar_type();
    auto acl_call = [=]() -> int {
        if (st == torch::kFloat32) {
            SIGMOID_KERNEL_LAUNCH_FLOAT(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        } else if (st == torch::kFloat16) {
            SIGMOID_KERNEL_LAUNCH_HALF(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        } else if (st == torch::kBFloat16) {
            SIGMOID_KERNEL_LAUNCH_BF16(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Sigmoid", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("sigmoid", sigmoid_npu);
}

} // namespace cann_bench
