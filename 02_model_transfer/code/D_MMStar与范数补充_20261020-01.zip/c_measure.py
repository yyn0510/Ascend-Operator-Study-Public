"""C NPU measurements: bounded real-input replay, complete model paths and profiling."""
from contextlib import contextmanager
import math
import hashlib
from pathlib import Path
import random
import statistics
import time

from run_cloud import read,save,sha
from cloud_helpers import initialize,candidate,patch,Captures,targets,SEED
import base_workers as base


class TokenClock:
    """HF first put contains prompt IDs; later puts contain new token batches."""
    def __init__(self,clock=time.perf_counter):self.clock=clock;self.initial=True;self.first=None;self.steps=0
    def put(self,value):
        if self.initial:self.initial=False;return
        if value.numel():
            self.steps+=1
            if self.first is None:self.first=self.clock()
    def end(self):pass


def synthesize(tokenizer,length):
    for word in (' test',' word',' a',' x'):
        text=word*length
        if len(tokenizer.encode(text,add_special_tokens=False))==length:return text
    raise ValueError('Cannot form the frozen exact-token synthetic content')


def prepared_generation(model,processor,c,condition):
    import torch
    from workers import select_samples
    row=dict(select_samples({'dataset':'docvqa','split':'dev','limit':1})[0])
    probe=read(c['plan'])['performance_probe']
    if str(row['id'])!=str(probe['id']) or row['image_sha256']!=probe['image_sha256']:raise ValueError('Frozen performance probe changed')
    tokenizer=processor.tokenizer if c['host'].startswith('qwen') else processor
    row['question']=synthesize(tokenizer,condition['text_tokens']);row.pop('choices',None)
    if c['host'].startswith('qwen'):
        from PIL import Image
        question=row['question']+'\nAnswer with a short phrase only.'
        messages=[{'role':'user','content':[{'type':'image'},{'type':'text','text':question}]}]
        prompt=processor.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
        imagepath=base.HERE/'data/docvqa'/row['image']
        if sha(imagepath)!=row['image_sha256']:raise ValueError('Probe image changed')
        with Image.open(imagepath) as im:image=im.convert('RGB')
        inputs=processor(text=[prompt]*condition['batch'],images=[image]*condition['batch'],return_tensors='pt',padding=True).to(f'npu:{c["device"]}')
        kwargs=dict(inputs,max_new_tokens=condition['new_tokens'],min_new_tokens=condition['new_tokens'],do_sample=False,use_cache=True)
        prefix=int(inputs['input_ids'].shape[-1]);args=()
        info={'input_tokens_per_sequence':prefix,'image_grid_thw':inputs['image_grid_thw'].tolist(),'synthetic_content_tokens':condition['text_tokens'],'batch':condition['batch']}
    else:
        if condition['batch']!=1:raise ValueError('InternVL scans freeze batch=1')
        (pixels,question),info=base.generation_input(c,row,processor)
        original=model.generate;saved={}
        class CapturedArguments(Exception):pass
        def capture(*args,**kwargs):saved.update(args=args,kwargs=kwargs);raise CapturedArguments()
        model.generate=capture
        try:
            model.chat(processor,pixels,question,{'max_new_tokens':condition['new_tokens'],'min_new_tokens':condition['new_tokens'],'do_sample':False},num_patches_list=[pixels.shape[0]])
        except CapturedArguments:pass
        finally:model.generate=original
        if not saved:raise ValueError('InternVL chat bypassed reviewed generate call')
        args=saved['args'];kwargs=saved['kwargs'];prefix=0
        # InternVL's reviewed generate already supplies use_cache=True to its
        # language model; passing it again through **generate_kwargs conflicts.
        kwargs.pop('use_cache',None)
        kwargs.update(max_new_tokens=condition['new_tokens'],min_new_tokens=condition['new_tokens'],do_sample=False)
        info.update(synthetic_content_tokens=condition['text_tokens'],batch=1)
        if kwargs.get('input_ids') is not None:info['input_tokens_per_sequence']=int(kwargs['input_ids'].shape[-1])
    def call(streamer=None):
        values=dict(kwargs)
        if streamer is not None:values['streamer']=streamer
        return model.generate(*args,**values)
    return call,info,prefix


def prepared_clip(model,processor,c,condition):
    import torch
    from PIL import Image
    rows=[r for r in read(base.HERE/'data/coco/samples.json') if r['split']=='dev'][:condition['batch']]
    images=[];texts=[]
    for row in rows:
        path=base.HERE/'data/coco'/row['image']
        if sha(path)!=row['image_sha256']:raise ValueError('Probe image changed')
        with Image.open(path) as im:images.append(im.convert('RGB'))
        texts.extend(cap['text'] for cap in row['captions'])
    inputs=processor(images=images,text=texts,return_tensors='pt',padding='max_length',max_length=condition['text_length'],truncation=True)
    inputs={k:v.to(device=f'npu:{c["device"]}',dtype=torch.bfloat16) if v.is_floating_point() else v.to(f'npu:{c["device"]}') for k,v in inputs.items()}
    return lambda streamer=None:model(**inputs),{'images':len(images),'texts':len(texts),'text_length':condition['text_length'],'image_resolution':224},0


def prepared(c):
    from workers import load_generation
    condition=c['condition'];values=dict(c,dataset='docvqa',max_pixels=condition.get('max_pixels',401408),min_pixels=min(200704,condition.get('max_pixels',401408)))
    if c['host'] in ('clip','quick_clip'):
        model,processor=base.load_clip(values);call,info,prefix=prepared_clip(model,processor,values,condition)
    else:
        model,processor=load_generation(values);call,info,prefix=prepared_generation(model,processor,values,condition)
    return model,call,info,prefix


def same_output(a,b):
    import torch
    if isinstance(a,torch.Tensor):return torch.equal(a,b)
    return torch.equal(a.image_embeds,b.image_embeds) and torch.equal(a.text_embeds,b.text_embeds)


def output_fingerprint(value):
    import torch
    values=[value] if isinstance(value,torch.Tensor) else [value.image_embeds,value.text_embeds]
    h=hashlib.sha256()
    for tensor in values:
        h.update(str((tuple(tensor.shape),tensor.dtype)).encode());h.update(tensor.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


def performance_control(c):
    import torch
    initialize(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False);model,call,info,prefix=prepared(c)
    captures=Captures(model,c)
    try:
        with torch.inference_mode():value=call()
    finally:captures.close()
    save(out/'control.json',{'condition':c['condition'],'input':info,'output_sha256':output_fingerprint(value),'host':c['host'],'plan_sha256':sha(c['plan']),'runtime_sha256':sha(c['runtime'])})


def measure_once(call,generative,batch,new_tokens,prefix):
    import torch
    torch.npu.synchronize();clock=TokenClock() if generative else None;begin=time.perf_counter()
    value=call(clock);torch.npu.synchronize();end=time.perf_counter()
    row={'wall_ms':1000*(end-begin)}
    if generative:
        produced=int(value.shape[-1])-prefix
        if produced!=new_tokens or clock.steps!=new_tokens or clock.first is None:raise ValueError('Forced-token length or streamer accounting differs from frozen protocol')
        decode=end-clock.first
        row.update(ttft_ms=1000*(clock.first-begin),new_tokens_per_sequence=produced,decode_tokens_per_second_batch=(produced-1)*batch/decode if decode>0 and produced>1 else None)
    return row


def model_performance(c):
    import torch
    initialize(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    row=candidate(c);operator=row['operator'];condition=c['condition'];model,call,info,prefix=prepared(c)
    generative=c['host'] not in ('clip','quick_clip');timing=read(c['plan'])['timing']
    reference=read(Path(c['control'])/'control.json')
    if reference['condition']!=condition or reference['plan_sha256']!=sha(c['plan']) or reference['runtime_sha256']!=sha(c['runtime']):raise ValueError('Performance condition control changed')
    with torch.inference_mode():native=call()
    if output_fingerprint(native)!=reference['output_sha256']:raise ValueError('Current native output differs from frozen condition control')
    with torch.inference_mode(),patch(model,dict(c,mode='wrapper'),operator) as counts:wrapped=call()
    if not same_output(native,wrapped):raise ValueError('Condition wrapper changes native output')
    gatecfg=dict(c,output=str(out/'input_gate'),captures=str(Path(c['control'])/'captures'/operator))
    base.gate(gatecfg);gate=read(out/'input_gate/eligibility.json')
    if not gate['eligible']:
        save(out/'summary.json',{'status':'condition_local_gate_failed','condition':condition,'input':info,'gate':gate});return
    with torch.inference_mode(),patch(model,c,operator) as candidate_counts:probe=call()
    save(out/'calls.json',candidate_counts)
    same=same_output(native,probe)
    records=[];rng=random.Random(SEED+c['session']);memory={}
    with torch.inference_mode():
        for mode in ('native','wrapper','candidate'):
            with patch(model,dict(c,mode=mode),operator,count=False):
                for _ in range(timing['model_warmup']):call()
        for block in range(timing['blocks']):
            order=['native','wrapper','candidate'];rng.shuffle(order)
            for mode in order:
                if hasattr(torch.npu,'reset_peak_memory_stats'):torch.npu.reset_peak_memory_stats(c['device'])
                with patch(model,dict(c,mode=mode),operator,count=False):
                    for repeat in range(timing['model_repeats']):
                        measured=measure_once(call,generative,condition['batch'],condition.get('new_tokens',0),prefix)
                        records.append({'mode':mode,'block':block,'repeat':repeat,'session':c['session'],**measured})
                        save(out/'measurements.json',records)
                current={name:int(getattr(torch.npu,name)(c['device'])) for name in ('max_memory_allocated','max_memory_reserved') if hasattr(torch.npu,name)}
                memory[mode]={name:max(value,memory.get(mode,{}).get(name,0)) for name,value in current.items()}
    medians={mode:statistics.median(r['wall_ms'] for r in records if r['mode']==mode) for mode in ('native','wrapper','candidate')}
    additional={}
    if generative:
        additional={mode:{key:statistics.median(r[key] for r in records if r['mode']==mode) for key in ('ttft_ms','decode_tokens_per_second_batch')} for mode in medians}
    save(out/'summary.json',{'status':'measured','condition':condition,'input':info,'median_wall_ms':medians,'candidate_over_native_wall_ratio':medians['candidate']/medians['native'],'candidate_over_wrapper_wall_ratio':medians['candidate']/medians['wrapper'],'candidate_probe_output_equal_native':same,'memory_bytes':memory,'generation':additional,'scope':'preprocessed model forward/generate; Python launch and adapters included; generation streamer transfer included equally for all modes; fixed synthetic generation length; not task-quality output','session':c['session']})


def repeat_rows(tensor,rows):
    import torch
    flat=tensor.reshape(-1,tensor.shape[-1])
    return flat.repeat((math.ceil(rows/flat.shape[0]),1))[:rows].contiguous()


def replay_functions(operator,host,kernel,x,parent=None):
    import torch
    from transformers.models.clip.modeling_clip import _get_vector_norm
    from clip_adapter import rowwise_foreach_norm
    if operator=='gelu':return [('kernel_contract',lambda:torch.nn.functional.gelu(x,approximate='none'),lambda:kernel(x,'tanh'))]
    if operator=='swi_glu':
        gate,up=x.chunk(2,dim=-1)
        raw=lambda:kernel(x,-1);native=lambda:torch.nn.functional.silu(gate)*up
        if host.startswith('qwen'):
            a,b=gate.contiguous(),up.contiguous()
            return [('kernel_contract',native,raw),('complete_activation_adapter',lambda:torch.nn.functional.silu(a)*b,lambda:kernel(torch.cat((a,b),dim=-1),-1))]
        return [('kernel_contract',native,raw),('complete_activation_adapter',native,raw)]
    if operator=='sigmoid':
        if parent is None:raise ValueError('QuickGELU parent input missing')
        return [('kernel_contract',lambda:torch.sigmoid(x),lambda:kernel(x)),('complete_activation_adapter',lambda:parent*torch.sigmoid(1.702*parent),lambda:parent*kernel(1.702*parent))]
    return [('kernel_contract',lambda:_get_vector_norm(x),lambda:rowwise_foreach_norm(x,kernel)),('complete_normalization_adapter',lambda:x/_get_vector_norm(x),lambda:x/rowwise_foreach_norm(x,kernel))]


def replay_performance(c):
    import torch,cann_bench
    from completion_utils import metrics
    initialize(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    row=candidate(c);op=row['operator'];index=read(Path(c['captures'])/'index.json')
    record=next((r for r in index['records'] if r['phase']=='prefill'),index['records'][0]);path=Path(c['captures'])/record['file']
    if sha(path)!=record['sha256']:raise ValueError('Replay source capture changed')
    data=torch.load(path,map_location='cpu',weights_only=True);kernel=getattr(cann_bench,op);timing=read(c['plan'])['timing'];results=[]
    rows_values=read(c['plan'])['replay_rows']['normalization' if op=='foreach_norm' else 'activation']
    with torch.inference_mode():
        for dtype_name in ('bfloat16','float16'):
            dtype=getattr(torch,dtype_name)
            for rows in rows_values:
                parent=repeat_rows(data['parent_input'],rows).to(device=f'npu:{c["device"]}',dtype=dtype) if op=='sigmoid' else None
                x=1.702*parent if parent is not None else repeat_rows(data['input'],rows).to(device=f'npu:{c["device"]}',dtype=dtype)
                for level,native,actual in replay_functions(op,c['host'],kernel,x,parent):
                    a=native();b=actual();check=metrics(b,a)
                    result={'dtype':dtype_name,'rows':rows,'shape':list(x.shape),'level':level,'local_check':check,'source_capture':record,'transform':'repeat/slice captured rows, retain feature width; dtype conversion explicit'}
                    if check['passed']:
                        measured={'native':[],'candidate':[]}
                        rng=random.Random(SEED+rows)
                        for fn in (native,actual):
                            for _ in range(timing['replay_warmup']):fn()
                        for block in range(timing['blocks']):
                            order=[('native',native),('candidate',actual)];rng.shuffle(order)
                            for mode,fn in order:
                                torch.npu.synchronize();start=time.perf_counter()
                                for _ in range(timing['replay_repeats']):fn()
                                torch.npu.synchronize();measured[mode].append(1000*(time.perf_counter()-start)/timing['replay_repeats'])
                        result.update(status='measured',block_ms=measured,median_ms={mode:statistics.median(values) for mode,values in measured.items()})
                        result['speedup_vs_native']=result['median_ms']['native']/result['median_ms']['candidate']
                    else:result['status']='numerical_gate_failed_not_timed'
                    results.append(result);save(out/'replay_results.json',results)
    save(out/'scope.json',{'source':'C native dev captured tensors; derived row counts are not additional real samples','timing':'synchronized batched wall time, includes Python and complete adapter at indicated level; not pure hardware kernel duration'})


@contextmanager
def profile_targets(model,c,events):
    import torch
    from transformers.models.clip import modeling_clip
    originals=[];norm_original=modeling_clip._get_vector_norm;op=c['operator']
    def span(name,fn):
        start=torch.npu.Event(enable_timing=True);end=torch.npu.Event(enable_timing=True)
        start.record();value=fn();end.record();events.append((name,start,end));return value
    try:
        if op=='foreach_norm':modeling_clip._get_vector_norm=lambda x:span('rowwise_norm',lambda:norm_original(x))
        else:
            modules=dict(model.named_modules())
            for name in targets(model,c['host'],op):
                module=modules[name];old=module.forward;inherited='forward' not in vars(module);originals.append((module,old,inherited))
                def forward(x,_module=module,_old=old,_name=name):
                    if op=='swi_glu':
                        if c['host']=='internvl':
                            gate,up=_module.gate_up_proj(x).chunk(2,dim=-1)
                            activation=span(_name+'.silu',lambda:_module.activation_fn(gate))
                            hidden=span(_name+'.multiply',lambda:up*activation)
                        else:
                            gate=_module.gate_proj(x)
                            activation=span(_name+'.silu',lambda:_module.act_fn(gate))
                            up=_module.up_proj(x);hidden=span(_name+'.multiply',lambda:activation*up)
                        return _module.down_proj(hidden)
                    if op=='sigmoid':
                        scaled=1.702*x;value=span(_name+'.sigmoid',lambda:torch.sigmoid(scaled));return x*value
                    return span(_name,lambda:_old(x))
                module.forward=forward
        yield
    finally:
        modeling_clip._get_vector_norm=norm_original
        for module,old,inherited in originals:
            if inherited:delattr(module,'forward')
            else:module.forward=old


def profile_native(c):
    import torch
    initialize(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False);model,call,info,prefix=prepared(c)
    records=[]
    with torch.inference_mode():
        for _ in range(2):call()
        torch.npu.synchronize();start=time.perf_counter();reference=call();torch.npu.synchronize();plain_ms=1000*(time.perf_counter()-start)
        for repeat in range(3):
            events=[];begin=torch.npu.Event(enable_timing=True);end=torch.npu.Event(enable_timing=True)
            torch.npu.synchronize();start=time.perf_counter();begin.record()
            with profile_targets(model,c,events):value=call()
            end.record();torch.npu.synchronize();wall=1000*(time.perf_counter()-start)
            if not same_output(reference,value):raise ValueError('Profiling decomposition changes native output')
            total=begin.elapsed_time(end);target=sum(a.elapsed_time(b) for _,a,b in events)
            records.append({'repeat':repeat,'profiled_wall_ms':wall,'profiled_stream_interval_ms':total,'sum_target_event_ms':target,'target_fraction_of_profiled_stream_interval':target/total if total>0 else None,'events':[{'name':name,'ms':a.elapsed_time(b)} for name,a,b in events]})
    save(out/'profile.json',{'input':info,'unprofiled_single_control_wall_ms':plain_ms,'records':records,'definition':'sum of native activation event intervals divided by profiled model stream interval; instrumentation overhead retained; descriptive and not an exact uninstrumented Amdahl fraction','operations':'SwiGLU excludes projections and profiles SiLU/multiply separately; Sigmoid excludes scale/final multiply; ForeachNorm excludes subsequent division','api_source':'https://github.com/Ascend/pytorch/blob/v2.7.1/torch_npu/npu/streams.py'})
