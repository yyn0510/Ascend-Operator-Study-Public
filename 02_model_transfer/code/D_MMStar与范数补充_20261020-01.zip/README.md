# D：MMStar任务质量及额外ForeachNorm验证

本批冻结Qwen-7B的两份GELU、两份SwiGLU和InternVL的两份SwiGLU，共6组MMStar正式质量比较；两个宿主分别建立原生基线。使用原63题dev和1241题eval、原题自带选项、固定单字母指令、BF16/eager和最多16个新token的贪心解码。

另固定补测Kimi_K3_foreach_norm_003_R2：构建→原20例→真实输入准入，通过后进行固定COCO检索及一个默认批量的3时段模型计时、BF16/FP16派生行数回放。原Kimi失败记录不覆盖；若新增候选不准入，不继续替换。新的8份应用候选（若形成）来自9份尝试，不改写原B批次的8份尝试/7份通过。

MMStar不新增模型性能扫描，不重跑旧101个计时条件，不把新旧SwiGLU接入耗时直接拼接。旧Qwen-3B四候选任务质量结果保留；本批的原生与包装对照及接入版本单独记录。固定eval成绩不用于更换候选或改容差。

上传“待上传”内的d_payload.zip和start_stage_d.py到原build目录，运行python /mnt/workspace/gitCode/cann/cann-learning-hub/build/start_stage_d.py。复用现有Qwen-7B、InternVL、CLIP权重以及C包COCO原图，全部校验后执行；不修改C包。不要同时运行其他更换cann_bench的任务。

后台日志和结果ZIP路径会打印。可用start_stage_d.py --stop正常停止并等待恢复、导出；使用start_stage_d.py --resume 原RUN_ID续跑同一冻结版本。保留云端目录、捕获张量和wheel，导出ZIP不含这些大文件。原生/包装/环境异常停止复查；候选不准入、部分执行或数值门槛失败均保留。无效/缺失答案保留在分母。

本机只做离线来源、CPU适配和控制流程检查。D新增路径仍需首次NPU执行核查。
