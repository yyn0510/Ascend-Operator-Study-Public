"""D-specific prompt preservation and bounded per-condition norm replay."""
from pathlib import Path
import random
import statistics
import time

def mmstar_prompt(row):
    if row.get('prompt_format')!='mmstar_embedded_options' or not row.get('original_question'):raise ValueError('Expected frozen original MMStar question with embedded options')
    return row['original_question']+'\nAnswer with one option letter only.'


def safe_norm_replay(c):
    import torch,cann_bench
    from run_cloud import read,save,sha
    from cloud_helpers import initialize,candidate,SEED
    from completion_utils import metrics
    from c_measure import repeat_rows,replay_functions
    import base_workers as base
    initialize(c)
    if candidate(c)['operator']!='foreach_norm':raise ValueError('D replay is only the one additional norm candidate')
    out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    source=Path(c['captures']);index=read(source/'index.json');record=next((r for r in index['records'] if r['phase']=='prefill'),index['records'][0])
    path=source/record['file']
    if sha(path)!=record['sha256']:raise ValueError('Captured input changed')
    data=torch.load(path,map_location='cpu',weights_only=True);plan=read(c['plan']);timing=plan['timing'];results=[]
    with torch.inference_mode():
        for dtype_name in ('bfloat16','float16'):
            for rows in plan['replay_rows']['normalization']:
                x=repeat_rows(data['input'],rows).to(device=f'npu:{c["device"]}',dtype=getattr(torch,dtype_name))
                for level,native,actual in replay_functions('foreach_norm','clip',cann_bench.foreach_norm,x):
                    result={'dtype':dtype_name,'rows':rows,'shape':list(x.shape),'level':level,'source_capture':record,'transform':'repeat/slice real captured rows; explicit dtype conversion; not additional task samples'}
                    try:
                        result['local_check']=metrics(actual(),native())
                        if result['local_check']['passed']:
                            measured={'native':[],'candidate':[]};rng=random.Random(SEED+rows)
                            for fn in (native,actual):
                                for _ in range(timing['replay_warmup']):fn()
                            for block in range(timing['blocks']):
                                order=[('native',native),('candidate',actual)];rng.shuffle(order)
                                for mode,fn in order:
                                    torch.npu.synchronize();start=time.perf_counter()
                                    for _ in range(timing['replay_repeats']):fn()
                                    torch.npu.synchronize();measured[mode].append(1000*(time.perf_counter()-start)/timing['replay_repeats'])
                            medians={mode:statistics.median(v) for mode,v in measured.items()}
                            result.update(status='measured',block_ms=measured,median_ms=medians,speedup_vs_native=medians['native']/medians['candidate'])
                        else:result['status']='numerical_gate_failed_not_timed'
                    except (RuntimeError,ValueError) as error:
                        result.update(status='condition_execution_failed_not_timed',error=repr(error))
                        base.health({k:v for k,v in dict(c,output=str(out/('health_'+dtype_name+'_'+str(rows)+'_'+level))).items() if k not in ('candidate','receipt')})
                    results.append(result);save(out/'replay_results.json',results)
    save(out/'scope.json',{'measurement':'same C synchronized wall blocks; complete normalization adapter includes list/stack/division; not pure hardware duration','numerical_tolerances':plan['tolerance'],'no_kernel_modification':True,'no_replacement_after_outcome':True})
