/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGlu host code - kernel launch and tiling (compiled with bisheng + -xasc)
 *
 * output = silu(x0) * x1 = (x0 * sigmoid(x0)) * x1, (x0, x1) = chunk(input, 2, dim)
 * FP16/BF16 输入在 kernel 内升精度到 FP32 计算，再 cast 回原 dtype。
 *
 * 输出视角的平坦切分：对输出平坦下标 p，
 *   o = p / blockOut, r = p % blockOut      (blockOut = (dimSize/2) * innerSize)
 *   x0 偏移 = o * fullStride + r            (fullStride = dimSize * innerSize)
 *   x1 偏移 = x0 偏移 + blockOut
 * 每个处理段都落在同一个 outer 块内，保证 x0 / x1 / output 三段拷贝均连续。
 *
 * 三条执行路径：
 * 1) 精确多行模式（行字节 32B 对齐且 tile 能容纳整行）：用 DataCopyPad 多块描述
 *    （blockCount=行数, blockLen=blockOut 字节, srcStride=行间隔）一次性聚合 P 行
 *    x0/x1，数据在 UB 中紧密排列，计算与输出写回均连续。
 * 2) 填充槽多行模式（行字节非 32B 对齐但 tile 能容纳 >=2 个填充行）：对每行分别发
 *    单块 DataCopyPad，写入 32B 对齐的 UB 槽（槽距 slotElems = align32(行字节)），
 *    一次 EnQue 后对 K*slotElems 个元素做整块向量化计算（槽内 padding 通道为
 *    无效数据，计算结果不写回），再按行把有效部分写回 GM。同步开销按 K 行摊薄。
 * 3) 单段连续模式：行内部分段或超大 blockOut，逐段连续搬运与计算。
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t SWI_GLU_PIPELINE_DEPTH = 2;

template <typename T>
class SwiGluKernel {
public:
    __aicore__ inline SwiGluKernel() {}

    __aicore__ inline void Init(GM_ADDR input, GM_ADDR output, int64_t totalOut,
                                int64_t blockOut, int64_t fullStride,
                                int64_t blockLength, int64_t tileElems)
    {
        this->totalOutVal = totalOut;
        this->blockOutVal = blockOut;
        this->fullStrideVal = fullStride;
        this->tileElemsVal = tileElems;
        int64_t rowBytes = blockOut * static_cast<int64_t>(sizeof(T));
        if (rowBytes % 32 == 0) {
            // 精确多行模式：多块 DataCopyPad 要求 blockLen 为 32B 整数倍
            this->maxRowsVal = tileElems / blockOut;
            this->slotElemsVal = blockOut;
            this->padRowsVal = 0;
        } else {
            // 填充槽模式：槽距对齐到 32B，保证每次写槽的 UB 目标地址 32B 对齐
            this->maxRowsVal = 0;
            this->slotElemsVal = (rowBytes + 31) / 32 * (32 / static_cast<int64_t>(sizeof(T)));
            this->padRowsVal = tileElems / this->slotElemsVal;
        }
        int64_t startPos = blockLength * AscendC::GetBlockIdx();
        int64_t endPos = startPos + blockLength;
        if (endPos > totalOut) endPos = totalOut;
        this->startPosVal = startPos;
        this->endPosVal = endPos;
        pipe.InitBuffer(inQueueX0, SWI_GLU_PIPELINE_DEPTH, tileElems * sizeof(T));
        pipe.InitBuffer(inQueueX1, SWI_GLU_PIPELINE_DEPTH, tileElems * sizeof(T));
        pipe.InitBuffer(outQueue, SWI_GLU_PIPELINE_DEPTH, tileElems * sizeof(T));
        if constexpr (std::is_same<T, float>::value) {
            pipe.InitBuffer(tmpBufC, tileElems * sizeof(float));
        } else {
            pipe.InitBuffer(tmpBufA, tileElems * sizeof(float));
            pipe.InitBuffer(tmpBufB, tileElems * sizeof(float));
            pipe.InitBuffer(tmpBufC, tileElems * sizeof(float));
        }
        inGm.SetGlobalBuffer((__gm__ T *)input);
        outGm.SetGlobalBuffer((__gm__ T *)output);
    }

    __aicore__ inline void Process()
    {
        int64_t pos = startPosVal;
        while (pos < endPosVal) {
            int64_t o = pos / blockOutVal;
            int64_t r = pos - o * blockOutVal;
            int64_t remaining = endPosVal - pos;
            if (r == 0) {
                int64_t rowsAvail = remaining / blockOutVal;
                if (maxRowsVal >= 1 && rowsAvail >= 1) {
                    // 精确多行批量：一次搬运 P 个完整 outer 行（紧密排列）
                    int64_t rows = rowsAvail < maxRowsVal ? rowsAvail : maxRowsVal;
                    CopyInRows(o, rows);
                    Compute(rows * blockOutVal);
                    CopyOut(o * blockOutVal, rows * blockOutVal);
                    pos += rows * blockOutVal;
                    continue;
                }
                if (padRowsVal >= 2 && rowsAvail >= 1) {
                    // 填充槽多行批量：K 行写入 32B 对齐槽，整块计算后按行写回
                    int64_t rows = rowsAvail < padRowsVal ? rowsAvail : padRowsVal;
                    CopyInRowsPadded(o, rows);
                    Compute(rows * slotElemsVal);
                    CopyOutRowsPadded(o, rows);
                    pos += rows * blockOutVal;
                    continue;
                }
            }
            // 单段（行内部分段或 blockOut 超过 tile 容量）
            int64_t len = blockOutVal - r;
            if (len > remaining) len = remaining;
            if (len > tileElemsVal) len = tileElemsVal;
            CopyIn(o * fullStrideVal + r, len);
            Compute(len);
            CopyOut(pos, len);
            pos += len;
        }
    }

private:
    __aicore__ inline void CopyIn(int64_t x0off, int64_t len)
    {
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto x0Local = inQueueX0.AllocTensor<T>();
        auto x1Local = inQueueX1.AllocTensor<T>();
        AscendC::DataCopyPad(x0Local, inGm[x0off], copyParams, padParams);
        AscendC::DataCopyPad(x1Local, inGm[x0off + blockOutVal], copyParams, padParams);
        inQueueX0.EnQue(x0Local);
        inQueueX1.EnQue(x1Local);
    }

    __aicore__ inline void CopyInRows(int64_t o, int64_t rows)
    {
        uint32_t rowBytes = static_cast<uint32_t>(blockOutVal * sizeof(T));
        uint32_t gapBytes = static_cast<uint32_t>((fullStrideVal - blockOutVal) * sizeof(T));
        AscendC::DataCopyExtParams copyParams{static_cast<uint16_t>(rows), rowBytes, gapBytes, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto x0Local = inQueueX0.AllocTensor<T>();
        auto x1Local = inQueueX1.AllocTensor<T>();
        AscendC::DataCopyPad(x0Local, inGm[o * fullStrideVal], copyParams, padParams);
        AscendC::DataCopyPad(x1Local, inGm[o * fullStrideVal + blockOutVal], copyParams, padParams);
        inQueueX0.EnQue(x0Local);
        inQueueX1.EnQue(x1Local);
    }

    __aicore__ inline void CopyInRowsPadded(int64_t o, int64_t rows)
    {
        uint32_t rowBytes = static_cast<uint32_t>(blockOutVal * sizeof(T));
        AscendC::DataCopyExtParams copyParams{1, rowBytes, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto x0Local = inQueueX0.AllocTensor<T>();
        auto x1Local = inQueueX1.AllocTensor<T>();
        int64_t base = o * fullStrideVal;
        for (int64_t i = 0; i < rows; ++i) {
            AscendC::DataCopyPad(x0Local[i * slotElemsVal], inGm[base + i * fullStrideVal], copyParams, padParams);
            AscendC::DataCopyPad(x1Local[i * slotElemsVal], inGm[base + i * fullStrideVal + blockOutVal], copyParams, padParams);
        }
        inQueueX0.EnQue(x0Local);
        inQueueX1.EnQue(x1Local);
    }

    __aicore__ inline void Compute(int64_t len)
    {
        auto x0Local = inQueueX0.DeQue<T>();
        auto x1Local = inQueueX1.DeQue<T>();
        auto outLocal = outQueue.AllocTensor<T>();
        if constexpr (std::is_same<T, float>::value) {
            auto c = tmpBufC.Get<float>();
            // c = 1 + exp(-x0)
            AscendC::Muls(c, x0Local, static_cast<float>(-1.0), len);
            AscendC::Exp(c, c, len);
            AscendC::Adds(c, c, static_cast<float>(1.0), len);
            // out = (x0 * x1) / c
            AscendC::Mul(outLocal, x0Local, x1Local, len);
            AscendC::Div(outLocal, outLocal, c, len);
        } else {
            auto a = tmpBufA.Get<float>();
            auto b = tmpBufB.Get<float>();
            auto c = tmpBufC.Get<float>();
            // 升精度到 FP32：f16/bf16 -> f32 上转换使用 CAST_NONE
            AscendC::Cast(a, x0Local, AscendC::RoundMode::CAST_NONE, len);
            AscendC::Cast(b, x1Local, AscendC::RoundMode::CAST_NONE, len);
            AscendC::Muls(c, a, static_cast<float>(-1.0), len);
            AscendC::Exp(c, c, len);
            AscendC::Adds(c, c, static_cast<float>(1.0), len);
            AscendC::Mul(a, a, b, len);
            AscendC::Div(a, a, c, len);
            // 降回原始 dtype：round-to-nearest-even，与 PyTorch .to() 一致
            AscendC::Cast(outLocal, a, AscendC::RoundMode::CAST_RINT, len);
        }
        outQueue.EnQue(outLocal);
        inQueueX0.FreeTensor(x0Local);
        inQueueX1.FreeTensor(x1Local);
    }

    __aicore__ inline void CopyOut(int64_t off, int64_t len)
    {
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        auto outLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(outGm[off], outLocal, copyParams);
        outQueue.FreeTensor(outLocal);
    }

    __aicore__ inline void CopyOutRowsPadded(int64_t o, int64_t rows)
    {
        uint32_t rowBytes = static_cast<uint32_t>(blockOutVal * sizeof(T));
        AscendC::DataCopyExtParams copyParams{1, rowBytes, 0, 0, 0};
        auto outLocal = outQueue.DeQue<T>();
        int64_t base = o * blockOutVal;
        for (int64_t i = 0; i < rows; ++i) {
            AscendC::DataCopyPad(outGm[base + i * blockOutVal], outLocal[i * slotElemsVal], copyParams);
        }
        outQueue.FreeTensor(outLocal);
    }

private:
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, SWI_GLU_PIPELINE_DEPTH> inQueueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, SWI_GLU_PIPELINE_DEPTH> inQueueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, SWI_GLU_PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBufA;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBufB;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBufC;
    AscendC::GlobalTensor<T> inGm;
    AscendC::GlobalTensor<T> outGm;
    int64_t totalOutVal = 0;
    int64_t blockOutVal = 0;
    int64_t fullStrideVal = 0;
    int64_t tileElemsVal = 0;
    int64_t maxRowsVal = 0;
    int64_t slotElemsVal = 0;
    int64_t padRowsVal = 0;
    int64_t startPosVal = 0;
    int64_t endPosVal = 0;
};

template <typename T>
__global__ __aicore__ void swi_glu_kernel(GM_ADDR input, GM_ADDR output, int64_t totalOut,
                                          int64_t blockOut, int64_t fullStride,
                                          int64_t blockLength, int64_t tileElems)
{
    SwiGluKernel<T> op;
    op.Init(input, output, totalOut, blockOut, fullStride, blockLength, tileElems);
    op.Process();
}

// Tiling function
std::tuple<int64_t, int64_t, int64_t> calc_swi_glu_tiling_params(int64_t totalOut, int64_t elemSize)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 2048;
    constexpr static int64_t MAX_TILE_ELEMS = 16384;
    constexpr static int64_t TILE_ALIGN_ELEMS = 16; // 保证 tileElems*sizeof(T) 为 32B 整数倍
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    int64_t numBlocks = std::min<int64_t>(coreNum, (totalOut + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalOut + numBlocks - 1) / numBlocks;
    // 3 个深度为 2 的 T 类型队列 + FP32 临时缓冲（fp32 路径仅需 1 个）
    int64_t bytesPerElem = 6 * elemSize + ((elemSize == 4) ? 4 : 12);
    int64_t maxTileElems = static_cast<int64_t>(ubSize) * 9 / 10 / bytesPerElem;
    int64_t tileElems = std::min<int64_t>(maxTileElems, MAX_TILE_ELEMS);
    if (tileElems < 64) tileElems = 64;
    tileElems -= tileElems % TILE_ALIGN_ELEMS;
    if (tileElems < TILE_ALIGN_ELEMS) tileElems = TILE_ALIGN_ELEMS;
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_swi_glu_kernel_float(GM_ADDR input, GM_ADDR output, int64_t totalOut,
                                 int64_t blockOut, int64_t fullStride, int64_t numBlocks,
                                 int64_t blockLength, int64_t tileElems, void* stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(input, output, totalOut, blockOut, fullStride, blockLength, tileElems);
}

void launch_swi_glu_kernel_half(GM_ADDR input, GM_ADDR output, int64_t totalOut,
                                int64_t blockOut, int64_t fullStride, int64_t numBlocks,
                                int64_t blockLength, int64_t tileElems, void* stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(input, output, totalOut, blockOut, fullStride, blockLength, tileElems);
}

void launch_swi_glu_kernel_bfloat16(GM_ADDR input, GM_ADDR output, int64_t totalOut,
                                    int64_t blockOut, int64_t fullStride, int64_t numBlocks,
                                    int64_t blockLength, int64_t tileElems, void* stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(input, output, totalOut, blockOut, fullStride, blockLength, tileElems);
}

}
