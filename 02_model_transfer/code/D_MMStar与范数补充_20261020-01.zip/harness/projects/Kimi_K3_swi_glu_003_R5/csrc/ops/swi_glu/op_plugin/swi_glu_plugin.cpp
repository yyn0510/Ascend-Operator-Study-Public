/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_plugin.cpp
 * \brief SwiGlu API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    auto sizes = input.sizes().vec();
    int64_t rank = static_cast<int64_t>(sizes.size());
    TORCH_CHECK(rank >= 1, "swi_glu: input must have at least 1 dimension.");
    int64_t d = dim;
    if (d < 0) d += rank;
    TORCH_CHECK(d >= 0 && d < rank, "swi_glu: dim out of range.");
    TORCH_CHECK(sizes[d] % 2 == 0, "swi_glu: size of split dim must be even.");
    sizes[d] /= 2;
    return torch::empty(sizes, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto inputContig = input.contiguous();
    auto output = swi_glu_meta(inputContig, dim);
    int64_t totalOut = output.numel();
    if (totalOut == 0) {
        return output;
    }
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    auto sizes = inputContig.sizes();
    int64_t rank = static_cast<int64_t>(sizes.size());
    int64_t d = dim;
    if (d < 0) d += rank;
    int64_t innerSize = 1;
    for (int64_t i = d + 1; i < rank; ++i) {
        innerSize *= sizes[i];
    }
    int64_t blockOut = (sizes[d] / 2) * innerSize;
    int64_t fullStride = sizes[d] * innerSize;
    int64_t elemSize = inputContig.element_size();

    int64_t numBlocks, blockLength, tileElems;
    std::tie(numBlocks, blockLength, tileElems) = calc_swi_glu_tiling_params(totalOut, elemSize);

    auto in_ptr = (GM_ADDR)inputContig.data_ptr();
    auto out_ptr = (GM_ADDR)output.data_ptr();
    auto dtype = inputContig.scalar_type();

    auto acl_call = [=]() -> int {
        if (dtype == torch::kFloat32) {
            launch_swi_glu_kernel_float(in_ptr, out_ptr, totalOut, blockOut, fullStride,
                                        numBlocks, blockLength, tileElems, stream);
        } else if (dtype == torch::kHalf) {
            launch_swi_glu_kernel_half(in_ptr, out_ptr, totalOut, blockOut, fullStride,
                                       numBlocks, blockLength, tileElems, stream);
        } else if (dtype == torch::kBFloat16) {
            launch_swi_glu_kernel_bfloat16(in_ptr, out_ptr, totalOut, blockOut, fullStride,
                                           numBlocks, blockLength, tileElems, stream);
        } else {
            TORCH_CHECK(false, "swi_glu: unsupported dtype.");
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return output;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
