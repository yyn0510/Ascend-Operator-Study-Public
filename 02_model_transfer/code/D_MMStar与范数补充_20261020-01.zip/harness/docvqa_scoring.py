"""Draft, explicit short-answer scoring, with missing/failed outputs in denominator.

ANLS convention: lowercase and strip both strings; normalized Levenshtein
similarity >= .5 is retained. Internal whitespace remains significant.
Literal 'none' is ordinary text. This is not a claim of byte-identical official
competition scoring. Freeze and disclose this definition before formal runs.
"""
from collections import Counter

def normalize(text):return text.lower().strip()

def distance(a,b):
    previous=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        current=[i]
        for j,y in enumerate(b,1):current.append(min(current[-1]+1,previous[j]+1,previous[j-1]+(x!=y)))
        previous=current
    return previous[-1]

def anls(answers,prediction):
    if not isinstance(prediction,str):return 0.0
    pred=normalize(prediction)
    if not pred:return 0.0
    scores=[]
    for answer in answers:
        answer=normalize(answer);size=max(len(answer),len(pred))
        value=1-distance(answer,pred)/size if size else 0
        scores.append(value if value>=.5 else 0)
    return max(scores,default=0.0)

def score_predictions(samples,predictions):
    expected={str(s['id']):s for s in samples}
    if len(expected)!=len(samples) or not expected:raise ValueError('Need nonempty unique sample IDs')
    outputs={}
    for row in predictions:
        key=str(row['id'])
        if key in outputs or key not in expected:raise ValueError('Duplicate or unknown prediction ID')
        outputs[key]=row
    rows=[];states=Counter()
    for key,sample in expected.items():
        p=outputs.get(key);state='missing' if p is None else p.get('status','success')
        text=None if p is None else p.get('text')
        valid=state=='success' and isinstance(text,str) and bool(text.strip())
        if state=='success' and not valid:state='empty_or_invalid'
        states[state]+=1
        score=anls(sample['answers'],text) if valid else 0.0
        exact=int(valid and normalize(text) in [normalize(a) for a in sample['answers']])
        rows.append({'id':key,'group_id':sample['group_id'],'state':state,'anls':score,'em':exact})
    return {'questions':len(samples),'anls':sum(r['anls'] for r in rows)/len(samples),
            'em':sum(r['em'] for r in rows)/len(samples),'states':dict(states),'per_sample':rows}

def self_test():
    assert anls(['none'],'none')==1
    assert anls(['ab'],'ac')==.5
    assert anls(['ab'],'axxx')==0
    assert anls(['a b'],'a  b')==.75
    assert anls(['target'],' '*100+'wrong'+' '*100)==0
    samples=[{'id':str(i),'group_id':'doc'+str(i//2),'answers':['none']} for i in range(4)]
    pred=[{'id':'0','text':'NONE','status':'success'}, {'id':'1','text':'none','status':'failure'},
          {'id':'2','text':'','status':'success'}]
    result=score_predictions(samples,pred)
    assert result['questions']==4 and result['anls']==result['em']==.25
    assert result['states']=={'success':1,'failure':1,'empty_or_invalid':1,'missing':1}
    rejected=0
    for extra in ([{'id':'0','text':'none'},{'id':'0','text':'none'}],[{'id':'unknown','text':'none'}]):
        try:score_predictions(samples,extra)
        except ValueError:rejected+=1
    assert rejected==2
    return {'status':'passed','literal_none_retained':True,'threshold_boundary_inclusive':True,
            'internal_whitespace_significant':True,'padding_denominator_not_inflated':True,
            'failed_empty_missing_stay_in_denominator':True,'duplicate_and_foreign_ids_rejected':True}

if __name__=='__main__':
    import json
    from pathlib import Path
    result=self_test()
    Path(__file__).with_name('scoring_pipeline_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))
