"""Serial C experiments, verified checkpoints, restartable steps and rollback."""
import argparse
from contextlib import ExitStack
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
import zipfile

HERE=Path(__file__).resolve().parent

def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.tmp');temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');temporary.replace(path)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()
def fingerprint(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def verify_package():
    for name,row in read(HERE/'PACKAGE_MANIFEST.json').items():
        path=(HERE/name).resolve()
        if not path.is_relative_to(HERE) or not path.is_file() or sha(path)!=row['sha256']:raise ValueError('Package changed: '+name)

class CandidateFailure(RuntimeError):pass

class Batch:
    def __init__(self,args):
        self.args=args;self.plan=read(HERE/'plan.json');self.out=HERE/'results'/args.run_id
        self.out.mkdir(parents=True,exist_ok=True)
        path=self.out/'batch_status.json'
        if path.exists():
            if not args.resume:raise FileExistsError('Existing run; use --resume '+args.run_id)
            self.state=read(path)
            if self.state['plan_sha256']!=sha(HERE/'plan.json') or self.state['package_manifest_sha256']!=sha(HERE/'PACKAGE_MANIFEST.json'):
                raise ValueError('Resume requires exactly the same code and frozen protocol')
            self.state['attempt']+=1
        else:
            if args.resume:raise FileNotFoundError('Unknown run to resume')
            self.state={'run_id':args.run_id,'stage':'C','attempt':1,'plan_sha256':sha(HERE/'plan.json'),'package_manifest_sha256':sha(HERE/'PACKAGE_MANIFEST.json'),'steps':{},'candidate_records':{},'restoration':'not_needed','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        self.state.update(status='running',error=None);self.persist()
    def persist(self):save(self.out/'batch_status.json',self.state)
    def task(self,name,action,cacheable=True,allow_failure=False,**values):
        cfg={'output':str(self.out/name),'batch_root':str(self.out),'package':str(HERE),'plan':str(HERE/'plan.json'),'runtime':str(self.out/'runtime.json'),'model_root':str(self.args.model_root.resolve()),'device':self.args.device_id,**values}
        dependencies={}
        for key in ('baseline','actual','captures','receipt','control'):
            if not cfg.get(key):continue
            path=Path(cfg[key])
            if path.is_file():dependencies[key]=sha(path)
            elif path.is_dir():
                names=('STEP_SUCCESS.json','index.json','predictions.json','ranks.jsonl','features.pt')
                dependencies[key]={n:sha(path/n) for n in names if (path/n).is_file()}
        cfg['dependency_sha256']=dependencies
        request_hash=fingerprint(cfg);marker=self.out/name/'STEP_SUCCESS.json'
        if cacheable and marker.exists():
            previous=read(marker)
            if previous['request_sha256']==request_hash and all((self.out/name/rel).is_file() and sha(self.out/name/rel)==digest for rel,digest in previous['artifacts'].items()):
                print('REUSE',name,flush=True);return self.out/name
            if previous['request_sha256']==request_hash:raise ValueError('Completed step artifacts changed: '+name)
            print('INVALIDATE_CHANGED_UPSTREAM',name,flush=True)
        output=self.out/name
        if output.exists():
            # Keep incomplete attempts, including partial answers, before retry.
            old=output.with_name(name+'.incomplete_attempt_'+str(self.state['attempt'])+'_'+str(time.time_ns()))
            output.rename(old)
        invocation=name+'.attempt_'+str(self.state['attempt'])+'_'+str(time.time_ns())
        request=self.out/'requests'/(invocation+'.json');save(request,cfg)
        log=self.out/'logs'/(invocation+'.log');log.parent.mkdir(exist_ok=True)
        record={'name':name,'action':action,'status':'running','attempt':self.state['attempt'],'log':str(log),'request_sha256':request_hash}
        self.state['steps'][name]=record;self.persist();print('START',name,flush=True)
        began=time.monotonic()
        with log.open('x',encoding='utf-8') as stream:
            child=subprocess.Popen([sys.executable,'-u',str(HERE/'workers.py'),action,str(request)],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,cwd=HERE)
            try:
                while child.poll() is None:
                    if time.monotonic()-began>self.args.timeout:raise TimeoutError('Step timeout: '+name)
                    time.sleep(1)
            except BaseException:
                try:os.killpg(child.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    try:os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    child.wait()
                record.update(status='interrupted',seconds=round(time.monotonic()-began,2));self.persist();raise
        record.update(status='completed' if child.returncode==0 else 'failed',returncode=child.returncode,seconds=round(time.monotonic()-began,2));self.persist();print(record['status'].upper(),name,flush=True)
        if child.returncode:
            if not allow_failure:raise RuntimeError('Inspect '+str(log))
            return None
        output.mkdir(parents=True,exist_ok=True)
        artifacts={p.relative_to(output).as_posix():sha(p) for p in output.rglob('*') if p.is_file() and p.name!='STEP_SUCCESS.json' and '__pycache__' not in p.parts}
        save(marker,{'request_sha256':request_hash,'artifacts':artifacts})
        return output
    def health(self,label):self.task('health_'+label,'health',cacheable=False)
    def execute(self):
        attempt=str(self.state['attempt'])
        self.task('preflight_attempt_'+attempt,'preflight',cacheable=False)
        if (self.out/'backup/backup.json').exists():self.task('verify_original_attempt_'+attempt,'verify_original',cacheable=False)
        else:self.task('backup','backup')
        self.baselines()
        for candidate in self.plan['candidates']:
            cid=candidate['candidate_id'];self.state['restoration']='required';self.persist()
            build=self.task('build_'+cid,'build',candidate=cid,allow_failure=True)
            if build is None:
                self.state['candidate_records'][cid]={'stage':'build','eligible':False};self.health(cid);continue
            # A reused build does not imply its wheel is still installed after
            # rollback or another candidate. Install before any fresh benchmark.
            self.task('install_benchmark_'+cid+'_attempt_'+attempt,'install',cacheable=False,candidate=cid,receipt=str(build/'receipt.json'))
            benchmark=self.task('benchmark_'+cid,'benchmark',candidate=cid,receipt=str(build/'receipt.json'),allow_failure=True)
            if benchmark is None or not read(benchmark/'precision_status.json')['full_correct']:
                self.state['candidate_records'][cid]={'stage':'original_benchmark','eligible':False};self.health(cid);continue
            receipt=str(build/'receipt.json');self.state['candidate_records'][cid]={'stage':'original_benchmark','eligible':True,'jobs':{}};self.persist()
            hosts=sorted({job['host'] for job in self.plan['quality_jobs'] if job['candidate']==cid})
            for host in hosts:
                self.task('install_'+host+'_'+cid+'_attempt_'+attempt,'install',cacheable=False,candidate=cid,receipt=receipt)
                jobs=[job for job in self.plan['quality_jobs'] if job['candidate']==cid and job['host']==host]
                for job in jobs:self.quality(candidate,receipt,job)
                # Performance conditions are fixed independently of formal task outcomes.
                for condition in self.plan['performance_jobs']:
                    if condition['candidate']!=cid or condition['host']!=host:continue
                    control=self.out/('performance_control_'+host+'_'+condition['condition']['id'])
                    if not (control/'STEP_SUCCESS.json').is_file():
                        self.state['candidate_records'][cid].setdefault('unmeasured_conditions',[]).append({'host':host,'condition':condition['condition'],'reason':'native_condition_failed'});self.persist();continue
                    for session in range(self.plan['timing']['sessions']):
                        name='performance_'+host+'_'+cid+'_'+condition['condition']['id']+'_s'+str(session)
                        output=self.task(name,'model_performance',candidate=cid,receipt=receipt,host=host,mode='candidate',condition=condition['condition'],session=session,control=str(control),allow_failure=True)
                        if output is None:self.health(name)
                replay=self.task('replay_'+host+'_'+cid,'replay_performance',candidate=cid,receipt=receipt,host=host,mode='candidate',captures=str(self.out/('dev_'+host+'_'+self.dataset(host))/'captures'/candidate['operator']),allow_failure=True)
                if replay is None:self.health('replay_'+host+'_'+cid)
        self.task('analysis','analysis',cacheable=False)
    def dataset(self,host):return 'coco' if host in ('clip','quick_clip') else 'ai2d'
    def baselines(self):
        for host in self.plan['models']:
            for dataset in (['coco'] if host in ('clip','quick_clip') else ['ai2d','docvqa']):
                action='clip' if dataset=='coco' else 'generative'
                limit=11 if dataset=='coco' else 20 if dataset=='docvqa' else 10
                native=self.task('dev_'+host+'_'+dataset,action,host=host,dataset=dataset,mode='native',split='dev',limit=limit,capture=True)
                for op,hosts in self.plan['operator_hosts'].items():
                    if host not in hosts:continue
                    self.task('wrapper_'+host+'_'+dataset+'_'+op,action,host=host,dataset=dataset,operator=op,mode='wrapper',split='dev',limit=limit,baseline=str(native))
                self.task('eval_native_'+host+'_'+dataset,action,host=host,dataset=dataset,mode='native',split='eval')
            for op,hosts in self.plan['operator_hosts'].items():
                if host in hosts:
                    profiled=self.task('profile_'+host+'_'+op,'profile_native',host=host,operator=op,mode='native',condition=self.plan['default_conditions']['clip' if host in ('clip','quick_clip') else 'generative'],allow_failure=True)
                    if profiled is None:self.health('profile_'+host+'_'+op)
            conditions={j['condition']['id']:j['condition'] for j in self.plan['performance_jobs'] if j['host']==host}
            for condition in conditions.values():
                name='performance_control_'+host+'_'+condition['id']
                control=self.task(name,'performance_control',host=host,mode='native',condition=condition,allow_failure=True)
                if control is None:self.health(name)
        # Native references for the two fixed resolution quality checks.
        for pixels in self.plan['resolution_quality_pixels']:
            self.task('resolution_dev_qwen3b_'+str(pixels),'generative',host='qwen3b',dataset='ai2d',mode='native',split='dev',limit=10,capture=True,max_pixels=pixels)
            self.task('resolution_native_qwen3b_'+str(pixels),'generative',host='qwen3b',dataset='ai2d',mode='native',split='dev',limit=100,max_pixels=pixels)
    def quality(self,candidate,receipt,job):
        cid=candidate['candidate_id'];host=job['host'];dataset=job['dataset'];pixels=job.get('max_pixels')
        tag=host+'_'+dataset+'_'+cid+('_pixels'+str(pixels) if pixels else '')
        native_dev=self.out/('resolution_dev_qwen3b_'+str(pixels) if pixels else 'dev_'+host+'_'+dataset)
        captures=native_dev/'captures'/candidate['operator']
        gate=self.task('gate_'+tag,'gate',candidate=cid,receipt=receipt,host=host,captures=str(captures),allow_failure=True)
        if gate is None:
            self.state['candidate_records'][cid]['jobs'][tag]={'stage':'real_input_gate_execution_failed','eligible':False};self.persist();self.health(tag);return
        verdict=read(gate/'eligibility.json')
        self.state['candidate_records'][cid]['jobs'][tag]=verdict;self.persist()
        if not verdict['eligible']:return
        action='clip' if dataset=='coco' else 'generative'
        values={'candidate':cid,'receipt':receipt,'host':host,'dataset':dataset,'mode':'candidate','split':job.get('split','eval')}
        if pixels:values.update(max_pixels=pixels,limit=100)
        baseline=self.out/('resolution_native_qwen3b_'+str(pixels) if pixels else 'eval_native_'+host+'_'+dataset)
        values['baseline']=str(baseline)
        output=self.task('quality_'+tag,action,allow_failure=True,**values)
        if output is None:self.health('quality_'+tag)
        # Includes missing/failed answers in the frozen denominator, including partial jobs.
        self.task('compare_'+tag,'compare_quality',host=host,dataset=dataset,baseline=str(baseline),actual=str(self.out/('quality_'+tag)))
    def finish(self):
        try:
            if self.state['restoration']=='required':
                self.task('restore_attempt_'+str(self.state['attempt']),'restore',cacheable=False);self.state['restoration']='verified'
        except BaseException as error:
            self.state.update(status='stopped_requires_review',restoration='FAILED_requires_review',restore_error=repr(error))
        self.state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();self.persist()
        self.args.export_dir.mkdir(parents=True,exist_ok=True)
        target=self.args.export_dir/(self.args.run_id+'_attempt'+str(self.state['attempt'])+'_results.zip')
        members={}
        for path in self.out.rglob('*'):
            if path.is_file() and path.suffix in ('.json','.jsonl','.md','.log','.txt') and path.stat().st_size<100*1024*1024:
                members['batch/'+path.relative_to(self.out).as_posix()]=path
        for name in ('plan.json','PACKAGE_MANIFEST.json','run_cloud.py','workers.py','base_workers.py','cloud_helpers.py','c_measure.py','README.md','dataset_selection.json'):
            members['provenance/'+name]=HERE/name
        temporary=target.with_suffix('.zip.part')
        with zipfile.ZipFile(temporary,'x',zipfile.ZIP_DEFLATED) as z:
            for name,path in members.items():z.write(path,name)
            z.writestr('EXPORT_MANIFEST.json',json.dumps({name:sha(path) for name,path in members.items()},indent=2))
        temporary.rename(target);print('BATCH_STATUS:',self.state['status'],'\nDOWNLOAD:',target,flush=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--model-root',type=Path,required=True);parser.add_argument('--export-dir',type=Path,required=True)
    parser.add_argument('--background',action='store_true');parser.add_argument('--resume');parser.add_argument('--device-id',type=int,default=0)
    parser.add_argument('--timeout',type=int,default=14400);parser.add_argument('--run-id');parser.add_argument('--plan',action='store_true');args=parser.parse_args()
    if args.plan:
        p=read(HERE/'plan.json');print(json.dumps(p['planned_counts'],ensure_ascii=False,indent=2));return
    if os.name!='posix':raise RuntimeError('C requires Linux Ascend; no CPU fallback')
    verify_package();args.run_id=args.resume or args.run_id or 'extension_C_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+str(os.getpid())
    if Path(args.run_id).name!=args.run_id or args.run_id in ('.','..'):raise ValueError('Unsafe run ID')
    if args.background:
        args.export_dir.mkdir(parents=True,exist_ok=True);stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        log=args.export_dir/(args.run_id+'_'+stamp+'.console.log')
        cmd=[sys.executable,'-u',str(HERE/'run_cloud.py'),*[s for s in sys.argv[1:] if s!='--background']]
        if not args.resume and '--run-id' not in sys.argv:cmd+=['--run-id',args.run_id]
        with log.open('x',encoding='utf-8') as stream:child=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,cwd=HERE)
        save(args.export_dir/(args.run_id+'.pid.json'),{'pid':child.pid,'script':str(HERE/'run_cloud.py'),'run_id':args.run_id,'stage':'C'})
        print('BACKGROUND_PID:',child.pid,'\nRUN_ID:',args.run_id,'\nLOG:',log,'\nDOWNLOAD_PATTERN:',args.export_dir/(args.run_id+'_attempt*_results.zip'));return
    import fcntl
    with ExitStack() as stack:
        for path in (Path('/mnt/workspace/.v3_transfer.lock'),Path('/mnt/workspace/v3_model_transfer/.transfer_batch.lock')):
            if path.parent.exists():
                handle=stack.enter_context(path.open('a'));fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        def stop(*unused):raise KeyboardInterrupt('Termination requested')
        signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
        batch=Batch(args)
        try:batch.execute();batch.state['status']='completed_with_candidate_records'
        except BaseException as error:
            batch.state.update(status='stopped_requires_review',error=repr(error));(batch.out/'exception_attempt_'+str(batch.state['attempt'])).with_suffix('.txt').write_text(traceback.format_exc(),encoding='utf-8')
        finally:batch.finish()

if __name__=='__main__':main()
