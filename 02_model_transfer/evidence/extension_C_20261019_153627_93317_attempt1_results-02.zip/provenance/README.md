# C包：正式扩展实验

本包固定31份B准入候选，不修改生成内核。既有A位置实验保留；这里扩大候选、跨规模/跨家族、DocVQA及输入性能范围。plan.json在正式运行前固定，运行结果不用于更换代表。

大权重复用云端build目录下五个原模型。上传“待上传”全部文件，启动：python /mnt/workspace/gitCode/cann/cann-learning-hub/build/start_stage_c.py。C文件名均带c前缀，不与A/B模型配置ZIP混用。

程序先复核原生与包装、DocVQA真实输入，再逐候选构建/原20例/输入准入/任务/性能。质量评估保持默认BF16；FP16仅用于明确标注的张量回放，不混入模型质量。分辨率质量扫描使用固定100题dev，正式任务使用各自固定1000题/图像子集。DocVQA不是官方整套验证集榜单结果，明确报告所抽取子集和ANLS式指标定义。

生成性能使用固定长度的合成文本和固定新token数，不用于质量结论。输入预处理在计时外，包含模型generate、调用与必要适配；首token由HF streamer观测，所有模式保留相同transfer开销。检索前向计时不等于完整检索吞吐。逐激活NPU事件剖析是带观测开销的诊断占比，不能当作精确无干预Amdahl上限。

相同C版本中断后可续跑：python /mnt/workspace/gitCode/cann/cann-learning-hub/build/start_stage_c.py --resume 原RUN_ID。已完成步骤只有在请求及依赖/输出哈希均匹配时才复用。保留原云端结果、tensor、wheel和模型；不要删除这些文件。代码、协议或环境变化时停止复用。候选结果、未测与失败分别记录。

停止：python /mnt/workspace/gitCode/cann/cann-learning-hub/build/stop_stage_c.py。控制器会停止子任务，尝试恢复原算子包，并导出本次attempt的结果ZIP。不要同时运行A/B/C；不要直接结束全部Python进程。

本机仅执行离线协议、源码、数据、CPU适配及控制流程检查。C新功能仍需首次NPU执行验证。遇到原生/包装/身份/环境异常停止复查；候选失败保留，不换实现或放宽容差。性能条件原生失败则该条件不测，其他正式任务可继续。原生检索/生成正式任务失败停止，避免把基础流程故障算作候选问题。
