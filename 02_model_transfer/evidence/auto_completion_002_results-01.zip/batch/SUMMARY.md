# 当前剩余补充实验批次
状态：completed
恢复：restored_and_verified

GELU为新建的有效tanh语义对齐条件；历史none比较不被覆盖。CLIP为Transformers实现的固定OpenCLIP检查点。COCO为固定1000图像内部检索子集，不是官方完整5000图像成绩。

|准入对象|通过/总数|准入|
|---|---:|---|
|clip_Grok_4_6_gelu_001_R4|18/18|True|
|clip_Kimi_K3_gelu_002_R3|18/18|True|
|clip_DeepSeek_V4_1_Flash_foreach_norm_002_R5|6/6|True|
|clip_Grok_4_6_foreach_norm_003_R5|6/6|True|
|qwen_ai2d_Grok_4_6_gelu_001_R4|10/10|True|
|qwen_ai2d_Kimi_K3_gelu_002_R3|10/10|True|
|qwen_mmstar_Grok_4_6_gelu_001_R4|10/10|True|
|qwen_mmstar_Kimi_K3_gelu_002_R3|10/10|True|

## 任务质量（仅已完成输出）

|条件|样本|原生|候选|差值（百分点）|
|---|---:|---:|---:|---:|
|qwen_ai2d_Grok_4_6_gelu_001_R4|1000|79.2000%|78.9000%|-0.3000|
|qwen_ai2d_Kimi_K3_gelu_002_R3|1000|79.2000%|79.2000%|0.0000|
|qwen_mmstar_Grok_4_6_gelu_001_R4|1241|56.7284%|56.8896%|0.1612|
|qwen_mmstar_Kimi_K3_gelu_002_R3|1241|56.7284%|56.7284%|0.0000|

|CLIP条件/方向|指标|原生|候选|差值（百分点）|
|---|---|---:|---:|---:|
|clip_eval_DeepSeek_V4_1_Flash_foreach_norm_002_R5/image_to_text|R@1|74.3000%|74.5000%|0.2000|
|clip_eval_DeepSeek_V4_1_Flash_foreach_norm_002_R5/image_to_text|R@5|92.8000%|93.0000%|0.2000|
|clip_eval_DeepSeek_V4_1_Flash_foreach_norm_002_R5/image_to_text|R@10|96.7000%|96.5000%|-0.2000|
|clip_eval_DeepSeek_V4_1_Flash_foreach_norm_002_R5/text_to_image|R@1|58.2367%|58.1967%|-0.0400|
|clip_eval_DeepSeek_V4_1_Flash_foreach_norm_002_R5/text_to_image|R@5|84.9460%|84.9460%|0.0000|
|clip_eval_DeepSeek_V4_1_Flash_foreach_norm_002_R5/text_to_image|R@10|92.7829%|92.7629%|-0.0200|
|clip_eval_Grok_4_6_foreach_norm_003_R5/image_to_text|R@1|74.3000%|74.5000%|0.2000|
|clip_eval_Grok_4_6_foreach_norm_003_R5/image_to_text|R@5|92.8000%|93.0000%|0.2000|
|clip_eval_Grok_4_6_foreach_norm_003_R5/image_to_text|R@10|96.7000%|96.5000%|-0.2000|
|clip_eval_Grok_4_6_foreach_norm_003_R5/text_to_image|R@1|58.2367%|58.1967%|-0.0400|
|clip_eval_Grok_4_6_foreach_norm_003_R5/text_to_image|R@5|84.9460%|84.9460%|0.0000|
|clip_eval_Grok_4_6_foreach_norm_003_R5/text_to_image|R@10|92.7829%|92.7629%|-0.0200|
|clip_eval_Grok_4_6_gelu_001_R4/image_to_text|R@1|74.3000%|74.0000%|-0.3000|
|clip_eval_Grok_4_6_gelu_001_R4/image_to_text|R@5|92.8000%|92.9000%|0.1000|
|clip_eval_Grok_4_6_gelu_001_R4/image_to_text|R@10|96.7000%|96.5000%|-0.2000|
|clip_eval_Grok_4_6_gelu_001_R4/text_to_image|R@1|58.2367%|58.1967%|-0.0400|
|clip_eval_Grok_4_6_gelu_001_R4/text_to_image|R@5|84.9460%|85.0060%|0.0600|
|clip_eval_Grok_4_6_gelu_001_R4/text_to_image|R@10|92.7829%|92.7229%|-0.0600|
|clip_eval_Kimi_K3_gelu_002_R3/image_to_text|R@1|74.3000%|74.3000%|0.0000|
|clip_eval_Kimi_K3_gelu_002_R3/image_to_text|R@5|92.8000%|92.8000%|0.0000|
|clip_eval_Kimi_K3_gelu_002_R3/image_to_text|R@10|96.7000%|96.7000%|0.0000|
|clip_eval_Kimi_K3_gelu_002_R3/text_to_image|R@1|58.2367%|58.2367%|0.0000|
|clip_eval_Kimi_K3_gelu_002_R3/text_to_image|R@5|84.9460%|84.9460%|0.0000|
|clip_eval_Kimi_K3_gelu_002_R3/text_to_image|R@10|92.7829%|92.7829%|0.0000|

## 性能描述统计

|输出目录/阶段|对照模式|工作负载数|原生耗时/该路径耗时（几何平均）|
|---|---|---:|---:|
|clip_model_timing_DeepSeek_V4_1_Flash_foreach_norm_002_R5/clip_forward_on_preprocessed_npu_inputs|wrapper|3|0.9205×|
|clip_model_timing_DeepSeek_V4_1_Flash_foreach_norm_002_R5/clip_forward_on_preprocessed_npu_inputs|candidate|3|0.9813×|
|clip_model_timing_Grok_4_6_foreach_norm_003_R5/clip_forward_on_preprocessed_npu_inputs|wrapper|3|0.9204×|
|clip_model_timing_Grok_4_6_foreach_norm_003_R5/clip_forward_on_preprocessed_npu_inputs|candidate|3|0.9809×|
|clip_model_timing_Grok_4_6_gelu_001_R4/clip_forward_on_preprocessed_npu_inputs|wrapper|3|0.9891×|
|clip_model_timing_Grok_4_6_gelu_001_R4/clip_forward_on_preprocessed_npu_inputs|candidate|3|0.9807×|
|clip_model_timing_Kimi_K3_gelu_002_R3/clip_forward_on_preprocessed_npu_inputs|wrapper|3|0.9896×|
|clip_model_timing_Kimi_K3_gelu_002_R3/clip_forward_on_preprocessed_npu_inputs|candidate|3|0.9791×|
|clip_operator_timing_DeepSeek_V4_1_Flash_foreach_norm_002_R5/norm_adapter_stack_divide|wrapper|6|0.2076×|
|clip_operator_timing_DeepSeek_V4_1_Flash_foreach_norm_002_R5/norm_adapter_stack_divide|candidate|6|0.5841×|
|clip_operator_timing_Grok_4_6_foreach_norm_003_R5/norm_adapter_stack_divide|wrapper|6|0.2377×|
|clip_operator_timing_Grok_4_6_foreach_norm_003_R5/norm_adapter_stack_divide|candidate|6|0.4882×|
|clip_operator_timing_Grok_4_6_gelu_001_R4/gelu_full_call|wrapper|12|1.0021×|
|clip_operator_timing_Grok_4_6_gelu_001_R4/gelu_full_call|candidate|12|0.8937×|
|clip_operator_timing_Kimi_K3_gelu_002_R3/gelu_full_call|wrapper|12|1.0007×|
|clip_operator_timing_Kimi_K3_gelu_002_R3/gelu_full_call|candidate|12|0.9503×|
|qwen_operator_timing_Grok_4_6_gelu_001_R4/gelu_full_call|wrapper|10|0.9973×|
|qwen_operator_timing_Grok_4_6_gelu_001_R4/gelu_full_call|candidate|10|0.8763×|
|qwen_operator_timing_Kimi_K3_gelu_002_R3/gelu_full_call|wrapper|10|1.0009×|
|qwen_operator_timing_Kimi_K3_gelu_002_R3/gelu_full_call|candidate|10|0.9544×|
|qwen_timing_Grok_4_6_gelu_001_R4/fixed_teacher_forced_decode|wrapper|30|0.9998×|
|qwen_timing_Grok_4_6_gelu_001_R4/fixed_teacher_forced_decode|candidate|30|0.9955×|
|qwen_timing_Grok_4_6_gelu_001_R4/prefill|wrapper|30|0.9987×|
|qwen_timing_Grok_4_6_gelu_001_R4/prefill|candidate|30|0.9984×|
|qwen_timing_Kimi_K3_gelu_002_R3/fixed_teacher_forced_decode|wrapper|30|1.0004×|
|qwen_timing_Kimi_K3_gelu_002_R3/fixed_teacher_forced_decode|candidate|30|1.0007×|
|qwen_timing_Kimi_K3_gelu_002_R3/prefill|wrapper|30|0.9986×|
|qwen_timing_Kimi_K3_gelu_002_R3/prefill|candidate|30|0.9947×|

完整日志、协议、逐题预测、检索排名、配对统计与原始计时见子目录。
输入图片、模型权重、捕获张量、特征缓存与wheel不放入返回包，仍在云端。
若状态为stopped_requires_review，请返回此结果包分析，不原地覆盖重跑。