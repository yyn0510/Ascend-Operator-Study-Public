"""Independent C follow-up: upload this file to the existing build directory.

Default: detach and print log/result paths. --stop: graceful stop.
--resume RUN_ID: reuse verified completed steps in this follow-up only.
Does not modify original C code, protocol, candidates or results.
"""
import argparse
from contextlib import ExitStack
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
import zipfile

SOURCE_ROOT=Path('/mnt/workspace/v3_extension_stage_c_20261019')
SOURCE_RUN='extension_C_20261019_153627_93317'
FOLLOWUP_ROOT=Path('/mnt/workspace/v3_extension_c_followup_20261020')
SCRIPT=Path(__file__).resolve()
SWI=['DeepSeek_V4_1_Flash_swi_glu_002_R4','Kimi_K3_swi_glu_003_R5']
NORM='Grok_4_6_foreach_norm_001_R5'
PINNED={
    'plan.json':'606afeb23b80f0daa748cad95881d726037dca141b5e9dcf83de6efe878008b9',
    'PACKAGE_MANIFEST.json':'d0cfa5baa0f1e937393fbc420fa0cff0e8e3524f761599d92350d366ca42ce8c',
    'results/'+SOURCE_RUN+'/runtime.json':'d79247604b1f2ab079c678fda5595398be8ccb50c3f3d031b5194d256afe0021',
    'results/'+SOURCE_RUN+'/build_'+SWI[0]+'/receipt.json':'a93bf4a2241f424100b0045cd73473a8028aed3edc762bc86d7cd89534b93ff1',
    'results/'+SOURCE_RUN+'/build_'+SWI[1]+'/receipt.json':'829c50a40e63165024fe2311fe78985605be647a51d88355de71fa3068a98905',
    'results/'+SOURCE_RUN+'/build_'+NORM+'/receipt.json':'e5a8868e7fc310d61c0b12b37ba90ead87e4db7dd31aeb4f25548c84f279fa8c',
    'results/'+SOURCE_RUN+'/dev_clip_coco/captures/foreach_norm/index.json':'c5395fdc729f55f04eeb203ca54c71c282e7c1b417b9366b40a4e99994781ffa',
    'results/'+SOURCE_RUN+'/replay_clip_'+NORM+'/replay_results.json':'94f10298f381d9ac2a9f15345d022a583fbd622ef9437754b6448e80dec1d704',
}


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');tmp.replace(path)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()
def fingerprint(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def source_out():return SOURCE_ROOT/'results'/SOURCE_RUN
def receipt(cid):return source_out()/('build_'+cid)/'receipt.json'
def stamp():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y%m%d_%H%M%S')


def followup_protocol():
    text=' test'*127
    return {'stage':'C_followup','source_C_run':SOURCE_RUN,'source_files':PINNED,'script_sha256':sha(SCRIPT),
            'reason':'Complete previously unmeasured C efficiency paths, with original numerical tolerances and kernels.',
            'internvl':{'candidates':SWI,'condition':{'id':'default','batch':1,'max_pixels':401408,'text_tokens':128,'new_tokens':16},
                        'tokenizer_use_fast':False,'synthetic_text':' test repeated 127 times','synthetic_text_sha256':hashlib.sha256(text.encode()).hexdigest(),
                        'changed':'input construction only: slow tokenizer adds a leading token; keep exact 128-token content budget',
                        'sessions_per_candidate':3,'profile_native':True,'independent_numbering':True},
            'foreach_norm':{'candidate':NORM,'dtype':'float16','rows':[1,4,8,32],'paths':['kernel_contract','complete_normalization_adapter'],
                            'not_repeated':'eight BF16 points already recorded in C','contract_unsupported_rows':[128],'implementation_tensor_list_limit':64},
            'not_in_scope':['new quality evaluations','new candidates','kernel edits','tolerance changes','rerunning 24 failed FP16 Sigmoid points']}


def exact_internvl_text(tokenizer,length):
    if length!=128 or getattr(tokenizer,'is_fast',True):raise ValueError('Follow-up requires reviewed slow tokenizer and 128-token budget')
    text=' test'*127
    if len(tokenizer.encode(text,add_special_tokens=False))!=length:raise ValueError('Slow tokenizer no longer matches frozen follow-up input')
    return text


def load_modules():
    sys.path[:0]=[str(SOURCE_ROOT),str(SOURCE_ROOT/'harness')]
    import run_cloud,cloud_helpers,base_workers,workers,c_measure
    # Runtime-only change in this independent worker. Original files stay intact.
    c_measure.synthesize=exact_internvl_text
    return run_cloud,cloud_helpers,base_workers,workers,c_measure


def check_sources():
    for name,digest in PINNED.items():
        path=SOURCE_ROOT/name
        if not path.is_file() or sha(path)!=digest:raise ValueError('Original C material changed/missing: '+name)
    state=read(source_out()/'batch_status.json')
    if state.get('status')!='completed_with_candidate_records' or state.get('restoration')!='verified' or state.get('error') is not None:
        raise ValueError('Original C batch is not completed/restored; inspect before follow-up')


def health(c):
    import torch
    _,helper,_,_,_=load_modules();helper.initialize({k:v for k,v in c.items() if k not in ('candidate','receipt')})
    x=torch.tensor([1.,2.,3.],device=f'npu:{c["device"]}');y=(x+1).cpu();torch.npu.synchronize()
    if not torch.equal(y,torch.tensor([2.,3.,4.])):raise ValueError('NPU arithmetic health check failed')
    save(Path(c['output'])/'health.json',{'basic_npu_arithmetic_passed':True})


def preflight(c):
    rc,helper,base,w,cm=load_modules();check_sources();rc.verify_package()
    helper.initialize(c)
    plan=read(c['plan']);desc=plan['models']['internvl'];folder=Path(c['model_root'])/desc['folder']
    for name,row in desc['files'].items():
        p=folder/name
        if not p.is_file() or p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:raise ValueError('InternVL model file changed: '+name)
    for cid in SWI+[NORM]:
        r=read(receipt(cid))
        if sha(r['wheel'])!=r['wheel_sha256']:raise ValueError('Original compiled wheel changed: '+cid)
    from transformers import AutoTokenizer
    tokenizer=AutoTokenizer.from_pretrained(folder,use_fast=False,local_files_only=True,trust_remote_code=False)
    text=exact_internvl_text(tokenizer,128)
    save(Path(c['output'])/'input_construction_check.json',{'tokenizer':type(tokenizer).__name__,'is_fast':tokenizer.is_fast,
         'original_128_repetitions_token_count':len(tokenizer.encode(' test'*128,add_special_tokens=False)),
         'corrected_content_tokens':len(tokenizer.encode(text,add_special_tokens=False)),'text_sha256':hashlib.sha256(text.encode()).hexdigest(),
         'same_original_condition':plan['default_conditions']['generative']==followup_protocol()['internvl']['condition']})
    health(dict(c,output=str(Path(c['output'])/'health')))


def norm_missing_fp16(c):
    import random,statistics
    import torch,cann_bench
    _,helper,_,_,cm=load_modules()
    from completion_utils import metrics
    helper.initialize(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    old=read(source_out()/('replay_clip_'+NORM)/'replay_results.json')
    expected={('bfloat16',rows,level) for rows in (1,4,8,32) for level in ('kernel_contract','complete_normalization_adapter')}
    if {(r['dtype'],r['rows'],r['level']) for r in old}!=expected:raise ValueError('Original partial replay differs; avoid duplicate/reclassified points')
    source=source_out()/'dev_clip_coco/captures/foreach_norm';index=read(source/'index.json')
    record=next((r for r in index['records'] if r['phase']=='prefill'),index['records'][0]);path=source/record['file']
    if sha(path)!=record['sha256']:raise ValueError('Original real-input tensor changed')
    data=torch.load(path,map_location='cpu',weights_only=True);timing=read(c['plan'])['timing'];results=[]
    save(out/'unsupported_conditions.json',{'rows':128,'dtypes':['bfloat16','float16'],'status':'outside_implementation_contract_not_invoked',
         'limit':64,'evidence':'original C exception: foreach_norm TensorList length must be in [1,64]',
         'note':'BF16 had already raised in original C; FP16 is contract-excluded without an attempted execution. Kernel and adapter not changed.'})
    with torch.inference_mode():
        for rows in (1,4,8,32):
            x=cm.repeat_rows(data['input'],rows).to(device=f'npu:{c["device"]}',dtype=torch.float16)
            for level,native,actual in cm.replay_functions('foreach_norm','clip',cann_bench.foreach_norm,x):
                result={'dtype':'float16','rows':rows,'shape':list(x.shape),'level':level,'source_capture':record,'source_index_sha256':sha(source/'index.json')}
                try:
                    check=metrics(actual(),native());result['local_check']=check
                    if check['passed']:
                        measured={'native':[],'candidate':[]};rng=random.Random(helper.SEED+rows)
                        for fn in (native,actual):
                            for _ in range(timing['replay_warmup']):fn()
                        for block in range(timing['blocks']):
                            order=[('native',native),('candidate',actual)];rng.shuffle(order)
                            for mode,fn in order:
                                torch.npu.synchronize();begin=time.perf_counter()
                                for _ in range(timing['replay_repeats']):fn()
                                torch.npu.synchronize();measured[mode].append(1000*(time.perf_counter()-begin)/timing['replay_repeats'])
                        result.update(status='measured',block_ms=measured,median_ms={mode:statistics.median(v) for mode,v in measured.items()})
                        result['speedup_vs_native']=result['median_ms']['native']/result['median_ms']['candidate']
                    else:result['status']='numerical_gate_failed_not_timed'
                except (RuntimeError,ValueError) as error:
                    result.update(status='condition_error_not_timed',error=repr(error))
                    health(dict(c,output=str(out/('health_'+str(rows)+'_'+level))))
                results.append(result);save(out/'replay_results.json',results)
    save(out/'scope.json',{'dtype':'FP16 only, previously unexecuted supported rows','completed_BF16_points_reused_as_existing_evidence':len(old),
         'timing':'original C synchronized wall blocks, warmup/repeats and adapters; no new pure-kernel timing claim','generated_kernels_modified':False})


def worker(action,request):
    c=read(request)
    if sha(SCRIPT)!=c['followup_script_sha256']:raise ValueError('Follow-up script changed while running')
    _,helper,base,w,cm=load_modules()
    functions={'preflight':preflight,'backup':helper.backup,'verify_original':w.verify_original,'health':health,
               'install':base.install,'profile':cm.profile_native,'control':cm.performance_control,'performance':cm.model_performance,'norm_fp16':norm_missing_fp16}
    if action=='restore':
        Path(c['output']).mkdir(parents=True,exist_ok=False);helper.restore(c)
    else:functions[action](c)


class Runner:
    def __init__(self,args):
        self.args=args;self.out=FOLLOWUP_ROOT/'results'/args.run_id;self.out.mkdir(parents=True,exist_ok=True)
        path=self.out/'batch_status.json';protocol=followup_protocol()
        if path.exists():
            if not args.resume:raise FileExistsError('Use --resume '+args.run_id)
            self.state=read(path)
            if self.state['protocol_sha256']!=fingerprint(protocol):raise ValueError('Follow-up script/protocol changed; do not resume')
            self.state['attempt']+=1
        else:
            if args.resume:raise FileNotFoundError('Unknown follow-up run')
            self.state={'run_id':args.run_id,'stage':'C_followup','protocol_sha256':fingerprint(protocol),'attempt':1,'steps':{},'restoration':'not_needed','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        self.state.update(status='running',error=None);save(self.out/'followup_protocol.json',protocol);self.persist()
    def persist(self):save(self.out/'batch_status.json',self.state)
    def task(self,name,action,allow_failure=False,cacheable=True,**values):
        cfg={'output':str(self.out/name),'batch_root':str(self.out),'plan':str(SOURCE_ROOT/'plan.json'),'runtime':str(source_out()/'runtime.json'),
             'model_root':str(self.args.model_root),'device':0,'followup_script_sha256':sha(SCRIPT),**values}
        deps={}
        for key in ('control','receipt'):
            if key not in cfg:continue
            path=Path(cfg[key]);deps[key]=sha(path) if path.is_file() else {n:sha(path/n) for n in ('STEP_SUCCESS.json','control.json') if (path/n).is_file()}
        cfg['dependency_sha256']=deps;key=fingerprint(cfg);marker=self.out/name/'STEP_SUCCESS.json'
        if cacheable and marker.exists():
            old=read(marker)
            if old['request_sha256']==key:
                if not all((self.out/name/p).is_file() and sha(self.out/name/p)==h for p,h in old['artifacts'].items()):raise ValueError('Cached follow-up output changed: '+name)
                print('REUSE',name,flush=True);return self.out/name
        output=self.out/name
        if output.exists():output.rename(output.with_name(name+'.previous_attempt_'+str(self.state['attempt'])+'_'+str(time.time_ns())))
        token=name+'.attempt'+str(self.state['attempt'])+'_'+str(time.time_ns())
        request=self.out/'requests'/(token+'.json');save(request,cfg);log=self.out/'logs'/(token+'.log');log.parent.mkdir(exist_ok=True)
        row={'name':name,'action':action,'status':'running','log':str(log),'attempt':self.state['attempt']};self.state['steps'][name]=row;self.persist();print('START',name,flush=True)
        begin=time.monotonic()
        with log.open('x',encoding='utf-8') as stream:
            child=subprocess.Popen([sys.executable,'-u',str(SCRIPT),'--worker',action,'--request',str(request)],stdout=stream,stderr=subprocess.STDOUT,cwd=SOURCE_ROOT,start_new_session=True)
            try:
                while child.poll() is None:
                    if time.monotonic()-begin>7200:raise TimeoutError(name)
                    time.sleep(1)
            except BaseException:
                try:os.killpg(child.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    try:os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    child.wait()
                row['status']='interrupted';self.persist();raise
        row.update(status='completed' if child.returncode==0 else 'failed',returncode=child.returncode,seconds=round(time.monotonic()-begin,2));self.persist();print(row['status'].upper(),name,flush=True)
        if child.returncode:
            if allow_failure:return None
            raise RuntimeError('Inspect '+str(log))
        output.mkdir(parents=True,exist_ok=True)
        save(marker,{'request_sha256':key,'artifacts':{p.relative_to(output).as_posix():sha(p) for p in output.rglob('*') if p.is_file() and p.name!='STEP_SUCCESS.json'}})
        return output
    def health(self,name):self.task('health_'+name,'health',cacheable=False)
    def execute(self):
        attempt=str(self.state['attempt']);self.task('preflight_attempt'+attempt,'preflight',cacheable=False)
        if (self.out/'backup/backup.json').exists():self.task('verify_original_attempt'+attempt,'verify_original',cacheable=False)
        else:self.task('backup','backup')
        profile=self.task('profile_internvl','profile',host='internvl',operator='swi_glu',mode='native',condition=followup_protocol()['internvl']['condition'],allow_failure=True)
        if profile is None:self.health('profile')
        control=self.task('control_internvl','control',host='internvl',mode='native',condition=followup_protocol()['internvl']['condition'])
        self.state['restoration']='required';self.persist()
        for cid in SWI:
            self.task('install_'+cid+'_attempt'+attempt,'install',cacheable=False,candidate=cid,receipt=str(receipt(cid)))
            for session in range(3):
                name='performance_internvl_'+cid+'_s'+str(session)
                result=self.task(name,'performance',candidate=cid,receipt=str(receipt(cid)),host='internvl',mode='candidate',condition=followup_protocol()['internvl']['condition'],session=session,control=str(control),allow_failure=True)
                if result is None:self.health(name)
        self.task('install_'+NORM+'_attempt'+attempt,'install',cacheable=False,candidate=NORM,receipt=str(receipt(NORM)))
        self.task('norm_missing_fp16','norm_fp16',candidate=NORM,receipt=str(receipt(NORM)),host='clip',mode='candidate')
        self.summary()
    def summary(self):
        reports=[]
        for cid in SWI:
            for session in range(3):
                p=self.out/('performance_internvl_'+cid+'_s'+str(session))/'summary.json'
                if p.is_file():reports.append({'candidate':cid,'session':session,**read(p)})
        norm=self.out/'norm_missing_fp16/replay_results.json'
        points=read(norm) if norm.exists() else []
        save(self.out/'followup_summary.json',{'source_C_run':SOURCE_RUN,'expected_performance_sessions':6,'performance_statuses':[{'candidate':r['candidate'],'session':r['session'],'status':r['status']} for r in reports],
             'performance_reports':reports,'norm_expected_supported_FP16_points':8,'norm_points':points,
             'norm_unsupported_rows':128,'original_24_FP16_Sigmoid_failures_preserved':True,'original_C_quality_results_unchanged':True})
    def finish(self):
        try:
            if self.state['restoration']=='required':
                self.task('restore_attempt'+str(self.state['attempt']),'restore',cacheable=False);self.state['restoration']='verified'
        except BaseException as error:self.state.update(status='stopped_requires_review',restoration='FAILED_requires_review',restore_error=repr(error))
        self.state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();self.persist()
        target=self.args.model_root/(self.args.run_id+'_attempt'+str(self.state['attempt'])+'_results.zip');tmp=target.with_suffix('.zip.part')
        members={'provenance/run_c_followup.py':SCRIPT,'provenance/original_C_plan.json':SOURCE_ROOT/'plan.json','provenance/original_C_runtime.json':source_out()/'runtime.json'}
        for p in self.out.rglob('*'):
            if p.is_file() and p.suffix in ('.json','.jsonl','.txt','.log','.md') and p.stat().st_size<100*1024*1024:members['batch/'+p.relative_to(self.out).as_posix()]=p
        with zipfile.ZipFile(tmp,'x',zipfile.ZIP_DEFLATED) as z:
            for name,p in members.items():z.write(p,name)
            z.writestr('EXPORT_MANIFEST.json',json.dumps({name:sha(p) for name,p in members.items()},indent=2))
        tmp.rename(target);print('BATCH_STATUS:',self.state['status'],'\nDOWNLOAD:',target,flush=True)


def stop_own(model_root):
    count=0
    for p in model_root.glob('C_followup_*.pid.json'):
        row=read(p);cmd=Path('/proc')/str(row['pid'])/'cmdline'
        if row.get('stop_requested'):continue
        if not cmd.is_file():continue
        args=cmd.read_bytes().split(b'\0')
        if str(SCRIPT).encode() not in args or row['run_id'].encode() not in args:continue
        os.kill(row['pid'],signal.SIGTERM);count+=1;row['stop_requested']=True;save(p,row)
    print('STOP_REQUESTED:',count,'; wait for rollback and results export.')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--foreground',action='store_true');parser.add_argument('--resume');parser.add_argument('--run-id');parser.add_argument('--stop',action='store_true');parser.add_argument('--worker');parser.add_argument('--request');args=parser.parse_args()
    if sys.platform!='linux':raise RuntimeError('Run on the original CANNLab instance, not local CPU')
    args.model_root=SCRIPT.parent
    if args.worker:return worker(args.worker,args.request)
    if args.stop:return stop_own(args.model_root)
    args.run_id=args.resume or args.run_id or 'C_followup_'+stamp()+'_'+str(os.getpid())
    if Path(args.run_id).name!=args.run_id or not args.run_id.startswith('C_followup_'):raise ValueError('Unsafe follow-up run ID')
    if not args.foreground:
        check_sources();log=args.model_root/(args.run_id+'_'+stamp()+'.console.log')
        cmd=[sys.executable,'-u',str(SCRIPT),'--foreground','--run-id',args.run_id]
        if args.resume:cmd+=['--resume',args.resume]
        with log.open('x',encoding='utf-8') as stream:child=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,cwd=SOURCE_ROOT)
        save(args.model_root/(args.run_id+'.pid.json'),{'pid':child.pid,'run_id':args.run_id,'stage':'C_followup','script':str(SCRIPT)})
        print('BACKGROUND_PID:',child.pid,'\nRUN_ID:',args.run_id,'\nLOG:',log,'\nDOWNLOAD_PATTERN:',args.model_root/(args.run_id+'_attempt*_results.zip'));return
    import fcntl
    with ExitStack() as stack:
        for p in (Path('/mnt/workspace/.v3_transfer.lock'),Path('/mnt/workspace/v3_model_transfer/.transfer_batch.lock')):
            if p.parent.exists():
                stream=stack.enter_context(p.open('a'));fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        def stop(*unused):raise KeyboardInterrupt('Termination requested')
        signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
        runner=Runner(args)
        try:runner.execute();runner.state['status']='completed_with_records'
        except BaseException as error:
            runner.state.update(status='stopped_requires_review',error=repr(error));(runner.out/('exception_attempt'+str(runner.state['attempt'])+'.txt')).write_text(traceback.format_exc(),encoding='utf-8')
        finally:runner.finish()

if __name__=='__main__':main()
