"""One isolated confirmation of the unchanged D ForeachNorm candidate.

Upload this one file beside start_stage_d.py. Default detaches; --stop requests
graceful termination and rollback. Three new probe processes, one original
capture, no rebuild, no input/precision/tolerance changes, no shape scan.
"""
import argparse
from contextlib import ExitStack
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
import zipfile

SCRIPT = Path(__file__).resolve()
SOURCE_ROOT = Path('/mnt/workspace/v3_extension_stage_d_20261020')
SOURCE_RUN = 'extension_D_20261020_152026_2347'
FOLLOWUP_ROOT = Path('/mnt/workspace/v3_norm_reproduce_20261020')
CANDIDATE = 'Kimi_K3_foreach_norm_003_R2'
PINNED = {'plan.json': '5097d5b2e5f40e1a911e86e9cd5947c58c700622aca521f8a34c21252d5cc862', 'PACKAGE_MANIFEST.json': '0a2c85c4edb501eb37bc19cba9ccd77f8210a143bacbc472669e0b77ccbcbb40', 'run_cloud.py': '9742e83e4c46638d7b87ca2982659f83ee4fad8ec3393a49c59b04e23d7df3c7', 'base_workers.py': '3b23fa72727b3f2b91b0e29ef87700510a4ef9e8ed7206c383dfa9241dee2ad0', 'cloud_helpers.py': 'e3f806f971f2d1f4d00431864369975fbe7e76d4c114f947f3807098f08948d7', 'workers.py': '34c4411325062ddc50adec5a82e5d7324b14d4e2a94d70afb8dbc709adf09a01', 'harness/candidates.json': '8ddc560379b2b6f66089bd9b36fde2d08e97c1223df115948a915b4cb76fd264', 'harness/common.py': '3344bda565f2d80b69c5d1b9e07c74f1e489f3d7298e7858316d682e9189c6ce', 'harness/host.py': '515233060714d9fd8cdea6f20d30c38b35a0d3fed6d31bdbe74d501a255ab287', 'harness/clip_adapter.py': 'def2dfaf13f5011b350eaca18a4d5b599dc0a0316468b9211dea621a5e5d4076', 'harness/completion_utils.py': '37bc786d7856f7734d1c938092d0fbb46490240095380c7cd505389a40183c74', 'results/extension_D_20261020_152026_2347/runtime.json': '870cfd470315c74dae876b05d92dce5bddd806dced25683b6d651c5881b6bf89', 'results/extension_D_20261020_152026_2347/batch_status.json': '1d1fdf8d55de49c077efd6acb737b8eedba123d071a71e1d96005722ff2fcd60', 'results/extension_D_20261020_152026_2347/build_Kimi_K3_foreach_norm_003_R2/receipt.json': '5fffe780e88b2b7854f6af80e67526ad50fdc456ee1a3c792ca692449bbd7f91', 'results/extension_D_20261020_152026_2347/dev_clip_coco/captures/foreach_norm/index.json': '2896f7509f2c0e61239ac8efad79d1ad0838a3416e3735399e90e22f744e262e', 'results/extension_D_20261020_152026_2347/requests/gate_initial_clip_Kimi_K3_foreach_norm_003_R2.attempt_1_1792485983230789242.json': 'ba9b01aeb1347076c0011c6c594e7991c60fb2a722419f7174bdc712510ea179', 'results/extension_D_20261020_152026_2347/logs/gate_initial_clip_Kimi_K3_foreach_norm_003_R2.attempt_1_1792485983230789242.log': 'c3716c7e85c36850735da32465a2125a7c484751fd72a8fed3b1f937969c829a'}
ORIGINAL_REQUEST_MEMBER = 'results/extension_D_20261020_152026_2347/requests/gate_initial_clip_Kimi_K3_foreach_norm_003_R2.attempt_1_1792485983230789242.json'
EXPECTED_CAPTURE_SHA = '9decf47842937549cc1e737e38a531abf4b1f230f54433134e734b8e0e1e20c4'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def stamp():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y%m%d_%H%M%S')


def source_out():
    return SOURCE_ROOT / 'results' / SOURCE_RUN


def original_request():
    return read(SOURCE_ROOT / ORIGINAL_REQUEST_MEMBER)


def check_sources():
    for name, expected in PINNED.items():
        path = SOURCE_ROOT / name
        if not path.is_file() or sha(path) != expected:
            raise ValueError('Original D file missing/changed; no rebuild or recapture: ' + name)
    state = read(source_out() / 'batch_status.json')
    if (state.get('status') != 'completed_with_candidate_records'
            or state.get('restoration') != 'verified' or state.get('error') is not None):
        raise ValueError('Original D state is not completed and restored')
    c = original_request()
    if c['candidate'] != CANDIDATE or c['host'] != 'clip' or c['device'] != 0:
        raise ValueError('Original failed request differs')
    if Path(c['plan']) != SOURCE_ROOT / 'plan.json' or Path(c['runtime']) != source_out() / 'runtime.json':
        raise ValueError('Original plan/runtime path differs')
    captures = Path(c['captures'])
    if captures != source_out() / 'dev_clip_coco/captures/foreach_norm':
        raise ValueError('Unexpected original capture path')
    record = read(captures / 'index.json')['records'][0]
    if record['file'] != '0000.pt' or record['shape'] != [8, 512] or record['dtype'] != 'torch.bfloat16':
        raise ValueError('First failing capture metadata differs')
    if record['sha256'] != EXPECTED_CAPTURE_SHA or sha(captures / record['file']) != EXPECTED_CAPTURE_SHA:
        raise ValueError('Original failing tensor missing/changed; do not substitute another input')
    receipt_path = Path(c['receipt'])
    if receipt_path != source_out() / ('build_' + CANDIDATE) / 'receipt.json':
        raise ValueError('Unexpected original receipt')
    receipt = read(receipt_path)
    wheel = Path(receipt['wheel'])
    if not wheel.resolve().is_relative_to((source_out() / ('build_' + CANDIDATE) / 'wheels').resolve()):
        raise ValueError('Not the immutable original D wheel')
    if not wheel.is_file() or sha(wheel) != receipt['wheel_sha256']:
        raise ValueError('Original compiled wheel missing/changed; no automatic rebuild')
    if receipt['soc'] != 'ascend910b':
        raise ValueError('Original build SoC differs')
    return {'candidate': CANDIDATE, 'receipt_sha256': sha(receipt_path),
            'wheel_sha256': sha(wheel), 'binary_sha256': receipt['binary_sha256'],
            'wrapper_sha256': receipt['wrapper_sha256'], 'capture_sha256': EXPECTED_CAPTURE_SHA}


def modules():
    sys.path[:0] = [str(SOURCE_ROOT), str(SOURCE_ROOT / 'harness')]
    import cloud_helpers
    return cloud_helpers


def device_health(c):
    import torch
    helper = modules()
    helper.initialize({k: v for k, v in c.items() if k not in ('candidate', 'receipt')})
    x = torch.tensor([1., 2., 3.], device=f'npu:{c["device"]}')
    y = (x + 1).cpu()
    torch.npu.synchronize()
    if not torch.equal(y, torch.tensor([2., 3., 4.])):
        raise ValueError('Fresh-process NPU arithmetic health check failed')
    return {'basic_NPU_arithmetic_passed': True, 'pid': os.getpid()}


def probe(c):
    out = Path(c['output'])
    out.mkdir(parents=True, exist_ok=False)
    result = {'probe': c['probe'], 'pid': os.getpid(), 'status': 'initializing',
              'candidate': CANDIDATE, 'original_capture_sha256': EXPECTED_CAPTURE_SHA,
              'phase': 'identity_and_environment', 'candidate_call_attempted': False}

    def checkpoint():
        save(out / 'result.json', result)
    checkpoint()
    try:
        check_sources()
        helper = modules()
        import torch
        import cann_bench
        from completion_utils import metrics, TOL
        from clip_adapter import rowwise_foreach_norm
        from host import record_device_status
        from transformers.models.clip.modeling_clip import _get_vector_norm
        result['identity'] = helper.initialize(c)
        result['device_before'] = device_health(c)
        record_device_status(out)
        captures = Path(c['captures'])
        index = read(captures / 'index.json')
        if (index['host'], index['mode'], index['plan_sha256'], index['runtime_sha256']) != (
                'clip', 'native', sha(c['plan']), sha(c['runtime'])):
            raise ValueError('Original capture metadata differs from original request')
        record = index['records'][0]
        data = torch.load(captures / record['file'], weights_only=True, map_location='cpu')
        if list(data['input'].shape) != [8, 512] or data['input'].dtype != torch.bfloat16:
            raise ValueError('Original tensor shape/dtype differs')
        result.update(capture=record, tolerance=TOL,
                      instrumentation='Added health and native-reference checks before one unchanged candidate invocation; original allocation state is not claimed identical')
        with torch.inference_mode():
            x = data['input'].to(f'npu:{c["device"]}')
            ref = data['reference']
            result['phase'] = 'native_reference_control'
            checkpoint()
            native = _get_vector_norm(x)
            result['native_reference'] = metrics(native, ref)
            if not result['native_reference']['exact_equal']:
                raise ValueError('Native replay differs from the saved reference; stop instead of attributing it to candidate')
            result.update(phase='candidate_call_and_output_checks', candidate_call_attempted=True,
                          candidate_invocations=1, tensor_list_length=8, tensor_length=512, norm_p=2.0)
            checkpoint()
            print('CANDIDATE_CALL_START', c['probe'], 'pid=', os.getpid(), flush=True)
            actual = rowwise_foreach_norm(x, cann_bench.foreach_norm)
            if actual.device != x.device:
                raise ValueError('Candidate returned off-device output')
            result['local_check'] = metrics(actual, ref)
            result['normalized_features_check'] = metrics(x / actual, x / native)
            torch.npu.synchronize()
            result['status'] = ('success_within_fixed_tolerance'
                                if result['local_check']['passed'] and result['normalized_features_check']['passed']
                                else 'numerical_check_failed')
            result['phase'] = 'completed'
            checkpoint()
        print('PROBE_RECORDED', result['status'], flush=True)
        return 0
    except Exception as error:
        trace = traceback.format_exc()
        result.update(status='candidate_execution_failed' if result['candidate_call_attempted'] else 'control_or_environment_failed',
                      error_type=type(error).__name__, error=str(error), traceback=trace)
        # Some driver diagnostics appear only in stderr, retained in the step log.
        result['alignment_exception_in_python_message'] = any(s in trace.lower() for s in ('not aligned', '507035'))
        checkpoint()
        print(trace, flush=True)
        return 0 if result['candidate_call_attempted'] else 2


def worker(action, request):
    c = read(request)
    if sha(SCRIPT) != c['script_sha256']:
        raise ValueError('Confirmation script changed during batch')
    if action == 'probe':
        return probe(c)
    helper = modules()
    out = Path(c['output'])
    if action == 'preflight':
        out.mkdir(parents=True, exist_ok=False)
        save(out / 'identity.json', check_sources())
        helper.initialize({k: v for k, v in c.items() if k not in ('candidate', 'receipt')})
        save(out / 'health.json', device_health(c))
    elif action == 'backup':
        helper.backup(c)
    elif action == 'install':
        # Reinstall the exact archived wheel. No build command is allowed here.
        check_sources()
        import base_workers
        base_workers.install(c)
    elif action == 'health':
        out.mkdir(parents=True, exist_ok=False)
        save(out / 'health.json', device_health(c))
    elif action == 'restore':
        out.mkdir(parents=True, exist_ok=False)
        helper.restore(c)
    else:
        raise ValueError(action)
    return 0


def classify(results):
    counts = {}
    for r in results:
        counts[r['status']] = counts.get(r['status'], 0) + 1
    if len(results) != 3:
        conclusion = 'incomplete_requires_review'
    elif counts.get('candidate_execution_failed') == 3:
        conclusion = ('execution_failure_with_same_alignment_signature_3_of_3'
                      if all(r.get('alignment_signature_in_log') for r in results)
                      else 'execution_failures_3_of_3_inspect_error_types')
    elif counts.get('success_within_fixed_tolerance') == 3:
        conclusion = 'original_failure_not_reproduced_in_three_confirmations'
    elif counts.get('candidate_execution_failed', 0) and counts.get('success_within_fixed_tolerance', 0):
        conclusion = 'intermittent_execution_failure_observed'
    else:
        conclusion = 'mixed_or_numerical_results_inspect_all_records'
    return {'attempts_recorded': len(results), 'expected_attempts': 3, 'counts': counts, 'conclusion': conclusion,
            'interpretation': 'Three fresh processes are repeatability evidence for this frozen capture, not a failure-rate estimate or proof of the precise offending instruction',
            'candidate_and_input_policy': 'fixed original D wheel and exact first capture; no replacement or recapture',
            'identity_confirmed_for_all_recorded_probes': bool(results) and all(
                r.get('identity') and r.get('original_capture_sha256') == EXPECTED_CAPTURE_SHA for r in results),
            'kernel_edited': False, 'results': results}


class Runner:
    def __init__(self, run_id, upload):
        self.upload = upload
        self.out = FOLLOWUP_ROOT / 'results' / run_id
        self.out.mkdir(parents=True, exist_ok=False)
        self.state = {'run_id': run_id, 'stage': 'D_norm_repeatability', 'steps': {},
                      'restoration': 'not_needed', 'error': None, 'status': 'running',
                      'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        save(self.out / 'protocol.json', {'original_D_run': SOURCE_RUN, 'original_request': ORIGINAL_REQUEST_MEMBER,
              'candidate': CANDIDATE, 'script_sha256': sha(SCRIPT), 'pinned_files': PINNED,
              'capture_sha256': EXPECTED_CAPTURE_SHA, 'repetitions': 3, 'new_process_each': True,
              'no_rebuild': True, 'no_input_changes': True, 'no_tolerance_changes': True,
              'no_further_candidates_or_shape_scans': True,
              'stop_rule': 'control/environment/identity failure stops for review; candidate failure retained, check fresh device health before continuing',
              'instrumentation': 'health/native reference prechecks added; no claim of identical allocator history'})
        self.persist()

    def persist(self):
        save(self.out / 'batch_status.json', self.state)

    def task(self, name, action, **values):
        c = original_request()
        c.update(output=str(self.out / name), batch_root=str(self.out), script_sha256=sha(SCRIPT), **values)
        request = self.out / 'requests' / (name + '.json')
        log = self.out / 'logs' / (name + '.log')
        save(request, c)
        log.parent.mkdir(exist_ok=True)
        row = {'action': action, 'status': 'running', 'log': str(log), 'request_sha256': sha(request)}
        self.state['steps'][name] = row
        self.persist()
        print('START', name, flush=True)
        began = time.monotonic()
        with log.open('x', encoding='utf-8') as stream:
            child = subprocess.Popen([sys.executable, '-u', str(SCRIPT), '--worker', action, '--request', str(request)],
                                     stdout=stream, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                     start_new_session=True, cwd=SOURCE_ROOT)
            row['child_pid'] = child.pid
            self.persist()
            try:
                while child.poll() is None:
                    if time.monotonic() - began > 600:
                        raise TimeoutError('Step exceeded 600 seconds: ' + name)
                    time.sleep(1)
            except BaseException:
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    child.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.wait()
                row['status'] = 'interrupted'
                self.persist()
                raise
        row.update(status='completed' if child.returncode == 0 else 'failed', returncode=child.returncode,
                   seconds=round(time.monotonic()-began, 2))
        self.persist()
        print(row['status'].upper(), name, flush=True)
        if child.returncode:
            raise RuntimeError('Inspect ' + str(log))
        return self.out / name

    def summary(self):
        records = []
        for i in range(1, 4):
            p = self.out / f'probe_{i}/result.json'
            if p.exists():
                r = read(p)
                log = self.out / f'logs/probe_{i}.log'
                text = log.read_text(encoding='utf-8', errors='replace') if log.exists() else ''
                r['alignment_signature_in_log'] = ('The UB address accessed by the VEC instruction is not aligned' in text
                                                     or '507035' in text)
                records.append(r)
        save(self.out / 'repeatability_summary.json', classify(records))

    def execute(self):
        self.task('preflight', 'preflight')
        self.task('backup', 'backup')
        # Set rollback requirement before any package mutation, including a partial pip failure.
        self.state['restoration'] = 'required'
        self.persist()
        self.task('install_original_D_wheel', 'install')
        pids = set()
        for i in range(1, 4):
            out = self.task(f'probe_{i}', 'probe', probe=i)
            r = read(out / 'result.json')
            print('PROBE_RESULT', i, r['status'], flush=True)
            if r['pid'] in pids:
                raise ValueError('Probe process identity was reused')
            pids.add(r['pid'])
            self.summary()
            self.task(f'fresh_health_after_probe_{i}', 'health')
        self.state['status'] = 'completed_with_records'

    def finish(self):
        try:
            if self.state['restoration'] == 'required':
                self.task('restore', 'restore')
                self.state['restoration'] = 'verified'
        except BaseException as error:
            self.state.update(status='stopped_requires_review', restoration='FAILED_requires_review', restore_error=repr(error))
        self.summary()
        self.state['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self.persist()
        target = self.upload / (self.state['run_id'] + '_results.zip')
        members = {'provenance/run_norm_reproduce.py': SCRIPT}
        for relative in PINNED:
            p = SOURCE_ROOT / relative
            if p.is_file():
                members['provenance/original_D/' + relative] = p
        for p in self.out.rglob('*'):
            if p.is_file() and p.suffix in ('.json', '.txt', '.log', '.md'):
                members['batch/' + p.relative_to(self.out).as_posix()] = p
        # Retain the original error log; no tensors or wheel are included in this small export.
        if (source_out() / 'batch_status.json').is_file():
            original_state = read(source_out() / 'batch_status.json')
            failure = original_state['steps']['gate_initial_clip_' + CANDIDATE]
            if Path(failure['log']).is_file():
                members['provenance/original_D_failure.log'] = Path(failure['log'])
        part = target.with_suffix('.zip.part')
        with zipfile.ZipFile(part, 'x', zipfile.ZIP_DEFLATED) as z:
            for name, path in members.items():
                z.write(path, name)
            z.writestr('EXPORT_MANIFEST.json', json.dumps({n: sha(p) for n, p in members.items()}, indent=2))
        part.rename(target)
        print('BATCH_STATUS:', self.state['status'], '\nDOWNLOAD:', target, flush=True)


def stop_own(upload):
    stopped = 0
    for p in upload.glob('Norm_reproduce_*.pid.json'):
        row = read(p)
        cmd = Path('/proc') / str(row['pid']) / 'cmdline'
        if row.get('stop_requested') or not cmd.is_file():
            continue
        args = cmd.read_bytes().split(b'\0')
        if str(SCRIPT).encode() not in args or row['run_id'].encode() not in args:
            continue
        os.kill(row['pid'], signal.SIGTERM)
        row['stop_requested'] = True
        save(p, row)
        stopped += 1
    print('STOP_REQUESTED:', stopped, '; wait for rollback/export.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--foreground', action='store_true')
    parser.add_argument('--run-id')
    parser.add_argument('--stop', action='store_true')
    parser.add_argument('--worker')
    parser.add_argument('--request')
    args = parser.parse_args()
    if sys.platform != 'linux':
        raise RuntimeError('Run on the original CANNLab instance; local CPU cannot confirm this fault')
    if args.worker:
        return worker(args.worker, args.request)
    upload = SCRIPT.parent
    if args.stop:
        stop_own(upload)
        return 0
    run_id = args.run_id or 'Norm_reproduce_' + stamp() + '_' + str(os.getpid())
    if Path(run_id).name != run_id or not run_id.startswith('Norm_reproduce_'):
        raise ValueError('Unsafe run ID')
    if not args.foreground:
        check_sources()
        log = upload / (run_id + '.console.log')
        with log.open('x', encoding='utf-8') as stream:
            child = subprocess.Popen([sys.executable, '-u', str(SCRIPT), '--foreground', '--run-id', run_id],
                                     stdout=stream, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                     start_new_session=True, cwd=SOURCE_ROOT)
        save(upload / (run_id + '.pid.json'), {'pid': child.pid, 'run_id': run_id, 'script': str(SCRIPT)})
        print('BACKGROUND_PID:', child.pid, '\nRUN_ID:', run_id, '\nLOG:', log,
              '\nDOWNLOAD_WHEN_FINISHED:', upload / (run_id + '_results.zip'))
        return 0
    import fcntl
    with ExitStack() as stack:
        for p in (Path('/mnt/workspace/.v3_transfer.lock'), Path('/mnt/workspace/v3_model_transfer/.transfer_batch.lock')):
            if p.parent.exists():
                stream = stack.enter_context(p.open('a'))
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        runner = Runner(run_id, upload)
        interrupted = False

        def stop(*unused):
            nonlocal interrupted
            if not interrupted:
                interrupted = True
                raise KeyboardInterrupt('Termination requested; rollback follows')
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        try:
            runner.execute()
        except BaseException as error:
            runner.state.update(status='stopped_requires_review', error=repr(error))
            (runner.out / 'exception.txt').write_text(traceback.format_exc(), encoding='utf-8')
        finally:
            signal.signal(signal.SIGTERM, signal.SIG_IGN)
            signal.signal(signal.SIGINT, signal.SIG_IGN)
            runner.finish()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
