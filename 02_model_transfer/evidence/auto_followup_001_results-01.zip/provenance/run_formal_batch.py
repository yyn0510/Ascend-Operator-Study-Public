"""Follow the existing plan: frozen protocol, numerical gates, held-out quality, timing.

Requires run_transfer_batch.py next to this file (the previous uploaded driver).
Original runners, generated kernels and the previous batch remain unchanged.
"""
import argparse
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import signal
import statistics
import subprocess
import sys
import time
import traceback
import zipfile


SIBLING = Path(__file__).resolve().with_name('run_transfer_batch.py')
spec = importlib.util.spec_from_file_location('transfer_driver', SIBLING)
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
read, write, sha = driver.read, driver.write, driver.sha
TOLERANCE = {'atol': 1e-5, 'rtol': 0.016}
RULES = {
    'answer_parser': 'Existing common.parse_answer: one option letter, optional single period; otherwise invalid',
    'invalid_answer_policy': 'Incorrect in the fixed question denominator; raw text preserved',
    'numerical_criterion': '|candidate-reference| <= 1e-5 + 0.016*|reference| for every element; same BF16 rule for both operators',
    'criterion_source': 'https://docs.pytorch.org/docs/2.7/testing.html#torch.testing.assert_close',
    'criterion_limits': 'Engineering closeness criterion, not proof of task equivalence or all-input correctness',
    'eligibility': 'Original benchmark 20/20; identity verified; all recorded host captures pass; no error or nonfinite output',
    'failures': 'Numerical gate failures recorded, never relaxed or replaced. Infrastructure/runtime failures stop for review.',
    'quality': 'Same preselected 1000 held-out questions, image-disjoint from dev, one native baseline and eligible candidates',
    'quality_equivalence_margin': None,
    'performance': 'Original 30 dev workload plan, warmup3, iterations5, blocks3, fixed native tokens16, fresh KV cache',
    'operator_timing': 'NPU synchronized wall time including Python launch and adapter/packing cost, not hardware kernel time',
    'sampling_limit': 'Existing 10-question captures span 3 image groups; SwiGLU capture budget omissions retained and disclosed',
    'harness_change': 'In isolated copied numerics.py only: expected-value relative denominator and rejection of any nonfinite output',
}


def gate_result(report):
    rows = report.get('inputs', [])
    if not rows or report.get('total') != len(rows) or report.get('checked') != len(rows):
        raise ValueError('Replay did not finish all captured inputs')
    if any('error' in row for row in rows):
        raise ValueError('Replay contains execution/metadata errors; review instead of treating as numerical rejection')
    if any(not row.get('wrapper', {}).get('passed') for row in rows):
        raise ValueError('Wrapper numerical control failed')
    passed = sum(bool(row.get('passed')) for row in rows)
    if report.get('passed') != passed:
        raise ValueError('Replay counts disagree')
    return {'eligible': passed == len(rows), 'passed': passed, 'total': len(rows),
            'decision': 'eligible' if passed == len(rows) else 'excluded_by_fixed_numerical_gate'}


def timing_digest(path):
    rows = read(path)['workload_results']
    by_key = {(r['workload'], r['phase'], r['mode']): r for r in rows}
    if len(by_key) != len(rows) or not rows or any(r['blocks'] != 3 or r['median_ms'] <= 0 for r in rows):
        raise ValueError('Missing/duplicate timing blocks or invalid latency')
    result = []
    for phase in sorted({r['phase'] for r in rows}):
        workloads = sorted({r['workload'] for r in rows if r['phase'] == phase})
        for mode in ('wrapper', 'candidate'):
            ratios, variation = [], []
            for work in workloads:
                native = by_key[(work, phase, 'native')]
                current = by_key[(work, phase, mode)]
                ratios.append(native['median_ms'] / current['median_ms'])
                variation.append(current['max_block_ms'] / max(current['min_block_ms'], 1e-12))
            result.append({'phase': phase, 'mode': mode, 'workloads': len(workloads),
                           'geometric_mean_speedup_vs_native': math.exp(sum(math.log(x) for x in ratios)/len(ratios)),
                           'median_workload_speedup_vs_native': statistics.median(ratios),
                           'min_workload_speedup': min(ratios), 'max_workload_speedup': max(ratios),
                           'largest_within_workload_block_max_min_ratio': max(variation),
                           'note': 'Descriptive summary of matched per-workload ratios; raw repetitions retained'})
    return result


def worker(action, cfg):
    if action == 'install':
        return driver.worker(action, cfg)
    if action != 'replay_gate':
        raise ValueError(action)
    command = [sys.executable, str(Path(cfg['harness']) / 'replay_npu.py'), '--protocol', cfg['protocol'],
               '--inputs', cfg['inputs'], '--operator', cfg['operator'], '--candidate-id', cfg['candidate'],
               '--receipt', cfg['receipt'], '--device-id', str(cfg['device']), '--output', cfg['output']]
    result = subprocess.run(command, cwd=cfg['root'])
    if result.returncode not in (0, 2):
        raise RuntimeError(f'Replay infrastructure/process failure: {result.returncode}')
    report = read(Path(cfg['output']) / 'replay.json')
    gate = gate_result(report)
    if (result.returncode == 0) != gate['eligible']:
        raise ValueError('Replay exit status disagrees with recorded numerical result')
    write(Path(cfg['output']) / 'eligibility.json', gate)
    print(json.dumps(gate), flush=True)


class FormalBatch(driver.Batch):
    def __init__(self, args):
        super().__init__(args)
        self.previous = self.root / 'results/auto_dev_001'
        self.harness = self.out / 'harness'
        self.state['scope'] = 'Frozen 1000-question quality comparison and planned operator/model timing'
        self.state['eligibility'] = {}
        self.state['performance'] = {}
        self.state['rules'] = RULES
        self.state['artifacts']['previous_batch'] = str(self.previous)
        self.save()

    def job(self, name, script, args):
        self.command(name, [sys.executable, self.harness / script, *map(str, args)])

    def task(self, name, action, **cfg):
        path = self.out / 'requests' / (name + '.json')
        config = {'root': str(self.root), 'harness': str(self.harness), 'protocol': str(self.protocol),
                  'device': self.a.device_id, 'soc': self.a.soc, **cfg}
        write(path, config)
        self.command(name, [sys.executable, Path(__file__).resolve(), '--worker', action, '--request', path])

    def prepare(self):
        previous = read(self.previous / 'batch_status.json')
        if previous['status'] != 'completed':
            raise ValueError('Previous dev batch is not completed')
        env = read(self.previous / 'preflight.json')
        for name, digest in env['runner_sha256'].items():
            if sha(self.root / name) != digest:
                raise ValueError(f'Original runner changed since dev batch: {name}')
        self.harness.mkdir()
        for p in sorted(self.root.glob('*.py')) + sorted(self.root.glob('*.json')):
            shutil.copyfile(p, self.harness / p.name)
        for name in ('projects', 'data', 'original_benchmark'):
            (self.harness / name).symlink_to(self.root / name, target_is_directory=True)
        p = self.harness / 'numerics.py'
        source = p.read_text(encoding='utf-8')
        old = 'torch.allclose(a, b, equal_nan=True, **tol)'
        new = '(bool(torch.isfinite(a).all()) and bool(torch.isfinite(b).all()) and torch.allclose(b, a, equal_nan=False, **tol))'
        if source.count(old) != 1:
            raise ValueError('Unexpected original numerical checker; refusing an ambiguous patch')
        p.write_text(source.replace(old, new), encoding='utf-8')
        write(self.out / 'harness_change.json', {'file': 'numerics.py', 'original_sha256': sha(self.root / 'numerics.py'),
              'isolated_sha256': sha(p), 'before': old, 'after': new,
              'reason': 'Use reference as the expected-value relative denominator; no nonfinite certification'})
        template = read(self.root / 'protocol.template.json')
        template['tolerances'] = {op: {'bfloat16': dict(TOLERANCE)} for op in ('gelu', 'swi_glu')}
        template['notes'] = 'Frozen before held-out outputs. See rules.json for criterion source and limits. Strict parser unchanged.'
        template['quality_margin_percentage_points'] = None
        self.dev_protocol = self.out / 'protocol.pre_freeze.json'
        write(self.dev_protocol, template)
        write(self.out / 'rules.json', RULES)
        self.job('inspect_frozen_harness', 'run_npu.py', ['--inspect', '--protocol', self.dev_protocol,
                 '--model-path', self.a.model_path.resolve(), '--device-id', self.a.device_id,
                 '--output', self.out / 'inventory'])
        # Preflight inventory also supplies the exact current environment and new runner hashes.
        inventory = read(self.out / 'inventory/inventory.json')
        if inventory['environment'] != env['environment']:
            raise ValueError('Environment changed since completed dev batch')
        revision = read(self.root / 'model_source.api.json')['sha']
        self.protocol = self.out / 'protocol.frozen.json'
        self.job('freeze_protocol', 'prepare_protocol.py', ['--template', self.dev_protocol,
                 '--model-path', self.a.model_path.resolve(), '--samples', self.samples,
                 '--inventory', self.out / 'inventory/inventory.json', '--model-revision', revision,
                 '--output', self.protocol])

    @property
    def samples(self):
        return self.root / 'data/ai2d_100dev_1000eval/samples.jsonl'

    def install(self, cid, op, receipt, phase):
        self.task('install_' + phase + '_' + cid, 'install', candidate=cid, operator=op, receipt=str(receipt),
                  output=str(self.out / ('identity_' + phase + '_' + cid + '.json')))

    def quality_eval(self, name, operator='gelu', candidate=None, receipt=None, replay=None):
        output = self.out / name
        cmd = ['--protocol', self.protocol, '--model-path', self.a.model_path.resolve(), '--samples', self.samples,
               '--split', 'eval', '--mode', 'candidate' if candidate else 'native', '--operator', operator,
               '--device-id', self.a.device_id, '--output', output]
        if candidate:
            cmd += ['--candidate-id', candidate, '--receipt', receipt, '--replay-report', replay]
        self.job(name, 'run_npu.py', cmd)
        status = read(output / 'status.json')
        if status.get('status') != 'completed' or status.get('samples') != 1000:
            raise ValueError('Incomplete formal quality run')
        self.state['artifacts'][name] = str(output)
        self.save()
        return output

    def pair_eval(self, cid, base, candidate):
        output = self.out / 'comparisons' / (cid + '.json')
        output.parent.mkdir(exist_ok=True)
        self.job('score_' + cid, 'score.py', ['--baseline', base / 'predictions.jsonl', '--candidate',
                 candidate / 'predictions.jsonl', '--samples', self.samples, '--split', 'eval', '--output', output])
        result = read(output)
        def predictions(path):
            rows = [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s.strip()]
            if len(rows) != len({r['id'] for r in rows}):
                raise ValueError('Duplicate prediction IDs')
            return {r['id']: r for r in rows}
        a, b = predictions(base / 'predictions.jsonl'), predictions(candidate / 'predictions.jsonl')
        if a.keys() != b.keys() or len(a) != 1000:
            raise ValueError('Incomplete paired formal prediction set')
        result['parsed_changes_including_invalid'] = sum(a[i].get('prediction') != b[i].get('prediction') for i in a)
        result['raw_text_changes'] = sum(a[i].get('text') != b[i].get('text') for i in a)
        write(output, result)
        self.state['comparisons'][cid] = result
        self.save()

    def run(self):
        self.prepare()
        previous = read(self.previous / 'batch_status.json')
        eligible = []
        for cid, op, _, _ in driver.CANDIDATES:
            build = Path(previous['artifacts']['build_' + cid])
            receipt = build / 'receipt.json'
            benchmark = previous['benchmark_checks'][cid]
            if sha(benchmark['report']) != benchmark['sha256']:
                raise ValueError('Original benchmark report changed')
            driver.ensure_benchmark(Path(benchmark['report']).parent.parent)
            self.state['benchmark_checks'][cid] = benchmark
            self.state['artifacts']['build_' + cid] = str(build)
            self.state['artifacts']['verify_' + cid] = str(Path(benchmark['report']).parent.parent)
            self.install(cid, op, receipt, 'gate')
            inputs = self.previous / ('capture_' + op + '_dev10/inputs')
            output = self.out / ('replay_' + cid)
            self.task('replay_' + cid, 'replay_gate', candidate=cid, operator=op, receipt=str(receipt),
                      inputs=str(inputs), output=str(output))
            gate = read(output / 'eligibility.json')
            self.state['eligibility'][cid] = gate
            self.save()
            if gate['eligible']:
                eligible.append((cid, op, receipt, output / 'replay.json', inputs))
        if not eligible:
            self.state['status'] = 'completed_no_eligible_candidates'
            return
        baseline = self.quality_eval('native_eval1000')
        for cid, op, receipt, replay, inputs in eligible:
            self.install(cid, op, receipt, 'formal')
            quality = self.quality_eval('candidate_' + cid + '_eval1000', op, cid, receipt, replay)
            self.pair_eval(cid, baseline, quality)
            for kind in ('operator', 'model'):
                name = 'timing_' + kind + '_' + cid
                output = self.out / name
                cmd = ['--kind', kind, '--protocol', self.protocol, '--operator', op, '--candidate-id', cid,
                       '--receipt', receipt, '--replay-report', replay, '--device-id', self.a.device_id,
                       '--output', output]
                cmd += ['--inputs', inputs] if kind == 'operator' else ['--model-path', self.a.model_path.resolve(), '--samples', self.samples]
                self.job(name, 'benchmark_npu.py', cmd)
                if read(output / 'status.json').get('status') != 'completed':
                    raise ValueError('Incomplete performance run')
                self.state['performance'][name] = {'file': str(output / 'summary.json'),
                                                   'matched_workload_summary': timing_digest(output / 'summary.json')}
                self.save()
        self.state['status'] = 'completed' if len(eligible) == 4 else 'completed_with_ineligible_candidates'

    def package(self):
        self.state['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        self.save()
        lines = ['# 正式质量与效率批次', '', '状态：' + self.state['status'], '',
                 '固定名单、严格答案解析、官方BF16默认数值标准；未按候选放宽；不作质量等效声明。', '',
                 '| 候选 | 数值回放 | 正式质量 |', '|---|---|---|']
        for cid, _, _, _ in driver.CANDIDATES:
            gate = self.state['eligibility'].get(cid)
            result = self.state['comparisons'].get(cid)
            numerical = f"{gate['passed']}/{gate['total']}; {gate['decision']}" if gate else '未完成'
            quality = (f"原模型{result['baseline_accuracy']:.2%}；候选{result['candidate_accuracy']:.2%}；"
                       f"差值{result['difference_percentage_points']:+.2f}个百分点") if result else '未测/未完成，见准入状态及日志'
            lines.append(f'| {cid} | {numerical} | {quality} |')
        lines += ['', '效率原始记录在 timing_* 目录，包含逐工作负载、逐块、逐模式耗时。',
                  '计时包含Python调用及接入成本；decode使用固定原模型token及新KV缓存，属于受控计时。',
                  '数值失败的候选不进入正式质量与性能比较；原始失败记录不删除。',
                  '所有捕获仍限于原开发批次记录，覆盖限制见rules.json；不宣称所有输入精度认证。']
        if self.state['performance']:
            lines += ['', '| 计时任务 | 阶段 | 模式 | 工作负载数 | 相对原生几何平均加速比 |',
                      '|---|---|---|---:|---:|']
            for name, entry in self.state['performance'].items():
                for row in entry['matched_workload_summary']:
                    lines.append(f"| {name} | {row['phase']} | {row['mode']} | {row['workloads']} | "
                                 f"{row['geometric_mean_speedup_vs_native']:.4f}× |")
        if self.state['error']:
            lines += ['', '```text', self.state['error'], '```']
        (self.out / 'SUMMARY.md').write_text('\n'.join(lines), encoding='utf-8')
        archive = self.a.model_path.resolve().parent / (self.out.name + '_results.zip')
        if archive.exists():
            raise FileExistsError(archive)
        members = {}
        allowed = {'.json', '.jsonl', '.log', '.txt', '.md', '.csv', '.py'}
        def add_tree(base, prefix):
            if not Path(base).exists():
                return
            for directory, folders, files in os.walk(base, followlinks=False):
                folders[:] = [f for f in folders if not (Path(directory)/f).is_symlink() and f != '__pycache__']
                for name in files:
                    p = Path(directory) / name
                    if not p.is_symlink() and p.suffix in allowed:
                        members[prefix + '/' + p.relative_to(base).as_posix()] = p
        add_tree(self.out, 'batch')
        for cid, _, _, _ in driver.CANDIDATES:
            for label in ('build_', 'verify_'):
                path = self.state['artifacts'].get(label + cid)
                if path:
                    add_tree(Path(path), 'reused/' + label + cid)
        for name in ('preflight.json', 'batch_status.json', 'protocol.dev.json'):
            p = self.previous / name
            if p.is_file():
                members['previous_batch/' + name] = p
        members['provenance/run_formal_batch.py'] = Path(__file__).resolve()
        members['provenance/run_transfer_batch.py'] = SIBLING
        manifest = {n: {'sha256': sha(p), 'bytes': p.stat().st_size} for n,p in members.items()}
        temporary = archive.with_suffix('.zip.part')
        with zipfile.ZipFile(temporary, 'x', zipfile.ZIP_DEFLATED) as z:
            for name, path in members.items():
                z.write(path, name)
            z.writestr('EXPORT_MANIFEST.json', json.dumps(manifest, indent=2))
        temporary.rename(archive)
        print(f'\nBATCH_STATUS: {self.state["status"]}\nDOWNLOAD: {archive}', flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path('/mnt/workspace/v3_model_transfer'))
    p.add_argument('--model-path', type=Path, default=Path('/mnt/workspace/gitCode/cann/cann-learning-hub/build/Qwen2.5-VL-3B-Instruct'))
    p.add_argument('--output', type=Path, default=Path('results/auto_formal_001'))
    p.add_argument('--soc', choices=['ascend910b', 'ascend910_93', 'ascend950'], default='ascend910b')
    p.add_argument('--device-id', type=int, default=0)
    p.add_argument('--timeout', type=int, default=14400)
    p.add_argument('--background', action='store_true')
    p.add_argument('--plan', action='store_true')
    p.add_argument('--worker', choices=['install', 'replay_gate'], help=argparse.SUPPRESS)
    p.add_argument('--request', type=Path, help=argparse.SUPPRESS)
    a = p.parse_args()
    if a.worker:
        worker(a.worker, read(a.request))
        return 0
    if a.plan:
        print(json.dumps({'candidates': [c[0] for c in driver.CANDIDATES], 'rules': RULES,
                          'held_out_questions': 1000, 'performance_workloads': 30}, indent=2))
        return 0
    if os.name != 'posix':
        raise RuntimeError('Execute on the Linux NPU server')
    a.root = a.root.resolve()
    if a.background:
        output = (a.root / a.output).resolve()
        if not output.is_relative_to(a.root / 'results') or output.exists():
            raise ValueError('Invalid or already existing output directory')
        log = output.with_suffix('.console.log')
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open('x', encoding='utf-8') as f:
            child = subprocess.Popen([sys.executable, '-u', str(Path(__file__).resolve()),
                                      *[v for v in sys.argv[1:] if v != '--background']],
                                     stdin=subprocess.DEVNULL, stdout=f, stderr=subprocess.STDOUT,
                                     start_new_session=True, cwd=a.root)
        print(f'BACKGROUND_PID: {child.pid}\nLOG: {log}\nDOWNLOAD_WHEN_FINISHED: '
              f'{a.model_path.resolve().parent / (output.name + "_results.zip")}')
        return 0
    import fcntl
    with (a.root / '.transfer_batch.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        batch = FormalBatch(a)
        def stop(sig, frame):
            raise KeyboardInterrupt(f'Received signal {sig}')
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        code = 0
        try:
            batch.run()
        except BaseException:
            batch.state['status'] = 'stopped_requires_review'
            batch.state['error'] = traceback.format_exc()
            print(batch.state['error'], flush=True)
            code = 1
        finally:
            batch.package()
        return code


if __name__ == '__main__':
    raise SystemExit(main())
