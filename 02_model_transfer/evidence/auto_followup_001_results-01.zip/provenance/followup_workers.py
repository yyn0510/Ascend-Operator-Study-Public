"""Fresh-process explanatory experiments; no kernel modifications."""
import json
import math
from pathlib import Path
import random
import statistics
import sys


def tensor_metrics(actual, expected, atol=1e-5, rtol=.016):
    import torch
    a, b = actual.detach().cpu().double(), expected.detach().cpu().double()
    if a.shape != b.shape or not bool(torch.isfinite(a).all() and torch.isfinite(b).all()):
        raise ValueError('Shape mismatch or nonfinite tensor; review required')
    delta = (a-b).abs()
    bad = delta > atol + rtol*b.abs()
    result = {'elements':a.numel(), 'failed_elements':int(bad.sum()),
              'failed_fraction':bad.double().mean().item(), 'max_abs':delta.max().item(),
              'mean_abs':delta.mean().item(), 'p99_abs':torch.quantile(delta.reshape(-1),.99).item(),
              'relative_l2':(torch.linalg.vector_norm(delta)/torch.linalg.vector_norm(b).clamp_min(1e-30)).item()}
    return result


def bf16_ulp_distance(a, b):
    import torch
    if a.dtype!=torch.bfloat16 or b.dtype!=a.dtype or a.shape!=b.shape:
        raise ValueError('ULP diagnostic requires matching BF16 tensors')
    def ordered(x):
        bits = x.detach().cpu().contiguous().view(torch.int16).to(torch.int32)
        return torch.where(bits<0,-32768-bits,bits)
    return (ordered(a)-ordered(b)).abs()


def high_precision_gelu(x):
    import torch
    value=x.detach().cpu().double()
    return .5*value*torch.erfc(-value/math.sqrt(2.))


def cost_digest(summary):
    lookup={(r['workload'],r['phase'],r['mode']):r for r in summary}
    if len(lookup)!=len(summary)or any(r['blocks']!=3 or r['median_ms']<=0 for r in summary):
        raise ValueError('Invalid or incomplete cost timing')
    results=[]
    for phase in sorted({r['phase']for r in summary}):
        work=sorted({r['workload']for r in summary if r['phase']==phase})
        def geometric(numerator,denominator):
            return math.exp(statistics.mean(math.log(lookup[w,phase,numerator]['median_ms']/lookup[w,phase,denominator]['median_ms'])for w in work))
        # All five modes must exist for every matched workload.
        for w in work:
            for mode in ('native','wrapper','pack_only','kernel_prepacked','replacement_full'):
                if(w,phase,mode)not in lookup:raise ValueError('Missing matched cost mode')
        results.append({'phase':phase,'workloads':len(work),
            'native_over_replacement_full':geometric('native','replacement_full'),
            'native_over_kernel_prepacked':geometric('native','kernel_prepacked'),
            'wrapper_over_replacement_full':geometric('wrapper','replacement_full'),
            'replacement_full_over_kernel_prepacked':geometric('replacement_full','kernel_prepacked'),
            'median_per_workload_ms':{mode:statistics.median(lookup[w,phase,mode]['median_ms']for w in work)
                                    for mode in ('native','wrapper','pack_only','kernel_prepacked','replacement_full')},
            'note':'Prepacked path is explanatory only. Separate timings cannot be added/subtracted to assert an exact causal overhead.'})
    return results


def gelu_diagnostic(cfg):
    import torch
    import torch_npu
    import cann_bench
    from common import read_json, save, verify_loaded, sha256
    from host import environment, verify_environment, record_device_status
    from numerics import capture_index, check_capture_source
    torch.set_num_threads(4)
    protocol=read_json(cfg['protocol'])
    env=environment(cfg['device']);verify_environment(protocol,env)
    identity=verify_loaded(cfg['candidate'],'gelu',cfg['receipt'])
    directory=Path(cfg['inputs']);rows,source=capture_index(directory,'gelu')
    check_capture_source(protocol,source,env)
    output=Path(cfg['output']);output.mkdir(parents=True,exist_ok=False)
    record_device_status(output)
    result={'candidate_id':cfg['candidate'],'identity':identity,'environment':env,
            'protocol_sha256':sha256(cfg['protocol']),'capture_index_sha256':sha256(directory/'index.jsonl'),
            'scope':'Explanatory diagnostics only. Original tolerance and eligibility decisions unchanged.',
            'high_precision_reference':'CPU FP64: 0.5*x*erfc(-x/sqrt(2)); evaluated at the SAME quantized BF16 inputs',
            'tolerance':{'atol':1e-5,'rtol':.016},'records':[]}
    with torch.inference_mode():
        for row in rows:
            data=torch.load(directory/row['file'],map_location='cpu',weights_only=True)
            if data['attrs']!=row['attrs'] or data['attrs']['approximate']!='none':
                raise ValueError('Unexpected captured GELU approximation')
            x=data['inputs'][0];reference=data['reference']
            if x.dtype!=torch.bfloat16 or reference.dtype!=x.dtype or not bool(torch.isfinite(x).all()):
                raise ValueError('Unexpected input dtype/nonfinite input')
            npu=x.to(f"npu:{cfg['device']}")
            native=torch.nn.functional.gelu(npu,approximate='none').cpu()
            if not torch.equal(native,reference):
                raise ValueError('Native recomputation differs from captured host output')
            fp32=torch.nn.functional.gelu(npu.float(),approximate='none').to(x.dtype).cpu()
            candidate=cann_bench.gelu(npu,'none').cpu()
            xd=x.double();high=high_precision_gelu(x);rounded=high.to(x.dtype)
            modes={'native_bf16':native,'native_fp32_then_bf16':fp32,'candidate':candidate,'cpu_fp64_then_bf16':rounded}
            item={k:row[k]for k in ('file','sample_id','group_id','shape','dtype','attrs')}
            item['modes']={}
            for name,value in modes.items():
                ulp=bf16_ulp_distance(value,reference)
                item['modes'][name]={'vs_host':tensor_metrics(value,reference),
                    'vs_cpu_fp64':tensor_metrics(value,high),
                    'vs_cpu_fp64_rounded_bf16':tensor_metrics(value,rounded),
                    'host_ulp':{'max':int(ulp.max()),'more_than_1':int((ulp>1).sum()),'more_than_2':int((ulp>2).sum())}}
            diff=(candidate.double()-reference.double()).abs()
            bound=1e-5+.016*reference.double().abs();bad=diff>bound
            intervals=[-math.inf,-6.,-4.,-2.,-1.,0.,1.,2.,4.,6.,math.inf]
            item['failure_by_input_interval']=[]
            for low,high_bound in zip(intervals,intervals[1:]):
                mask=(xd>=low)&(xd<high_bound)
                item['failure_by_input_interval'].append({'lower':str(low),'upper':str(high_bound),
                    'elements':int(mask.sum()),'failed':int((mask&bad).sum())})
            flat=(diff/bound).reshape(-1)
            indices=torch.topk(flat,min(16,flat.numel())).indices.tolist()
            item['largest_error_over_bound_examples']=[{'flat_index':i,'x':xd.reshape(-1)[i].item(),
                'host':reference.reshape(-1)[i].item(),'candidate':candidate.reshape(-1)[i].item(),
                'native_fp32_then_bf16':fp32.reshape(-1)[i].item(),'cpu_fp64':high.reshape(-1)[i].item(),
                'cpu_fp64_then_bf16':rounded.reshape(-1)[i].item(),'absolute_error':diff.reshape(-1)[i].item(),
                'allowed_error':bound.reshape(-1)[i].item()}for i in indices]
            result['records'].append(item)
            save(output/'diagnostic.json',result)
            print(f"GELU {len(result['records'])}/{len(rows)}: {row['file']}; bad={int(bad.sum())}/{bad.numel()}",flush=True)
    save(output/'status.json',{'status':'completed','records':len(rows)})


def swiglu_cost(cfg):
    import torch
    import torch_npu
    import cann_bench
    from common import read_json, save, verify_loaded, append_result, sha256
    from host import environment,verify_environment,record_device_status
    from numerics import capture_index,check_capture_source,compare_tensors,tolerance
    from benchmark_npu import timed,select_captures
    protocol=read_json(cfg['protocol']);env=environment(cfg['device']);verify_environment(protocol,env)
    identity=verify_loaded(cfg['candidate'],'swi_glu',cfg['receipt'])
    directory=Path(cfg['inputs']);rows,source=capture_index(directory,'swi_glu');check_capture_source(protocol,source,env)
    selected=select_captures(rows,30)
    output=Path(cfg['output']);output.mkdir(parents=True,exist_ok=False);record_device_status(output)
    save(output/'request.json',{'identity':identity,'environment':env,'protocol_sha256':sha256(cfg['protocol']),
        'captures':selected,'capture_index_sha256':sha256(directory/'index.jsonl'),
        'timing':'NPU synchronized wall latency; kernel_prepacked excludes packing ONLY for attribution, not actual deployment speed',
        'repeats':50,'warmup':10,'blocks':3,'caution':'Separate median timings are not an exact additive decomposition'})
    rng=random.Random(protocol['seed']);results=[]
    with torch.inference_mode():
        for row in selected:
            data=torch.load(directory/row['file'],map_location='cpu',weights_only=True)
            a,b=[x.to(f"npu:{cfg['device']}")for x in data['inputs']]
            packed=torch.cat((a,b),dim=-1)
            def wrapper():
                p=torch.cat((a,b),dim=-1);gate,up=p.chunk(2,dim=-1)
                return torch.nn.functional.silu(gate)*up
            functions={'native':lambda:torch.nn.functional.silu(a)*b,
                       'wrapper':wrapper,'pack_only':lambda:torch.cat((a,b),dim=-1),
                       'kernel_prepacked':lambda:cann_bench.swi_glu(packed,-1),
                       'replacement_full':lambda:cann_bench.swi_glu(torch.cat((a,b),dim=-1),-1)}
            tol=tolerance(protocol,'swi_glu',data['reference'].dtype)
            for mode in ('native','wrapper','kernel_prepacked','replacement_full'):
                check=compare_tensors(data['reference'],functions[mode](),tol)
                if not check['passed']:
                    save(output/'numerical_failure.json',{'row':row,'mode':mode,'check':check})
                    raise ValueError('Numerical validation failed before explanatory timing')
            for block in range(3):
                modes=list(functions);rng.shuffle(modes)
                for mode in modes:
                    r={'workload':row['file'],'phase':row['phase'],'shape':row['shape'],'dtype':row['dtype'],
                       'mode':mode,'block':block,**timed(functions[mode],10,50)}
                    append_result(output/'timings.jsonl',r);results.append(r)
            print(f"COST completed {row['file']}",flush=True)
    grouped={}
    for r in results:grouped.setdefault((r['workload'],r['phase'],r['mode']),[]).append(r['milliseconds_per_call'])
    summary=[{'workload':k[0],'phase':k[1],'mode':k[2],'median_ms':statistics.median(v),
              'min_block_ms':min(v),'max_block_ms':max(v),'blocks':len(v)}for k,v in grouped.items()]
    save(output/'summary.json',{'workload_results':summary,'matched_summary':cost_digest(summary)})
    save(output/'status.json',{'status':'completed','timing_rows':len(results),'workloads':len(selected)})


def dispatch(action,cfg):
    # Import the frozen, unchanged first-formal harness for explanatory diagnostics.
    sys.path.insert(0,cfg['harness'])
    if action=='gelu':return gelu_diagnostic(cfg)
    if action=='swiglu_cost':return swiglu_cost(cfg)
    raise ValueError(action)
