"""Explanatory diagnostics plus a fixed, image-separated MMStar cross-task subset.

Run from the unpacked followup ZIP. Defaults to all stages in one background job.
"""
import argparse
from collections import defaultdict
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback
import zipfile

PACKAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('formal_driver',PACKAGE/'run_formal_batch.py')
formal=importlib.util.module_from_spec(spec);spec.loader.exec_module(formal)
driver=formal.driver
read,write,sha=driver.read,driver.write,driver.sha


def fingerprint(x):
    return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def prompt_patch(source):
    marker='def make_prompt(row, protocol):\n'
    if source.count(marker)!=1:
        raise ValueError('Unexpected prompt builder; do not patch ambiguously')
    return source.replace(marker,marker+"    if row.get('prompt_format') == 'mmstar_embedded_options':\n"
                          "        return row['original_question'] + '\\n' + protocol['answer_instruction']\n")


def read_predictions(path):
    rows=[json.loads(s)for s in Path(path).read_text(encoding='utf-8').splitlines()if s.strip()]
    if len(rows)!=len({r['id']for r in rows}):raise ValueError('Duplicate predictions')
    return {r['id']:r for r in rows}


def worker(action,cfg):
    if action=='install':return driver.worker(action,cfg)
    if action=='replay_gate':return formal.worker(action,cfg)
    from followup_workers import dispatch
    return dispatch(action,cfg)


class Followup(formal.FormalBatch):
    def __init__(self,args):
        driver.Batch.__init__(self,args)
        self.old=self.root/'results/auto_formal_001'
        self.previous=self.root/'results/auto_dev_001'
        self.harness=self.old/'harness'
        self.protocol=self.old/'protocol.frozen.json'
        self.mmdata=PACKAGE/'data/mmstar_followup_001'
        self.state.update(scope='Explain GELU numerical differences and SwiGLU adapter costs; cross-task MMStar evaluation',
                          eligibility={},performance={},diagnostics={},phase=args.phase)
        self.save()

    @property
    def samples(self):return self.mmdata/'samples.jsonl'

    def task(self,name,action,**cfg):
        request=self.out/'requests'/f'{name}.json'
        write(request,{'root':str(self.root),'harness':str(self.harness),'protocol':str(self.protocol),
                       'device':self.a.device_id,'soc':self.a.soc,**cfg})
        self.command(name,[sys.executable,Path(__file__).resolve(),'--worker',action,'--request',request])

    def preflight(self):
        manifest=read(PACKAGE/'PACKAGE_MANIFEST.json')
        for name,entry in manifest.items():
            p=(PACKAGE/name).resolve()
            if not p.is_relative_to(PACKAGE)or not p.is_file()or p.stat().st_size!=entry['bytes']or sha(p)!=entry['sha256']:
                raise ValueError(f'Followup package integrity mismatch: {name}')
        previous=read(self.old/'batch_status.json')
        if previous['status']not in ('completed','completed_with_ineligible_candidates'):
            raise ValueError('First formal batch not completed')
        protocol=read(self.protocol)
        if protocol['protocol_fingerprint']!=fingerprint({k:v for k,v in protocol.items()if k!='protocol_fingerprint'}):
            raise ValueError('Previous frozen protocol changed')
        for name,digest in protocol['runner_sha256'].items():
            if sha(self.harness/name)!=digest:raise ValueError('Previous frozen runner changed')
        for cid,op,_,_ in driver.CANDIDATES:
            if op=='swi_glu'and not previous['eligibility'][cid]['eligible']:
                raise ValueError('A planned SwiGLU candidate did not pass the first formal gate')
        write(self.out/'source_provenance.json',{'prior_frozen_protocol_sha256':sha(self.protocol),
              'prior_batch_status_sha256':sha(self.old/'batch_status.json'),
              'package_manifest_sha256':sha(PACKAGE/'PACKAGE_MANIFEST.json'),
              'mmstar_manifest':read(self.mmdata/'dataset_manifest.json')})

    def receipt(self,cid):
        return Path(read(self.old/'batch_status.json')['artifacts']['build_'+cid])/'receipt.json'

    def explain(self):
        for cid,op,_,_ in driver.CANDIDATES:
            receipt=self.receipt(cid)
            self.install(cid,op,receipt,'explanatory')
            action='gelu'if op=='gelu'else 'swiglu_cost'
            target=self.out/(action+'_'+cid)
            inputs=self.previous/('capture_'+op+'_dev10/inputs')
            self.task(action+'_'+cid,action,candidate=cid,receipt=str(receipt),inputs=str(inputs),output=str(target))
            if read(target/'status.json')['status']!='completed':raise ValueError('Incomplete explanatory run')
            self.state['diagnostics'][cid]={'kind':action,'output':str(target)};self.save()

    def prepare_mmstar(self):
        old_harness=self.old/'harness'
        self.harness=self.out/'mmstar_harness';self.harness.mkdir()
        for p in sorted(old_harness.glob('*.py'))+sorted(old_harness.glob('*.json')):
            shutil.copyfile(p,self.harness/p.name)
        for name in ('projects','data','original_benchmark'):
            (self.harness/name).symlink_to(self.root/name,target_is_directory=True)
        common=self.harness/'common.py';before=common.read_text(encoding='utf-8')
        common.write_text(prompt_patch(before),encoding='utf-8')
        write(self.out/'prompt_adaptation.json',{'source_sha256':sha(old_harness/'common.py'),
              'adapted_sha256':sha(common),'policy':'Use original MMStar question WITH embedded options once, append unchanged answer instruction',
              'parser':'Existing strict option-letter parser unchanged; invalid answers stay in denominator'})
        p=read(self.old/'protocol.frozen.json')
        for name in ('protocol_fingerprint','environment','runner_sha256'):p.pop(name,None)
        p['state']='draft';p['dataset']=None
        p['capture']['max_bytes']=2*1024**3
        p['notes']='MMStar non-AI2D-source image-separated subset. Original embedded-option question, strict parser. No tolerance relaxation.'
        template=self.out/'mmstar_protocol.pre_freeze.json';write(template,p)
        self.job('inspect_mmstar_harness','run_npu.py',['--inspect','--protocol',template,'--model-path',self.a.model_path.resolve(),
                  '--device-id',self.a.device_id,'--output',self.out/'mmstar_inventory'])
        actual=read(self.out/'mmstar_inventory/inventory.json')
        if actual['environment']!=read(self.old/'protocol.frozen.json')['environment']:
            raise ValueError('NPU/software environment changed')
        self.protocol=self.out/'mmstar_protocol.frozen.json'
        self.job('freeze_mmstar','prepare_protocol.py',['--template',template,'--model-path',self.a.model_path.resolve(),
                 '--samples',self.samples,'--inventory',self.out/'mmstar_inventory/inventory.json',
                 '--model-revision',p['model']['revision'],'--output',self.protocol])

    def quality(self,name,mode='native',capture=False,limit=None,cid=None,receipt=None,replay=None,split='dev'):
        target=self.out/name
        cmd=['--protocol',self.protocol,'--model-path',self.a.model_path.resolve(),'--samples',self.samples,
             '--split',split,'--mode',mode,'--operator','swi_glu','--device-id',self.a.device_id,'--output',target]
        if capture:cmd+=['--capture']
        if limit:cmd+=['--max-samples',limit]
        if cid:cmd+=['--candidate-id',cid,'--receipt',receipt]
        if replay:cmd+=['--replay-report',replay]
        self.job(name,'run_npu.py',cmd)
        expected=limit or read(self.mmdata/'dataset_manifest.json')[split+'_questions']
        status=read(target/'status.json')
        if status.get('status')!='completed'or status.get('samples')!=expected:
            raise ValueError('Incomplete MMStar quality run')
        return target

    def score_mmstar(self,cid,base,candidate):
        output=self.out/'comparisons'/f'{cid}.json';output.parent.mkdir(exist_ok=True)
        self.job('score_mmstar_'+cid,'score.py',['--baseline',base/'predictions.jsonl','--candidate',candidate/'predictions.jsonl',
                 '--samples',self.samples,'--split','eval','--output',output])
        result=read(output);a=read_predictions(base/'predictions.jsonl');b=read_predictions(candidate/'predictions.jsonl')
        manifest=read(self.mmdata/'dataset_manifest.json')
        if a.keys()!=b.keys()or len(a)!=manifest['eval_questions']:raise ValueError('Incomplete paired MMStar run')
        result['parsed_changes_including_invalid']=sum(a[i].get('prediction')!=b[i].get('prediction')for i in a)
        result['raw_text_changes']=sum(a[i].get('text')!=b[i].get('text')for i in a)
        meta={r['id']:r for r in [json.loads(s)for s in self.samples.read_text(encoding='utf-8').splitlines()if s.strip()]}
        result['category_results']=[]
        correct=lambda r:int(r['status']=='success'and r.get('prediction')==r['answer'])
        for category in sorted({meta[i]['category']for i in a}):
            ids=[i for i in a if meta[i]['category']==category]
            result['category_results'].append({'category':category,'n':len(ids),
                'baseline_correct':sum(correct(a[i])for i in ids),'candidate_correct':sum(correct(b[i])for i in ids),
                'baseline_invalid':sum(a[i].get('prediction')is None for i in ids),
                'candidate_invalid':sum(b[i].get('prediction')is None for i in ids)})
        write(output,result);self.state['comparisons'][cid]=result;self.save()

    def mmstar(self):
        self.prepare_mmstar()
        baseline_dev=self.quality('mmstar_capture_dev10',capture=True,limit=10)
        control=self.quality('mmstar_wrapper_dev10',mode='wrapper',limit=10)
        a=read_predictions(baseline_dev/'predictions.jsonl');b=read_predictions(control/'predictions.jsonl')
        if len(a)!=10 or a.keys()!=b.keys()or any(a[i]['status']!='success'or b[i]['status']!='success'or a[i]['text']!=b[i]['text']for i in a):
            raise ValueError('MMStar wrapper control differs from native; review before full evaluation')
        write(self.out/'mmstar_wrapper_control.json',{'samples':10,'raw_text_changes':0,'runtime_errors':0})
        eligible=[]
        for cid,op,_,_ in driver.CANDIDATES:
            if op!='swi_glu':continue
            receipt=self.receipt(cid);self.install(cid,op,receipt,'mmstar_gate')
            target=self.out/('mmstar_replay_'+cid)
            self.task('mmstar_replay_'+cid,'replay_gate',candidate=cid,operator=op,receipt=str(receipt),
                      inputs=str(baseline_dev/'inputs'),output=str(target))
            gate=read(target/'eligibility.json');self.state['eligibility'][cid]=gate;self.save()
            if gate['eligible']:eligible.append((cid,receipt,target/'replay.json'))
        if not eligible:
            self.state['status']='completed_no_mmstar_eligible_candidates';return
        baseline=self.quality('mmstar_native_eval',split='eval')
        for cid,receipt,replay in eligible:
            self.install(cid,'swi_glu',receipt,'mmstar_quality')
            output=self.quality('mmstar_candidate_'+cid,mode='candidate',cid=cid,receipt=receipt,replay=replay,split='eval')
            self.score_mmstar(cid,baseline,output)
        self.state['status']='completed'if len(eligible)==2 else 'completed_with_ineligible_candidates'

    def run(self):
        self.preflight()
        if self.a.phase in ('all','diagnostics'):self.explain()
        if self.a.phase in ('all','mmstar'):self.mmstar()
        else:self.state['status']='completed'

    def package(self):
        self.state['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());self.save()
        lines=['# 解释性实验与MMStar跨任务补充','', '状态：'+self.state['status'],'',
               'GELU使用相同BF16输入，对比宿主、NPU FP32转BF16、CPU FP64 erfc参考及候选。原准入标准与结论不变。',
               'SwiGLU记录原生、包装、拼接、预拼接内核、实际替换五条计时路径。预拼接结果仅用于归因，不代替部署速度。',
               'MMStar排除AI2D来源图像及与原AI2D清单的RGB精确重叠；独立图像分组校准，严格解析不变。']
        for cid,entry in self.state['diagnostics'].items():
            p=Path(entry['output'])
            if entry['kind']=='gelu':
                data=read(p/'diagnostic.json');rs=data['records']
                bad=sum(r['modes']['candidate']['vs_host']['failed_elements']for r in rs)
                total=sum(r['modes']['candidate']['vs_host']['elements']for r in rs)
                lines+=['',f'{cid}：宿主标准下超阈值元素{bad}/{total}（{bad/total:.4%}）；重复图像分别保留，非独立样本。']
            else:
                cost=read(p/'summary.json')['matched_summary']
                for row in cost:
                    lines+=['',f"{cid} / {row['phase']}：原生/实际替换 {row['native_over_replacement_full']:.4f}×；"
                            f"原生/预拼接内核 {row['native_over_kernel_prepacked']:.4f}×（后者仅供解释）。"]
        if self.state['comparisons']:
            lines+=['','| MMStar候选 | 题数 | 原模型 | 候选 | 差值（百分点） | 无效答案 |', '|---|---:|---:|---:|---:|---:|']
            for cid,r in self.state['comparisons'].items():
                lines.append(f"| {cid} | {r['samples']} | {r['baseline_accuracy']:.2%} | {r['candidate_accuracy']:.2%} | {r['difference_percentage_points']:+.3f} | {r['candidate_invalid_answer']} |")
        if self.state['error']:lines+=['','```text',self.state['error'],'```']
        lines+=['','原始张量与权重不进入压缩包；日志、输入索引、逐题预测、数值分布与计时重复值保留。',
                '运行器仅在新的MMStar副本加入原始问题格式支持；不修改原候选、V3数据、开发批次或第一正式批次。']
        (self.out/'SUMMARY.md').write_text('\n'.join(lines),encoding='utf-8')
        members={};allowed={'.py','.json','.jsonl','.md','.txt','.log','.csv'}
        def add_tree(base,prefix):
            for directory,folders,files in os.walk(base,followlinks=False):
                folders[:]=[f for f in folders if f!='__pycache__'and not(Path(directory)/f).is_symlink()]
                for name in files:
                    p=Path(directory)/name
                    if p.suffix in allowed and not p.is_symlink():members[prefix+'/'+p.relative_to(base).as_posix()]=p
        add_tree(self.out,'batch')
        for p in PACKAGE.glob('*.py'):members['provenance/'+p.name]=p
        for name in ('dataset_manifest.json','samples.jsonl'):
            p=self.mmdata/name
            if p.is_file():members['mmstar_data/'+name]=p
        if(PACKAGE/'PACKAGE_MANIFEST.json').is_file():members['provenance/PACKAGE_MANIFEST.json']=PACKAGE/'PACKAGE_MANIFEST.json'
        for name in ('protocol.frozen.json','batch_status.json'):
            p=self.old/name
            if p.is_file():members['prior_formal/'+name]=p
        for op in ('gelu','swi_glu'):
            for name in ('index.jsonl','coverage.json'):
                p=self.previous/('capture_'+op+'_dev10/inputs')/name
                if p.is_file():members['prior_captures/'+op+'/'+name]=p
        target=self.a.model_path.resolve().parent/(self.out.name+'_results.zip')
        if target.exists():raise FileExistsError(target)
        manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size}for n,p in members.items()}
        tmp=target.with_suffix('.zip.part')
        with zipfile.ZipFile(tmp,'x',zipfile.ZIP_DEFLATED)as z:
            for n,p in members.items():z.write(p,n)
            z.writestr('EXPORT_MANIFEST.json',json.dumps(manifest,indent=2))
        tmp.rename(target)
        print(f'\nBATCH_STATUS: {self.state["status"]}\nDOWNLOAD: {target}',flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path('/mnt/workspace/v3_model_transfer'))
    p.add_argument('--model-path',type=Path,default=Path('/mnt/workspace/gitCode/cann/cann-learning-hub/build/Qwen2.5-VL-3B-Instruct'))
    p.add_argument('--output',type=Path,default=Path('results/auto_followup_001'))
    p.add_argument('--phase',choices=['all','diagnostics','mmstar'],default='all')
    p.add_argument('--soc',default='ascend910b',choices=['ascend910b','ascend910_93','ascend950'])
    p.add_argument('--device-id',type=int,default=0)
    p.add_argument('--timeout',type=int,default=14400)
    p.add_argument('--background',action='store_true');p.add_argument('--plan',action='store_true')
    p.add_argument('--worker',choices=['install','replay_gate','gelu','swiglu_cost'],help=argparse.SUPPRESS)
    p.add_argument('--request',type=Path,help=argparse.SUPPRESS)
    a=p.parse_args()
    if a.worker:worker(a.worker,read(a.request));return 0
    if a.plan:
        manifest=read(PACKAGE/'data/mmstar_followup_001/dataset_manifest.json')
        print(json.dumps({'phase':a.phase,'diagnostics':['GELU reference attribution','SwiGLU packing/call decomposition'],
            'mmstar':{k:manifest[k]for k in ('source','source_rows','retained_rows','dev_questions','eval_questions','dev_image_groups','eval_image_groups','eval_category_counts','first_capture_groups')},
            'candidate_policy':'GELU explanatory only; the two SwiGLU candidates require fresh MMStar calibration gates'},ensure_ascii=False,indent=2));return 0
    if os.name!='posix':raise RuntimeError('Execute actual jobs on the Linux NPU server')
    a.root=a.root.resolve()
    if a.background:
        out=(a.root/a.output).resolve()
        if not out.is_relative_to(a.root/'results')or out.exists():raise ValueError('Invalid/already existing output')
        log=out.with_suffix('.console.log');log.parent.mkdir(parents=True,exist_ok=True)
        with log.open('x',encoding='utf-8')as f:
            child=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),*[x for x in sys.argv[1:]if x!='--background']],
                    stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,cwd=a.root)
        print(f'BACKGROUND_PID: {child.pid}\nLOG: {log}\nDOWNLOAD_WHEN_FINISHED: {a.model_path.resolve().parent/(out.name+"_results.zip")}');return 0
    import fcntl
    with(a.root/'.transfer_batch.lock').open('a')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        batch=Followup(a)
        def stop(sig,frame):raise KeyboardInterrupt(f'Received signal {sig}')
        signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
        code=0
        try:batch.run()
        except BaseException:
            batch.state['status']='stopped_requires_review';batch.state['error']=traceback.format_exc();print(batch.state['error'],flush=True);code=1
        finally:batch.package()
        return code


if __name__=='__main__':raise SystemExit(main())
