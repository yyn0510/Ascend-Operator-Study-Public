"""Offline conversion of the verified official MMStar parquet for a second task.

Keep original embedded-option prompts; exclude AI2D-source images and exact RGB
overlap with the existing AI2D manifest; reserve 10 image groups per capability.
No model predictions enter selection. Actual counts are written to the manifest.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import io
import json
from pathlib import Path
import re

REPO = 'Lin-Chen/MMStar'
REVISION = 'bc98d668301da7b14f648724866e57302778ab27'
PARQUET_SHA256 = '29afd74b0134cfab083a8909b5358577ab18fd41c1e612031577cfb3635531c2'
SEED = 20261016


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def options(question):
    if '\nOptions:' in question:
        stem, body = question.rsplit('\nOptions:', 1)
        body = body.strip()
        matches = list(re.finditer(r'(?:^|,\s+|\n\s*)([A-Z])\s*:\s*', body))
    else:
        matches_all = list(re.finditer(r'(?m)^\(([A-Z])\)\s*', question))
        if not matches_all:
            raise ValueError('Cannot find embedded option labels')
        stem = question[:matches_all[0].start()].rstrip()
        body = question[matches_all[0].start():]
        matches = list(re.finditer(r'(?m)^\(([A-Z])\)\s*', body))
    labels = [m.group(1) for m in matches]
    if not 2 <= len(labels) <= 26 or labels != [chr(65+i) for i in range(len(labels))]:
        raise ValueError(f'Unexpected MMStar option labels: {labels}')
    values = [body[m.end():matches[i+1].start() if i+1<len(matches) else len(body)].strip()
              for i,m in enumerate(matches)]
    if not stem.strip() or not all(values):
        raise ValueError('Empty question/option')
    return stem, values


def split_groups(rows, per_category=10):
    groups = defaultdict(list)
    for row in rows:
        groups[row['group_id']].append(row)
    categories = sorted({r['category'] for r in rows})
    reserved = set()
    for category in categories:
        eligible = [g for g, rs in groups.items() if any(r['category']==category for r in rs)]
        eligible.sort(key=lambda g: fingerprint([SEED, category, g]))
        # Reserve whole images, even if a diagram has questions in several categories.
        chosen = eligible[:per_category]
        if len(chosen) != per_category:
            raise ValueError('Insufficient image groups for deterministic calibration')
        reserved.update(chosen)
    dev = [dict(r, split='dev') for r in rows if r['group_id'] in reserved]
    evaluation = [dict(r, split='eval') for r in rows if r['group_id'] not in reserved]
    # Interleave capabilities and avoid repeating an image in the first capture samples.
    queues = {c: sorted([r for r in dev if r['category']==c], key=lambda r:fingerprint([SEED,r['id']])) for c in categories}
    ordered, seen = [], set()
    while any(queues.values()):
        progress = False
        for c in categories:
            queue = queues[c]
            index = next((i for i,r in enumerate(queue) if r['group_id'] not in seen), None)
            if index is not None:
                row = queue.pop(index);ordered.append(row);seen.add(row['group_id']);progress=True
        if not progress:
            break
    for c in categories:
        ordered.extend(queues[c])
    evaluation.sort(key=lambda r:r['source_index'])
    return ordered, evaluation


def convert(parquet, ai2d, output):
    import pyarrow.parquet as pq
    from PIL import Image
    if sha(parquet) != PARQUET_SHA256:
        raise ValueError('Official MMStar parquet hash mismatch')
    if output.exists():
        raise FileExistsError(output)
    ai2d_rows = [json.loads(s) for s in ai2d.read_text(encoding='utf-8').splitlines() if s.strip()]
    existing = {r['group_id'] for r in ai2d_rows}
    source = pq.read_table(parquet).to_pylist()
    if len(source)!=1500 or len({r['index'] for r in source})!=1500:
        raise ValueError('Unexpected official row/ID count')
    rows, raw_images, ai2d_source_groups = [], {}, set()
    for r in source:
        raw = r['image'] if isinstance(r['image'],bytes) else r['image']['bytes']
        with Image.open(io.BytesIO(raw)) as image:
            rgb = image.convert('RGB')
            group = hashlib.sha256(str(rgb.size).encode()+rgb.tobytes()).hexdigest()
            width,height = rgb.size
        image_hash = hashlib.sha256(raw).hexdigest()
        # Preserve original encoded image bytes; no image recompression or resize.
        raw_images[image_hash] = raw
        stem, choices = options(r['question'])
        if len(r['answer'])!=1 or not 'A' <= r['answer'] < chr(65+len(choices)):
            raise ValueError('Invalid answer encoding')
        row = {'id':f"mmstar_{r['index']:05d}", 'group_id':group, 'image':f'images/{image_hash}.img',
               'image_sha256':image_hash, 'question':stem, 'choices':choices, 'answer':r['answer'],
               'original_question':r['question'], 'prompt_format':'mmstar_embedded_options',
               'category':r['category'], 'l2_category':r['l2_category'], 'source_index':r['index'],
               'source_metadata':r['meta_info'], 'width':width, 'height':height}
        rows.append(row)
        if r['meta_info']['source']=='AI2D_TEST':
            ai2d_source_groups.add(group)
    retained, excluded = [], []
    for row in rows:
        reasons = []
        if row['group_id'] in ai2d_source_groups:
            reasons.append('image_has_AI2D_TEST_source')
        if row['group_id'] in existing:
            reasons.append('exact_RGB_overlap_existing_AI2D')
        if reasons:
            excluded.append({'id':row['id'],'group_id':row['group_id'],'category':row['category'],
                             'source':row['source_metadata']['source'],'reasons':reasons})
        else:
            retained.append(row)
    dev, evaluation = split_groups(retained)
    assert {r['group_id']for r in dev}.isdisjoint(r['group_id']for r in evaluation)
    output.mkdir(parents=True)
    (output/'images').mkdir()
    selected = dev+evaluation
    for name in {r['image_sha256']for r in selected}:
        (output/'images'/f'{name}.img').write_bytes(raw_images[name])
    samples = output/'samples.jsonl'
    samples.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in selected),encoding='utf-8')
    manifest = {'source':{'repository':REPO,'revision':REVISION,'file':'mmstar.parquet','sha256':PARQUET_SHA256},
                'source_rows':1500,'excluded':excluded,'retained_rows':len(retained),
                'selection':'Remove all images with AI2D_TEST provenance and exact RGB overlap with existing AI2D; reserve 10 image groups per capability by fixed hash before predictions',
                'seed':SEED,'dev_questions':len(dev),'eval_questions':len(evaluation),
                'dev_image_groups':len({r['group_id']for r in dev}), 'eval_image_groups':len({r['group_id']for r in evaluation}),
                'eval_category_counts':dict(Counter(r['category']for r in evaluation)),
                'source_counts':dict(Counter(r['meta_info']['source']for r in source)),
                'samples_sha256':sha(samples),'existing_ai2d_samples_sha256':sha(ai2d),
                'prompt':'Original question with embedded options is used verbatim, then the fixed one-letter instruction is appended',
                'images':'Original encoded bytes; exact RGB+size grouping; near duplicates/re-encoded overlap not fully detected',
                'interpretation':'Internal cross-task MMStar subset, NOT the full official 1500-sample leaderboard protocol',
                'first_capture_ids':[r['id']for r in dev[:10]],
                'first_capture_groups':len({r['group_id']for r in dev[:10]})}
    (output/'dataset_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:manifest[k]for k in ['source_rows','retained_rows','dev_questions','eval_questions','eval_category_counts','first_capture_groups']},ensure_ascii=False,indent=2))
    return manifest


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--parquet',type=Path,required=True)
    p.add_argument('--ai2d',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();convert(a.parquet,a.ai2d,a.output)
