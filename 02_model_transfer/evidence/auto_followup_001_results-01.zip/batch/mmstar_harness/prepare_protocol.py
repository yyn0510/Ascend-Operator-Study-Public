"""Freeze an inspected development protocol without altering the template."""
import argparse
import math
import re
from pathlib import Path
from common import HERE, dataset_info, fingerprint, load_protocol, model_inventory, read_json, reference_contract, save


def freeze(template, model_path, samples, inventory_path, revision, output):
    p = load_protocol(template)
    if output.exists():
        raise FileExistsError(output)
    if not re.fullmatch('[0-9a-f]{40}', revision):
        raise ValueError('Record an immutable 40-character model repository revision')
    inventory = read_json(inventory_path)
    if inventory['reference_contract'] != reference_contract(p):
        raise ValueError('Inventory came from different host settings; inspect again with this template')
    p['targets'] = inventory['targets']
    for op in ('gelu', 'swi_glu'):
        if not p['targets'].get(op) or len(set(p['targets'][op])) != len(p['targets'][op]):
            raise ValueError('Inspect and record both exact target lists before freezing')
        tol = p['tolerances'][op].get(p['model']['dtype'])
        if not tol or set(tol) != {'atol', 'rtol'} or any(
                not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0 for v in tol.values()):
            raise ValueError(f'Set development-justified {op}/{p["model"]["dtype"]} atol and rtol')
    p['dataset'] = dataset_info(samples)
    if not p['dataset']['splits']['eval'] or not p['dataset']['splits']['dev']:
        raise ValueError('Need separate dev and eval data')
    p['model']['revision'] = revision
    p['model']['files_sha256'] = model_inventory(model_path)
    if not any(k.endswith('.safetensors') for k in p['model']['files_sha256']):
        raise ValueError('No model safetensors found')
    source = read_json(HERE / 'model_source.api.json')
    if source['sha'] != revision or source['id'] != p['model']['id']:
        raise ValueError('Model revision differs from pinned official source manifest')
    from prepare_model import valid
    for row in source['siblings']:
        if row['rfilename'].endswith(('.safetensors', '.json', '.txt')) and not valid(model_path / row['rfilename'], row):
            raise ValueError(f'Missing or changed official model file: {row["rfilename"]}')
    p['environment'] = inventory['environment']
    p['runner_sha256'] = inventory['runner_sha256']
    p['state'] = 'frozen'
    p['protocol_fingerprint'] = fingerprint(p)
    save(output, p)
    load_protocol(output, 'eval')


if __name__ == '__main__':
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument('--template', type=Path, required=True)
    a.add_argument('--model-path', type=Path, required=True)
    a.add_argument('--samples', type=Path, required=True)
    a.add_argument('--inventory', type=Path, required=True)
    a.add_argument('--model-revision', required=True)
    a.add_argument('--output', type=Path, required=True)
    args = a.parse_args()
    freeze(args.template, args.model_path, args.samples, args.inventory, args.model_revision, args.output)
    print(args.output)
