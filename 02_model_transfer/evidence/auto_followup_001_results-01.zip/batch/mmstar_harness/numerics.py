"""Hashed capture loading and dtype-specific host-reference checks."""
import json
import math
from pathlib import Path
from common import fingerprint, read_json, reference_contract, sha256


def capture_index(path, operator):
    path = Path(path).resolve()
    source = read_json(path.parent / 'run.json')
    if source['mode'] != 'native' or source['split'] != 'dev' or not source['capture']:
        raise ValueError('Reference captures must come from native/dev')
    rows = [json.loads(s) for s in (path / 'index.jsonl').read_text(encoding='utf-8').splitlines() if s.strip()]
    if not rows:
        raise ValueError('Empty capture index')
    if len({r['file'] for r in rows}) != len(rows):
        raise ValueError('Duplicate capture file')
    for r in rows:
        file = (path / r['file']).resolve()
        if (not file.is_relative_to(path) or r['operator'] != operator
                or sha256(file) != r['sha256']):
            raise ValueError('Capture identity/operator/hash mismatch')
    return rows, source


def tolerance(protocol, operator, dtype):
    dtype = str(dtype).removeprefix('torch.')
    row = protocol['tolerances'][operator].get(dtype)
    if not row or set(row) != {'atol', 'rtol'} or any(
            not isinstance(x, (int, float)) or not math.isfinite(x) or x < 0 for x in row.values()):
        raise ValueError(f'Set justified {operator}/{dtype} tolerances in the development protocol')
    return row


def compare_tensors(reference, actual, tol):
    import torch
    if actual.shape != reference.shape or actual.dtype != reference.dtype:
        return {'passed': False, 'error': 'Shape/dtype mismatch'}
    a, b = reference.detach().cpu().float(), actual.detach().cpu().float()
    special = bool(torch.equal(torch.isnan(a), torch.isnan(b))
                   and torch.equal(torch.isposinf(a), torch.isposinf(b))
                   and torch.equal(torch.isneginf(a), torch.isneginf(b)))
    finite = torch.isfinite(a) & torch.isfinite(b)
    diff = (a[finite] - b[finite]).abs()
    relative = diff / a[finite].abs().clamp_min(1e-12)
    def metric(value):
        value = float(value)
        return value if math.isfinite(value) else None
    return {'passed': special and bool((bool(torch.isfinite(a).all()) and bool(torch.isfinite(b).all()) and torch.allclose(b, a, equal_nan=False, **tol))),
            'special_values_match': special,
            'max_abs': metric(diff.max()) if diff.numel() else 0.,
            'mean_abs': metric(diff.mean()) if diff.numel() else 0.,
            'max_relative': metric(relative.max()) if relative.numel() else 0.,
            'metric_overflow_count': int((~torch.isfinite(diff)).sum()),
            'relative_denominator_floor': 1e-12}


def functions(operator, inputs, attrs, candidate_kernel):
    import torch
    from torch.nn import functional as F
    if operator == 'gelu':
        approximate = attrs['approximate']
        return {'native': lambda: F.gelu(inputs[0], approximate=approximate),
                'wrapper': lambda: F.gelu(inputs[0], approximate=approximate),
                'candidate': lambda: candidate_kernel(inputs[0], approximate)}
    def wrapper():
        packed = torch.cat(inputs, dim=-1)
        a, b = packed.chunk(2, dim=-1)
        return F.silu(a) * b
    return {'native': lambda: F.silu(inputs[0]) * inputs[1], 'wrapper': wrapper,
            'candidate': lambda: candidate_kernel(torch.cat(inputs, dim=-1), -1)}


def check_capture_source(protocol, source, env):
    if source['environment'] != env:
        raise ValueError('Capture and replay environments differ')
    if source['reference_contract'] != reference_contract(protocol):
        raise ValueError('Capture and replay host dtype/processing/generation settings differ')
    if protocol.get('state') == 'frozen':
        if source['model_files_fingerprint'] != fingerprint(protocol['model']['files_sha256']):
            raise ValueError('Reference capture model differs from frozen weights')
        if source['data'] != protocol['dataset']:
            raise ValueError('Capture dataset differs from frozen dataset; capture using full samples.jsonl')
