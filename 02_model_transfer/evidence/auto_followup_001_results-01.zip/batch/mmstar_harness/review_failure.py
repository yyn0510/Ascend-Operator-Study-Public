"""Classify one stopped quality attempt, preserving its original error record."""
import argparse
from pathlib import Path
from common import append_result, fingerprint, read_json, save


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--kind', choices=['implementation', 'infrastructure'], required=True)
    p.add_argument('--reason', required=True)
    a = p.parse_args()
    import json
    errors = [json.loads(s) for s in (a.run / 'errors.jsonl').read_text(encoding='utf-8').splitlines() if s.strip()]
    last = errors[-1]
    reviews = read_json(a.run / 'failure_reviews.json') if (a.run / 'failure_reviews.json').exists() else {}
    key = fingerprint(last)
    if key in reviews:
        raise ValueError('This error was already classified')
    if not a.reason.strip():
        raise ValueError('Supply the evidence/reason from logs')
    if a.kind == 'implementation':
        append_result(a.run / 'predictions.jsonl', {**last, 'status': 'failed',
                      'failure_classification': 'implementation', 'classification_reason': a.reason})
    reviews[key] = {'kind': a.kind, 'reason': a.reason}
    save(a.run / 'failure_reviews.json', reviews)
    print('Recorded implementation failure; resume skips it.' if a.kind == 'implementation'
          else 'Recorded infrastructure interruption; resume retries this sample.')


if __name__ == '__main__':
    main()
