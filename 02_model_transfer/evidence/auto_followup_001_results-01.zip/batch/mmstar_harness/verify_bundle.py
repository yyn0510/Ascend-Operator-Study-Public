"""Portable stdlib integrity check; run in the extracted bundle before building."""
from pathlib import Path
from common import HERE, load_rows, read_json, sha256


if __name__ == '__main__':
    files = read_json(HERE / 'files.sha256.json')
    for relative, expected in files.items():
        path = (HERE / relative).resolve()
        if not path.is_relative_to(HERE.resolve()) or sha256(path) != expected:
            raise ValueError(f'Bundle hash/path mismatch: {relative}')
    samples = HERE / 'data/ai2d_100dev_1000eval/samples.jsonl'
    rows = load_rows(samples)
    print({'files_checked': len(files), 'questions': len(rows),
           'dev': sum(r['split'] == 'dev' for r in rows), 'eval': sum(r['split'] == 'eval' for r in rows),
           'npu_execution': 'not tested by integrity check'})
