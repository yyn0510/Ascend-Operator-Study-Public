"""Download a pinned AI2D release; make deterministic, image-disjoint subsets.

Only this command uses network access. All NPU runners use local files only.
The published lmms-lab-encoder release is a derived test split: reserved dev and
eval subsets below are internal subsets, NOT the official full test score.
"""
import argparse
import hashlib
import io
import json
import sys
import urllib.request
from collections import defaultdict
from pathlib import Path
from common import SEED, fingerprint, load_rows, read_json, save, sha256

REPO = 'lmms-lab-encoder/ai2d'
REVISION = 'c83a9b9692933aff8349157c88a413df9d02c4e5'
FILES = ['data/test-00000-of-00002.parquet', 'data/test-00001-of-00002.parquet']


def download(url, target, expected=None):
    if target.exists():
        if expected and sha256(target) != expected:
            raise ValueError(f'Cached download hash mismatch: {target}')
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_suffix(target.suffix + '.part')
    # Restart incomplete downloads. Never mistake partial data for a complete file.
    with urllib.request.urlopen(url, timeout=90) as response, partial.open('wb') as out:
        length = response.headers.get('Content-Length')
        count = 0
        while chunk := response.read(1024 * 1024):
            out.write(chunk)
            count += len(chunk)
        if length and count != int(length):
            raise ValueError('Incomplete download')
    if expected and sha256(partial) != expected:
        raise ValueError(f'Download hash mismatch: {target}')
    partial.rename(target)
    print(f'Downloaded {target.name}: {target.stat().st_size} bytes', flush=True)


def fetch(cache):
    cache.mkdir(parents=True, exist_ok=True)
    meta_path = cache / 'release.json'
    if not meta_path.exists():
        with urllib.request.urlopen(
                f'https://huggingface.co/api/datasets/{REPO}/tree/{REVISION}/data?expand=true',
                timeout=45) as response:
            listing = json.load(response)
        entries = {}
        for row in listing:
            if row.get('path') in FILES:
                lfs = row.get('lfs', {})
                expected = lfs.get('oid', '').removeprefix('sha256:')
                if len(expected) != 64:
                    raise ValueError('Release API did not provide an LFS SHA256')
                entries[row['path']] = {'sha256': expected, 'bytes': row['size']}
        if set(entries) != set(FILES):
            raise ValueError('Pinned release file list changed')
        save(meta_path, {'repository': REPO, 'revision': REVISION, 'files': entries})
    meta = read_json(meta_path)
    if meta['repository'] != REPO or meta['revision'] != REVISION:
        raise ValueError('Wrong release in cache')
    for rel in FILES:
        download(f'https://huggingface.co/datasets/{REPO}/resolve/{REVISION}/{rel}',
                 cache / Path(rel).name, meta['files'][rel]['sha256'])
    download(f'https://huggingface.co/datasets/{REPO}/raw/{REVISION}/README.md', cache / 'SOURCE_README.md')
    return meta


def answer_letter(value, options):
    # This pinned release encodes ZERO-BASED numeric indices as strings.
    if not isinstance(value, str) or not value.isdigit():
        raise ValueError(f'Unexpected AI2D answer encoding: {value!r}')
    index = int(value)
    if not 0 <= index < len(options):
        raise ValueError('Answer index outside options')
    return chr(65 + index)


def choose(groups, dev_count, eval_count, seed=SEED):
    if dev_count < 1 or eval_count < 1:
        raise ValueError('Both subset sizes must be positive')
    order = sorted(groups, key=lambda key: fingerprint([seed, key]))
    selected, reserved, cursor = [], {}, 0
    for split, target in [('dev', dev_count), ('eval', eval_count)]:
        count = 0
        while count < target and cursor < len(order):
            group = order[cursor]
            cursor += 1
            reserved[group] = split
            # Reserve the WHOLE group even if the target cuts off its last questions.
            for row in sorted(groups[group], key=lambda r: r['id']):
                if count == target:
                    break
                selected.append({**row, 'split': split})
                count += 1
        if count != target:
            raise ValueError(f'Insufficient disjoint samples for {split}: {count}/{target}')
    return selected, reserved


def convert(cache, output, dev_count=100, eval_count=1000):
    import pyarrow.parquet as pq
    from PIL import Image
    if output.exists():
        raise FileExistsError(f'Refusing to overwrite dataset: {output}')
    meta = read_json(cache / 'release.json')
    groups, image_bytes, source_records = defaultdict(list), {}, []
    count = 0
    for rel in FILES:
        parquet = cache / Path(rel).name
        if sha256(parquet) != meta['files'][rel]['sha256']:
            raise ValueError('Parquet release hash mismatch')
        table = pq.ParquetFile(parquet)
        for batch in table.iter_batches(batch_size=32):
            for r in batch.to_pylist():
                raw = r['image']['bytes']
                if not raw:
                    raise ValueError('This converter requires embedded images')
                with Image.open(io.BytesIO(raw)) as im:
                    image = im.convert('RGB')
                    pixels = hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest()
                    if pixels not in image_bytes:
                        buffer = io.BytesIO()
                        image.save(buffer, format='PNG')
                        image_bytes[pixels] = buffer.getvalue()
                    width, height = image.size
                if not isinstance(r['options'], list) or not 2 <= len(r['options']) <= 26:
                    raise ValueError('Unexpected option layout')
                row = {'id': f'ai2d_release_row_{count:05d}', 'group_id': pixels,
                       'image': f'images/{pixels}.png',
                       'image_sha256': hashlib.sha256(image_bytes[pixels]).hexdigest(),
                       'question': r['question'], 'choices': r['options'],
                       'answer': answer_letter(r['answer'], r['options']),
                       'source_index': count, 'source_shard': rel, 'source_image_path': r['image'].get('path'),
                       'source_image_sha256': hashlib.sha256(raw).hexdigest(),
                       'width': width, 'height': height}
                groups[pixels].append(row)
                source_records.append({'id': row['id'], 'answer_index': r['answer'],
                                       'answer': row['answer'], 'options': r['options'],
                                       'question': r['question'], 'group_id': pixels})
                count += 1
    rows, reserved = choose(groups, dev_count, eval_count)
    output.mkdir(parents=True)
    (output / 'images').mkdir()
    for group in {r['group_id'] for r in rows}:
        (output / 'images' / f'{group}.png').write_bytes(image_bytes[group])
    samples = output / 'samples.jsonl'
    samples.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in rows), encoding='utf-8')
    load_rows(samples)
    # Dev-only quick manifests retain group identity and relative image paths.
    pilot = [r for r in rows if r['split'] == 'dev'][:10]
    (output / 'pilot10.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in pilot), encoding='utf-8')
    audit_ids = {r['id'] for r in pilot}
    save(output / 'answer_mapping_audit.json', [r for r in source_records if r['id'] in audit_ids])
    manifest = {'source': meta, 'original_project': 'https://prior.allenai.org/projects/diagram-understanding',
                'protocol': 'Internal image-disjoint subsets of a published derived TEST split; not full official test',
                'answer_mapping': 'zero-based numeric string -> option letter; option order retained',
                'image_transform': 'Decode to RGB and save lossless PNG; no resize or annotation overlay',
                'grouping': 'Exact decoded RGB pixels and dimensions; near-duplicate diagrams not detected',
                'seed': SEED, 'source_rows': count, 'source_pixel_groups': len(groups),
                'reserved_groups': reserved, 'subset_counts': {'dev': dev_count, 'eval': eval_count},
                'samples_sha256': sha256(samples), 'pilot10_sha256': sha256(output / 'pilot10.jsonl'),
                'images': {r['image']: r['image_sha256'] for r in rows}}
    save(output / 'dataset_manifest.json', manifest)
    print(json.dumps({k: manifest[k] for k in ['source_rows', 'source_pixel_groups', 'subset_counts', 'samples_sha256']}, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache', type=Path, required=True)
    p.add_argument('--download', action='store_true')
    p.add_argument('--output', type=Path)
    p.add_argument('--dev-count', type=int, default=100)
    p.add_argument('--eval-count', type=int, default=1000)
    args = p.parse_args()
    if args.download:
        fetch(args.cache)
    if args.output:
        convert(args.cache, args.output, args.dev_count, args.eval_count)
    if not args.download and not args.output:
        p.error('Choose --download and/or --output')
