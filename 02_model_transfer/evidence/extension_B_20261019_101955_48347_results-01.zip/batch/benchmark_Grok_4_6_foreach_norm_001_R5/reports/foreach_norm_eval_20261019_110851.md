# 算子评测报告

**评测代号**: foreach_norm_eval_20261019_110851
**评测时间**: 2026-10-19T11:09:05.642663
**设备**: npu:0
**框架版本**: V0.3.0
**评测集版本**: tasks-v0.0.0-dev

## 概览

| 指标 | 数值 |
|------|------|
| 评测算子数 | 1 |
| 总用例数 | 20 |
| 通过用例数 | 20 |
| 失败用例数 | 0 |
| 通过率 | 100.00% |
| 综合得分 | 0.00 |

## 算子详情

### ForeachNorm（level1/foreach_norm）

| 指标 | 数值 |
|------|------|
| 用例数 | 20 |
| 通过数 | 20 |
| 失败数 | 0 |
| 通过率 | 100.00% |
| 平均加速比 | 0.00x |
| 得分 | 0.00 |

| 用例ID | 状态 | 耗时(μs) | 加速比 | 精度误差 |
|--------|------|----------|--------|----------|
| level1/foreach_norm_1 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_2 | ✅ | N/A | N/A | 0.250000 |
| level1/foreach_norm_3 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_4 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_5 | ✅ | N/A | N/A | 0.000183 |
| level1/foreach_norm_6 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_7 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_8 | ✅ | N/A | N/A | 0.000002 |
| level1/foreach_norm_9 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_10 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_11 | ✅ | N/A | N/A | 0.004395 |
| level1/foreach_norm_12 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_13 | ✅ | N/A | N/A | 0.000048 |
| level1/foreach_norm_14 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_15 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_16 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_17 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_18 | ✅ | N/A | N/A | 0.000061 |
| level1/foreach_norm_19 | ✅ | N/A | N/A | 0.000000 |
| level1/foreach_norm_20 | ✅ | N/A | N/A | 0.000732 |
