# B_新路径预检

这是一份独立上传包，不依赖旧云端results目录。

1. 上传本文件夹中的start_stage_b.py、stage_b_payload.zip、models_metadata.zip到CANNLab的build目录。
2. 按上传清单，将模型权重放到build目录下的对应模型文件夹。旧模型若还在，不用重复上传；元数据ZIP会补齐小文件，并拒绝覆盖不同内容。
3. 执行：python /mnt/workspace/gitCode/cann/cann-learning-hub/build/start_stage_b.py

脚本会输出后台PID、日志路径及最终结果ZIP路径。结果目录每次自动生成新编号，不覆盖旧结果。结束或异常时都会尝试恢复原cann_bench包并导出报告。

B包只做预检：五个检查点的原生/包装对照、DocVQA训练dev、小批次输入捕获、32份候选的构建/原20例/真实输入准入及固定代表集的少量接入。没有新增正式eval或计时结论。

核心环境要求：torch 2.7.1+cpu、torch-npu 2.7.1.post4、Transformers 4.51.3、CANN 9.1.0。A另要求原Ascend910_9362、Pillow12.2.0、NumPy1.26.4。缺少的辅助依赖会按脚本安装；不会升级Torch或torch_npu。B需要timm、匹配torch的torchvision、SentencePiece、protobuf等。如果环境无法满足，返回日志，不修改内核或放宽门槛。

候选编译或数值失败会记录并继续其他候选；原生、包装、环境或加载身份异常会停止供复查。B预检结果应先返回分析，再编写新增宿主/数据集正式实验脚本。A与B互斥运行，建议先运行B，分析结果期间再运行A。

原始分数仅用于来源选择；精度复核关闭性能时出现0综合分不代表精度失败。查看precision_status.json的20/20字段。

尚未在本机执行NPU代码。LOCAL_VALIDATION.json记录本地真实检查边界。
