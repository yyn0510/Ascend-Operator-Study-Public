/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_kernel.cpp
 * \brief ForeachNorm kernel - per-tensor p-norm via two-stage reduction
 *
 * Stage 1 (partial kernel): each AIV block accumulates |x|^p (fp32) over its
 * chunk into a vector accumulator, reduces it to one fp32 partial and writes
 * it to a workspace in GM.
 * Stage 2 (final kernel): one block reduces the partials, applies the 1/p
 * power, casts to the output dtype and writes the scalar result.
 *
 * mode: 0 = L0 (count nonzero), 1 = sum|x|, 2 = sum x^2 (+sqrt),
 *       3 = general sum|x|^p via masked exp(p*ln|x|),
 *       4 = max|x| (+inf), 5 = min|x| (-inf),
 *       6 = sum|x|^n via mul chain (integer 3..8),
 *       7 = sum |x|^(k+0.5) via mul chain + sqrt,
 *       8 = sum 1/|x|^n via mul chain + masked reciprocal (negative integer)
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;
constexpr static int64_t TILE_ELEMS = 8192;
constexpr static float FLOAT_MAX_VAL = 3.4028234663852886e38f;

template <typename T>
__global__ __aicore__ void foreach_norm_partial_kernel(
    GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t blockLength,
    uint32_t tileElems, int32_t mode, float p, int32_t pInt)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> accBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> xfBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> mBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBuf;
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(outQueue, 1, 32);
    pipe.InitBuffer(accBuf, tileElems * sizeof(float));
    if constexpr (sizeof(T) != sizeof(float)) {
        pipe.InitBuffer(xfBuf, tileElems * sizeof(float));
    }
    pipe.InitBuffer(mBuf, tileElems * sizeof(float));
    pipe.InitBuffer(tmpBuf, tileElems * sizeof(float));
    pipe.InitBuffer(workBuf, 8192);

    auto acc = accBuf.Get<float>();
    auto mm = mBuf.Get<float>();
    auto tmp = tmpBuf.Get<float>();
    auto work = workBuf.Get<float>();
    AscendC::LocalTensor<float> xf;
    if constexpr (sizeof(T) != sizeof(float)) {
        xf = xfBuf.Get<float>();
    }

    float ident = (mode == 5) ? FLOAT_MAX_VAL : 0.0f;
    AscendC::Duplicate(acc, ident, static_cast<int32_t>(tileElems));

    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t start = blockIdx * blockLength;
    int64_t curLen = totalLength - start;
    if (curLen > blockLength) curLen = blockLength;

    AscendC::GlobalTensor<T> xGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + start);
    AscendC::GlobalTensor<float> pGm;
    pGm.SetGlobalBuffer((__gm__ float *)partial);

    for (int64_t off = 0; off < curLen; off += tileElems) {
        int64_t cnt = curLen - off;
        if (cnt > static_cast<int64_t>(tileElems)) cnt = tileElems;
        int32_t c = static_cast<int32_t>(cnt);
        auto inLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyExtParams cp{1, static_cast<uint32_t>(cnt * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> pad{false, 0, 0, 0};
        AscendC::DataCopyPad(inLocal, xGm[off], cp, pad);
        inQueue.EnQue(inLocal);
        inLocal = inQueue.DeQue<T>();

        AscendC::LocalTensor<float> af;
        if constexpr (sizeof(T) == sizeof(float)) {
            AscendC::Abs(inLocal, inLocal, c);
            af = inLocal;
        } else {
            AscendC::Cast(xf, inLocal, AscendC::RoundMode::CAST_NONE, c);
            AscendC::Abs(xf, xf, c);
            af = xf;
        }

        if (mode == 0) {
            AscendC::Muls(tmp, af, 1.0e30f, c);
            AscendC::Mins(tmp, tmp, 1.0f, c);
            AscendC::Add(acc, acc, tmp, c);
        } else if (mode == 1) {
            AscendC::Add(acc, acc, af, c);
        } else if (mode == 2) {
            AscendC::Mul(tmp, af, af, c);
            AscendC::Add(acc, acc, tmp, c);
        } else if (mode == 4) {
            AscendC::Max(acc, acc, af, c);
        } else if (mode == 5) {
            AscendC::Min(acc, acc, af, c);
        } else if (mode == 6) {
            // |x|^pInt via mul chain, pInt in [3, 8]
            AscendC::Mul(tmp, af, af, c);
            for (int32_t i = 3; i <= pInt; ++i) {
                AscendC::Mul(tmp, tmp, af, c);
            }
            AscendC::Add(acc, acc, tmp, c);
        } else if (mode == 7) {
            // |x|^(pInt + 0.5) = |x|^pInt * sqrt(|x|)
            AscendC::Sqrt(mm, af, c);
            if (pInt <= 1) {
                AscendC::Mul(tmp, af, mm, c);
            } else {
                AscendC::Mul(tmp, af, af, c);
                for (int32_t i = 3; i <= pInt; ++i) {
                    AscendC::Mul(tmp, tmp, af, c);
                }
                AscendC::Mul(tmp, tmp, mm, c);
            }
            AscendC::Add(acc, acc, tmp, c);
        } else if (mode == 8) {
            // 1/|x|^pInt with zero masking: contribution is 0 when |x| == 0
            AscendC::Muls(mm, af, 1.0e30f, c);
            AscendC::Mins(mm, mm, 1.0f, c);
            if (pInt <= 1) {
                AscendC::Adds(tmp, af, 1.0f, c);
            } else {
                AscendC::Mul(tmp, af, af, c);
                for (int32_t i = 3; i <= pInt; ++i) {
                    AscendC::Mul(tmp, tmp, af, c);
                }
                AscendC::Adds(tmp, tmp, 1.0f, c);
            }
            AscendC::Sub(tmp, tmp, mm, c);
            AscendC::Reciprocal(tmp, tmp, c);
            AscendC::Mul(tmp, tmp, mm, c);
            AscendC::Add(acc, acc, tmp, c);
        } else {
            // masked exp(p * ln(|x|)), contribution is 0 when |x| == 0
            AscendC::Muls(mm, af, 1.0e30f, c);
            AscendC::Mins(mm, mm, 1.0f, c);
            AscendC::Adds(tmp, af, 1.0f, c);
            AscendC::Sub(tmp, tmp, mm, c);
            AscendC::Ln(tmp, tmp, c);
            AscendC::Muls(tmp, tmp, p, c);
            AscendC::Exp(tmp, tmp, c);
            AscendC::Mul(tmp, tmp, mm, c);
            AscendC::Add(acc, acc, tmp, c);
        }
        inQueue.FreeTensor(inLocal);
    }

    auto outLocal = outQueue.AllocTensor<float>();
    if (mode == 4) {
        AscendC::ReduceMax(outLocal, acc, work, static_cast<int32_t>(tileElems));
    } else if (mode == 5) {
        AscendC::ReduceMin(outLocal, acc, work, static_cast<int32_t>(tileElems));
    } else {
        AscendC::ReduceSum(outLocal, acc, work, static_cast<int32_t>(tileElems));
    }
    outQueue.EnQue(outLocal);
    outLocal = outQueue.DeQue<float>();
    AscendC::DataCopyExtParams ocp{1, static_cast<uint32_t>(sizeof(float)), 0, 0, 0};
    AscendC::DataCopyPad(pGm[blockIdx], outLocal, ocp);
    outQueue.FreeTensor(outLocal);
}

template <typename T>
__global__ __aicore__ void foreach_norm_final_kernel(
    GM_ADDR partial, GM_ADDR y, int64_t numPartials, int32_t mode, float invP)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> redQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBuf;
    pipe.InitBuffer(inQueue, 1, 512);
    pipe.InitBuffer(redQueue, 1, 32);
    pipe.InitBuffer(outQueue, 1, 32);
    pipe.InitBuffer(workBuf, 1024);

    AscendC::GlobalTensor<float> pGm;
    pGm.SetGlobalBuffer((__gm__ float *)partial);
    AscendC::GlobalTensor<T> yGm;
    yGm.SetGlobalBuffer((__gm__ T *)y);

    int64_t padded = (numPartials + 7) / 8 * 8;
    auto inLocal = inQueue.AllocTensor<float>();
    AscendC::DataCopyExtParams cp{1, static_cast<uint32_t>(numPartials * sizeof(float)), 0, 0, 0};
    AscendC::DataCopyPadExtParams<float> pad{false, 0, 0, 0};
    AscendC::DataCopyPad(inLocal, pGm, cp, pad);
    inQueue.EnQue(inLocal);
    inLocal = inQueue.DeQue<float>();
    if (padded > numPartials) {
        float ident = (mode == 5) ? FLOAT_MAX_VAL : 0.0f;
        // Diagnostic only: same padding elements, aligned UB base and bit mask.
        const int64_t alignedBase = (numPartials / 8) * 8;
        uint64_t tailMask[1] = {uint64_t(0xff) & (uint64_t(0xff) << (numPartials - alignedBase))};
        AscendC::Duplicate(inLocal[alignedBase], ident, tailMask, 1, 1, 8);
    }

    auto work = workBuf.Get<float>();
    auto red = redQueue.AllocTensor<float>();
    if (mode == 4) {
        AscendC::ReduceMax(red, inLocal, work, static_cast<int32_t>(padded));
    } else if (mode == 5) {
        AscendC::ReduceMin(red, inLocal, work, static_cast<int32_t>(padded));
    } else {
        AscendC::ReduceSum(red, inLocal, work, static_cast<int32_t>(padded));
    }
    inQueue.FreeTensor(inLocal);

    if (mode == 2) {
        AscendC::Sqrt(red, red, 8);
    } else if (mode == 3 || mode == 6 || mode == 7 || mode == 8) {
        AscendC::Ln(red, red, 8);
        AscendC::Muls(red, red, invP, 8);
        AscendC::Exp(red, red, 8);
    }

    AscendC::DataCopyExtParams ocp{1, static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
    if constexpr (sizeof(T) == sizeof(float)) {
        redQueue.EnQue(red);
        red = redQueue.DeQue<float>();
        AscendC::DataCopyPad(yGm, red, ocp);
        redQueue.FreeTensor(red);
    } else {
        auto outLocal = outQueue.AllocTensor<T>();
        AscendC::Cast(outLocal, red, AscendC::RoundMode::CAST_RINT, 8);
        outQueue.EnQue(outLocal);
        redQueue.FreeTensor(red);
        outLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm, outLocal, ocp);
        outQueue.FreeTensor(outLocal);
    }
}

// Tiling function
std::tuple<int64_t, int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 4096;
    constexpr static int64_t MAX_BLOCKS = 128;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    if (totalLength < 1) totalLength = 1;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    numBlocks = std::min(numBlocks, std::min(coreNum, MAX_BLOCKS));
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    numBlocks = (totalLength + blockLength - 1) / blockLength;
    return std::make_tuple(numBlocks, blockLength, TILE_ELEMS);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_foreach_norm_partial_float(GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t numBlocks,
                                       int64_t blockLength, uint32_t tileElems, int32_t mode, float p,
                                       int32_t pInt, void *stream)
{
    foreach_norm_partial_kernel<float><<<numBlocks, nullptr, stream>>>(x, partial, totalLength, blockLength, tileElems, mode, p, pInt);
}

void launch_foreach_norm_partial_half(GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t numBlocks,
                                      int64_t blockLength, uint32_t tileElems, int32_t mode, float p,
                                      int32_t pInt, void *stream)
{
    foreach_norm_partial_kernel<half><<<numBlocks, nullptr, stream>>>(x, partial, totalLength, blockLength, tileElems, mode, p, pInt);
}

void launch_foreach_norm_partial_bfloat16(GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t numBlocks,
                                          int64_t blockLength, uint32_t tileElems, int32_t mode, float p,
                                          int32_t pInt, void *stream)
{
    foreach_norm_partial_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, partial, totalLength, blockLength, tileElems, mode, p, pInt);
}

void launch_foreach_norm_final_float(GM_ADDR partial, GM_ADDR y, int64_t numPartials, int32_t mode, float invP, void *stream)
{
    foreach_norm_final_kernel<float><<<1, nullptr, stream>>>(partial, y, numPartials, mode, invP);
}

void launch_foreach_norm_final_half(GM_ADDR partial, GM_ADDR y, int64_t numPartials, int32_t mode, float invP, void *stream)
{
    foreach_norm_final_kernel<half><<<1, nullptr, stream>>>(partial, y, numPartials, mode, invP);
}

void launch_foreach_norm_final_bfloat16(GM_ADDR partial, GM_ADDR y, int64_t numPartials, int32_t mode, float invP, void *stream)
{
    foreach_norm_final_kernel<bfloat16_t><<<1, nullptr, stream>>>(partial, y, numPartials, mode, invP);
}

}
