
#include <cstdint>
#include <tuple>
#include <dlfcn.h>
std::tuple<int64_t,int64_t,int64_t> calc_foreach_norm_tiling_params(int64_t);
extern "C" int query_norm_tiling(int64_t length, int64_t* out) {
    try {
        auto t = calc_foreach_norm_tiling_params(length);
        out[0]=std::get<0>(t); out[1]=std::get<1>(t); out[2]=std::get<2>(t);
        return 0;
    } catch (...) { return 1; }
}
extern "C" const char* query_bound_extension() {
    Dl_info info;
    if (!dladdr(reinterpret_cast<void*>(&calc_foreach_norm_tiling_params), &info)) return nullptr;
    return info.dli_fname;
}
