"""Fresh-process C formal tasks and comparisons; pinned models and real NPU only."""
from collections import Counter,defaultdict
import importlib.util
import json
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'harness'))
from run_cloud import read,save,sha
import base_workers as base
from cloud_helpers import initialize,modelpath,candidate,patch,Captures,SEED,targets


def load_generation(c):
    # All primary quality runs retain the B settings; scans change one input factor.
    model,processor=base.load_generation(c)
    if c['host'].startswith('qwen') and ('max_pixels' in c or 'min_pixels' in c):
        from transformers import AutoProcessor
        maximum=c.get('max_pixels',401408);minimum=min(c.get('min_pixels',200704),maximum)
        processor=AutoProcessor.from_pretrained(modelpath(c),use_fast=False,local_files_only=True,min_pixels=minimum,max_pixels=maximum)
    return model,processor


def select_samples(c):
    dataset=c.get('dataset','ai2d')
    path=HERE/'data'/dataset/('samples.json' if dataset=='coco' else 'samples.jsonl')
    records=read(path) if dataset=='coco' else [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s.strip()]
    result=[r for r in records if r['split']==c.get('split','eval')]
    if c.get('limit'):result=result[:c['limit']]
    if not result:raise ValueError('Empty frozen dataset slice')
    return result


def build(c):
    """Keep an immutable wheel per run, independent of later project rebuilds."""
    import shutil
    base.build(c)
    receipt_path=Path(c['output'])/'receipt.json';receipt=read(receipt_path)
    wheel=Path(receipt['wheel']);target=Path(c['output'])/'wheels'/wheel.name
    target.parent.mkdir();shutil.copyfile(wheel,target)
    if sha(target)!=receipt['wheel_sha256']:raise ValueError('Archived candidate wheel changed')
    receipt['wheel']=str(target.resolve());save(receipt_path,receipt)


def generative(c):
    import torch
    identity=initialize(c);model,processor=load_generation(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    samples=select_samples(c);op=candidate(c)['operator'] if identity else c.get('operator','swi_glu')
    captures=Captures(model,c) if c.get('capture') else None
    maximum=read(c['plan'])['generation']['mmstar_max_new_tokens']
    predictions=[];lengths=[];original_generate=None
    if c['host']=='internvl':
        original_generate=model.generate
        def recorded_generate(*args,**kwargs):
            value=original_generate(*args,**kwargs);lengths.append((int(value.shape[-1]),value.detach().cpu().tolist()[0]));return value
        model.generate=recorded_generate
    if hasattr(torch.npu,'reset_peak_memory_stats'):torch.npu.reset_peak_memory_stats(c['device'])
    save(out/'run.json',{'host':c['host'],'operator':op,'mode':c['mode'],'identity':identity,'dataset':c.get('dataset'),'split':c.get('split'),'max_new_tokens':maximum,'samples_expected':len(samples),'max_pixels':c.get('max_pixels',401408),'formal_eval':c.get('split')=='eval'})
    try:
        with torch.inference_mode(),patch(model,c,op) as calls:
            for index,row in enumerate(samples):
                inputs,info=base.generation_input(c,row,processor)
                if c['host'].startswith('qwen'):
                    generated=model.generate(**inputs,max_new_tokens=maximum,do_sample=False,use_cache=True)
                    tokens=generated[:,inputs['input_ids'].shape[1]:]
                    text=processor.batch_decode(tokens,skip_special_tokens=True)[0].strip();token_ids=tokens.detach().cpu().tolist()[0];length=int(tokens.shape[-1])
                else:
                    pixels,question=inputs
                    text=model.chat(processor,pixels,question,{'max_new_tokens':maximum,'do_sample':False},num_patches_list=[pixels.shape[0]])
                    length,token_ids=lengths[-1]
                    if length>maximum:raise ValueError('InternVL generation prefix accounting changed')
                torch.npu.synchronize()
                result={'id':str(row['id']),'group_id':str(row['group_id']),'text':text,'status':'success','new_tokens':length,'token_ids':token_ids,'possibly_at_length_limit':length>=maximum,'input':info}
                if 'answers' in row:result['answers']=row['answers']
                if 'answer' in row:
                    from common import parse_answer
                    result.update(answer=row['answer'],prediction=parse_answer(text,len(row['choices'])))
                    result['correct']=result['prediction']==result['answer']
                predictions.append(result);save(out/'predictions.json',predictions)
                if (index+1)%25==0 or index+1==len(samples):print('SAMPLE',index+1,'/',len(samples),flush=True)
            save(out/'calls.json',calls)
        if c['mode']=='wrapper':
            reference=read(Path(c['baseline'])/'predictions.json')
            if [(r['id'],r['text'],r['token_ids']) for r in reference]!=[(r['id'],r['text'],r['token_ids']) for r in predictions]:raise ValueError('Wrapper changes native tokens or decoded output')
        score=score_rows(samples,predictions,c.get('dataset','ai2d'));save(out/'scores.json',score)
        memory={key:int(getattr(torch.npu,key)(c['device'])) for key in ('max_memory_allocated','max_memory_reserved') if hasattr(torch.npu,key)}
        save(out/'memory.json',{'bytes':memory,'scope':'formal task peak allocated/reserved, includes model; not matched-throughput inference'})
    finally:
        if captures:captures.close()
        if original_generate is not None:model.generate=original_generate


def score_rows(samples,predictions,dataset):
    if dataset=='docvqa':
        from docvqa_scoring import score_predictions
        return score_predictions(samples,predictions)
    by_id={str(r['id']):r for r in samples}
    if len(by_id)!=len(samples):raise ValueError('Duplicate sample ID')
    answers={}
    for row in predictions:
        key=str(row['id'])
        if key not in by_id or key in answers:raise ValueError('Duplicate or foreign prediction ID')
        answers[key]=row
    result=[];states=Counter()
    for key,sample in by_id.items():
        row=answers.get(key);status='missing' if row is None else row.get('status','success')
        if row and status=='success' and row.get('prediction') is None:status='invalid_answer'
        correct=int(status=='success' and row['prediction']==sample['answer'])
        states[status]+=1;result.append({'id':key,'group_id':str(sample['group_id']),'state':status,'accuracy':correct})
    return {'questions':len(samples),'accuracy':sum(r['accuracy'] for r in result)/len(samples),'states':dict(states),'per_sample':result}


def clustered_difference(native,actual,metric,seed=20261019,replicates=5000):
    import numpy as np
    if [(r['id'],r['group_id']) for r in native]!=[(r['id'],r['group_id']) for r in actual]:raise ValueError('Paired rows differ')
    groups=defaultdict(lambda:[0.,0])
    for a,b in zip(native,actual):groups[a['group_id']][0]+=b[metric]-a[metric];groups[a['group_id']][1]+=1
    values=np.array(list(groups.values()),dtype=float);rng=np.random.default_rng(seed);boot=[]
    for start in range(0,replicates,128):
        draws=rng.integers(0,len(values),size=(min(128,replicates-start),len(values)))
        selected=values[draws];boot.extend((selected[:,:,0].sum(1)/selected[:,:,1].sum(1)).tolist())
    diff=float(values[:,0].sum()/values[:,1].sum());ci=np.percentile(boot,[2.5,97.5]).tolist()
    return {'difference_percentage_points':100*diff,'paired_group_bootstrap_95pct_pp':[100*x for x in ci],'groups':len(values),'replicates':replicates,'seed':seed,'interpretation':'conditional on frozen sample set; does not establish equivalence'}


def compare_quality(c):
    out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    if c['dataset']=='coco':
        from completion_utils import rows,retrieval_pair
        reference=Path(c['baseline'])/'ranks.jsonl';actual=Path(c['actual'])/'ranks.jsonl'
        if not actual.is_file():
            save(out/'comparison.json',{'status':'candidate_job_failed_before_complete_ranking','baseline':str(reference),'candidate_directory':c['actual'],'quality_not_estimated':True});return
        save(out/'comparison.json',retrieval_pair(rows(reference),rows(actual)));return
    run=read(Path(c['baseline'])/'run.json');samples=select_samples({'dataset':c['dataset'],'split':run['split'],'limit':run['samples_expected']})
    native=read(Path(c['baseline'])/'predictions.json');path=Path(c['actual'])/'predictions.json';actual=read(path) if path.exists() else []
    a=score_rows(samples,native,c['dataset']);b=score_rows(samples,actual,c['dataset'])
    metrics=['anls','em'] if c['dataset']=='docvqa' else ['accuracy']
    pairs={metric:{'native':a[metric],'candidate':b[metric],**clustered_difference(a['per_sample'],b['per_sample'],metric)} for metric in metrics}
    lookup={r['id']:r for r in actual};changes=sum(row['text']!=lookup.get(row['id'],{}).get('text') for row in native)
    extra={'token_sequence_changes_including_missing':sum(row['token_ids']!=lookup.get(row['id'],{}).get('token_ids') for row in native)}
    if c['dataset'] in ('ai2d','mmstar'):extra['parsed_answer_changes_including_missing']=sum(row['prediction']!=lookup.get(row['id'],{}).get('prediction') for row in native)
    save(out/'comparison.json',{'samples':len(samples),'candidate_outputs':len(actual),'candidate_states':b['states'],'decoded_output_changes_including_missing':changes,'possibly_at_length_limit':sum(r.get('possibly_at_length_limit',False) for r in actual),'metrics':pairs,**extra})


def verify_original(c):
    import importlib.metadata
    description=read(Path(c['batch_root'])/'backup/backup.json');spec=importlib.util.find_spec('cann_bench')
    if not description['installed']:
        if spec is not None:raise ValueError('Original package changed between attempts')
    else:
        if spec is None:raise ValueError('Original package no longer installed')
        root=Path(spec.origin).parent
        if any(not (root/Path(name).relative_to('cann_bench')).is_file() or sha(root/Path(name).relative_to('cann_bench'))!=expected for name,expected in description['package_files'].items()):raise ValueError('Installed package differs from original rollback snapshot; review before resume')
        if sha(description['wheel'])!=description['wheel_sha256']:raise ValueError('Rollback archive changed')
    save(Path(c['output'])/'identity.json',{'original_package_identity_verified':True})


def analysis(c):
    import math
    out=Path(c['output']);out.mkdir(parents=True,exist_ok=False);root=Path(c['batch_root']);plan=read(c['plan']);state=read(root/'batch_status.json')
    records=[]
    for row in plan['candidates']:
        cid=row['candidate_id']
        for host in sorted({j['host'] for j in plan['quality_jobs'] if j['candidate']==cid}):
            timing=[]
            for step in state['steps'].values():
                if step['status']!='completed' or not step['name'].startswith('performance_'+host+'_'+cid+'_default_'):continue
                path=root/step['name']/'summary.json'
                if path.exists():
                    s=read(path)
                    if s.get('status')=='measured':timing.append(s['candidate_over_native_wall_ratio'])
            comparisons={}
            for job in plan['quality_jobs']:
                if job['candidate']!=cid or job['host']!=host:continue
                tag=host+'_'+job['dataset']+'_'+cid+('_pixels'+str(job['max_pixels']) if job.get('max_pixels') else '')
                path=root/('compare_'+tag)/'comparison.json'
                if path.exists():comparisons[tag]=read(path)
            records.append({'candidate_id':cid,'generating_model':row['model'],'trajectory':row['trajectory'],'operator':row['operator'],'host':host,'historical_score':row['score'],'historical_speedup':row['avg_speedup'],'default_latency_ratios':timing,'default_ratio_geomean':math.exp(sum(math.log(r) for r in timing)/len(timing)) if timing else None,'quality':comparisons})
    correlations=[]
    # Descriptive only: generators/trajectories are related and N is small.
    from scipy.stats import spearmanr
    for host,op in sorted({(r['host'],r['operator']) for r in records}):
        group=[r for r in records if r['host']==host and r['operator']==op and r['default_ratio_geomean'] is not None]
        if len(group)<4:continue
        ys=[1/r['default_ratio_geomean'] for r in group];correlation={}
        for key in ('historical_speedup','historical_score'):
            xs=[r[key] for r in group]
            correlation[key+'_vs_current_model_speed_spearman']=float(spearmanr(xs,ys).statistic) if len(set(xs))>=3 and len(set(ys))>=3 else None
        correlations.append({'host':host,'operator':op,'n':len(group),'generating_models':len({r['generating_model'] for r in group}),**correlation,'interpretation':'selected candidate set, exploratory; no independent-sample p-value or causal claim'})
    save(out/'candidate_application_summary.json',{'records':records,'descriptive_correlations':correlations,'excluded_after_B':plan['excluded_after_B']})
    save(out/'completion.json',{'planned_counts':plan['planned_counts'],'step_statuses':dict(Counter(r['status'] for r in state['steps'].values())),'candidate_records':state['candidate_records']})


def main():
    action,request=sys.argv[1:];c=read(request)
    from d_extra import safe_norm_replay
    from c_measure import model_performance,replay_performance,profile_native,performance_control
    functions={'preflight':base.preflight,'backup':base.backup,'restore':base.restore,'install':base.install,'build':build,'benchmark':base.benchmark,'gate':base.gate,'health':base.health,'clip':base.clip,'generative':generative,'compare_quality':compare_quality,'verify_original':verify_original,'analysis':analysis,'model_performance':model_performance,'replay_performance':safe_norm_replay,'profile_native':profile_native,'performance_control':performance_control}
    if action=='restore':Path(c['output']).mkdir(parents=True,exist_ok=False)
    functions[action](c)

if __name__=='__main__':main()
