"""Frozen reporting rules; no model or NPU import at module scope."""
import hashlib
import json
import math
from pathlib import Path
import statistics

SEED=20261016
GELU=['Grok_4_6_gelu_001_R4','Kimi_K3_gelu_002_R3']
NORM=['DeepSeek_V4_1_Flash_foreach_norm_002_R5','Grok_4_6_foreach_norm_003_R5']
TOL={'atol':1e-5,'rtol':.016}

def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');tmp.replace(path)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def fp(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def append(path,obj):
    with Path(path).open('a',encoding='utf-8') as f:f.write(json.dumps(obj,ensure_ascii=False,allow_nan=False)+'\n')
def rows(path):return [json.loads(s) for s in Path(path).read_text(encoding='utf-8').splitlines() if s.strip()]
def metrics(actual,reference):
    import torch
    if actual.shape!=reference.shape or actual.dtype!=reference.dtype:raise ValueError('Output shape/dtype mismatch')
    a=actual.detach().cpu().double();b=reference.detach().cpu().double()
    if not bool(torch.isfinite(a).all() and torch.isfinite(b).all()):raise ValueError('Nonfinite value; review before continuing')
    d=(a-b).abs();bad=d>TOL['atol']+TOL['rtol']*b.abs()
    return {'passed':not bool(bad.any()),'elements':a.numel(),'failed_elements':int(bad.sum()),'max_abs':float(d.max()),'mean_abs':float(d.mean()),'exact_equal':bool(torch.equal(actual.detach().cpu(),reference.detach().cpu()))}
def timings_summary(records):
    groups={}
    for r in records:groups.setdefault((r['workload'],r['phase'],r['mode']),[]).append(r['milliseconds_per_call'])
    out=[]
    for (work,phase,mode),v in sorted(groups.items()):
        if len(v)!=3 or min(v)<=0:raise ValueError('Incomplete timing blocks')
        base=statistics.median(groups[(work,phase,'native')]);med=statistics.median(v)
        out.append({'workload':work,'phase':phase,'mode':mode,'median_ms':med,'blocks':3,'min_block_ms':min(v),'max_block_ms':max(v),'speedup_vs_native':base/med})
    aggregate=[]
    for phase in sorted({r['phase'] for r in out}):
        for mode in ('wrapper','candidate'):
            v=[r['speedup_vs_native'] for r in out if r['phase']==phase and r['mode']==mode]
            if v:aggregate.append({'phase':phase,'mode':mode,'workloads':len(v),'geometric_mean_speedup':math.exp(sum(math.log(x) for x in v)/len(v))})
    return {'workload_results':out,'aggregate':aggregate,'measurement':'NPU synchronized wall latency including Python, launch and adapters; not hardware-only; three blocks descriptive, not independent workloads'}

def retrieval(image,text,ids,caption_ids,owners):
    """Full fixed-corpus ranks. CPU FP32 scores; stable corpus-index tie break."""
    import numpy as np
    a=np.asarray(image,dtype=np.float32);b=np.asarray(text,dtype=np.float32)
    if a.ndim!=2 or b.ndim!=2 or a.shape[1]!=b.shape[1] or len(ids)!=len(a) or len(caption_ids)!=len(b) or len(owners)!=len(b):raise ValueError('Retrieval identity/shape mismatch')
    if not np.isfinite(a).all() or not np.isfinite(b).all():raise ValueError('Nonfinite retrieval feature')
    if len(set(ids))!=len(ids) or len(set(caption_ids))!=len(caption_ids) or set(owners)!=set(ids):raise ValueError('Retrieval corpus identities invalid')
    scores=a@b.T
    if not np.isfinite(scores).all():raise ValueError('Nonfinite similarity')
    image_index={v:i for i,v in enumerate(ids)};out=[]
    for direction,mat,query_ids,pool in [('image_to_text',scores,ids,caption_ids),('text_to_image',scores.T,caption_ids,ids)]:
        for i,q in enumerate(query_ids):
            order=np.argsort(-mat[i],kind='stable')
            good=np.array([j for j,o in enumerate(owners) if o==q]) if direction=='image_to_text' else np.array([image_index[owners[i]]])
            rank=int(np.flatnonzero(np.isin(order,good))[0])+1
            out.append({'direction':direction,'query_id':q,'group_id':q if direction=='image_to_text' else owners[i],'rank':rank,'top10':[pool[j] for j in order[:10]],'top1_score':float(mat[i,order[0]])})
    summary={direction:{f'R@{k}':sum(r['rank']<=k for r in out if r['direction']==direction)/sum(r['direction']==direction for r in out) for k in (1,5,10)} for direction in ('image_to_text','text_to_image')}
    return out,summary

def retrieval_pair(a,b,replicates=5000):
    import numpy as np
    key=lambda r:(r['direction'],r['query_id'])
    if [key(r) for r in a]!=[key(r) for r in b] or any(x['group_id']!=y['group_id'] for x,y in zip(a,b)):raise ValueError('Unpaired retrieval rows')
    rng=np.random.default_rng(SEED);report={}
    for direction in ('image_to_text','text_to_image'):
        pairs=[(x,y) for x,y in zip(a,b) if x['direction']==direction];groups=sorted({x['group_id'] for x,y in pairs})
        report[direction]={'queries':len(pairs),'image_groups':len(groups),'top1_changes':sum(x['top10'][0]!=y['top10'][0] for x,y in pairs),'recall':{}}
        # Bootstrap query image groups against the same fixed retrieval corpus.
        for k in (1,5,10):
            sums=[];counts=[]
            for g in groups:
                selected=[(x,y) for x,y in pairs if x['group_id']==g]
                sums.append(sum(int(y['rank']<=k)-int(x['rank']<=k) for x,y in selected));counts.append(len(selected))
            sums=np.array(sums);counts=np.array(counts);boot=[]
            for _ in range(replicates):
                idx=rng.integers(0,len(groups),len(groups));boot.append(float(sums[idx].sum()/counts[idx].sum()))
            report[direction]['recall'][f'R@{k}']={'native':sum(x['rank']<=k for x,y in pairs)/len(pairs),'candidate':sum(y['rank']<=k for x,y in pairs)/len(pairs),'difference_percentage_points':100*float(sums.sum()/counts.sum()),'paired_image_group_bootstrap_95pct_pp':(100*np.quantile(boot,[.025,.975])).tolist()}
    report['bootstrap']={'replicates':replicates,'seed':SEED,'scope':'query image groups; retrieval corpus fixed; CI does not establish equivalence'}
    return report
