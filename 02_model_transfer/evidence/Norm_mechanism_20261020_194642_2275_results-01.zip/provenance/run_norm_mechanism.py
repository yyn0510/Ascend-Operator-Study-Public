"""Isolated ForeachNorm mechanism scan. Upload this one file, then run it.

Three separate variants: archived D binary, source-identical rebuild control,
and one diagnostic tail-padding change. No new formal candidate or model score.
"""
import argparse
import base64
import ctypes
import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback
import types
import zipfile

SCRIPT = Path(__file__).resolve()
support = types.ModuleType('_sealed_norm_confirmation_support')
support.__file__ = str(SCRIPT)
exec(compile(gzip.decompress(base64.b64decode('H4sIAAAAAAACCtU8a3OkSHLf9SvwXGxA7/UgoB90a6MdMStpdhWrlWQ99s7WKogCCglPN2CgR9KO5787M6sKCrpb0qzPYVsXt0NDkZWVle/M4t27d+cZN9IqX7Kax0aUZ0larlid5pmRJ0b9wI11Fj2w7B6eHhkf85Kz6OEsL1dGxLI4jeE1e2/vpljmLIbhaWXkADBJl9wIeZXG3KhqVtYB/PeeB7FdPNvGEU/YelkbMa8BGK9+MN6/r+q8MEr+H2te1dXefckinqyXRs3LVZoJfGA+o8yXy5BFn2zj+qHk3Mj4o1GUecjxvxGvKl4NCYO8TO/hxeVexIp6XfKhkeUAP1yny5iu06xY1/tFyaO0Auj7db7kJcsibojlVjSqemAFLAHWau+9e/duL10VeVkbrLwvWFnxvaTMV0i1mj/VyzQ05PPjp7S+gsV9Ui8gnep0xdXvB1Y9wHj189+rPFPXeSWgFqx+0EBewE81pErvcWnq1zqUi2/uPDeX+qQ1UjXUsPojLXCn9vauDi9PLq6NBc1iBQHeDYKBXXLgjM/cGuxdnd9cHh4Hl+fnzTBzf5XV+495+akqAPD+51EAVOAZklPtd+A53tR1PMdsQdycAQSzHXrUDArcCV4G3mjsm3sfz09Pz/92c/HapBlwY1ByoEG8jrg+4+GHs6OTow/XxzjhL+kqDX4ZBYngYfGa44yCS8/cuzg5Ozs+gmFfzGIJm40bYh4Y5sSZ+/Ek9PgkGTvcZXPX5bMpn0fxZD72o8ks8h1n6nksYhPPTWZsNI4815t48SSKZlPPHBrmxYfDXz78dBz8+uHs5OPx1XUD3GFeNJtEYx6HE8fl4cgPI3cehWweRbHvJzPPdZg7HsGWhdHY96bTOXdC34/gZxiOHQRerrMgWuZrlCyEOffHHp+N+DgaT6ejWeyHMz9i3nzmTSfzBB7wccLiGY9Go/mIjefRZB46Y+6NYj9ORpGPMENW8QBJzMtKgh2F3ihhvgf/C0eJF87d0OHenCczHwgwATzHPJnzGY99z5lGo9koTtjcG7sx5x6LCVVCM3jgy6KFy0fJzJkmc99NvNhNxrHjjEfubDoeTedzf5KE3Of+NB5HrjtOgOLJaOb4znyWOLP5GFaHcHuYwsrHrjvyJrAvcRxNHBbzaMJmsIexP/LGoTuOYcFsPo59hyXhLA5hE+csTuA/josQH1iZgTjtNyquavZshiCnzsifh144TaZTQCSM5+FomsTci50Zn/uR6wE9E9cFHpkBy0zCcRT6MMCbjjvg89UqzxTeo/E4jNlkOgFKzJxwClsTuyHsuB/548Tl49k8gV2CreT+bDIbudN4Couau7N5NI24Dvghr2oJdgIiNRo5U8eHZc+TeBbFnE0Tz4lHDmxTOJowuEx4PI1HbhgDvccxMCPzJhMWejO/g+8yLQIWg0LlpQQfc8A2YYk7SuAtF8A5IFzMnTEAE07m8zhymAO4jqezcO65Ls7uuWwCmzF2/GmPHMWSo6oP1nW6bDYUpMKfTWNY9DTx/dE4dqM5sMEcqJ2AGEzHc8cbO858AjcjHyTTgas5GzvuDBiaKA56DAxOtf+a0tkHcUKN2W6370RJPPZhCROAFTM+86ehM4lh9ohPwjiGvZrCZexNprNRCHsycUEtzNxwGiaz+TdNHrIa9BJoznrdMpwLYhEns3gyiTmIq+P7PImnoBF8IMyMg+5gLnAb7C/zXe7G8ynIo+95SeIlUTx1vg0DNI/BC5pyH+wlT4u6VZBJkgA/Onw2A4GAPRonUwYyzaf+xJsy2IwkjsaTKQflCbsx9yI2Bb0wnodh7Cdz95vQi/nngJgwyqN8X1r2al/Hcz/NYv7UoOfN5sA0oMUTLwKcgFJzFs3A/4j9eeyCYpqNUGe7Uz7yR5PRfM7noNe8xB+Diph6/NuYR7ov+/egMoI0S+uULQXCL5DUZnXNV0UduIEL9BnPJvPZyBs5/gx+eM1KwCqEIJc8dGEqkJzIAXkDwQcdw/35HC5BGjxQ0aB054nv+qBNIh9MkQsSCYC/aSXL/P4fuwoAiIuIRr47jXwOVm80nU0coHnMQCdPJwytJvOj8WzsT4DjfY/NQCuNQjeZg7IFbTjz5sz8und+efLTydmH0+Dy+F9uwJoGvx7/+uPxJVr4/wMbtXf894vjw+vjo+Dww8X1zeVxcPXzB8RtDkYoGfuzsQfLmYAgRy4HCebAfpORy8IE7FICwJLJeDwawR7D0zHINzgd3HOisbm3twfKFlxYFlvoGg4O9gz4KznIQEYOpI0+eGWRm0QjbBwcoGtq8SzK4zS7X5jrOnk/MwcDCa9i4N7h6KHxmS3XXILFO8rlIljNXRscX57V9upTnJaW+FEtrss1uNj8Ka3qIP9EP8UrSLG8ZOUzQKPXH9MaqMpWYlYbr4y/GqZdrwqz94r9WKawP7QAWmC8XhWVRXjCZFkF0h+wKkrTxUe2rOAeCn9WL7yhwZbL/BHmycSjAc7xe2biaz1K9OYER3IJjqVctSTSA9NpjpSRDrwNj0DzWwIKrk2jmZ0XPLPMMjQHBqsgEIL9WAkQ+AcshnEBA6wNWGdpLdkKPIADOZB2zxob3xvAv+qfwdAITXPQAiF87HWBXoqF0AY6WzzYD/wpTiGaqa1mMTVbFVaXfVR4YjcXWf5oNT/wP39AVNW9E/NlzayHfF1Wi9lgMLAB7wQfWOZ3//rd6rs4+O7n73797spsZoah4KDn67o3vR5c7DdybMJ1GzNIGCquC6QM9yARzbrgdigMhRQEoNGnQKBWKWi4NciZyNIFjzA0hk0SQYINe7VqRmrC0p0WX29GpAkEk7UQgLSi8MoawFpazjL+adHM1d3dkqUVN35Dpj8uy7y0zHNJAwjIKdBepVUFHL0v4/QftFAX5wCTLSwlKGAQA0RMMAl6GhwQJ6Lpm4ObsOmMiJdgKRa9aN/z2jLFAJPwN6UHx+OApLxxn2GzoryMK7OzMFx+Cwg2vQYJRPdPQvvMyzRJeWz2RnKkAoxJKyLqGTCmthkvkkusWL7YYCsyCzQ/zCaWGQFdNnlNUSC6NZvFmXeIbRtqArLwGF1w8cREu2LK2+DBpJF8xXkT0gmDLY5VasSIU/C3yqrdDFI3ABnDVvOOKNcTpzagRSTUeOnpylf6u9/1g9+CJ86i3GchEV1UlbemrAqRUNwCHBrCqlFbcHqD9/ciqjdZI8xqZ9V8hLCpVCfyqhKLBiFAQHMtB0BAydN3t86dQl/cuzVRLOXuO/BnF7UpJZEeU1ZJPL+dDY2J693pj+P6WT02gSejBztMwLbX7vTF9X1MS2AQ5BdQBs3KVrxmZGU2OEfDBkyYmG+r+yL1lEaK7joHu958M4MjwuizwUwbyizOSVqrdVjVab0G+WXw+4GXIoXX7hrGJYHuuES0SXhb47DOwE0us0wRA6GmbGRaiEQn8vlGPlN4dJBVPKajJB2JB86Xahny8a1Jd7WlIFnoXpunQ+tS8iWo0c/gOOWW9eblESDgjhbWi0r1DObG7HC6Wq1rFi7bjCuoWYHoFjw3bB/dJv7prjJQTPkmFkJNTlpS0G2bPWTrOse8dqQso9nnCBCEPJJSB04lz+K564RvU37C1l7lhz0pk17JF81aHLR0HzZMpZZ7QETp8MOwYzO71DnQaIh5O8ClfG4fNgvrPrjrgyxZUfByy3u9J3eYxBNKoB28Te6/St9qlcfrZetVVc+VjWu6PXDugLlvwV/UfTVYQu8O8qXMDpkDqWRF5rqTS9RJ3X0g0BBGF26yJWoFiY1KiqOCFW49vQSINWhrt20ZJaZ/cOvLpwPjM/mInyBqQs8wUk4h8tMnYni4a2nb3u61OfgqAD/BVEK9C9Vn3br20PDg/yMbSC2wXiQmaLmDL9HtO3Hj3d1XyVwYUllPIMjuwI6KtURXQIR37Oo5ix7KPEOUO7IohoBDwZbW87CHg5h/aIztu5c1wEdQFA/vZeXBOLu4MRiEaw9gb0DIBK2Fcy1dmL5IhKxKowDeC9r3gOWrCoYeGCKgNIsUf+QVen5wbQ0Ua1HRp9lLUG+a0odfaBikooRfLwerIkCUyGHkIcoAOAHMja4VXd5tQwfuSQ/4AP0DySKgfMyukBnGThXQeJlvEq0NsAVEopxmx9A3rZ8DmCfg2ecUtn4Ftyj13njiEQTGgUxkEKFp9UBVBNbEQ0WeZrUe4lCaAKnchGfCDg4lyaSPp70rmLF8bmH0Iq3m/g652yqjugpgWRaEEM63T2Q1rptGVuOBwco0qobG9flp7w0tr61Gl/njI3B8Jw/UfQs9/GY0+UOBVDSCI7qj65JlFQBbYaUCFgq21sZ5xTUwDLm2Cl4A/BV8Bh8iL7szC2rfNpttoiLd1FDRYOMNiVvIcUX0Wl8taq9srgY3vx3xBmeedgod5tc8aT1ItuiBip5EPgd+Io20nxhqaDZJ3pWxR/OAvAqrJy6GDMdAJjJykuCKfNsmgGp+twHS4M0B+S6nW/CA5g1SMGf2SQ6kUovpBxcknghR2QxM9u12yYfGI0/vH+oqyLPls9R4K1YEyzyiGHthgsnoEn8J+pBSSMBe5Fnf2RSoDPpxSncMRSs4pBuqvJlm0u+nqfYFsK4T1XKxynPJZS/EmtGCydr9AmR7uLHlihnBu1ijRpQE+BDH4DJKS4UpAMER70sOk3PRCQAaqzKEzFBbQdsM0ahUAPxZEvWHdosx/yhu9pIOS4apM0MIMGhjbZGUPhRUTDOJQ4C8b/U4EGWquwng6u92FFoiJs2LzSLNu94YoS6EWUE1IQUlaN4IsN+hzJfdbM6G7ld/4nUA1Fdq1tNg69T9+QgLqb0t8RDNTtJ9W/o2u4HcmvyJRXVAfo8eWLwQ5AjUKSX83JVljH3QKGJmRk7xg0FNLMhnoO+wfQbsbJmGYIUgvE3RjLVcY25bu+JvIv5iw2qDXReuTSAYE3TXLsMuJH6HJAgNrl5s2bdauEMpjgEqg2DJs/v6YTFr74oboAiwO6ZcBcXCs53B2xihKPGe2fg+4NacngZX1x8ur3ElPT9rAfc6jlayXFcPWmVB/cGewoaildlisq2noeYo2PqjDfYRgGwhPajQnuT1W1jlsFEHwsHF4D9J3ktg0iPdzu+oKJZiSzusLvDZwuoNj8MqyN7HQcIZGYItYJ7AOChQT5SYRqbuQnwpaOjPKv1dnMIyq3WE7j/le9MMgvsnQKZRx+YLDNiQfSsZgBlEJHCnkrOvrbh949VJwffioNbAFpRpM2fQiVJeUIdN2vgN+k+y/MXl+Y8Q0R4fnl8eHR81TnNLy+3cLUMlh27wp4gX2FmG/1A7XGVQJrzlTurvQgdB9Xkhv68YqLynyNplSwUKurLhTzxak/8sSaLv0s5I4k6SVRqHALSFFoQoULtUEq0kQOO/wP9Y9HtgB1QpDIKhGLDA/IB4NGxXuaCrdn1/Ma7yFTgRJbA5OCspu8/AnQRRMDCbwUoDXSKMz6s6BmC4GzVLM1HjIb1e88JY5vf2hhMNvHcv1sPVPoD+DIrn+gGuViAJ7F6wCcuerYoAInLgrT3y0hpQ0qASuQG0VgQPyYKdZr4zmmBh9g0cRUBfZppv2TRPBtWikwoVDyxsqNxU6XxEbbpS3FYpBfSXRQMheYqgyKuo1JJaL+bwDvWOU/GeoVyseF2i5aRKVJuuE9gZCxBFGaP3165yAy9ldV7KGPQn4ckSfWltom/JKfTDZxW6qQC6Fxb34+L/gcRTHyPhAit8+mGheAdi1A5VUPDWhUYSia24r4jffwt9I+BA7bW/GJdc3iXZIx/NYGCO0s8qoWsbZ7lMsWLLHBoE8Kapwk8OfMntV5MMMrDWWxubZ51+R4nMrhUIsvyDWOHPEF7WKf8bGMidkoDahVb8BUEVGHRSeI6qoC/B8KbJsyXr9kpf5BBAY4bgy9empo41G6mVKi0xRCNvy9YeogYVd6nkW+qW0sFeDlcJKnikzbyofUY62CwCBUmEQ9ZThpvKuSm6DiVQnD+aLZ21OV8yiAPciV0zWWZ3PKb0qBxeoSlrLQg1cVPCbxTkSTDa5Szh9gM/lgKrbe+DBcL+qsEGiQd7LzlAG2hWEhMAWGEBK2itsorFN6j0igP4IqXa1KeiE+ivtpM7xoXV2OYf6OcSqm/fL2IaVBvfgDm+s5uX6FwCmFHyBPq7nYcVLz8rB7ErWF1AK5oU4+HGGZVb1+wBGuxO+0STQJdmvJKPKZuri8MQt1gUIpXJxzT1CPPBRAfMbtMF3VF40V31o1cqooUX6C/VYqQpjmEkWAtoj2CA/qaoGVx0FqZLMHYGSFpMORXkUTonAmH0HzwztPMZoPcNScP3JYZSoKHSFV7AOwAcImp5JkUc2+AYYvEspvCasjukpHpOpsYYGEFTxiQo8mUaUXsx7ftG8ZK4RdiihMrqEk3ZW0MtYiiFnf6a/sRNRl6yL0YtsNftjsIN8lVwJ8I8X7aaDKdHqd+MPAXzNvlfMVTe3VVKICncWtrf0Bi9JYBJzPgy4HGqVQvaTlIqFtIV1mXIEBiX6yzjMipB8xBQg2UQWBVfJuBUrsFljofGmo4M6SUGeGyLuyAa4qL7UPhs3WMh3XYxAXzjrW8z0PiSao36YgqQuFCJuElHW5B1jpqjJy2jmzSAF0iaL193hTudbieAhHov4zwWoYBocDqgzqZOgQlQyLbVllpWBwcdxX1dRzD+jV19NozGxoFcRItYY+s4Kw3t98njrvMoXyqf5UvLc0cBoAezti17enFLpbwPdvXjvble1g0uDvTwgzJHwH0xdRkgyUTL3hbYbym14TYVQCthdYTmzPhjIPVcgKkkVarsz5DlgWo0aIqZcE9oH3nCrPOksTz9p1sgJ+sSG2DaBrsKbQhl0AM8q7bzXUxQwjYtiX1lpL6vhen7Sq8oPUwpzUqoCXKWftAS32qMip+Hqt5L1kCmvmR+XebQcc40W28tkPYS9IiieHk/U3lYlZhH/S9y8wyT+KSVKbOOBqJJraskPCAPBgf+eTa/9uQcuwRS0Ryr9JW6hc/7FVBdFDYbJIea7tAA1qz6JJWf6ClV8fX331Mrc6X7GbvbDumxytqIgJXyIRpO1No5FAFzAPayOwBLW7rsLDqS0yCjRdOi5XBh6MtWvfOobq2me7tXygN3tPcanijovkIua5e8EjbwUQdUt+V8S5M5YZs/kr4WxAXmUVTepj8JH5M6rS24GgybdfU7cUSq4+sW63Ar9fzdLS7pTiSgd3FXLyGokt6CH7alcUJ+z9BFJE29ysFA5FmqZ/GoWITEEU3mT9ta27d1nYsgGWPphXZy1L4gMLfYoiMcWuzpArK8X5uyLadRse/fi1jZbDkZ7ikFL0Yrwt0NX83GCnLVcS74GZAdyszcQsPv6vro/OaanqSZ/uDo+Lezm9PTN8+Dh5FRiYObig6udAaix3ihtyJ1k8D5461JNAuwAYSCU/xlF5qv8cKmb3RCNHv4gO3bElYO7h41NaPZP9jbEQr2+cF4L1nln42p4xzspIII6K/hbaCzzL1dYZ4TE5noeODrsABQ0HHVbxTv/xES1ZLzwnK7I2SW+kdW8SZTvYnUVmJQKqOyP6XLZXFvNQQeytPO9tXJT9fHl79uYiTnvBAMcZrnn9bFcTcz3ilDgZP6dowEHo8sra1aEG/hTnbioPGlIvVTkZb9lv5XZ30DLX45OT3dvjvfSI+dNOktf3MykgutHCTCw3JdbBRHXhGOhkF1bb5RoGjqLtQoToiJWBi0HscIx5GJjSbqbx8v+uO36gvJ/osSouLY6ovaexK0oeENBm9T8x36wHIKLAG8pPS3rGtbG8Wl6EyRUnwiEgUkssqebZQDek5C65xU69WKlc99b0dmHLBL865zYCmlYBEdVMsdGuNeY0LRtfqJyNAHX9Kv+3rXWL/yWthk1Kt+nwNhosoOxSbPbLgZCfkZ+82s5GRsCjt/Qq8GjefuE3Ky5ASMJ8N9k3Ls+JJCVrLb5gTl7Ut5OlE5vX7gxs2P6L+W2D/JKBkFajh8pgzHb8eHek5DtY+oghFVlgDtt1m9DdVSNvUmBWiLQAoWsLFoBtJQDna7wp0IOJAs1dQ32vQwARxorrFwNfiGr42wyW3Wqi9DvRQz2DZW1iSGTXWiUxPkdfP1EENmgCmDIyMTlj2DGow+QWxvYEu7cGxSTIRRgonB0xILMUaRFir0sbf6hXpwfycOptJ0mlLcoTe0xcg6RKDF16KtftiWUTSFk5KwVlyH9rq8ioxKO6smsILeWF8bioLaIu15RUowt7SFbm38UFXwq5tT9H3ToVG+VgFXLQK3pnC8YC240rc0ZFzoX4Uxmrj2EVzikq+rjUo/wrVBGi012WDTtVPKcssjST4KfWUJJ2AJmMOgQ1FZPhrsiCdaU9o7StdkgBvRSdIsrR76krPhUWB9djdr6rx5sN1iC25UVadhW4AabB+/Swaa03x7L/mKW7oaupD7XgHmJwqgUr+mMzQ0DBbmxw8np8dHO0dxUepYYO1BNhj0t2hj6/XVis2Qibc70WT3p1JvrykICF/ueSOzMlsKUXWH9CJjeYdRtion2H+kujpc8VWIrWyy0f0zzzDzhMf3el/TEd/gELHf145iUaeM2oOxm65A9yiHemPT+jfHgjZ5UGJ6q6PZqsR9dHoUXKR70cGxoC4PlQQu75d5aJnf949Pd1GgfHoB+50k6ZMopitLZtr1E9khcivw31VsvoQzJWIIx8LWT2U1GRmbVUGRV+mTNehij2VxTKqRL9AUJ4gz0QWhhJfoyavQmsuaRcmlwVK9LOA1VCssrfMnLH/bnV7rN5z43bUzzQ78qSPEzRbJ/OGiB6/NrJibH2jonFy7628kNXRIuLeU5Lkb/Hn2UhU9W7lt28Brx8BLlEwhouI7B4KLgINA/DCLVfe7feUXuOx/S4uPiCKOAcbCbE7z6OQiODr+eArLPaKMzh/dZbRn1elII+y7XNTmQXX194f4soL87sNmnC+fYzRhHv/94vzyuvfxqqGhfY/hSyaSZYUoQIPXVGzB4mv7dYZBl2YgGvQ9CEG4jVzZjx+uD3/GNtHrm6uDTo5V9x7M37Oj87+dnZ5/OMJBAlbXqVCfP8iLIH/MrE4BSpoR2D5nr6M9xChbqI6z7pfGvseYXDL2QS8R2Q9ZolXcfsIMvRITRYRSZRglCo8DhQYGLtNMa51E/weiYXnaHvP3IrdGfQhIb+wqX8W7uFxm3FutC5RBxY+vUPQTPtfYKWNXBXjvVmj+7nSPBWjJP5uCJFSSstGIYKExwDUou7N11CtIyWSHRozdeR8ZVncogcKJu9yNUYohDtaMqtzlvy5kA0mTjj2/UOWoY+IfORL46gcDsx/C5MnwYV9q0+bDFivQ1Fbz5ZSyon4z9Y1A+0N5T1WNC3pixVxk4dEvCYI4j4JgoL2JPmjA5CuW+f49Rif3lJFoEq7k9oDTAtGh8sN2vAx78j6NXx6Da/0ToGUS+OXpOwddJOfJsfQPjq7a04l0QhTsJLpDdBAXRGH9tHEGt5sAgV9G3rOUYCHOTllIITSj3nxqLzYOL26oH5w+/0BFedmMgB+k1HoMAStbLHCju1A1SbZDhmJ8py+yKWQL0ZEljA58pPtBhzd1vbS9C1jImOAumFH8wnC+p5pEMog+9EJuoEoOaR313S9ICFAD8T0ePI7dgKZTFfTLpux5hYZrQxeag5ePxFcs4QjGODnqHgynhbQ8/vpxQZH0aV1fiSmWlGBLq3zJe6Wl/81KSUd4W3lUbRD/78sjpGa37kVrGrFLQByc1RLZ2/oqSC3Kqpwk4tct7sDhLz9dnt+cHQUXJ6Srdai/Z5c3Z4G43wD+PTs9/wnvABNsVJ1bvyH428/HZ8HHk7OTq5+FFdi2sG5EtUNMZbdpEmX1sv0yVPNVWEvyG1webAYs1tYPndqfR4E4RAq6E5TZJyTsrk+i0qHSZvi+ra4Ccsnl69vCIFlp3Z2OFSyIEoHYg6nHFIf8AK5VSBFjOmGa9SEx7ATntuQXrtBfyXI63EMPT88PfwmO/278p/777EeNyNRbBLOLJiOr10ykHTxtChHYMYQNPnvtMUrpBVrfrzNMBPVWmeWZsBUakG0nzbTHm2TqItDxTLpa8hf+HOasjE/UC5Z5rX3zuPFwfmiTl0mOnc/66UjpKYl/rK7fJHyZ18eenF33h24kkwT5bZW1HfyZVI6E8Y3JnBfSM/hnSagyFdkczqCAfaB/R2772Zhdn4UjvkWHYtmjxCsUb34HJz+dDd70pqD/Cy/KJcq830YndoqdduK0DOX1ggC90iCQzpPgtqtn4KUV6iFL+KyDvf8CntFzGwNcAAA=')).decode('utf-8'),
             '<sealed original confirmation support>', 'exec'), support.__dict__)
support.FOLLOWUP_ROOT = Path('/mnt/workspace/v3_norm_mechanism_20261020')
read, save, sha = support.read, support.save, support.sha
CID = support.CANDIDATE
SOURCE_ROOT = support.SOURCE_ROOT
VARIANTS = ['archived_original', 'rebuilt_control', 'aligned_tail_diagnostic']
LENGTHS = [512, 4096, 4097, 24577, 28673, 32768, 32769]
TARGET_PARTIALS = [1, 1, 2, 7, 8, 8, 9]
KERNEL = 'csrc/ops/foreach_norm/op_kernel/foreach_norm_kernel.cpp'
OLD = '''        auto tail = inLocal[numPartials];
        AscendC::Duplicate(tail, ident, static_cast<int32_t>(padded - numPartials));'''
NEW = '''        // Diagnostic only: same padding elements, aligned UB base and bit mask.
        const int64_t alignedBase = (numPartials / 8) * 8;
        uint64_t tailMask[1] = {uint64_t(0xff) & (uint64_t(0xff) << (numPartials - alignedBase))};
        AscendC::Duplicate(inLocal[alignedBase], ident, tailMask, 1, 1, 8);'''
QUERY_CPP = r'''
#include <cstdint>
#include <tuple>
#include <dlfcn.h>
std::tuple<int64_t,int64_t,int64_t> calc_foreach_norm_tiling_params(int64_t);
extern "C" int query_norm_tiling(int64_t length, int64_t* out) {
    try {
        auto t = calc_foreach_norm_tiling_params(length);
        out[0]=std::get<0>(t); out[1]=std::get<1>(t); out[2]=std::get<2>(t);
        return 0;
    } catch (...) { return 1; }
}
extern "C" const char* query_bound_extension() {
    Dl_info info;
    if (!dladdr(reinterpret_cast<void*>(&calc_foreach_norm_tiling_params), &info)) return nullptr;
    return info.dli_fname;
}
'''


def source_files():
    prefix = f'harness/projects/{CID}/'
    return {name.removeprefix(prefix): row['sha256']
            for name, row in read(SOURCE_ROOT / 'PACKAGE_MANIFEST.json').items() if name.startswith(prefix)}


def verify_original_files():
    result = support.check_sources()
    files = source_files()
    if KERNEL not in files or not all(rel in files for rel in ['build.sh', 'setup.py', 'CMakeLists.txt',
                                                            'csrc/CMakeLists.txt', 'csrc/ops/CMakeLists.txt']):
        raise ValueError('Original isolated project scaffold is incomplete')
    project = SOURCE_ROOT / 'harness/projects' / CID
    for relative, expected in files.items():
        path = (project / relative).resolve()
        if not path.is_relative_to(project.resolve()) or not path.is_file() or sha(path) != expected:
            raise ValueError('Original source changed: ' + relative)
    if (project / KERNEL).read_text(encoding='utf-8').count(OLD) != 1:
        raise ValueError('Diagnostic target differs; do not patch an unreviewed location')
    return result


def protocol():
    return {'stage': 'ForeachNorm_mechanism_diagnostic', 'parent_candidate': CID,
            'original_D_run': support.SOURCE_RUN, 'script_sha256': sha(SCRIPT),
            'variants_in_order': VARIANTS, 'lengths': LENGTHS, 'expected_actual_partial_counts': TARGET_PARTIALS,
            'tensor_list_length': 8, 'dtype': 'bfloat16', 'norm_p': 2.0,
            'source_capture_sha256': support.EXPECTED_CAPTURE_SHA,
            'input_construction': '512 uses exact saved input; other lengths repeat/truncate each saved row; no RNG',
            'independent_process_per_variant_length': True, 'calls_per_point': 1,
            'expected_points': 21, 'tolerance': {'atol': 1e-5, 'rtol': .016},
            'tiling_observation': 'tiny host-only library calls the current installed binary actual calc_foreach_norm_tiling_params; dladdr checks binding; not a formula-only estimate',
            'diagnostic_change': {'file': KERNEL, 'before': OLD, 'after': NEW,
                                  'effect': 'replace unaligned tail-start vector fill with aligned-base masked vector fill of exactly the same padding elements',
                                  'not_changed': ['p-norm arithmetic', 'tiling function', 'buffers', 'explicit synchronization statements', 'dtype', 'tolerance', 'other source files']},
            'role': 'explicit human diagnostic modification, separate from unchanged model-generated candidate; never added to V3 or formal candidate ranking',
            'failure_policy': 'record original/control/diagnostic candidate failures; fresh device health after each; controls/identity/build/tiling failures stop for review; restore initial package',
            'limits': 'No quality dataset, model run, timing claim, FP16 sweep, extra candidates or retries until a desired pattern appears.'}


def initialize(c):
    helper = support.modules()
    helper.initialize({k: v for k, v in c.items() if k not in ('candidate', 'receipt')})
    return helper


def verify_variant(c):
    import cann_bench
    if c['variant'] == 'archived_original':
        from common import verify_loaded
        identity = verify_loaded(CID, 'foreach_norm', c['receipt'])
        return dict(identity, variant='archived_original', diagnostic_only=False)
    r = read(c['variant_receipt'])
    if r['variant'] != c['variant'] or r['parent_candidate'] != CID or not r['diagnostic_only']:
        raise ValueError('Wrong diagnostic receipt')
    manifest = read(r['source_manifest'])
    if sha(r['source_manifest']) != r['source_manifest_sha256']:
        raise ValueError('Diagnostic source manifest changed')
    for name, expected in manifest['source_files_before_build'].items():
        if sha(Path(r['project']) / name) != expected:
            raise ValueError('Diagnostic source changed: ' + name)
    for path, expected in [(r['wheel'], r['wheel_sha256']), (cann_bench._C.__file__, r['binary_sha256']),
                           (cann_bench.__file__, r['wrapper_sha256'])]:
        if sha(path) != expected:
            raise ValueError('Diagnostic loaded artifact differs: ' + str(path))
    return {'variant': r['variant'], 'diagnostic_only': True, 'parent_candidate': CID,
            'receipt_sha256': sha(c['variant_receipt']), 'source_manifest_sha256': r['source_manifest_sha256'],
            'binary_sha256': r['binary_sha256'], 'wrapper_sha256': r['wrapper_sha256'],
            'binary': str(Path(cann_bench._C.__file__).resolve())}


def prepare_project(c):
    verify_original_files()
    variant = c['variant']
    if variant not in VARIANTS[1:]:
        raise ValueError(variant)
    output = Path(c['output'])
    output.mkdir(parents=True, exist_ok=False)
    project = Path(c['batch_root']) / 'projects' / variant
    project.mkdir(parents=True, exist_ok=False)
    before = source_files()
    original_project = SOURCE_ROOT / 'harness/projects' / CID
    for name in before:
        destination = project / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(original_project / name, destination)
    path = project / KERNEL
    if variant == 'aligned_tail_diagnostic':
        old = path.read_text(encoding='utf-8')
        if old.count(OLD) != 1:
            raise ValueError('Patch target changed')
        path.write_text(old.replace(OLD, NEW), encoding='utf-8', newline='\n')
        (output / 'diagnostic.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), path.read_text(encoding='utf-8').splitlines(True),
                                                    fromfile='original/' + KERNEL, tofile=variant + '/' + KERNEL)), encoding='utf-8')
    after = {name: sha(project / name) for name in before}
    changed = [name for name in before if before[name] != after[name]]
    expected = [KERNEL] if variant == 'aligned_tail_diagnostic' else []
    if changed != expected:
        raise ValueError('Unexpected source differences: ' + str(changed))
    source_manifest = output / 'source_manifest.json'
    save(source_manifest, {'variant': variant, 'parent_candidate': CID, 'diagnostic_only': True,
                          'original_source_hashes': before, 'source_files_before_build': after,
                          'changed_files': changed, 'project': str(project)})
    command = ['bash', 'build.sh', '--soc=ascend910b']
    save(output / 'build_request.json', {'command': command, 'cwd': str(project), 'variant': variant,
                                       'no_install_by_build_command': True})
    with (output / 'build.log').open('x', encoding='utf-8') as stream:
        subprocess.run(command, cwd=project, stdout=stream, stderr=subprocess.STDOUT, check=True)
    if any(sha(project / name) != expected for name, expected in after.items()):
        raise ValueError('Build modified an input source file')
    wheels = list((project / 'dist').glob('cann_bench-*.whl'))
    if len(wheels) != 1:
        raise ValueError('Expected one isolated diagnostic wheel')
    archive = output / 'wheels' / wheels[0].name
    archive.parent.mkdir()
    shutil.copyfile(wheels[0], archive)
    with zipfile.ZipFile(archive) as z:
        names = [n for n in z.namelist() if n.startswith('cann_bench/_C') and n.endswith('.so')]
        if len(names) != 1:
            raise ValueError('Unexpected diagnostic wheel layout')
        binary_sha = hashlib.sha256(z.read(names[0])).hexdigest()
        wrapper_sha = hashlib.sha256(z.read('cann_bench/__init__.py')).hexdigest()
    if wrapper_sha != sha(project / 'cann_bench/__init__.py'):
        raise ValueError('Diagnostic wheel wrapper differs')
    save(output / 'receipt.json', {'variant': variant, 'parent_candidate': CID, 'diagnostic_only': True,
                                  'soc': 'ascend910b', 'project': str(project),
                                  'source_manifest': str(source_manifest), 'source_manifest_sha256': sha(source_manifest),
                                  'wheel': str(archive), 'wheel_sha256': sha(archive),
                                  'binary_sha256': binary_sha, 'wrapper_sha256': wrapper_sha})


def compile_query(c):
    initialize(c)
    import cann_bench
    from common import verify_loaded
    verify_loaded(CID, 'foreach_norm', c['receipt'])
    out = Path(c['output'])
    out.mkdir(parents=True, exist_ok=False)
    source = out / 'tiling_query.cpp'
    source.write_text(QUERY_CPP, encoding='utf-8')
    binary = Path(cann_bench._C.__file__).resolve()
    library = out / 'tiling_query.so'
    command = ['g++', '-std=c++17', '-O2', '-fPIC', '-shared', str(source), str(binary),
               '-Wl,-rpath,' + str(binary.parent), '-ldl', '-o', str(library)]
    with (out / 'build.log').open('x', encoding='utf-8') as stream:
        subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True)
    save(out / 'query_receipt.json', {'source_sha256': sha(source), 'library': str(library),
                                    'library_sha256': sha(library), 'linked_extension_path': str(binary),
                                    'command': command, 'purpose': 'host-only query of actual installed candidate tiling function'})


def query_tiling(c, length, identity):
    q = read(c['query_receipt'])
    if q['source_sha256'] != hashlib.sha256(QUERY_CPP.encode()).hexdigest() or sha(q['library']) != q['library_sha256']:
        raise ValueError('Tiling query source/binary differs')
    lib = ctypes.CDLL(q['library'])
    lib.query_bound_extension.argtypes = []
    lib.query_bound_extension.restype = ctypes.c_char_p
    bound = lib.query_bound_extension()
    if not bound or Path(os.fsdecode(bound)).resolve() != Path(identity['binary']).resolve():
        raise ValueError('Tiling query bound to a different library; do not report calculated estimates as observations')
    lib.query_norm_tiling.argtypes = [ctypes.c_int64, ctypes.POINTER(ctypes.c_int64)]
    lib.query_norm_tiling.restype = ctypes.c_int
    result = (ctypes.c_int64 * 3)()
    if lib.query_norm_tiling(length, result) != 0:
        raise ValueError('Actual binary tiling query failed')
    blocks, block_len, tile = map(int, result)
    if min(blocks, block_len, tile) <= 0:
        raise ValueError('Invalid actual tiling result')
    return {'source': 'actual current binary host function', 'num_partials': blocks,
            'block_length': block_len, 'tile_elems': tile, 'tail_padding_branch': blocks % 8 != 0,
            'original_tail_start_offset_mod32': (blocks * 4) % 32, 'bound_binary': str(Path(os.fsdecode(bound)).resolve())}


def make_input(torch, original, length):
    if length == 512:
        return original
    return original.repeat(1, (length + original.shape[1] - 1) // original.shape[1])[:, :length].contiguous()


def scan_probe(c):
    out = Path(c['output'])
    out.mkdir(parents=True, exist_ok=False)
    r = {'variant': c['variant'], 'length': c['length'], 'pid': os.getpid(), 'status': 'initializing',
         'phase': 'identity_and_controls', 'candidate_call_attempted': False}
    def checkpoint():
        save(out / 'result.json', r)
    checkpoint()
    try:
        verify_original_files()
        initialize(c)
        import torch
        import cann_bench
        from completion_utils import metrics, TOL
        from clip_adapter import rowwise_foreach_norm
        from host import record_device_status
        from transformers.models.clip.modeling_clip import _get_vector_norm
        identity = verify_variant(c)
        r.update(identity=identity, device_before=support.device_health(c), tolerance=TOL)
        record_device_status(out)
        tiling = query_tiling(c, c['length'], identity)
        if tiling['num_partials'] != c['expected_partials']:
            raise ValueError('Actual partial count differs from predeclared target')
        r['tiling'] = tiling
        original = torch.load(Path(c['captures']) / '0000.pt', weights_only=True, map_location='cpu')
        cpu = make_input(torch, original['input'], c['length'])
        r['input'] = {'shape': list(cpu.shape), 'dtype': str(cpu.dtype), 'row_stride': cpu.stride(0),
                      'value_sha256': hashlib.sha256(cpu.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest(),
                      'original_capture_sha256': support.EXPECTED_CAPTURE_SHA,
                      'exact_original_capture': c['length'] == 512,
                      'role': 'original real input' if c['length'] == 512 else 'derived diagnostic input; not a full-model workload'}
        with torch.inference_mode():
            x = cpu.to(f'npu:{c["device"]}')
            native = _get_vector_norm(x)
            if c['length'] == 512:
                r['saved_reference_control'] = metrics(native, original['reference'])
                if not r['saved_reference_control']['exact_equal']:
                    raise ValueError('Original-length native result differs from saved reference')
            a = native.cpu()
            if not bool(torch.isfinite(a).all()):
                raise ValueError('Native reference nonfinite')
            ref = torch.linalg.vector_norm(cpu.double(), ord=2, dim=1, keepdim=True)
            diff = (a.double() - ref).abs()
            r['native_control'] = {'finite': True, 'max_abs_vs_CPU_FP64': float(diff.max()),
                                   'max_relative_vs_CPU_FP64': float((diff / ref.abs().clamp_min(1e-30)).max())}
            if not bool(torch.allclose(a.double(), ref, atol=TOL['atol'], rtol=TOL['rtol'])):
                raise ValueError('Native result differs from CPU FP64 reference beyond fixed tolerance')
            r.update(phase='candidate_call_and_output_checks', candidate_call_attempted=True, candidate_invocations=1)
            checkpoint()
            print('MECHANISM_CALL_START', c['variant'], c['length'], 'pid=', os.getpid(), flush=True)
            actual = rowwise_foreach_norm(x, cann_bench.foreach_norm)
            if actual.device != x.device:
                raise ValueError('Off-device candidate output')
            r['local_check'] = metrics(actual, native)
            r['normalized_features_check'] = metrics(x / actual, x / native)
            r['cpu_fp64_diagnostic_max_abs'] = float((actual.cpu().double() - ref).abs().max())
            torch.npu.synchronize()
            r['status'] = ('success_within_fixed_tolerance' if r['local_check']['passed'] and r['normalized_features_check']['passed']
                           else 'numerical_check_failed')
            r['phase'] = 'completed'
            checkpoint()
        return 0
    except Exception as error:
        r.update(status='candidate_execution_failed' if r['candidate_call_attempted'] else 'control_or_environment_failed',
                 error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
        checkpoint()
        print(r['traceback'], flush=True)
        return 0 if r['candidate_call_attempted'] else 2


def worker(action, request):
    c = read(request)
    if sha(SCRIPT) != c['script_sha256']:
        raise ValueError('Mechanism script changed during batch')
    if action == 'scan':
        return scan_probe(c)
    if action == 'prepare_build':
        initialize(c)
        prepare_project(c)
    elif action == 'compile_query':
        compile_query(c)
    elif action == 'install_variant':
        initialize(c)
        r = read(c['variant_receipt'])
        if sha(r['wheel']) != r['wheel_sha256'] or sha(r['source_manifest']) != r['source_manifest_sha256']:
            raise ValueError('Diagnostic artifact changed before install')
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--force-reinstall', '--no-deps', r['wheel']], check=True)
        save(Path(c['output']) / 'installed.json', {'variant': c['variant'], 'wheel_sha256': r['wheel_sha256']})
    elif action == 'tiling_control':
        initialize(c)
        identity = verify_variant(c)
        rows = [dict(length=n, **query_tiling(c, n, identity)) for n in LENGTHS]
        if [r['num_partials'] for r in rows] != TARGET_PARTIALS:
            raise ValueError('Actual tiling targets not realized; stop before classifying this scan')
        save(Path(c['output']) / 'tiling_control.json', rows)
    else:
        return support.worker(action, request)
    return 0


def analyze(records):
    matrix = []
    for n in LENGTHS:
        by_variant = {r['variant']: r for r in records if r['length'] == n}
        row = {'length': n, 'variants': {k: v['status'] for k, v in by_variant.items()}}
        if len(by_variant) == 3:
            values = list(by_variant.values())
            row['same_input_values'] = len({r['input']['value_sha256'] for r in values}) == 1
            row['same_actual_partial_count'] = len({r['tiling']['num_partials'] for r in values}) == 1
            if not row['same_input_values'] or not row['same_actual_partial_count']:
                raise ValueError('Cross-variant input or tiling mismatch')
            row['actual_num_partials'] = values[0]['tiling']['num_partials']
            row['tail_padding_branch'] = values[0]['tiling']['tail_padding_branch']
        matrix.append(row)
    complete = len(records) == 21 and all(len(row['variants']) == 3 for row in matrix)
    def expected_pattern(variant):
        rows = [r for r in records if r['variant'] == variant]
        return len(rows) == len(LENGTHS) and all(
            (r['status'] == 'candidate_execution_failed' and r.get('exact_alignment_signature_in_log'))
            if r['tiling']['tail_padding_branch'] else r['status'] == 'success_within_fixed_tolerance' for r in rows)
    original_pattern = expected_pattern('archived_original')
    control_pattern = expected_pattern('rebuilt_control')
    patched = [r for r in records if r['variant'] == 'aligned_tail_diagnostic']
    patched_pass = len(patched) == len(LENGTHS) and all(r['status'] == 'success_within_fixed_tolerance' for r in patched)
    conclusion = ('controlled_scan_supports_tail_alignment_mechanism_in_tested_conditions'
                  if complete and original_pattern and control_pattern and patched_pass
                  else 'inspect_recorded_outcomes_do_not_force_alignment_explanation')
    return {'expected_points': 21, 'recorded_points': len(records), 'complete': complete,
            'matrix': matrix, 'archived_pattern_matches_branch_hypothesis': original_pattern,
            'source_identical_rebuild_pattern_matches': control_pattern, 'diagnostic_all_numerical_checks_passed': patched_pass,
            'conclusion': conclusion, 'scope': 'single candidate, derived BF16 lengths, p=2, TensorList length 8; diagnostic modification is not a formal generated candidate',
            'records': records}


class Runner(support.Runner):
    def __init__(self, run_id, upload):
        super().__init__(run_id, upload)
        self.state['stage'] = 'ForeachNorm_mechanism_diagnostic'
        save(self.out / 'protocol.json', protocol())
        self.persist()

    def summary(self):
        records = []
        for variant in VARIANTS:
            for n in LENGTHS:
                name = f'scan_{variant}_n{n}'
                path = self.out / name / 'result.json'
                if path.is_file():
                    r = read(path)
                    log = self.out / 'logs' / (name + '.log')
                    text = log.read_text(encoding='utf-8', errors='replace') if log.is_file() else ''
                    r['exact_alignment_signature_in_log'] = 'The UB address accessed by the VEC instruction is not aligned' in text
                    records.append(r)
        # During an interrupted control check a partial result may lack input/tiling.
        usable = [r for r in records if 'input' in r and 'tiling' in r]
        result = analyze(usable)
        result['all_partial_records'] = records
        save(self.out / 'mechanism_summary.json', result)

    def execute(self):
        self.task('preflight', 'preflight')
        self.task('backup', 'backup')
        self.state['restoration'] = 'required'
        self.persist()
        self.task('install_archived_original', 'install')
        query = self.task('compile_host_tiling_query', 'compile_query') / 'query_receipt.json'
        self.task('verify_actual_tiling', 'tiling_control', variant='archived_original', query_receipt=str(query))
        seen = set()
        for variant in VARIANTS:
            extra = {}
            if variant != 'archived_original':
                built = self.task('build_' + variant, 'prepare_build', variant=variant)
                extra['variant_receipt'] = str(built / 'receipt.json')
                self.task('install_' + variant, 'install_variant', variant=variant, **extra)
            for n, partials in zip(LENGTHS, TARGET_PARTIALS):
                name = f'scan_{variant}_n{n}'
                out = self.task(name, 'scan', variant=variant, length=n, expected_partials=partials,
                                query_receipt=str(query), **extra)
                r = read(out / 'result.json')
                if r['pid'] in seen:
                    raise ValueError('Probe PID reused')
                seen.add(r['pid'])
                print('SCAN_RESULT', variant, n, r['status'], flush=True)
                self.summary()
                self.task('health_after_' + name, 'health')
        self.state['status'] = 'completed_with_records'

    def finish(self):
        try:
            if self.state['restoration'] == 'required':
                self.task('restore', 'restore')
                self.state['restoration'] = 'verified'
        except BaseException as error:
            self.state.update(status='stopped_requires_review', restoration='FAILED_requires_review', restore_error=repr(error))
        try:
            self.summary()
        except Exception as error:
            self.state.update(status='stopped_requires_review', summary_error=repr(error))
        self.state['finished_utc'] = support.datetime.datetime.now(support.datetime.timezone.utc).isoformat()
        self.persist()
        members = {'provenance/run_norm_mechanism.py': SCRIPT}
        for name in support.PINNED:
            p = SOURCE_ROOT / name
            if p.is_file():
                members['provenance/original_D/' + name] = p
        for p in self.out.rglob('*'):
            relative = p.relative_to(self.out).as_posix()
            if p.is_file() and not relative.startswith('projects/') and p.suffix in ('.json', '.log', '.txt', '.md', '.patch', '.cpp'):
                members['batch/' + relative] = p
        for variant in VARIANTS[1:]:
            p = self.out / ('build_' + variant) / 'source_manifest.json'
            if p.is_file():
                data = read(p)
                for name in data['source_files_before_build']:
                    source = Path(data['project']) / name
                    if source.is_file():
                        members['diagnostic_sources/' + variant + '/' + name] = source
        target = self.upload / (self.state['run_id'] + '_results.zip')
        part = target.with_suffix('.zip.part')
        with zipfile.ZipFile(part, 'x', zipfile.ZIP_DEFLATED) as z:
            for name, p in members.items():
                z.write(p, name)
            z.writestr('EXPORT_MANIFEST.json', json.dumps({name: sha(p) for name, p in members.items()}, indent=2))
        part.rename(target)
        print('BATCH_STATUS:', self.state['status'], '\nDOWNLOAD:', target, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--foreground', action='store_true')
    parser.add_argument('--run-id')
    parser.add_argument('--stop', action='store_true')
    parser.add_argument('--worker')
    parser.add_argument('--request')
    args = parser.parse_args()
    if sys.platform != 'linux':
        raise RuntimeError('Use original CANNLab NPU environment; local CPU cannot run this diagnosis')
    if args.worker:
        return worker(args.worker, args.request)
    upload = SCRIPT.parent
    if args.stop:
        # Reuse exact command/PID ownership checks, with this diagnostic prefix.
        stopped = 0
        for p in upload.glob('Norm_mechanism_*.pid.json'):
            row = read(p)
            cmd = Path('/proc') / str(row['pid']) / 'cmdline'
            if row.get('stop_requested') or not cmd.is_file():
                continue
            argv = cmd.read_bytes().split(b'\0')
            if str(SCRIPT).encode() in argv and row['run_id'].encode() in argv:
                os.kill(row['pid'], signal.SIGTERM)
                row['stop_requested'] = True
                save(p, row)
                stopped += 1
        print('STOP_REQUESTED:', stopped, '; wait for rollback/export.')
        return 0
    run_id = args.run_id or 'Norm_mechanism_' + support.stamp() + '_' + str(os.getpid())
    if Path(run_id).name != run_id or not run_id.startswith('Norm_mechanism_'):
        raise ValueError('Unsafe diagnostic run ID')
    if not args.foreground:
        verify_original_files()
        log = upload / (run_id + '.console.log')
        with log.open('x', encoding='utf-8') as stream:
            child = subprocess.Popen([sys.executable, '-u', str(SCRIPT), '--foreground', '--run-id', run_id],
                                     stdout=stream, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                     start_new_session=True, cwd=SOURCE_ROOT)
        save(upload / (run_id + '.pid.json'), {'pid': child.pid, 'run_id': run_id, 'script': str(SCRIPT)})
        print('BACKGROUND_PID:', child.pid, '\nRUN_ID:', run_id, '\nLOG:', log,
              '\nDOWNLOAD_WHEN_FINISHED:', upload / (run_id + '_results.zip'))
        return 0
    import fcntl
    with support.ExitStack() as stack:
        for p in (Path('/mnt/workspace/.v3_transfer.lock'), Path('/mnt/workspace/v3_model_transfer/.transfer_batch.lock')):
            if p.parent.exists():
                stream = stack.enter_context(p.open('a'))
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        runner = Runner(run_id, upload)
        interrupted = False
        def stop(*unused):
            nonlocal interrupted
            if not interrupted:
                interrupted = True
                raise KeyboardInterrupt('Stop requested; restore follows')
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        try:
            runner.execute()
        except BaseException as error:
            runner.state.update(status='stopped_requires_review', error=repr(error))
            (runner.out / 'exception.txt').write_text(traceback.format_exc(), encoding='utf-8')
        finally:
            signal.signal(signal.SIGTERM, signal.SIG_IGN)
            signal.signal(signal.SIGINT, signal.SIG_IGN)
            runner.finish()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
