"""Fresh-process stage A experiments / stage B preflight, never CPU fallback."""
from contextlib import nullcontext
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'harness'))
from run_cloud import read,save,sha
from cloud_helpers import (bootstrap,initialize,candidate,modelpath,backup,restore,patch,Captures,SEED,targets)

def preflight(c):
    p=read(c['plan']);bootstrap(p['stage'])
    import torch,torch_npu,transformers
    from host import environment,record_device_status
    env=environment(c['device']);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False);record_device_status(out)
    if env['torch']!='2.7.1+cpu' or env['torch-npu']!='2.7.1.post4' or transformers.__version__!='4.51.3':
        raise ValueError('Core environment differs from verified cloud baseline; return report, do not upgrade Torch')
    if p['stage']=='A' and env['device']!='Ascend910_9362':raise ValueError('A requires previously verified device class')
    if p['stage']=='A' and (env['numpy']!='1.26.4' or env['Pillow']!='12.2.0'):raise ValueError('A preprocessing/array environment differs from prior validation')
    from transformers.models.clip import modeling_clip
    if p['stage']=='A' and sha(modeling_clip.__file__)!=p['upstream_clip_source_sha256']:raise ValueError('A upstream CLIP implementation differs from verified source')
    if not any('9.1.0' in text for text in env['ascend_version_files'].values()):raise ValueError('CANN 9.1.0 not confirmed')
    import shutil,os
    if any(shutil.which(name) is None for name in ('cmake','g++','bisheng')):raise ValueError('Required CANN compiler tools missing')
    check_env=dict(os.environ,PYTHONPATH=str(HERE/'harness/original_benchmark/src'))
    subprocess.run([sys.executable,'-m','kernel_eval.cli','--help'],cwd=HERE/'harness/original_benchmark',env=check_env,check=True)
    probe=torch.tensor([-3.,-2.,-1.5,-1.,0.,.5,1.,1.5,2.,3.],device=f'npu:{c["device"]}')
    actual=torch.nn.functional.gelu(probe,approximate='none').cpu().double();x=probe.cpu().double()
    tanh=.5*x*(1+torch.tanh((2/torch.pi)**.5*(x+.044715*x**3)))
    erf=.5*x*(1+torch.erf(x/(2**.5)))
    semantics={'max_abs_vs_cpu_tanh':float((actual-tanh).abs().max()),'max_abs_vs_cpu_erf':float((actual-erf).abs().max())}
    save(out/'gelu_semantic_probe.json',semantics)
    if p['stage']=='A' and semantics['max_abs_vs_cpu_tanh']>2e-6:raise ValueError('Prior effective-tanh GELU condition not reproduced')
    checks={}
    for host,desc in p['models'].items():
        root=Path(c['model_root'])/desc['folder'];checks[host]={}
        for name,row in desc['files'].items():
            path=root/name
            if not path.is_file() or path.stat().st_size!=row['bytes'] or sha(path)!=row['sha256']:
                raise ValueError('Model incomplete/mismatched: '+str(path))
            checks[host][name]={'sha256':row['sha256'],'bytes':row['bytes']}
    save(c['runtime'],{'environment':env,'plan_sha256':sha(c['plan']),'model_checks':checks,'gelu_semantic_probe':semantics,'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    save(out/'environment.json',env)

def install(c):
    initialize({k:v for k,v in c.items() if k!='candidate'})
    receipt=read(c['receipt'])
    if sha(receipt['wheel'])!=receipt['wheel_sha256']:raise ValueError('Wheel changed')
    subprocess.run([sys.executable,'-m','pip','install','--force-reinstall','--no-deps',receipt['wheel']],check=True)
    # The build or next worker verifies identity in a genuinely fresh interpreter.
    from common import verify_project
    verify_project(receipt['project'],candidate(c))
    save(Path(c['output'])/'installed.json',{'candidate':c['candidate'],'wheel_sha256':receipt['wheel_sha256']})

def build(c):
    initialize({k:v for k,v in c.items() if k!='candidate'})
    from build_candidate import build as compile_candidate
    compile_candidate(c['candidate'],read(c['plan'])['soc'],Path(c['output']),c['device'])

def benchmark(c):
    initialize(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    root=HERE/'harness/original_benchmark';op=candidate(c)['operator']
    env=dict(__import__('os').environ,PYTHONPATH=str(root/'src'))
    cmd=[sys.executable,'-m','kernel_eval.cli','eval','--bench-name','cann','--task-dir',str(root/'tasks/level1'/op),
         '--device','npu','--device-id',str(c['device']),'--processes-per-card','1','--no-perf','--eval-seed','0','--reports-dir',str(out/'reports')]
    result=subprocess.run(cmd,env=env,cwd=root)
    reports=list((out/'reports').glob('*_eval_*.json'))
    if len(reports)!=1:raise ValueError('Missing/ambiguous precision report')
    report=read(reports[0]);full=report.get('passed_cases')==report.get('total_cases')==20
    save(out/'precision_status.json',{'full_correct':full,'passed':report.get('passed_cases'),'total':report.get('total_cases'),'returncode':result.returncode,
                                     'note':'Precision-only rerun; aggregate score is not a V3 score or a speed result'})

def load_clip(c):
    import torch
    from transformers import CLIPModel,CLIPProcessor
    model=CLIPModel.from_pretrained(modelpath(c),local_files_only=True,torch_dtype=torch.bfloat16,attn_implementation='eager').to(f'npu:{c["device"]}').eval()
    processor=CLIPProcessor.from_pretrained(modelpath(c),local_files_only=True,use_fast=False)
    act='quick_gelu' if c['host']=='quick_clip' else 'gelu'
    if model.config.text_config.hidden_act!=act or model.config.vision_config.hidden_act!=act:raise ValueError('Wrong checkpoint activation')
    return model,processor

def clip_batches(c,processor,probes=False):
    import torch
    from PIL import Image
    root=HERE/'data/coco';rows=[r for r in read(root/'samples.json') if r['split']==c.get('split','dev')]
    if c.get('limit'):rows=rows[:c['limit']]
    batches=[(rows[i:i+8],None) for i in range(0,len(rows),8)]
    if probes:batches=[(rows[:8],None),(rows[8:11],None),(rows[:1],2)]
    for index,(batch,text_limit) in enumerate(batches):
        images=[]
        for r in batch:
            path=root/r['image']
            if sha(path)!=r['image_sha256']:raise ValueError('COCO image changed')
            with Image.open(path) as im:images.append(im.convert('RGB'))
        caps=[(r['image_id'],cap) for r in batch for cap in r['captions']]
        if text_limit:caps=caps[:text_limit]
        inputs=processor(images=images,text=[cap['text'] for _,cap in caps],return_tensors='pt',padding='max_length',max_length=77,truncation=True)
        inp={k:v.to(device=f'npu:{c["device"]}',dtype=torch.bfloat16) if v.is_floating_point() else v.to(f'npu:{c["device"]}') for k,v in inputs.items()}
        yield index,batch,caps,inp

def clip(c):
    import torch
    from completion_utils import metrics,retrieval
    identity=initialize(c);model,processor=load_clip(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    op=candidate(c)['operator'] if identity else c.get('operator',('sigmoid' if c['host']=='quick_clip' else 'gelu'))
    captures=Captures(model,c) if c.get('capture') else None
    baseline=torch.load(Path(c['baseline'])/'features.pt',weights_only=True,map_location='cpu') if c.get('baseline') else None
    image_features=[];text_features=[];ids=[];caption_ids=[];owners=[];drift=[];diagnostics=[];seen=set()
    def observe(name,x,value,old):
        if name in seen:return
        seen.add(name);ref=old(x)
        diagnostics.append({'module':name,'input_shape':list(x.shape),'same_input_native_comparison':metrics(value,ref)})
    stats={}
    try:
        with torch.inference_mode(),patch(model,c,op,observe if c.get('diagnostics') else None) as stats:
            for i,batch,caps,inp in clip_batches(c,processor):
                result=model(**inp)
                image_features.append(result.image_embeds.detach().cpu());text_features.append(result.text_embeds.detach().cpu())
                ids.extend(r['image_id'] for r in batch);caption_ids.extend(cap['id'] for _,cap in caps);owners.extend(owner for owner,_ in caps)
                print('CLIP_BATCH',i+1,'images',len(ids),'texts',len(owners),flush=True)
        features={'image':torch.cat(image_features),'text':torch.cat(text_features),'image_ids':ids,'caption_ids':caption_ids,'owners':owners}
        if baseline:
            if ids!=baseline['image_ids'] or caption_ids!=baseline['caption_ids']:raise ValueError('Control corpus mismatch')
            drift={k:metrics(features[k],baseline[k]) for k in ('image','text')}
            if c['mode']=='wrapper' and not all(r['exact_equal'] for r in drift.values()):raise ValueError('Native wrapper changes final features')
        torch.save(features,out/'features.pt');save(out/'calls.json',stats);save(out/'drift.json',drift);save(out/'diagnostics.json',diagnostics)
        if read(c['plan'])['stage']=='A':
            ranks,summary=retrieval(features['image'].float().numpy(),features['text'].float().numpy(),ids,caption_ids,owners)
            (out/'ranks.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in ranks),encoding='utf-8');save(out/'retrieval.json',summary)
        save(out/'run.json',{'identity':identity,'operator':op,'host':c['host'],'mode':c['mode'],'scope':c.get('scope','both'),'image_count':len(ids),'text_count':len(owners)})
    finally:
        if captures:captures.close()

def load_generation(c):
    import torch
    path=modelpath(c);device=f'npu:{c["device"]}'
    if c['host'].startswith('qwen'):
        from transformers import AutoProcessor,Qwen2_5_VLForConditionalGeneration
        model=Qwen2_5_VLForConditionalGeneration.from_pretrained(path,local_files_only=True,torch_dtype=torch.bfloat16,attn_implementation='eager').to(device).eval()
        processor=AutoProcessor.from_pretrained(path,use_fast=False,local_files_only=True,min_pixels=200704,max_pixels=401408)
        return model,processor
    from transformers import AutoTokenizer
    # Load exactly the reviewed repository's local files; no unpinned downloads.
    import types,importlib
    package=types.ModuleType('pinned_internvl');package.__path__=[str(path)];sys.modules[package.__name__]=package
    config_cls=importlib.import_module(package.__name__+'.configuration_internvl_chat').InternVLChatConfig
    model_cls=importlib.import_module(package.__name__+'.modeling_internvl_chat').InternVLChatModel
    cfg=config_cls.from_dict(read(path/'config.json'))
    model=model_cls.from_pretrained(path,config=cfg,local_files_only=True,torch_dtype=torch.bfloat16,use_flash_attn=False).to(device).eval()
    tokenizer=AutoTokenizer.from_pretrained(path,use_fast=False,local_files_only=True,trust_remote_code=False)
    return model,tokenizer

def generation_input(c,row,processor):
    from PIL import Image
    question=row['question']
    if row.get('choices'):
        question+='\n'+'\n'.join(chr(65+i)+'. '+choice for i,choice in enumerate(row['choices']))+'\nAnswer with one option letter only.'
    else:question+='\nAnswer with a short phrase only.'
    root=HERE/'data'/('docvqa' if c.get('dataset')=='docvqa' else 'ai2d')
    path=root/row['image']
    if sha(path)!=row['image_sha256']:raise ValueError('Input image changed')
    with Image.open(path) as image:im=image.convert('RGB')
    if c['host'].startswith('qwen'):
        messages=[{'role':'user','content':[{'type':'image'},{'type':'text','text':question}]}]
        prompt=processor.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
        value=processor(text=[prompt],images=[im],return_tensors='pt').to(f'npu:{c["device"]}')
        return value,{'input_tokens':int(value['input_ids'].shape[-1]),'image_grid_thw':value['image_grid_thw'].tolist()}
    import torch
    from internvl_preprocess import build_transform,dynamic_preprocess
    config=read(modelpath(c)/'config.json')
    tiles=dynamic_preprocess(im,min_num=config.get('min_dynamic_patch',1),max_num=config.get('max_dynamic_patch',12),image_size=448,use_thumbnail=config.get('use_thumbnail',True))
    pixels=torch.stack([build_transform(448)(tile) for tile in tiles]).to(device=f'npu:{c["device"]}',dtype=torch.bfloat16)
    return (pixels,question),{'tiles':len(tiles),'image_tokens':len(tiles)*256}

def generative(c):
    import torch
    identity=initialize(c);model,processor=load_generation(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    captures=Captures(model,c) if c.get('capture') else None
    datafile=HERE/'data'/('docvqa/dev_preflight.jsonl' if c.get('dataset')=='docvqa' else 'ai2d/samples.jsonl')
    rows=[json.loads(s) for s in datafile.read_text(encoding='utf-8').splitlines() if s.strip()]
    rows=[r for r in rows if r.get('split','dev')==c.get('split','dev')][:c.get('limit',10)]
    op=candidate(c)['operator'] if identity else c.get('operator','swi_glu')
    native=read(Path(c['baseline'])/'predictions.json') if c.get('baseline') else None
    predictions=[];max_tokens=64 if c.get('dataset')=='docvqa' else 16
    generated_lengths=[];original_generate=None
    if c['host']=='internvl':
        original_generate=model.generate
        def record_generation(*args,**kwargs):
            value=original_generate(*args,**kwargs);generated_lengths.append(int(value.shape[-1]));return value
        model.generate=record_generation
    if hasattr(torch.npu,'reset_peak_memory_stats'):torch.npu.reset_peak_memory_stats(c['device'])
    try:
        with torch.inference_mode(),patch(model,c,op) as calls:
            for row in rows:
                inp,info=generation_input(c,row,processor)
                if c['host'].startswith('qwen'):
                    generated=model.generate(**inp,max_new_tokens=max_tokens,do_sample=False,use_cache=True)
                    tokens=generated[:,inp['input_ids'].shape[1]:];text=processor.batch_decode(tokens,skip_special_tokens=True)[0].strip();new_tokens=int(tokens.shape[1])
                else:
                    pixels,question=inp;text=model.chat(processor,pixels,question,{'max_new_tokens':max_tokens,'do_sample':False},num_patches_list=[pixels.shape[0]])
                    new_tokens=generated_lengths[-1]
                    if new_tokens>max_tokens:raise ValueError('Unexpected InternVL returned token prefix; review length accounting')
                torch.npu.synchronize()
                r={'id':row['id'],'group_id':row['group_id'],'text':text,'status':'success','new_tokens':new_tokens,
                   'possibly_at_length_limit':new_tokens>=max_tokens,'input':info}
                if 'answers' in row:r['answers']=row['answers']
                if 'answer' in row:
                    from common import parse_answer
                    r['answer']=row['answer'];r['prediction']=parse_answer(text,len(row['choices']));r['correct']=r['answer']==r['prediction']
                predictions.append(r);save(out/'predictions.json',predictions);print('DEV_SAMPLE',len(predictions),'/',len(rows),flush=True)
        if native and [(r['id'],r['text']) for r in native]!=[(r['id'],r['text']) for r in predictions]:raise ValueError('Wrapper changes native decoded output')
        save(out/'calls.json',calls);save(out/'run.json',{'host':c['host'],'operator':op,'mode':c['mode'],'identity':identity,'max_new_tokens':max_tokens,'formal_eval':False})
        memory={}
        for name in ('memory_allocated','memory_reserved','max_memory_allocated','max_memory_reserved'):
            if hasattr(torch.npu,name):memory[name]=int(getattr(torch.npu,name)(c['device']))
        save(out/'memory.json',{'bytes':memory,'scope':'Generation preflight memory after model load; not a throughput measurement'})
        if c.get('dataset')=='docvqa':
            from docvqa_scoring import score_predictions
            save(out/'dev_scores.json',score_predictions(rows,predictions))
    finally:
        if captures:captures.close()
        if original_generate is not None:model.generate=original_generate

def gate(c):
    import torch,cann_bench
    from completion_utils import metrics,TOL
    identity=initialize(c);row=candidate(c);op=row['operator'];root=Path(c['captures'])
    index=read(root/'index.json');records=index['records']
    if index['host']!=c['host'] or index['mode']!='native' or index['plan_sha256']!=sha(c['plan']) or index['runtime_sha256']!=sha(c['runtime']):
        raise ValueError('Capture host/protocol/runtime does not match request')
    if not records:raise ValueError('No captured real inputs')
    out=Path(c['output']);out.mkdir(parents=True,exist_ok=False);reports=[]
    with torch.inference_mode():
        for r in records:
            path=root/r['file']
            if sha(path)!=r['sha256']:raise ValueError('Capture changed')
            data=torch.load(path,weights_only=True,map_location='cpu');x=data['input'].to(f'npu:{c["device"]}')
            ref=data['reference'];kernel=getattr(cann_bench,op)
            if op=='gelu':native=torch.nn.functional.gelu(x,approximate='none');actual=kernel(x,'tanh')
            elif op=='sigmoid':native=torch.sigmoid(x);actual=kernel(x)
            elif op=='swi_glu':
                a,b=x.chunk(2,dim=-1);native=torch.nn.functional.silu(a)*b;actual=kernel(x,-1)
            else:
                from transformers.models.clip.modeling_clip import _get_vector_norm
                from clip_adapter import rowwise_foreach_norm
                native=_get_vector_norm(x);actual=rowwise_foreach_norm(x,kernel)
            checks=metrics(actual,ref)
            if not metrics(native,ref)['exact_equal']:raise ValueError('Native replay control differs')
            if actual.device!=x.device:raise ValueError('Candidate returned off-device output')
            if op=='sigmoid':
                parent=data['parent_input'].to(x.device);checks['complete_activation']=metrics(parent*actual,data['parent_reference'])
            if op=='foreach_norm':checks['normalized_features']=metrics(x/actual,x/native)
            reports.append({'capture':r,'checks':checks});save(out/'replay.json',reports)
    eligible=all(r['checks']['passed'] and r['checks'].get('complete_activation',{'passed':True})['passed'] and r['checks'].get('normalized_features',{'passed':True})['passed'] for r in reports)
    save(out/'eligibility.json',{'eligible':eligible,'host':c['host'],'candidate':c['candidate'],'operator':op,'tolerance':TOL,
                                'captures':len(records),'identity':identity,'plan_sha256':sha(c['plan']),
                                'GELU_condition':'candidate explicit tanh vs actual host reference; not a universal formula assumption' if op=='gelu' else None})

def clip_timing(c):
    import torch
    from benchmark_npu import timed
    from completion_utils import append,timings_summary
    initialize(c);model,processor=load_clip(c);out=Path(c['output']);out.mkdir(parents=True,exist_ok=False)
    records=[];rng=random.Random(SEED+c['session'])
    with torch.inference_mode():
        for i,batch,caps,inputs in clip_batches(dict(c,split='dev'),processor,probes=True):
            with patch(model,c,'gelu',count=True) as calls:model(**inputs)
            save(out/f'calls_probe_{i}.json',calls)
            for block in range(3):
                order=['native','wrapper','candidate'];rng.shuffle(order)
                for mode in order:
                    with patch(model,dict(c,mode=mode),'gelu',count=False):
                        measurements=timed(lambda:model(**inputs),3,10)
                    r={'workload':str(i),'phase':'clip_preprocessed_forward','mode':mode,'block':block,'session':c['session'],
                       'images':len(batch),'texts':len(caps),**measurements};records.append(r);append(out/'timings.jsonl',r)
    save(out/'summary.json',timings_summary(records));save(out/'scope.json',{'scope':c['scope'],'note':'Three fixed probe workloads; not full retrieval throughput','session':c['session']})

def compare_clip(c):
    from completion_utils import rows,retrieval_pair
    save(Path(c['output'])/'comparison.json',retrieval_pair(rows(Path(c['baseline'])/'ranks.jsonl'),rows(Path(c['actual'])/'ranks.jsonl')))

def health(c):
    initialize(c);save(Path(c['output'])/'device_health.json',{'basic_NPU_arithmetic_passed':True})

def main():
    action,path=sys.argv[1:];c=read(path)
    if action=='restore':Path(c['output']).mkdir(parents=True,exist_ok=False)
    functions={'preflight':preflight,'backup':backup,'restore':restore,'install':install,'build':build,'benchmark':benchmark,
               'clip':clip,'generative':generative,'gate':gate,'clip_timing':clip_timing,'compare_clip':compare_clip,'health':health}
    functions[action](c)
if __name__=='__main__':main()
