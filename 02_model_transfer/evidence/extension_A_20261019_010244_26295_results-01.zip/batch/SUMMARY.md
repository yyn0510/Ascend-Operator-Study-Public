# 批次结果
状态：completed_with_candidate_records
包恢复：verified

B包只作预检，不提供新增宿主的正式任务或速度结论。候选失败、未测和环境错误分别保留。
完整张量和wheel留在云端；此返回包包括日志、配置、预测、排名和逐项状态。