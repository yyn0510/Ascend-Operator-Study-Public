"""Separate NPU performance runner: no capture hooks or diagnostic counters.

Reports synchronized wall latency INCLUDING Python launch/adapter overhead, not
kernel-only hardware time. Decode uses fixed native tokens and fresh KV caches.
"""
import argparse
import random
import statistics
import time
from collections import defaultdict
from pathlib import Path
from common import (append_result, fingerprint, load_protocol, load_rows, reference_contract, save,
                    sha256, verify_data, verify_loaded, verify_model)
from host import (PatchSession, environment, inputs_for, load_host, record_device_status,
                  runner_hashes, target_paths, verify_environment)
from numerics import capture_index, check_capture_source, compare_tensors, functions, tolerance


def timed(fn, warmup, iterations, setup=None):
    import torch
    values = []
    for i in range(warmup + iterations):
        state = setup() if setup else None
        torch.npu.synchronize()
        start = time.perf_counter_ns()
        value = fn(state) if setup else fn()
        torch.npu.synchronize()
        elapsed = (time.perf_counter_ns() - start) / 1e6
        if i >= warmup:
            values.append(elapsed)
        del value, state
    return {'milliseconds_per_call': statistics.median(values), 'raw_milliseconds': values,
            'iterations': iterations}


def summarize(rows):
    groups = defaultdict(list)
    for r in rows:
        groups[(r['workload'], r['phase'], r['mode'])].append(r['milliseconds_per_call'])
    summaries = [{'workload': key[0], 'phase': key[1], 'mode': key[2],
                  'median_ms': statistics.median(values), 'min_block_ms': min(values),
                  'max_block_ms': max(values), 'blocks': len(values)} for key, values in groups.items()]
    by_key = {(r['workload'], r['phase'], r['mode']): r for r in summaries}
    for r in summaries:
        native = by_key.get((r['workload'], r['phase'], 'native'))
        if native:
            r['speedup_vs_native'] = native['median_ms'] / r['median_ms']
    return summaries


def select_captures(rows, limit):
    # Round-robin shape/phase/dtype strata; retain workload IDs in output.
    buckets = defaultdict(list)
    for row in rows:
        buckets[fingerprint([row['shape'], row['phase'], row['dtype']])].append(row)
    keys, selected = sorted(buckets), []
    while len(selected) < limit and any(buckets.values()):
        for key in keys:
            if buckets[key] and len(selected) < limit:
                selected.append(buckets[key].pop(0))
    return selected


def operator_benchmark(a, protocol, env, kernel):
    import torch
    index, source = capture_index(a.inputs, a.operator)
    check_capture_source(protocol, source, env)
    selected = select_captures(index, protocol['performance']['samples'])
    settings, rng, results = protocol['performance'], random.Random(protocol['seed']), []
    save(a.output / 'workloads.json', {'captures': selected, 'index_sha256': sha256(a.inputs / 'index.jsonl')})
    with torch.inference_mode():
        for row in selected:
            data = torch.load(a.inputs / row['file'], map_location='cpu', weights_only=True)
            xs = [x.to(f'npu:{a.device_id}') for x in data['inputs']]
            fns = functions(a.operator, xs, data['attrs'], kernel)
            tol = tolerance(protocol, a.operator, data['reference'].dtype)
            for mode in fns:
                check = compare_tensors(data['reference'], fns[mode](), tol)
                if not check['passed']:
                    save(a.output / 'numerical_failure.json', {'input': row, 'mode': mode, 'check': check})
                    raise RuntimeError('Numerical check failed before timing')
            for block in range(settings['blocks']):
                modes = list(fns)
                rng.shuffle(modes)
                for mode in modes:
                    result = {'workload': row['file'], 'phase': row['phase'], 'mode': mode,
                              'block': block, 'shape': row['shape'], 'dtype': row['dtype'],
                              **timed(fns[mode], settings['operator_warmup'], settings['operator_iterations'])}
                    results.append(result)
                    append_result(a.output / 'timings.jsonl', result)
    return results


def prepare_prefill(model, inputs):
    import torch
    position = torch.arange(inputs['input_ids'].shape[1], device=inputs['input_ids'].device)
    return model.prepare_inputs_for_generation(**dict(inputs), cache_position=position, use_cache=True)


def fixed_decode_inputs(inputs, tokens):
    import torch
    length = inputs['input_ids'].shape[1]
    steps = []
    for i in range(tokens.shape[1]):
        ids = torch.cat((inputs['input_ids'], tokens[:, :i + 1]), dim=-1)
        mask = torch.cat((inputs['attention_mask'], torch.ones((1, i + 1),
                         dtype=inputs['attention_mask'].dtype, device=ids.device)), dim=-1)
        kwargs = dict(inputs)
        kwargs.update(input_ids=ids, attention_mask=mask,
                      cache_position=torch.tensor([length + i], device=ids.device), pixel_values=None)
        steps.append(kwargs)
    return steps


def decode(model, steps, cache):
    for kwargs in steps:
        prepared = model.prepare_inputs_for_generation(**kwargs, past_key_values=cache, use_cache=True)
        output = model(**prepared, return_dict=True)
        cache = output.past_key_values
    return output


def model_benchmark(a, protocol, kernel):
    import torch
    settings, rng, results = protocol['performance'], random.Random(protocol['seed']), []
    model, processor = load_host(protocol, a.model_path, f'npu:{a.device_id}')
    paths = target_paths(model, a.operator, protocol)
    rows = [r for r in load_rows(a.samples, verify_images=False) if r['split'] == 'dev']
    # Spread over image area and text length. No eval outcomes enter selection.
    rows.sort(key=lambda r: (r.get('width', 0) * r.get('height', 0), len(r['question']), r['id']))
    count = min(settings['samples'], len(rows))
    selected = [rows[round(i * (len(rows) - 1) / max(count - 1, 1))] for i in range(count)]
    save(a.output / 'workloads.json', {'sample_ids': [r['id'] for r in selected], 'targets': paths,
          'selection': 'Evenly spaced in image-area/text-length order; all from dev'})
    with torch.inference_mode():
        for row in selected:
            inputs = inputs_for(row, a.samples, processor, protocol, f'npu:{a.device_id}')
            length, steps_count = inputs['input_ids'].shape[1], settings['decode_steps']
            # Native reference token values are frozen per workload; every mode consumes them.
            tokens = model.generate(**inputs, do_sample=False, use_cache=True,
                                    min_new_tokens=steps_count, max_new_tokens=steps_count)[:, length:].detach()
            if tokens.shape[1] != steps_count:
                raise RuntimeError('Reference generation did not produce the fixed number of tokens')
            steps = fixed_decode_inputs(inputs, tokens)
            token_fingerprint = fingerprint(tokens.cpu().tolist())
            # One untimed diagnostic call verifies that each intended adapter is exercised.
            probe = PatchSession(model, paths, a.operator, 'candidate', kernel, diagnostics=True)
            try:
                cache = model(**prepare_prefill(model, inputs), return_dict=True).past_key_values
                decode(model, steps, cache)
                torch.npu.synchronize()
                if any(v == 0 for v in probe.counters.values()):
                    raise RuntimeError('Candidate not exercised at all intended modules')
                del cache
            finally:
                probe.close()
            for block in range(settings['blocks']):
                modes = ['native', 'wrapper', 'candidate']
                rng.shuffle(modes)
                for mode in modes:
                    patch = PatchSession(model, paths, a.operator, mode, kernel, diagnostics=False)
                    try:
                        def prefill():
                            return model(**prepare_prefill(model, inputs), return_dict=True)
                        def setup_cache():
                            # Fresh KV cache per iteration; this prefill is outside decode timer.
                            return prefill().past_key_values
                        def run_decode(cache):
                            return decode(model, steps, cache)
                        for phase, fn, setup in [('prefill', prefill, None),
                                                 ('fixed_teacher_forced_decode', run_decode, setup_cache)]:
                            result = {'workload': row['id'], 'phase': phase, 'mode': mode, 'block': block,
                                      'input_tokens': length, 'decode_steps': steps_count,
                                      'native_token_fingerprint': token_fingerprint,
                                      **timed(fn, settings['warmup'], settings['iterations'], setup)}
                            if phase == 'fixed_teacher_forced_decode':
                                result['milliseconds_per_decode_step'] = result['milliseconds_per_call'] / steps_count
                            append_result(a.output / 'timings.jsonl', result)
                            results.append(result)
                    finally:
                        patch.close()
    return results


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--kind', choices=['operator', 'model'], required=True)
    p.add_argument('--protocol', type=Path, required=True)
    p.add_argument('--operator', choices=['gelu', 'swi_glu'], required=True)
    p.add_argument('--candidate-id', required=True)
    p.add_argument('--receipt', type=Path, required=True)
    p.add_argument('--replay-report', type=Path, required=True)
    p.add_argument('--inputs', type=Path)
    p.add_argument('--model-path', type=Path)
    p.add_argument('--samples', type=Path)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--development-only', action='store_true')
    p.add_argument('--device-id', type=int, default=0)
    a = p.parse_args()
    protocol = load_protocol(a.protocol, 'dev' if a.development_only else 'eval')
    if a.output.exists():
        raise FileExistsError(a.output)
    env = environment(a.device_id)
    verify_environment(protocol, env)
    identity = verify_loaded(a.candidate_id, a.operator, a.receipt)
    from common import read_json
    replay = read_json(a.replay_report)
    if (not replay.get('total') or replay.get('passed') != replay['total']
            or replay['identity']['binary_sha256'] != identity['binary_sha256']
            or replay.get('operator') != a.operator
            or replay.get('environment') != env
            or replay.get('capture_reference_contract') != reference_contract(protocol)
            or replay['tolerances'] != protocol['tolerances'][a.operator]):
        raise ValueError('Need a successful numerical replay for this binary/protocol')
    if protocol.get('state') == 'frozen' and (
            replay.get('capture_model_files_fingerprint') != fingerprint(protocol['model']['files_sha256'])
            or replay.get('capture_data') != protocol['dataset']):
        raise ValueError('Replay reference model/dataset differs from frozen protocol')
    if a.kind == 'model':
        if not a.model_path or not a.samples:
            p.error('Model timing needs --model-path and --samples')
        verify_model(protocol, a.model_path)
        verify_data(protocol, a.samples)
    elif not a.inputs:
        p.error('Operator timing needs --inputs')
    a.output.mkdir(parents=True)
    save(a.output / 'run.json', {'kind': a.kind, 'operator': a.operator, 'identity': identity,
         'protocol_sha256': sha256(a.protocol), 'environment': env, 'runner_sha256': runner_hashes(),
         'development_only': a.development_only,
         'measurement': 'NPU-synchronized wall latency; includes Python/launch/adapter overhead; not kernel-only',
         'decode': 'Fixed native teacher-forced tokens. Fresh prefill/KV cache outside decode timing. Not task accuracy.'})
    record_device_status(a.output)
    import cann_bench
    kernel = getattr(cann_bench, a.operator)
    try:
        rows = operator_benchmark(a, protocol, env, kernel) if a.kind == 'operator' else model_benchmark(a, protocol, kernel)
        save(a.output / 'summary.json', {'workload_results': summarize(rows),
             'note': 'Per-workload ratios; no unweighted ratio-of-means claim across differing shapes'})
        save(a.output / 'status.json', {'status': 'completed', 'timing_rows': len(rows)})
    except BaseException as exc:
        save(a.output / 'status.json', {'status': 'interrupted_or_failed', 'error': f'{type(exc).__name__}: {exc}'})
        raise


if __name__ == '__main__':
    main()
