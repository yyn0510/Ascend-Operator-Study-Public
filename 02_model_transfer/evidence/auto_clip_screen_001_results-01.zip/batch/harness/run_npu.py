"""Quality/inspection runner. NPU required; no CPU or native-kernel fallback."""
import argparse
from pathlib import Path
from common import (append_result, fingerprint, load_protocol, load_rows, model_inventory, parse_answer,
                    prepare_output, read_json, reference_contract, save, sha256, verify_data, verify_loaded, verify_model)
from host import (PatchSession, discover, environment, inputs_for, load_host, record_device_status,
                  runner_hashes, target_paths, verify_environment)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--protocol', type=Path)
    p.add_argument('--model-path', type=Path)
    p.add_argument('--samples', type=Path)
    p.add_argument('--split', choices=['dev', 'eval'], default='dev')
    p.add_argument('--operator', choices=['gelu', 'swi_glu'], default='gelu')
    p.add_argument('--mode', choices=['native', 'wrapper', 'candidate'], default='native')
    p.add_argument('--candidate-id')
    p.add_argument('--receipt', type=Path)
    p.add_argument('--replay-report', type=Path)
    p.add_argument('--scope', choices=['all', 'first'], default='all')
    p.add_argument('--capture', action='store_true')
    p.add_argument('--max-samples', type=int)
    p.add_argument('--resume', action='store_true')
    p.add_argument('--inspect', action='store_true')
    p.add_argument('--device-id', type=int, default=0)
    p.add_argument('--environment-only', action='store_true')
    a = p.parse_args()
    if a.environment_only:
        if a.output.exists():
            raise FileExistsError(a.output)
        a.output.mkdir(parents=True)
        save(a.output / 'environment.json', environment(a.device_id))
        record_device_status(a.output)
        return
    if not a.protocol or not a.model_path:
        p.error('Need --protocol and --model-path')
    protocol = load_protocol(a.protocol, a.split)
    if a.split == 'eval' and (a.scope != 'all' or a.max_samples or a.capture):
        raise ValueError('Formal eval requires full frozen scope/subset without capture')
    if a.max_samples is not None and a.max_samples < 1:
        raise ValueError('max-samples must be positive')
    if a.capture and (a.split != 'dev' or a.mode != 'native' or a.resume):
        raise ValueError('Capture requires a fresh native/dev run')
    env = environment(a.device_id)
    verify_environment(protocol, env)
    verify_model(protocol, a.model_path)
    identity = verify_loaded(a.candidate_id, a.operator, a.receipt) if a.mode == 'candidate' else None
    if a.split == 'eval' and a.mode == 'candidate':
        report = read_json(a.replay_report) if a.replay_report else {}
        if (not report.get('total') or report.get('passed') != report['total']
                or report.get('identity', {}).get('binary_sha256') != identity['binary_sha256']
                or report.get('operator') != a.operator
                or report.get('environment') != env
                or report.get('capture_model_files_fingerprint') != fingerprint(protocol['model']['files_sha256'])
                or report.get('capture_data') != protocol['dataset']
                or report.get('capture_reference_contract') != reference_contract(protocol)
                or report.get('tolerances') != protocol['tolerances'][a.operator]):
            raise ValueError('Formal eval needs a successful replay matching binary/tolerances')
    device = f'npu:{a.device_id}'
    if a.inspect:
        if a.output.exists():
            raise FileExistsError(a.output)
        model, processor = load_host(protocol, a.model_path, device)
        a.output.mkdir(parents=True)
        save(a.output / 'inventory.json', {'targets': {op: discover(model, op) for op in ('gelu', 'swi_glu')},
             'environment': env, 'runner_sha256': runner_hashes(), 'model_config': model.config.to_dict(),
             'reference_contract': reference_contract(protocol),
             'processor': processor.to_dict() if hasattr(processor, 'to_dict') else str(processor)})
        return
    if not a.samples:
        p.error('Need --samples')
    data_info = verify_data(protocol, a.samples)
    rows = [r for r in load_rows(a.samples, verify_images=False) if r['split'] == a.split]
    if a.max_samples:
        rows = rows[:a.max_samples]
    if not rows:
        raise ValueError('No selected samples')
    run = {'protocol_sha256': sha256(a.protocol), 'data': data_info,
           'model_files_fingerprint': fingerprint(model_inventory(a.model_path)),
           'reference_contract': reference_contract(protocol),
           'model_path': str(a.model_path.resolve()), 'samples_path': str(a.samples.resolve()),
           'split': a.split, 'operator': a.operator, 'mode': a.mode, 'scope': a.scope,
           'max_samples': a.max_samples, 'capture': a.capture, 'identity': identity,
           'environment': env, 'runner_sha256': runner_hashes()}
    completed = prepare_output(a.output, run, a.resume)
    if a.resume and (a.output / 'errors.jsonl').exists():
        import json
        errors = [json.loads(s) for s in (a.output / 'errors.jsonl').read_text(encoding='utf-8').splitlines() if s.strip()]
        reviews = read_json(a.output / 'failure_reviews.json') if (a.output / 'failure_reviews.json').exists() else {}
        if any(fingerprint(e) not in reviews for e in errors):
            raise ValueError('Classify stopped errors with review_failure.py before resuming')
    selected = {r['id']: r for r in rows}
    if any(r['id'] not in selected or r['answer'] != selected[r['id']]['answer'] for r in completed):
        raise ValueError('Resumed predictions differ from selected questions/answers')
    done = {r['id'] for r in completed}
    save(a.output / 'environment.json', env)
    record_device_status(a.output)
    patch, collector = None, None
    try:
        import torch
        model, processor = load_host(protocol, a.model_path, device)
        paths = target_paths(model, a.operator, protocol, a.scope)
        kernel = None
        if a.mode == 'candidate':
            import cann_bench
            kernel = getattr(cann_bench, a.operator)
        patch = PatchSession(model, paths, a.operator, a.mode, kernel, diagnostics=a.mode != 'native')
        if a.capture:
            from capture import Capture
            collector = Capture(model, paths, a.operator, a.output / 'inputs', protocol['capture'])
        save(a.output / 'configuration.json', {'targets': paths, 'model_config': model.config.to_dict(),
             'mode': a.mode, 'measurement': 'quality/diagnostics; no performance claims'})
        if identity:
            save(a.output / 'loaded_candidate.json', identity)
        for index, row in enumerate(rows):
            if row['id'] in done:
                continue
            if collector:
                collector.begin_sample(row, index)
            result = {'id': row['id'], 'group_id': row['group_id'], 'answer': row['answer'], 'status': 'failed'}
            try:
                inputs = inputs_for(row, a.samples, processor, protocol, device)
                with torch.inference_mode():
                    generated = model.generate(**inputs, max_new_tokens=protocol['decode']['max_new_tokens'],
                                               do_sample=False, use_cache=True)
                torch.npu.synchronize()
                text = processor.batch_decode(generated[:, inputs.input_ids.shape[1]:], skip_special_tokens=True)[0].strip()
                prediction = parse_answer(text, len(row['choices']))
                result.update(status='success', text=text, prediction=prediction, correct=prediction == row['answer'])
            except Exception as exc:
                result['error'] = f'{type(exc).__name__}: {exc}'
                result['failure_classification'] = 'unclassified_requires_log_review'
                append_result(a.output / 'errors.jsonl', result)
                raise RuntimeError(f"Stopped at {row['id']}; classify failure before resuming") from exc
            append_result(a.output / 'predictions.jsonl', result)
        if a.mode != 'native' and len(done) != len(rows) and any(v == 0 for v in patch.counters.values()):
            raise RuntimeError('Some intended target modules were not called')
        save(a.output / f'calls_{len(done):05d}.json', patch.counters)
        save(a.output / 'status.json', {'status': 'completed', 'samples': len(rows),
             'note': 'Invalid answers remain in denominator. Review recorded execution failures.'})
    except BaseException as exc:
        save(a.output / 'status.json', {'status': 'interrupted_or_failed', 'error': f'{type(exc).__name__}: {exc}'})
        raise
    finally:
        if collector:
            collector.close()
        if patch:
            patch.close()


if __name__ == '__main__':
    main()
