"""Build ONE isolated candidate on NPU; bind its source, wheel and loaded binary."""
import argparse
import os
import subprocess
import sys
import zipfile
from pathlib import Path
from common import HERE, fingerprint, read_json, save, selection, sha256, verify_project
from host import environment, record_device_status


def build(candidate_id, soc, output, device_id=0):
    rows = read_json(HERE / 'candidates.json')
    row = next((r for r in rows if r['candidate_id'] == candidate_id), None)
    if row is None:
        raise ValueError('Unknown fixed candidate')
    project = verify_project(HERE / 'projects' / candidate_id, row)
    files = read_json(HERE / 'files.sha256.json')
    # Validate all original project build inputs against the exported bundle.
    for rel, expected in files.items():
        if rel.startswith(f'projects/{candidate_id}/') and sha256(HERE / rel) != expected:
            raise ValueError(f'Exported project changed: {rel}')
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)
    env = environment(device_id)
    save(output / 'environment.json', env)
    record_device_status(output)
    command = ['bash', 'build.sh', f'--soc={soc}']
    save(output / 'build_request.json', {'command': command, 'project': str(project),
                                       'candidate_id': candidate_id, 'soc': soc})
    with (output / 'build.log').open('w', encoding='utf-8') as log:
        subprocess.run(command, cwd=project, stdout=log, stderr=subprocess.STDOUT, check=True)
    wheels = list((project / 'dist').glob('cann_bench-*.whl'))
    if len(wheels) != 1:
        raise ValueError('Expected exactly one candidate wheel')
    wheel = wheels[0].resolve()
    with zipfile.ZipFile(wheel) as z:
        binaries = [n for n in z.namelist() if n.startswith('cann_bench/_C') and n.endswith('.so')]
        if len(binaries) != 1:
            raise ValueError('Wheel has an unexpected extension layout')
        import hashlib
        binary_sha = hashlib.sha256(z.read(binaries[0])).hexdigest()
        wrapper_sha = hashlib.sha256(z.read('cann_bench/__init__.py')).hexdigest()
    if wrapper_sha != sha256(project / 'cann_bench/__init__.py'):
        raise ValueError('Wheel wrapper differs from selected source project')
    with (output / 'install.log').open('w', encoding='utf-8') as log:
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--force-reinstall', '--no-deps', str(wheel)],
                       cwd=output, stdout=log, stderr=subprocess.STDOUT, check=True)
    receipt = {'candidate_id': candidate_id, 'project': str(project),
               'selection_fingerprint': fingerprint(row), 'soc': soc, 'wheel': str(wheel),
               'wheel_sha256': sha256(wheel), 'binary_sha256': binary_sha, 'wrapper_sha256': wrapper_sha,
               'environment': env}
    receipt_path = (output / 'receipt.json').resolve()
    save(receipt_path, receipt)
    # New process, away from the source project: imports must resolve to the installed wheel.
    probe = 'from common import verify_loaded; import sys,json; print(json.dumps(verify_loaded(*sys.argv[1:])))'
    child_env = dict(os.environ)
    child_env['PYTHONPATH'] = str(HERE)
    with (output / 'import_check.log').open('w', encoding='utf-8') as log:
        subprocess.run([sys.executable, '-c', probe, candidate_id, row['operator'], str(receipt_path)],
                       cwd=output, env=child_env, stdout=log, stderr=subprocess.STDOUT, check=True)
    save(output / 'status.json', {'status': 'built_installed_identity_verified',
                               'note': 'This is NOT correctness or model compatibility certification'})
    print(receipt_path)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate-id', required=True)
    p.add_argument('--soc', required=True, choices=['ascend910b', 'ascend910_93', 'ascend950'])
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--device-id', type=int, default=0)
    a = p.parse_args()
    build(a.candidate_id, a.soc, a.output.resolve(), a.device_id)
