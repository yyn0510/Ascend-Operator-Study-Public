"""Check one verified candidate against captured, actual host outputs on NPU."""
import argparse
from pathlib import Path
from common import load_protocol, save, sha256, verify_loaded
from host import environment, verify_environment
from numerics import capture_index, check_capture_source, compare_tensors, functions, tolerance


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inputs', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--protocol', type=Path, required=True)
    p.add_argument('--operator', choices=['gelu', 'swi_glu'], required=True)
    p.add_argument('--candidate-id', required=True)
    p.add_argument('--receipt', type=Path, required=True)
    p.add_argument('--device-id', type=int, default=0)
    a = p.parse_args()
    protocol = load_protocol(a.protocol)
    if a.output.exists():
        raise FileExistsError(a.output)
    env = environment(a.device_id)
    verify_environment(protocol, env)
    identity = verify_loaded(a.candidate_id, a.operator, a.receipt)
    index, source = capture_index(a.inputs, a.operator)
    check_capture_source(protocol, source, env)
    a.output.mkdir(parents=True)
    save(a.output / 'environment.json', env)
    import torch
    import cann_bench
    kernel = getattr(cann_bench, a.operator)
    results = []
    with torch.inference_mode():
        for row in index:
            result = {'input': row['file'], 'sample_id': row['sample_id'], 'module': row['module'],
                      'phase': row['phase'], 'shape': row['shape'], 'dtype': row['dtype'], 'passed': False}
            try:
                data = torch.load(a.inputs / row['file'], map_location='cpu', weights_only=True)
                if data['operator'] != a.operator or data['attrs'] != row['attrs']:
                    raise ValueError('Tensor metadata differs from index')
                tol = tolerance(protocol, a.operator, data['reference'].dtype)
                xs = [x.to(f'npu:{a.device_id}') for x in data['inputs']]
                fns = functions(a.operator, xs, data['attrs'], kernel)
                actual, wrapper = fns['candidate'](), fns['wrapper']()
                torch.npu.synchronize()
                candidate_check = compare_tensors(data['reference'], actual, tol)
                wrapper_check = compare_tensors(data['reference'], wrapper, tol)
                result.update(**candidate_check, tolerance=tol, wrapper=wrapper_check)
                result['passed'] = candidate_check['passed'] and wrapper_check['passed']
            except Exception as exc:
                result['error'] = f'{type(exc).__name__}: {exc}'
            results.append(result)
            save(a.output / 'replay.json', {'candidate_id': a.candidate_id, 'operator': a.operator,
                 'identity': identity, 'protocol_sha256': sha256(a.protocol),
                 'capture_index_sha256': sha256(a.inputs / 'index.jsonl'),
                 'capture_model_files_fingerprint': source['model_files_fingerprint'],
                 'capture_reference_contract': source['reference_contract'],
                 'capture_data': source['data'], 'environment': env,
                 'tolerances': protocol['tolerances'][a.operator],
                 'passed': sum(r['passed'] for r in results), 'total': len(index), 'checked': len(results),
                 'inputs': results})
    if not all(r['passed'] for r in results):
        raise SystemExit(2)


if __name__ == '__main__':
    main()
