"""Download exactly the pinned official weight/processor files, on the server."""
import argparse
import hashlib
import urllib.request
from pathlib import Path
from common import HERE, read_json, save, sha256


def git_blob(path):
    data = path.read_bytes()
    return hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()


def valid(path, row):
    if not path.is_file() or path.stat().st_size != row['size']:
        return False
    return sha256(path) == row['lfs']['sha256'] if row.get('lfs') else git_blob(path) == row['blobId']


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--source', type=Path, default=HERE / 'model_source.api.json')
    p.add_argument('--metadata-only', action='store_true', help='Download small configs/tokenizer only, no weights')
    a = p.parse_args()
    source = read_json(a.source)
    a.output.mkdir(parents=True, exist_ok=True)
    receipt = a.output / 'download_source.json'
    if receipt.exists() and read_json(receipt) != source:
        raise ValueError('Existing download directory belongs to a different revision')
    save(receipt, source)
    for row in source['siblings']:
        name = row['rfilename']
        if name == '.gitattributes' or (a.metadata_only and name.endswith('.safetensors')):
            continue
        path = (a.output / name).resolve()
        if not path.is_relative_to(a.output.resolve()):
            raise ValueError('Unsafe source filename')
        if valid(path, row):
            print(f'Verified cached {name}', flush=True)
            continue
        if path.exists():
            raise ValueError(f'Existing complete file has wrong hash: {path}')
        path.parent.mkdir(parents=True, exist_ok=True)
        partial = path.with_suffix(path.suffix + '.part')
        size = partial.stat().st_size if partial.exists() else 0
        url = f'https://huggingface.co/{source["id"]}/resolve/{source["sha"]}/{name}'
        request = urllib.request.Request(url, headers={'Range': f'bytes={size}-'} if size else {})
        with urllib.request.urlopen(request, timeout=120) as response:
            append = size and response.status == 206
            if append and not response.headers.get('Content-Range', '').startswith(f'bytes {size}-'):
                raise ValueError('Unexpected range response')
            with partial.open('ab' if append else 'wb') as out:
                while block := response.read(1024 * 1024):
                    out.write(block)
        if not valid(partial, row):
            raise ValueError(f'Incomplete/hash-mismatched download: {name}; partial preserved')
        partial.rename(path)
        print(f'Downloaded and verified {name}', flush=True)
    save(a.output / 'download_status.json', {'metadata_only': a.metadata_only,
         'revision': source['sha'], 'all_weights_verified': all(
             valid(a.output / row['rfilename'], row) for row in source['siblings']
             if row['rfilename'].endswith('.safetensors'))})


if __name__ == '__main__':
    main()
