"""Dev-only hooks capture ORIGINAL host intermediates; never used for timing."""
from collections import Counter
from pathlib import Path
from common import append_result, fingerprint, save, sha256


class Capture:
    def __init__(self, model, paths, operator, output, settings):
        self.output, self.operator, self.settings = Path(output), operator, settings
        self.output.mkdir()
        self.handles, self.pending, self.strata = [], {}, Counter()
        self.sample, self.calls, self.saved, self.bytes = None, Counter(), 0, 0
        self.skipped = Counter()
        chosen = list(dict.fromkeys([paths[0], paths[len(paths) // 2], paths[-1]]))
        named = dict(model.named_modules())
        for name in chosen:
            module = named[name]
            if operator == 'gelu':
                def hook(m, args, output_tensor, n=name):
                    self.record(n, [args[0]], output_tensor, {'approximate': m.approximate})
                self.handles.append(module.register_forward_hook(hook))
            else:
                def gate(m, args, output_tensor, n=name):
                    self.pending[(n, 'gate')] = output_tensor
                def up(m, args, output_tensor, n=name):
                    self.pending[(n, 'up')] = output_tensor
                def before_down(m, args, n=name):
                    a = self.pending.pop((n, 'gate'))
                    b = self.pending.pop((n, 'up'))
                    self.record(n, [a, b], args[0], {'dim': -1, 'reference': 'native_pre_down_proj'})
                self.handles += [module.gate_proj.register_forward_hook(gate),
                                 module.up_proj.register_forward_hook(up),
                                 module.down_proj.register_forward_pre_hook(before_down)]
        self.chosen = chosen

    def begin_sample(self, row, sample_index):
        self.sample = row if sample_index < self.settings['sample_limit'] else None
        self.calls.clear()
        self.pending.clear()

    def record(self, name, inputs, reference, attrs):
        if self.sample is None:
            return
        import torch
        number = self.calls[name]
        self.calls[name] += 1
        phase = 'vision' if self.operator == 'gelu' else ('prefill' if number == 0 else 'decode')
        key = fingerprint([self.sample['id'], name, phase, [list(x.shape) for x in inputs], str(reference.dtype)])
        if self.strata[key] >= self.settings['per_stratum']:
            return
        estimate = sum(x.numel() * x.element_size() for x in [*inputs, reference])
        if self.saved >= self.settings['max_files'] or self.bytes + estimate > self.settings['max_bytes']:
            self.skipped['capture_budget'] += 1
            return
        filename = f'{self.saved:04d}.pt'
        tensors = [x.detach().cpu() for x in inputs]
        ref = reference.detach().cpu()
        torch.save({'sample_id': self.sample['id'], 'group_id': self.sample['group_id'],
                    'module': name, 'phase': phase, 'operator': self.operator, 'attrs': attrs,
                    'inputs': tensors, 'reference': ref}, self.output / filename)
        append_result(self.output / 'index.jsonl', {
            'file': filename, 'sha256': sha256(self.output / filename), 'sample_id': self.sample['id'],
            'group_id': self.sample['group_id'], 'module': name, 'phase': phase, 'operator': self.operator,
            'attrs': attrs, 'shape': [list(x.shape) for x in tensors], 'dtype': str(ref.dtype),
            'input_ranges': [{'min': float(x.float().min()), 'max': float(x.float().max())}
                             if x.numel() and bool(torch.isfinite(x).all()) else {'nonfinite_or_empty': True}
                             for x in tensors]})
        self.saved += 1
        self.bytes += estimate
        self.strata[key] += 1

    def close(self):
        for handle in self.handles:
            handle.remove()
        self.pending.clear()
        save(self.output / 'coverage.json', {'chosen_modules': self.chosen, 'saved': self.saved,
             'tensor_bytes_estimate': self.bytes, 'skipped': dict(self.skipped), 'settings': self.settings,
             'note': 'Limited dev captures, not proof of full input coverage'})
