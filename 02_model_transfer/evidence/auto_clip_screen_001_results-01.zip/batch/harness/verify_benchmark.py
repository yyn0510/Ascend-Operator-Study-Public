"""Run original, copied CANN-Bench definitions with the already verified wheel.

No generation, platform submission, kernel repair, or performance collection.
The unchanged kernel_eval framework supplies the original precision criteria.
"""
import argparse
import os
import subprocess
import sys
from pathlib import Path
from common import HERE, read_json, save, sha256, verify_loaded


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate-id', required=True)
    p.add_argument('--operator', required=True, choices=['gelu', 'swi_glu', 'foreach_norm'])
    p.add_argument('--receipt', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--device-id', type=int, default=0)
    a = p.parse_args()
    if a.output.exists():
        raise FileExistsError(a.output)
    identity = verify_loaded(a.candidate_id, a.operator, a.receipt)
    root = HERE / 'original_benchmark'
    files = read_json(HERE / 'files.sha256.json')
    for rel, expected in files.items():
        if rel.startswith('original_benchmark/') and sha256(HERE / rel) != expected:
            raise ValueError(f'Original framework/task changed: {rel}')
    a.output.mkdir(parents=True)
    child_env = dict(os.environ)
    child_env['PYTHONPATH'] = str(root / 'src')
    command = [sys.executable, '-m', 'kernel_eval.cli', 'eval', '--bench-name', 'cann',
               '--task-dir', str(root / 'tasks/level1' / a.operator), '--device', 'npu',
               '--device-id', str(a.device_id), '--processes-per-card', '1', '--no-perf',
               '--eval-seed', '0', '--reports-dir', str(a.output.resolve() / 'reports')]
    save(a.output / 'request.json', {'command': command, 'identity': identity,
                                  'note': 'Uses installed wheel, no source-dir: no rebuild or kernel changes'})
    with (a.output / 'framework.log').open('w', encoding='utf-8') as log:
        result = subprocess.run(command, cwd=root, env=child_env, stdout=log, stderr=subprocess.STDOUT)
    save(a.output / 'status.json', {'process_returncode': result.returncode,
         'note': 'Read original report for actual case counts. Exit code alone is not 20/20 proof.'})
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
