"""NPU host loading, precise target discovery, and reversible operator adapters."""
import importlib.metadata
import os
import platform
import subprocess
import types
from pathlib import Path
from common import HERE, sha256


def runner_hashes():
    return {name: sha256(HERE / name) for name in
            ['common.py', 'host.py', 'capture.py', 'numerics.py', 'run_npu.py', 'replay_npu.py',
             'benchmark_npu.py', 'score.py']}


def environment(device_id=0, smoke=True):
    info = {'python': platform.python_version(), 'platform': platform.platform(), 'device_id': device_id}
    for package in ['torch', 'torch-npu', 'transformers', 'Pillow', 'numpy']:
        try:
            info[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            info[package] = None
    import torch
    import torch_npu
    if not torch.npu.is_available():
        raise RuntimeError('Ascend NPU unavailable; no CPU fallback is enabled')
    torch.npu.set_device(device_id)
    info['device'] = torch.npu.get_device_name(device_id)
    info['device_count'] = torch.npu.device_count()
    version_files = [Path('/usr/local/Ascend/driver/version.info')]
    for base in [os.environ.get('ASCEND_HOME_PATH'), '/usr/local/Ascend/ascend-toolkit/latest']:
        if base:
            version_files += [Path(base) / x for x in ['version.cfg', 'version.info', 'aarch64-linux/ascend_toolkit_install.info']]
    info['ascend_version_files'] = {str(p): p.read_text(errors='replace') for p in version_files if p.is_file()}
    info['ascend_home'] = os.environ.get('ASCEND_HOME_PATH')
    if smoke:
        x = torch.ones(4, device=f'npu:{device_id}')
        if float((x + x).sum().cpu()) != 8.0:
            raise RuntimeError('Basic NPU arithmetic failed')
        torch.npu.synchronize()
        info['smoke_test'] = 'passed'
    return info


def record_device_status(output):
    try:
        result = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, timeout=15)
        (Path(output) / 'npu-smi.txt').write_text(result.stdout + result.stderr, encoding='utf-8')
    except (OSError, subprocess.TimeoutExpired) as exc:
        (Path(output) / 'npu-smi.txt').write_text(str(exc), encoding='utf-8')


def verify_environment(protocol, current):
    if protocol.get('state') == 'frozen' and current != protocol['environment']:
        raise ValueError('Environment differs from frozen protocol; identify a separate experiment')
    if protocol.get('state') == 'frozen' and runner_hashes() != protocol['runner_sha256']:
        raise ValueError('Runner files changed after protocol freeze')


def discover(model, operator):
    named = dict(model.named_modules())
    if operator == 'gelu':
        paths = [n for n, m in named.items() if n.endswith('visual.merger.mlp.1') and type(m).__name__ == 'GELU']
    else:
        paths = [n for n, m in named.items() if type(m).__name__ == 'Qwen2MLP'
                 and all(hasattr(m, a) for a in ('gate_proj', 'up_proj', 'down_proj', 'act_fn'))]
        for n in paths:
            if 'silu' not in type(named[n].act_fn).__name__.lower():
                raise ValueError(f'Unexpected host activation: {n}')
    if not paths:
        raise ValueError(f'No verified {operator} modules; inspect actual host source/version')
    return paths


def target_paths(model, operator, protocol, scope='all'):
    paths = discover(model, operator)
    expected = protocol['targets'].get(operator)
    if expected is not None and paths != expected:
        raise ValueError(f'{operator}: actual module list differs from recorded scope')
    return paths[:1] if scope == 'first' else paths


def load_host(protocol, model_path, device):
    import torch
    from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration
    torch.manual_seed(protocol['seed'])
    model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
        str(model_path), torch_dtype=getattr(torch, protocol['model']['dtype']),
        attn_implementation=protocol['model']['attention'], local_files_only=True).to(device).eval()
    processor = AutoProcessor.from_pretrained(
        str(model_path), local_files_only=True, min_pixels=protocol['model']['min_pixels'],
        max_pixels=protocol['model']['max_pixels'], use_fast=protocol['model']['processor_use_fast'])
    return model, processor


def inputs_for(row, samples, processor, protocol, device):
    from PIL import Image
    from common import make_prompt
    messages = [{'role': 'user', 'content': [{'type': 'image'},
                 {'type': 'text', 'text': make_prompt(row, protocol)}]}]
    prompt = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    with Image.open(Path(samples).parent / row['image']) as image:
        inputs = processor(text=[prompt], images=[image.convert('RGB')], return_tensors='pt')
    return inputs.to(device)


class PatchSession:
    """No hooks or forward assignment for native; counters only when requested."""
    def __init__(self, model, paths, operator, mode, kernel=None, diagnostics=False):
        self.originals = []
        self.counters = {n: 0 for n in paths}
        if mode == 'native':
            return
        if mode not in ('wrapper', 'candidate') or (mode == 'candidate' and kernel is None):
            raise ValueError('Unknown patch mode or missing candidate kernel')
        import torch
        named = dict(model.named_modules())
        for name in paths:
            module = named[name]
            old, inherited = module.forward, 'forward' not in vars(module)
            self.originals.append((module, old, inherited))
            if operator == 'gelu':
                approximate = module.approximate
                def forward(self_module, x, _old=old, _approx=approximate, _name=name):
                    if diagnostics:
                        self.counters[_name] += 1
                    return kernel(x, _approx) if mode == 'candidate' else _old(x)
            else:
                def forward(self_module, x, _name=name):
                    if diagnostics:
                        self.counters[_name] += 1
                    gate, up = self_module.gate_proj(x), self_module.up_proj(x)
                    packed = torch.cat((gate, up), dim=-1)
                    if mode == 'candidate':
                        value = kernel(packed, -1)
                    else:
                        a, b = packed.chunk(2, dim=-1)
                        value = self_module.act_fn(a) * b
                    return self_module.down_proj(value)
            module.forward = types.MethodType(forward, module)

    def close(self):
        for module, old, inherited in reversed(self.originals):
            if inherited:
                del module.forward
            else:
                module.forward = old
        self.originals.clear()
