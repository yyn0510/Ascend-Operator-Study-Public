"""Shared, offline-safe protocol and provenance helpers (no torch import)."""
import hashlib
import json
import os
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SEED = 20261015


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode()).hexdigest()


def reference_contract(protocol):
    return fingerprint({'model': {k: protocol['model'][k] for k in
                        ['id', 'dtype', 'attention', 'processor_use_fast', 'min_pixels', 'max_pixels']},
                        'decode': protocol['decode'], 'seed': protocol['seed'],
                        'answer_instruction': protocol['answer_instruction']})


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    os.replace(temp, path)


def load_rows(path, verify_images=True):
    path = Path(path).resolve()
    rows, seen, groups, image_groups = [], set(), {}, {}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        r = json.loads(line)
        if not {'id', 'split', 'image', 'group_id', 'question', 'choices', 'answer'} <= r.keys():
            raise ValueError('Samples require id/split/image/group_id/question/choices/answer')
        if not isinstance(r['id'], str) or not r['id'] or r['id'] in seen:
            raise ValueError('Empty/non-string/duplicate ID')
        if r['split'] not in ('dev', 'eval') or not isinstance(r['group_id'], str) or not r['group_id']:
            raise ValueError('Invalid split/group_id')
        if not isinstance(r['question'], str) or not r['question'].strip():
            raise ValueError('Empty question')
        if (not isinstance(r['choices'], list) or not 2 <= len(r['choices']) <= 26
                or not all(isinstance(x, str) and x.strip() for x in r['choices'])):
            raise ValueError('Need 2..26 nonempty string options')
        if r['answer'] not in [chr(65 + i) for i in range(len(r['choices']))]:
            raise ValueError('Invalid option-letter answer')
        image = path.parent / r['image']
        if Path(r['image']).is_absolute() or not image.resolve().is_relative_to(path.parent):
            raise ValueError('Images must stay inside the dataset directory')
        if verify_images:
            if not image.is_file():
                raise FileNotFoundError(image)
            if 'image_sha256' not in r or sha256(image) != r['image_sha256']:
                raise ValueError(f"Image hash mismatch: {r['id']}")
        if r['group_id'] in groups and groups[r['group_id']] != r['split']:
            raise ValueError('Image group leaked across dev/eval')
        identity = r.get('image_sha256')
        if not identity or (identity in image_groups and image_groups[identity] != (r['group_id'], r['split'])):
            raise ValueError('Same image has inconsistent group/split labels')
        image_groups[identity] = (r['group_id'], r['split'])
        groups[r['group_id']] = r['split']
        seen.add(r['id'])
        rows.append(r)
    if not rows:
        raise ValueError('Empty dataset')
    return rows


def dataset_info(samples):
    samples = Path(samples).resolve()
    rows = load_rows(samples)
    return {'samples_sha256': sha256(samples), 'count': len(rows),
            'splits': {s: sum(r['split'] == s for r in rows) for s in ('dev', 'eval')},
            'groups': len({r['group_id'] for r in rows})}


def load_protocol(path, split='dev'):
    p = read_json(path)
    if p.get('schema_version') != 1:
        raise ValueError('Unsupported protocol schema')
    m, d, perf = p['model'], p['decode'], p['performance']
    if m['dtype'] not in ('bfloat16', 'float16', 'float32') or m['attention'] != 'eager':
        raise ValueError('Inspect host semantics before enabling another dtype/attention path')
    if m['min_pixels'] <= 0 or m['max_pixels'] < m['min_pixels']:
        raise ValueError('Invalid image pixel bounds')
    if d['max_new_tokens'] < 1 or d['do_sample'] is not False:
        raise ValueError('Expected deterministic greedy decoding')
    if min(perf['warmup'], perf['iterations'], perf['decode_steps']) < 1 or perf['blocks'] < 3:
        raise ValueError('Need warmup/iterations/decode steps >0 and >=3 timing blocks')
    if split == 'eval' and p.get('state') != 'frozen':
        raise ValueError('Formal eval requires a frozen protocol; use dev for preparation')
    if p.get('state') == 'frozen':
        expected = p.get('protocol_fingerprint')
        if expected != fingerprint({k: v for k, v in p.items() if k != 'protocol_fingerprint'}):
            raise ValueError('Frozen protocol was modified')
    return p


def verify_data(protocol, samples):
    info = dataset_info(samples)
    if protocol.get('state') == 'frozen' and protocol.get('dataset') != info:
        raise ValueError('Frozen dataset no longer matches protocol')
    return info


def model_inventory(path):
    root = Path(path).resolve()
    files = sorted(p for p in root.rglob('*') if p.is_file() and '.cache' not in p.parts)
    allowed = ('.safetensors', '.bin', '.json', '.txt', '.model', '.jinja')
    return {p.relative_to(root).as_posix(): sha256(p) for p in files if p.suffix in allowed
            and p.name not in ('download_source.json', 'download_status.json')}


def verify_model(protocol, path):
    # Includes every weight shard and tokenizer/processor config, not just config.json.
    if protocol.get('state') == 'frozen':
        actual = model_inventory(path)
        if not actual or actual != protocol['model']['files_sha256']:
            raise ValueError('Model/tokenizer/processor files differ from frozen protocol')


def selection(candidate_id, operator, manifest=None):
    path = Path(manifest) if manifest else HERE / 'candidates.json'
    rows = read_json(path)
    selected = [r for r in rows if r['candidate_id'] == candidate_id and r['operator'] == operator]
    if len(selected) != 1:
        raise ValueError('Unknown candidate/operator; use the exported manifest')
    return selected[0]


def verify_project(project, selected):
    project = Path(project).resolve()
    project_selection = read_json(project / 'selection.json')
    if any(project_selection.get(k) != v for k, v in selected.items()):
        raise ValueError('Project selection differs from candidate manifest')
    for rel, expected in selected['source']['source_files'].items():
        if rel.endswith('.append'):
            continue  # Complete installed wrapper checked against bundle and wheel below.
        p = (project / rel).resolve()
        if not p.is_relative_to(project) or sha256(p) != expected:
            raise ValueError(f'Candidate source changed: {rel}')
    return project


def verify_loaded(candidate_id, operator, receipt_path, manifest=None):
    if not receipt_path:
        raise ValueError('Candidate runs require --receipt from build_candidate.py')
    selected = selection(candidate_id, operator, manifest)
    receipt = read_json(receipt_path)
    if receipt['candidate_id'] != candidate_id or receipt['selection_fingerprint'] != fingerprint(selected):
        raise ValueError('Build receipt belongs to a different candidate')
    verify_project(receipt['project'], selected)
    import cann_bench
    binary, wrapper = Path(cann_bench._C.__file__).resolve(), Path(cann_bench.__file__).resolve()
    if sha256(binary) != receipt['binary_sha256'] or sha256(wrapper) != receipt['wrapper_sha256']:
        raise ValueError('Loaded package does not match the recorded candidate wheel')
    wheel = Path(receipt['wheel'])
    if not wheel.is_file() or sha256(wheel) != receipt['wheel_sha256']:
        raise ValueError('Recorded wheel is missing or changed')
    return {'candidate_id': candidate_id, 'receipt_sha256': sha256(receipt_path),
            'binary_sha256': sha256(binary), 'wrapper_sha256': sha256(wrapper),
            'binary': str(binary), 'selection_fingerprint': fingerprint(selected)}


def make_prompt(row, protocol):
    return row['question'] + '\n' + '\n'.join(
        f'{chr(65+i)}. {x}' for i, x in enumerate(row['choices'])) + '\n' + protocol['answer_instruction']


def parse_answer(text, nchoices):
    match = re.fullmatch(r'([A-Z])[.。]?', text.strip())
    return match.group(1) if match and ord(match.group(1)) - 65 < nchoices else None


def append_result(path, row):
    with Path(path).open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n')
        f.flush()
        os.fsync(f.fileno())


def prepare_output(path, run_config, resume=False):
    path = Path(path)
    if path.exists():
        if not resume or read_json(path / 'run.json') != run_config:
            raise ValueError('Existing output: use --resume with exactly the same inputs/configuration')
    else:
        if resume:
            raise ValueError('Cannot resume a nonexistent run')
        path.mkdir(parents=True)
        save(path / 'run.json', run_config)
    rows = []
    predictions = path / 'predictions.jsonl'
    if predictions.exists():
        # A partial final line is not silently removed: preserve it and recover explicitly.
        rows = [json.loads(x) for x in predictions.read_text(encoding='utf-8').splitlines() if x.strip()]
        ids = [r['id'] for r in rows]
        if len(ids) != len(set(ids)):
            raise ValueError('Duplicate completed IDs in result file')
    return rows
