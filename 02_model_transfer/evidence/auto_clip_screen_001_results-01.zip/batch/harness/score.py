"""Paired task comparison with image-cluster bootstrap and fixed denominators."""
import argparse
import math
import random
from collections import defaultdict
from pathlib import Path
from common import SEED, load_rows, read_json, save


def read(path):
    import json
    rows = [json.loads(x) for x in Path(path).read_text(encoding='utf-8').splitlines() if x.strip()]
    ids = [r['id'] for r in rows]
    if not rows or len(set(ids)) != len(ids):
        raise ValueError('Empty/duplicate predictions')
    return {r['id']: r for r in rows}


def quantile(values, q):
    values = sorted(values)
    position = (len(values) - 1) * q
    lo, hi = math.floor(position), math.ceil(position)
    return values[lo] + (values[hi] - values[lo]) * (position - lo)


def compare(baseline, candidate, expected=None, bootstrap=5000):
    if baseline.keys() != candidate.keys():
        raise ValueError('Paired sample sets must match exactly')
    if expected is not None and baseline.keys() != expected.keys():
        raise ValueError('Missing/extra formal samples; incomplete runs cannot be scored as full runs')
    if bootstrap < 100:
        raise ValueError('Too few bootstrap replicates')
    groups = defaultdict(list)
    for i in sorted(baseline):
        a, b = baseline[i], candidate[i]
        if a['answer'] != b['answer'] or a.get('group_id') != b.get('group_id'):
            raise ValueError('Ground-truth/group mismatch')
        if expected is not None and (a['answer'] != expected[i]['answer'] or a.get('group_id') != expected[i]['group_id']):
            raise ValueError('Prediction metadata differs from frozen sample manifest')
        for row in (a, b):
            if row['status'] != 'success' and row.get('failure_classification') != 'implementation':
                raise ValueError('Unclassified/infrastructure failures require review and completion')
        groups[a.get('group_id', i)].append(i)
    def correct(row):
        return int(row['status'] == 'success' and row.get('prediction') == row['answer'])
    differences = {i: correct(candidate[i]) - correct(baseline[i]) for i in baseline}
    aggregated = [(sum(differences[i] for i in ids), len(ids)) for ids in groups.values()]
    rng, boot = random.Random(SEED), []
    for _ in range(bootstrap):
        draw = rng.choices(aggregated, k=len(aggregated))
        boot.append(sum(x[0] for x in draw) / sum(x[1] for x in draw))
    n = len(baseline)
    valid = [i for i in baseline if all(r['status'] == 'success' and r.get('prediction') is not None
                                      for r in (baseline[i], candidate[i]))]
    changed = sum(baseline[i]['prediction'] != candidate[i]['prediction'] for i in valid)
    result = {'samples': n, 'image_groups': len(groups),
              'baseline_accuracy': sum(correct(r) for r in baseline.values()) / n,
              'candidate_accuracy': sum(correct(r) for r in candidate.values()) / n,
              'accuracy_difference': sum(differences.values()) / n,
              'difference_percentage_points': 100 * sum(differences.values()) / n,
              'paired_image_cluster_bootstrap_95pct': [quantile(boot, .025), quantile(boot, .975)],
              'bootstrap_replicates': bootstrap, 'seed': SEED,
              'correct_to_incorrect': sum(v == -1 for v in differences.values()),
              'incorrect_to_correct': sum(v == 1 for v in differences.values()),
              'joint_valid_answers': len(valid), 'changed_valid_answers': changed,
              'answer_flip_fraction_all_samples': changed / n,
              'answer_flip_fraction_joint_valid': changed / len(valid) if valid else None,
              'note': 'No change in correctness is not evidence of equivalence. Four candidates are separate descriptive comparisons.'}
    for label, rows in [('baseline', baseline), ('candidate', candidate)]:
        result[label + '_failed'] = sum(r['status'] != 'success' for r in rows.values())
        result[label + '_invalid_answer'] = sum(r['status'] == 'success' and r.get('prediction') is None for r in rows.values())
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline', type=Path, required=True)
    p.add_argument('--candidate', type=Path, required=True)
    p.add_argument('--samples', type=Path, required=True)
    p.add_argument('--split', choices=['dev', 'eval'], default='eval')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists():
        raise FileExistsError(a.output)
    expected = {r['id']: r for r in load_rows(a.samples) if r['split'] == a.split}
    base_run, cand_run = read_json(a.baseline.parent / 'run.json'), read_json(a.candidate.parent / 'run.json')
    for key in ['protocol_sha256', 'data', 'model_files_fingerprint', 'environment', 'runner_sha256', 'scope', 'split']:
        if base_run[key] != cand_run[key]:
            raise ValueError(f'Incomparable runs: {key}')
    if base_run['mode'] != 'native' or cand_run['mode'] not in ('wrapper', 'candidate'):
        raise ValueError('Compare an untouched native baseline to wrapper/candidate')
    result = compare(read(a.baseline), read(a.candidate), expected)
    save(a.output, result)
    print(a.output)
