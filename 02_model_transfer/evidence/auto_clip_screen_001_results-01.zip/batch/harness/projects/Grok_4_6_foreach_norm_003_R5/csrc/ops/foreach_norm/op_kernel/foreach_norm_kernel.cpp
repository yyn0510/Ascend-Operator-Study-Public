/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr int64_t PIPELINE_DEPTH = 3;
constexpr int32_t PTYPE_FINITE = 0;
constexpr int32_t PTYPE_INF = 1;
constexpr int32_t PTYPE_NEG_INF = 2;
constexpr int32_t VEC_ALIGN = 8;
constexpr float F32_MAX = 3.402823466e+38f;
constexpr int64_t MAX_BATCH = 4;
constexpr int64_t MAX_CORES = 64;

using namespace AscendC;

__aicore__ inline float LocalGetFloat(LocalTensor<float> &src, int32_t idx)
{
    event_t eventId = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_S));
    SetFlag<HardEvent::V_S>(eventId);
    WaitFlag<HardEvent::V_S>(eventId);
    return src.GetValue(idx);
}

__aicore__ inline void SyncSV()
{
    event_t eventId = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::S_V));
    SetFlag<HardEvent::S_V>(eventId);
    WaitFlag<HardEvent::S_V>(eventId);
}

__aicore__ inline void ApplyPower(LocalTensor<float> &bufA, LocalTensor<float> &bufB, int32_t count, float p)
{
    if (p == 0.0f) {
        Sign(bufA, bufA, count);
        PipeBarrier<PIPE_V>();
        Abs(bufA, bufA, count);
        PipeBarrier<PIPE_V>();
        return;
    }
    if (p == 3.0f) {
        Mul(bufB, bufA, bufA, count);
        PipeBarrier<PIPE_V>();
        Mul(bufA, bufB, bufA, count);
        PipeBarrier<PIPE_V>();
        return;
    }
    if (p == 5.0f) {
        Mul(bufB, bufA, bufA, count);
        PipeBarrier<PIPE_V>();
        Mul(bufB, bufB, bufB, count);
        PipeBarrier<PIPE_V>();
        Mul(bufA, bufB, bufA, count);
        PipeBarrier<PIPE_V>();
        return;
    }
    if (p == 1.5f) {
        Sqrt(bufB, bufA, count);
        PipeBarrier<PIPE_V>();
        Mul(bufA, bufA, bufB, count);
        PipeBarrier<PIPE_V>();
        return;
    }
    if (p == 2.5f) {
        Sqrt(bufB, bufA, count);
        PipeBarrier<PIPE_V>();
        Mul(bufA, bufA, bufA, count);
        PipeBarrier<PIPE_V>();
        Mul(bufA, bufA, bufB, count);
        PipeBarrier<PIPE_V>();
        return;
    }
    if (p == -1.0f) {
        Reciprocal(bufA, bufA, count);
        PipeBarrier<PIPE_V>();
        return;
    }
    Ln(bufA, bufA, count);
    PipeBarrier<PIPE_V>();
    Muls(bufA, bufA, p, count);
    PipeBarrier<PIPE_V>();
    Exp(bufA, bufA, count);
    PipeBarrier<PIPE_V>();
}

template <typename T>
__aicore__ inline void ComputeAndAcc(LocalTensor<T> &xLocal, LocalTensor<float> &aLocal, LocalTensor<float> &bLocal,
                                     LocalTensor<float> &accLocal, int32_t n, float p, int32_t pType)
{
    if constexpr (sizeof(T) == sizeof(float)) {
        if (pType == PTYPE_FINITE && p == 1.0f) {
            Abs(xLocal, xLocal, n);
            PipeBarrier<PIPE_V>();
            Add(accLocal, accLocal, xLocal, n);
            PipeBarrier<PIPE_V>();
            return;
        }
        if (pType == PTYPE_FINITE && p == 2.0f) {
            Mul(aLocal, xLocal, xLocal, n);
            PipeBarrier<PIPE_V>();
            Add(accLocal, accLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            return;
        }
        if (pType == PTYPE_FINITE && p == 4.0f) {
            Mul(aLocal, xLocal, xLocal, n);
            PipeBarrier<PIPE_V>();
            Mul(aLocal, aLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            Add(accLocal, accLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            return;
        }
        Abs(aLocal, xLocal, n);
    } else {
        Cast(aLocal, xLocal, RoundMode::CAST_NONE, n);
        PipeBarrier<PIPE_V>();
        if (pType == PTYPE_FINITE && p == 1.0f) {
            Abs(aLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            Add(accLocal, accLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            return;
        }
        if (pType == PTYPE_FINITE && p == 2.0f) {
            Mul(aLocal, aLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            Add(accLocal, accLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            return;
        }
        if (pType == PTYPE_FINITE && p == 4.0f) {
            Mul(aLocal, aLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            Mul(aLocal, aLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            Add(accLocal, accLocal, aLocal, n);
            PipeBarrier<PIPE_V>();
            return;
        }
        Abs(aLocal, aLocal, n);
    }
    PipeBarrier<PIPE_V>();
    if (pType == PTYPE_INF) {
        Max(accLocal, accLocal, aLocal, n);
        PipeBarrier<PIPE_V>();
        return;
    }
    if (pType == PTYPE_NEG_INF) {
        Min(accLocal, accLocal, aLocal, n);
        PipeBarrier<PIPE_V>();
        return;
    }
    if (p != 1.0f) {
        ApplyPower(aLocal, bLocal, n, p);
    }
    Add(accLocal, accLocal, aLocal, n);
    PipeBarrier<PIPE_V>();
}

__aicore__ inline float ApplyNormFinal(LocalTensor<float> &vec, float s, float p, int32_t pType)
{
    if (pType == PTYPE_INF || pType == PTYPE_NEG_INF || p == 0.0f || p == 1.0f) {
        return s;
    }
    SyncSV();
    Duplicate(vec, s, VEC_ALIGN);
    PipeBarrier<PIPE_V>();
    if (p == 2.0f) {
        Sqrt(vec, vec, VEC_ALIGN);
    } else if (p == 4.0f) {
        Sqrt(vec, vec, VEC_ALIGN);
        PipeBarrier<PIPE_V>();
        Sqrt(vec, vec, VEC_ALIGN);
    } else if (p == -1.0f) {
        Reciprocal(vec, vec, VEC_ALIGN);
    } else {
        Ln(vec, vec, VEC_ALIGN);
        PipeBarrier<PIPE_V>();
        Muls(vec, vec, 1.0f / p, VEC_ALIGN);
        PipeBarrier<PIPE_V>();
        Exp(vec, vec, VEC_ALIGN);
    }
    PipeBarrier<PIPE_V>();
    return LocalGetFloat(vec, 0);
}

__aicore__ inline void WritePartial(GlobalTensor<float> &wsGm, LocalTensor<float> &outLocal, int64_t index, float acc)
{
    SyncSV();
    Duplicate(outLocal, acc, VEC_ALIGN);
    event_t eventVM = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_MTE3));
    SetFlag<HardEvent::V_MTE3>(eventVM);
    WaitFlag<HardEvent::V_MTE3>(eventVM);
    DataCopy(wsGm[index * VEC_ALIGN], outLocal, VEC_ALIGN);
    event_t eventMS = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::MTE3_S));
    SetFlag<HardEvent::MTE3_S>(eventMS);
    WaitFlag<HardEvent::MTE3_S>(eventMS);
}

template <typename T>
__aicore__ inline void WriteScalar(GM_ADDR y, LocalTensor<float> &fLocal, LocalTensor<T> &tLocal, float val)
{
    GlobalTensor<T> yGm;
    yGm.SetGlobalBuffer((__gm__ T *)y, 1);
    SyncSV();
    Duplicate(fLocal, val, VEC_ALIGN);
    PipeBarrier<PIPE_V>();
    DataCopyExtParams copyParams{1, static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
    if constexpr (sizeof(T) == sizeof(float)) {
        event_t eventVM = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_MTE3));
        SetFlag<HardEvent::V_MTE3>(eventVM);
        WaitFlag<HardEvent::V_MTE3>(eventVM);
        DataCopyPad(yGm, fLocal, copyParams);
    } else {
        Cast(tLocal, fLocal, RoundMode::CAST_RINT, VEC_ALIGN);
        event_t eventVM = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_MTE3));
        SetFlag<HardEvent::V_MTE3>(eventVM);
        WaitFlag<HardEvent::V_MTE3>(eventVM);
        DataCopyPad(yGm, tLocal, copyParams);
    }
    event_t eventMV = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::MTE3_V));
    SetFlag<HardEvent::MTE3_V>(eventMV);
    WaitFlag<HardEvent::MTE3_V>(eventMV);
}

template <typename T>
__aicore__ inline void CopyInTile(TQue<QuePosition::VECIN, PIPELINE_DEPTH> &inQueue, GlobalTensor<T> &xGm,
                                  int64_t offset, int32_t n)
{
    LocalTensor<T> xLocal = inQueue.AllocTensor<T>();
    uint32_t bytes = static_cast<uint32_t>(n) * static_cast<uint32_t>(sizeof(T));
    if ((bytes & 31u) == 0u) {
        DataCopy(xLocal, xGm[offset], n);
    } else {
        DataCopyExtParams copyParams{1, bytes, 0, 0, 0};
        DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
    }
    inQueue.EnQue(xLocal);
}

template <typename T>
__aicore__ inline float ProcessOneTensor(GM_ADDR x, TQue<QuePosition::VECIN, PIPELINE_DEPTH> &inQueue,
                                         LocalTensor<float> &aLocal, LocalTensor<float> &bLocal,
                                         LocalTensor<float> &accLocal, LocalTensor<float> &outLocal,
                                         int64_t totalLength, int64_t numBlocks, int64_t tileElems, float p,
                                         int32_t pType, float initVal)
{
    int64_t blockIdx = GetBlockIdx();
    int64_t align = static_cast<int64_t>(32 / sizeof(T));
    if (align < 8) {
        align = 8;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    blockLength = (blockLength + align - 1) / align * align;
    if (blockLength < align) {
        blockLength = align;
    }
    int64_t start = blockIdx * blockLength;
    int64_t currentBlockLength = totalLength - start;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength < 0) {
        currentBlockLength = 0;
    }

    float acc = initVal;
    if (currentBlockLength <= 0 || tileElems <= 0) {
        return acc;
    }

    GlobalTensor<T> xGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + start, currentBlockLength);

    int32_t tileElemsI = static_cast<int32_t>(tileElems);
    Duplicate(accLocal, initVal, tileElemsI);

    int64_t tileNum = currentBlockLength / tileElems;
    int64_t tailNum = currentBlockLength - tileNum * tileElems;
    int64_t totalTiles = tileNum + (tailNum > 0 ? 1 : 0);
    int32_t elementNumPerTile = tileElemsI;

    int64_t issued = 0;
    int64_t preload = 2;
    if (preload > totalTiles) {
        preload = totalTiles;
    }
    for (; issued < preload; ++issued) {
        int32_t n = (issued < tileNum) ? elementNumPerTile : static_cast<int32_t>(tailNum);
        CopyInTile(inQueue, xGm, issued * tileElems, n);
    }

    PipeBarrier<PIPE_V>();

    for (int64_t computed = 0; computed < totalTiles; ++computed) {
        int32_t n = (computed < tileNum) ? elementNumPerTile : static_cast<int32_t>(tailNum);
        LocalTensor<T> xLocal = inQueue.DeQue<T>();
        if (issued < totalTiles) {
            int32_t n2 = (issued < tileNum) ? elementNumPerTile : static_cast<int32_t>(tailNum);
            CopyInTile(inQueue, xGm, issued * tileElems, n2);
            ++issued;
        }
        ComputeAndAcc(xLocal, aLocal, bLocal, accLocal, n, p, pType);
        inQueue.FreeTensor(xLocal);
    }

    if (pType == PTYPE_INF) {
        ReduceMax<float>(outLocal, accLocal, bLocal, tileElemsI, false);
    } else if (pType == PTYPE_NEG_INF) {
        ReduceMin<float>(outLocal, accLocal, bLocal, tileElemsI, false);
    } else {
        ReduceSum<float>(outLocal, accLocal, bLocal, tileElemsI);
    }
    acc = LocalGetFloat(outLocal, 0);
    return acc;
}

template <typename T>
__global__ __aicore__ void foreach_norm_kernel(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR y0, GM_ADDR y1,
                                               GM_ADDR y2, GM_ADDR y3, int64_t n0, int64_t n1, int64_t n2, int64_t n3,
                                               int64_t tensorCount, GM_ADDR workspace, int64_t numBlocks,
                                               int64_t tileElems, float p, int32_t pType)
{
    TPipe pipe;
    GlobalTensor<float> wsGm;
    TQue<QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    TBuf<QuePosition::VECCALC> bufA;
    TBuf<QuePosition::VECCALC> bufB;
    TBuf<QuePosition::VECCALC> accBuf;
    TBuf<QuePosition::VECCALC> outBuf;
    TBuf<QuePosition::VECCALC> outTBuf;

    uint32_t inTileBytes = static_cast<uint32_t>(tileElems * static_cast<int64_t>(sizeof(T)));
    inTileBytes = (inTileBytes + 31u) & ~31u;
    uint32_t fp32Bytes = static_cast<uint32_t>(tileElems * static_cast<int64_t>(sizeof(float)));
    fp32Bytes = (fp32Bytes + 31u) & ~31u;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, inTileBytes);
    pipe.InitBuffer(bufA, fp32Bytes);
    pipe.InitBuffer(bufB, fp32Bytes);
    pipe.InitBuffer(accBuf, fp32Bytes);
    pipe.InitBuffer(outBuf, 256);
    pipe.InitBuffer(outTBuf, 256);

    wsGm.SetGlobalBuffer((__gm__ float *)workspace);

    LocalTensor<float> aLocal = bufA.Get<float>();
    LocalTensor<float> bLocal = bufB.Get<float>();
    LocalTensor<float> accLocal = accBuf.Get<float>();
    LocalTensor<float> outLocal = outBuf.Get<float>();
    LocalTensor<T> tLocal = outTBuf.Get<T>();

    float initVal = (pType == PTYPE_NEG_INF) ? F32_MAX : 0.0f;
    int64_t blockIdx = GetBlockIdx();
    int32_t nTensors = static_cast<int32_t>(tensorCount);
    if (nTensors > static_cast<int32_t>(MAX_BATCH)) {
        nTensors = static_cast<int32_t>(MAX_BATCH);
    }

    for (int32_t t = 0; t < nTensors; ++t) {
        GM_ADDR xPtr = x0;
        GM_ADDR yPtr = y0;
        int64_t len = n0;
        if (t == 1) {
            xPtr = x1;
            yPtr = y1;
            len = n1;
        } else if (t == 2) {
            xPtr = x2;
            yPtr = y2;
            len = n2;
        } else if (t == 3) {
            xPtr = x3;
            yPtr = y3;
            len = n3;
        }

        float acc = ProcessOneTensor<T>(xPtr, inQueue, aLocal, bLocal, accLocal, outLocal, len, numBlocks, tileElems, p,
                                        pType, initVal);
        if (numBlocks == 1) {
            if (blockIdx == 0) {
                float result = ApplyNormFinal(outLocal, acc, p, pType);
                WriteScalar<T>(yPtr, outLocal, tLocal, result);
            }
        } else {
            WritePartial(wsGm, outLocal, static_cast<int64_t>(t) * numBlocks + blockIdx, acc);
        }
    }

    if (numBlocks <= 1) {
        return;
    }

    PipeBarrier<PIPE_ALL>();
    SyncAll();

    if (blockIdx == 0) {
        int32_t nblocks = static_cast<int32_t>(numBlocks);
        int32_t exactN = nblocks * VEC_ALIGN;
        int32_t paddedN = (exactN + 63) & ~63;
        int32_t tileCap = static_cast<int32_t>(tileElems);
        if (paddedN > tileCap || paddedN < exactN) {
            paddedN = exactN;
        }

        for (int32_t t = 0; t < nTensors; ++t) {
            GM_ADDR yPtr = y0;
            if (t == 1) {
                yPtr = y1;
            } else if (t == 2) {
                yPtr = y2;
            } else if (t == 3) {
                yPtr = y3;
            }

            Duplicate(aLocal, initVal, paddedN);
            PipeBarrier<PIPE_V>();
            event_t eventVM2 = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_MTE2));
            SetFlag<HardEvent::V_MTE2>(eventVM2);
            WaitFlag<HardEvent::V_MTE2>(eventVM2);
            DataCopy(aLocal, wsGm[static_cast<int64_t>(t) * numBlocks * VEC_ALIGN], exactN);
            event_t eventM2V = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::MTE2_V));
            SetFlag<HardEvent::MTE2_V>(eventM2V);
            WaitFlag<HardEvent::MTE2_V>(eventM2V);

            if (pType == PTYPE_INF) {
                ReduceMax<float>(outLocal, aLocal, bLocal, paddedN, false);
            } else if (pType == PTYPE_NEG_INF) {
                ReduceMin<float>(outLocal, aLocal, bLocal, paddedN, false);
            } else {
                ReduceSum<float>(outLocal, aLocal, bLocal, paddedN);
            }
            float s = LocalGetFloat(outLocal, 0);
            if (pType == PTYPE_FINITE) {
                s = s * 0.125f;
            }
            float result = ApplyNormFinal(outLocal, s, p, pType);
            WriteScalar<T>(yPtr, outLocal, tLocal, result);
        }
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr int64_t TILE_ALIGN = 64;
    constexpr int64_t MAX_TILE_ELEMS = 16384;
    constexpr int64_t MIN_TILE_ELEMS = 512;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 192 * 1024;
    int64_t coreNum = 1;
    if (ascendcPlatform != nullptr) {
        ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
        coreNum = ascendcPlatform->GetCoreNumAiv();
    }
    if (ubSize < 64 * 1024) {
        ubSize = 192 * 1024;
    }
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (coreNum > MAX_CORES) {
        coreNum = MAX_CORES;
    }
    if (totalLength < 1) {
        return std::make_tuple(static_cast<int64_t>(1), static_cast<int64_t>(0), MIN_TILE_ELEMS);
    }

    int64_t perElem = PIPELINE_DEPTH * dtypeSize + 3 * static_cast<int64_t>(sizeof(float));
    int64_t usable = static_cast<int64_t>(ubSize) - 16 * 1024;
    if (usable < 32 * 1024) {
        usable = 32 * 1024;
    }
    int64_t tileElems = usable / perElem;
    tileElems = (tileElems / TILE_ALIGN) * TILE_ALIGN;
    if (tileElems > MAX_TILE_ELEMS) {
        tileElems = MAX_TILE_ELEMS;
    }
    if (tileElems < MIN_TILE_ELEMS) {
        tileElems = MIN_TILE_ELEMS;
    }

    int64_t numBlocks = coreNum;
    if (totalLength < coreNum * MIN_ELEMS_PER_CORE) {
        numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
        if (numBlocks < 1) {
            numBlocks = 1;
        }
        if (numBlocks > coreNum) {
            numBlocks = coreNum;
        }
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

extern "C" {

void launch_foreach_norm_kernel_float(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR y0, GM_ADDR y1,
                                      GM_ADDR y2, GM_ADDR y3, int64_t n0, int64_t n1, int64_t n2, int64_t n3,
                                      int64_t tensorCount, GM_ADDR workspace, int64_t numBlocks, int64_t tileElems,
                                      float p, int32_t pType, void *stream)
{
    foreach_norm_kernel<float><<<numBlocks, nullptr, stream>>>(x0, x1, x2, x3, y0, y1, y2, y3, n0, n1, n2, n3,
                                                               tensorCount, workspace, numBlocks, tileElems, p, pType);
}

void launch_foreach_norm_kernel_half(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR y0, GM_ADDR y1, GM_ADDR y2,
                                     GM_ADDR y3, int64_t n0, int64_t n1, int64_t n2, int64_t n3, int64_t tensorCount,
                                     GM_ADDR workspace, int64_t numBlocks, int64_t tileElems, float p, int32_t pType,
                                     void *stream)
{
    foreach_norm_kernel<half><<<numBlocks, nullptr, stream>>>(x0, x1, x2, x3, y0, y1, y2, y3, n0, n1, n2, n3,
                                                              tensorCount, workspace, numBlocks, tileElems, p, pType);
}

void launch_foreach_norm_kernel_bf16(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR y0, GM_ADDR y1, GM_ADDR y2,
                                     GM_ADDR y3, int64_t n0, int64_t n1, int64_t n2, int64_t n3, int64_t tensorCount,
                                     GM_ADDR workspace, int64_t numBlocks, int64_t tileElems, float p, int32_t pType,
                                     void *stream)
{
    foreach_norm_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x0, x1, x2, x3, y0, y1, y2, y3, n0, n1, n2, n3,
                                                                    tensorCount, workspace, numBlocks, tileElems, p,
                                                                    pType);
}

}
