/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include <cmath>
#include <vector>

#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<at::Tensor> foreach_norm_meta(at::TensorList x, double scalar)
{
    TORCH_CHECK(x.size() > 0, "foreach_norm: x must not be empty");
    auto dtype = x[0].scalar_type();
    TORCH_CHECK(dtype == at::kFloat || dtype == at::kHalf || dtype == at::kBFloat16,
                "foreach_norm: only float32, float16 and bfloat16 are supported");
    std::vector<at::Tensor> y;
    y.reserve(x.size());
    for (const auto &t : x) {
        TORCH_CHECK(t.scalar_type() == dtype, "foreach_norm: all tensors must have the same dtype");
        y.push_back(at::empty({}, t.options()));
    }
    (void)scalar;
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

std::vector<at::Tensor> foreach_norm_npu(at::TensorList xList, double scalar)
{
    TORCH_CHECK(xList.size() > 0, "foreach_norm: x must not be empty");
    std::vector<at::Tensor> inputs;
    inputs.reserve(xList.size());
    for (const auto &t : xList) {
        inputs.push_back(t.contiguous());
    }

    const c10::OptionalDeviceGuard guard(inputs[0].device());
    auto outputs = foreach_norm_meta(inputs, scalar);
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int32_t pType = 0;
    float p = static_cast<float>(scalar);
    if (std::isinf(scalar)) {
        pType = (scalar > 0.0) ? 1 : 2;
        p = 0.0f;
    }

    auto dtype = inputs[0].scalar_type();
    int64_t dtypeSize = inputs[0].element_size();
    auto workspace = at::empty({4 * 64 * 8}, inputs[0].options().dtype(at::kFloat));

    auto acl_call = [=]() -> int {
        const size_t n = inputs.size();
        for (size_t base = 0; base < n; base += 4) {
            size_t cnt = n - base;
            if (cnt > 4) {
                cnt = 4;
            }

            GM_ADDR x0 = (GM_ADDR)inputs[base].data_ptr();
            GM_ADDR y0 = (GM_ADDR)outputs[base].data_ptr();
            int64_t n0 = inputs[base].numel();
            GM_ADDR x1 = x0;
            GM_ADDR y1 = y0;
            int64_t n1 = 0;
            GM_ADDR x2 = x0;
            GM_ADDR y2 = y0;
            int64_t n2 = 0;
            GM_ADDR x3 = x0;
            GM_ADDR y3 = y0;
            int64_t n3 = 0;
            int64_t maxLen = n0;
            if (cnt > 1) {
                x1 = (GM_ADDR)inputs[base + 1].data_ptr();
                y1 = (GM_ADDR)outputs[base + 1].data_ptr();
                n1 = inputs[base + 1].numel();
                if (n1 > maxLen) {
                    maxLen = n1;
                }
            }
            if (cnt > 2) {
                x2 = (GM_ADDR)inputs[base + 2].data_ptr();
                y2 = (GM_ADDR)outputs[base + 2].data_ptr();
                n2 = inputs[base + 2].numel();
                if (n2 > maxLen) {
                    maxLen = n2;
                }
            }
            if (cnt > 3) {
                x3 = (GM_ADDR)inputs[base + 3].data_ptr();
                y3 = (GM_ADDR)outputs[base + 3].data_ptr();
                n3 = inputs[base + 3].numel();
                if (n3 > maxLen) {
                    maxLen = n3;
                }
            }

            int64_t numBlocks = 1;
            int64_t blockLength = maxLen;
            int64_t tileElems = 512;
            std::tie(numBlocks, blockLength, tileElems) = calc_foreach_norm_tiling_params(maxLen, dtypeSize);
            (void)blockLength;

            GM_ADDR wsPtr = (GM_ADDR)workspace.data_ptr();
            int64_t tensorCount = static_cast<int64_t>(cnt);

            if (dtype == at::kFloat) {
                launch_foreach_norm_kernel_float(x0, x1, x2, x3, y0, y1, y2, y3, n0, n1, n2, n3, tensorCount, wsPtr,
                                                 numBlocks, tileElems, p, pType, stream);
            } else if (dtype == at::kHalf) {
                launch_foreach_norm_kernel_half(x0, x1, x2, x3, y0, y1, y2, y3, n0, n1, n2, n3, tensorCount, wsPtr,
                                                numBlocks, tileElems, p, pType, stream);
            } else if (dtype == at::kBFloat16) {
                launch_foreach_norm_kernel_bf16(x0, x1, x2, x3, y0, y1, y2, y3, n0, n1, n2, n3, tensorCount, wsPtr,
                                                numBlocks, tileElems, p, pType, stream);
            }
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
    return outputs;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

} // namespace cann_bench
