/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/gelu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("gelu(Tensor x, str approximate=\"none\") -> Tensor");
}

torch::Tensor gelu_meta(const torch::Tensor &x, c10::string_view approximate)
{
    TORCH_CHECK(approximate == "none" || approximate == "tanh",
                "gelu: approximate must be \"none\" or \"tanh\".");
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("gelu", gelu_meta);
}

torch::Tensor gelu_npu(const torch::Tensor &x, c10::string_view approximate)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto y = gelu_meta(x, approximate);
    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t totalLength = x.numel();
    if (totalLength == 0) {
        return y;
    }
    int64_t numBlocks, blockLength, tileSize;
    std::tie(numBlocks, blockLength, tileSize) = calc_gelu_tiling_params(totalLength);
    uint32_t mode = (approximate == "tanh") ? 1u : 0u;
    auto x_ptr = (GM_ADDR)x.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();

    auto acl_call = [=]() -> int {
        if (x.scalar_type() == torch::kFloat32) {
            launch_gelu_kernel_float(x_ptr, y_ptr, totalLength, numBlocks, blockLength,
                                     static_cast<uint32_t>(tileSize), mode, stream);
        } else if (x.scalar_type() == torch::kFloat16) {
            launch_gelu_kernel_half(x_ptr, y_ptr, totalLength, numBlocks, blockLength,
                                    static_cast<uint32_t>(tileSize), mode, stream);
        } else if (x.scalar_type() == torch::kBFloat16) {
            launch_gelu_kernel_bfloat16(x_ptr, y_ptr, totalLength, numBlocks, blockLength,
                                        static_cast<uint32_t>(tileSize), mode, stream);
        } else {
            TORCH_CHECK(false, "gelu: unsupported dtype.");
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Gelu", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("gelu", gelu_npu);
}

} // namespace cann_bench
