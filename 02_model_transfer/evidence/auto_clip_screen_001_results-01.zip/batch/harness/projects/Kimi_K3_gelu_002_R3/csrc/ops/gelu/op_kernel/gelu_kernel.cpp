/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t GELU_PIPELINE_DEPTH = 2;
constexpr static int64_t GELU_MIN_ELEMS_PER_CORE = 2048;
constexpr static uint32_t GELU_TILE_BYTES = 8192;

template <typename T>
__aicore__ inline void gelu_to_float(const AscendC::LocalTensor<float> &dst,
                                     const AscendC::LocalTensor<T> &src, uint32_t count)
{
    if constexpr (std::is_same<T, float>::value) {
        AscendC::Adds(dst, src, 0.0f, count);
    } else {
        AscendC::Cast(dst, src, AscendC::RoundMode::CAST_NONE, count);
    }
}

template <typename T>
__aicore__ inline void gelu_from_float(const AscendC::LocalTensor<T> &dst,
                                       const AscendC::LocalTensor<float> &src, uint32_t count)
{
    if constexpr (std::is_same<T, float>::value) {
        AscendC::Adds(dst, src, 0.0f, count);
    } else {
        AscendC::Cast(dst, src, AscendC::RoundMode::CAST_RINT, count);
    }
}

template <typename T>
__aicore__ inline void gelu_compute_tile(const AscendC::LocalTensor<T> &xLocal,
                                         const AscendC::LocalTensor<T> &yLocal,
                                         const AscendC::LocalTensor<float> &xf,
                                         const AscendC::LocalTensor<float> &ta,
                                         const AscendC::LocalTensor<float> &tb,
                                         const AscendC::LocalTensor<float> &tc,
                                         const AscendC::LocalTensor<float> &td,
                                         uint32_t count, uint32_t mode)
{
    gelu_to_float<T>(xf, xLocal, count);

    if (mode == 0) {
        // Exact: y = 0.5*x*(1+erf(x/sqrt(2))); erf via Abramowitz-Stegun 7.1.26.
        AscendC::Maxs(xf, xf, -6.0f, count);
        AscendC::Muls(ta, xf, 0.70710678118654752f, count);   // ta = u
        AscendC::Abs(tb, ta, count);                          // tb = |u|
        AscendC::Muls(tc, tb, 0.3275911f, count);
        AscendC::Adds(tc, tc, 1.0f, count);
        AscendC::Duplicate(td, 1.0f, count);
        AscendC::Div(tc, td, tc, count);                      // tc = t
        AscendC::Duplicate(td, 1.061405429f, count);
        AscendC::Mul(td, td, tc, count);
        AscendC::Adds(td, td, -1.453152027f, count);
        AscendC::Mul(td, td, tc, count);
        AscendC::Adds(td, td, 1.421413741f, count);
        AscendC::Mul(td, td, tc, count);
        AscendC::Adds(td, td, -0.284496736f, count);
        AscendC::Mul(td, td, tc, count);
        AscendC::Adds(td, td, 0.254829592f, count);
        AscendC::Mul(td, td, tc, count);                      // td = poly(t)
        AscendC::Mul(tb, ta, ta, count);
        AscendC::Muls(tb, tb, -1.0f, count);
        AscendC::Exp(tb, tb, count);                          // tb = exp(-u*u)
        AscendC::Mul(td, td, tb, count);
        AscendC::Muls(td, td, -1.0f, count);
        AscendC::Adds(td, td, 1.0f, count);                   // td = erf(|u|)
        AscendC::Sign(tb, ta, count);
        AscendC::Mul(td, td, tb, count);                      // td = erf(u)
        AscendC::Adds(td, td, 1.0f, count);
        AscendC::Muls(td, td, 0.5f, count);
        AscendC::Mul(xf, xf, td, count);
    } else {
        // Tanh: y = x*sigmoid(2z), z = sqrt(2/pi)*(x + 0.044715*x^3).
        // Only clamp positive side of z: z=+inf must give sigmoid=1 (y=x),
        // z=-inf must give sigmoid=0 so that (-inf)*0 = NaN, matching golden.
        AscendC::Mul(tb, xf, xf, count);
        AscendC::Mul(tb, tb, xf, count);                      // tb = x^3
        AscendC::Muls(tb, tb, 0.044715f, count);
        AscendC::Add(ta, xf, tb, count);
        AscendC::Muls(ta, ta, 0.79788456080286536f, count);   // ta = z
        AscendC::Mins(ta, ta, 30.0f, count);                  // clamp +inf side only
        AscendC::Muls(ta, ta, 2.0f, count);
        AscendC::Exp(tb, ta, count);                          // tb = exp(2z)
        AscendC::Adds(tc, tb, 1.0f, count);
        AscendC::Div(ta, tb, tc, count);                      // ta = sigmoid(2z)
        AscendC::Mul(xf, xf, ta, count);
    }

    gelu_from_float<T>(yLocal, xf, count);
}

template <typename T>
__global__ __aicore__ void gelu_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                       int64_t blockLength, uint32_t tileSize, uint32_t mode)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, GELU_PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, GELU_PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufXf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufA;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufB;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufC;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufD;

    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength <= 0) {
        return;
    }
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    pipe.InitBuffer(inQueueX, GELU_PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, GELU_PIPELINE_DEPTH, tileSize);
    uint32_t elementNumPerTile = tileSize / sizeof(T);
    uint32_t floatTileBytes = elementNumPerTile * sizeof(float);
    pipe.InitBuffer(bufXf, floatTileBytes);
    pipe.InitBuffer(bufA, floatTileBytes);
    pipe.InitBuffer(bufB, floatTileBytes);
    pipe.InitBuffer(bufC, floatTileBytes);
    pipe.InitBuffer(bufD, floatTileBytes);

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * blockIdx);

    auto xf = bufXf.Get<float>();
    auto ta = bufA.Get<float>();
    auto tb = bufB.Get<float>();
    auto tc = bufC.Get<float>();
    auto td = bufD.Get<float>();

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();
        gelu_compute_tile<T>(xLocal, yLocal, xf, ta, tb, tc, td, elementNumPerTile, mode);
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        uint32_t count = static_cast<uint32_t>(tailTileElementNum);
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();
        gelu_compute_tile<T>(xLocal, yLocal, xf, ta, tb, tc, td, count, mode);
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_gelu_tiling_params(int64_t totalLength)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    int64_t numBlocks = std::min(coreNum, (totalLength + GELU_MIN_ELEMS_PER_CORE - 1) / GELU_MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    int64_t tileSize = GELU_TILE_BYTES;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_gelu_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                              int64_t blockLength, uint32_t tileSize, uint32_t mode, void *stream)
{
    gelu_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, mode);
}

void launch_gelu_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                             int64_t blockLength, uint32_t tileSize, uint32_t mode, void *stream)
{
    gelu_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, mode);
}

void launch_gelu_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                 int64_t blockLength, uint32_t tileSize, uint32_t mode, void *stream)
{
    gelu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, mode);
}

}
