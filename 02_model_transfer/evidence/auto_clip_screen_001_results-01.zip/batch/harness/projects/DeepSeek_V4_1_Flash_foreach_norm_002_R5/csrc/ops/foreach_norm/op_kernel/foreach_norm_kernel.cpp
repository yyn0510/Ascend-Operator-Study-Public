/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_kernel.cpp
 * \brief ForeachNorm batched multi-tensor p-norm reduce kernel (AI Core only).
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr int32_t NORM_MODE_FINITE = 0;
constexpr int32_t NORM_MODE_INF = 1;
constexpr int32_t NORM_MODE_ZERO = 2;
constexpr int32_t PIPELINE_DEPTH = 2;

template <typename T>
__aicore__ inline void ForeachNormCastToFloat(const AscendC::LocalTensor<float> &dst,
                                              const AscendC::LocalTensor<T> &src,
                                              int32_t count)
{
    if constexpr (std::is_same<T, float>::value) {
        AscendC::Adds(dst, src, 0.0f, count);
    } else {
        AscendC::Cast(dst, src, AscendC::RoundMode::CAST_NONE, count);
    }
}

template <typename T>
__aicore__ inline void ForeachNormCastFromFloat(const AscendC::LocalTensor<T> &dst,
                                                const AscendC::LocalTensor<float> &src,
                                                int32_t count)
{
    if constexpr (std::is_same<T, float>::value) {
        AscendC::Adds(dst, src, 0.0f, count);
    } else {
        AscendC::Cast(dst, src, AscendC::RoundMode::CAST_RINT, count);
    }
}

template <typename T>
__global__ __aicore__ void foreach_norm_reduce_batched(
    GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
    GM_ADDR workspace,
    int64_t totalLength, int64_t blockLength,
    int32_t numBlocksPerTensor, int32_t numTensors,
    int32_t tileLen, float p, int32_t mode)
{
    int64_t bid = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t tIdx = bid / numBlocksPerTensor;
    int64_t localBid = bid - tIdx * static_cast<int64_t>(numBlocksPerTensor);
    if (tIdx >= static_cast<int64_t>(numTensors)) {
        return;
    }

    GM_ADDR xSel = x0;
    if (tIdx == 1) {
        xSel = x1;
    } else if (tIdx == 2) {
        xSel = x2;
    } else if (tIdx == 3) {
        xSel = x3;
    }

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> accBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmp2Buf;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;

    uint32_t inBytes = static_cast<uint32_t>(tileLen) * static_cast<uint32_t>(sizeof(T));
    uint32_t fBytes = static_cast<uint32_t>(tileLen) * 4u;
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, inBytes);
    pipe.InitBuffer(accBuf, fBytes);
    pipe.InitBuffer(tmpBuf, fBytes);
    pipe.InitBuffer(tmp2Buf, fBytes);
    pipe.InitBuffer(outQueue, 1, 32u);

    AscendC::LocalTensor<float> accLocal = accBuf.Get<float>();
    AscendC::LocalTensor<float> tmpLocal = tmpBuf.Get<float>();
    AscendC::LocalTensor<float> tmp2Local = tmp2Buf.Get<float>();
    AscendC::Duplicate(accLocal, 0.0f, tileLen);

    AscendC::GlobalTensor<T> xGm;
    xGm.SetGlobalBuffer((__gm__ T *)xSel);
    AscendC::GlobalTensor<float> wsGm;
    wsGm.SetGlobalBuffer((__gm__ float *)workspace);

    int64_t offset = localBid * blockLength;
    int64_t remain = totalLength - offset;
    if (remain > blockLength) {
        remain = blockLength;
    }

    while (remain > 0) {
        int32_t count = (remain > static_cast<int64_t>(tileLen)) ? tileLen : static_cast<int32_t>(remain);
        uint32_t copyBytes = static_cast<uint32_t>(count) * static_cast<uint32_t>(sizeof(T));
        AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        AscendC::LocalTensor<T> inLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(inLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(inLocal);
        inLocal = inQueue.DeQue<T>();

        ForeachNormCastToFloat(tmpLocal, inLocal, count);
        inQueue.FreeTensor(inLocal);

        AscendC::Abs(tmpLocal, tmpLocal, count);
        if (mode == NORM_MODE_INF) {
            AscendC::Max(accLocal, accLocal, tmpLocal, count);
        } else if (mode == NORM_MODE_ZERO) {
            AscendC::Muls(tmp2Local, tmpLocal, 1.0e30f, count);
            AscendC::Mins(tmp2Local, tmp2Local, 1.0f, count);
            AscendC::Add(accLocal, accLocal, tmp2Local, count);
        } else if (p == 1.0f) {
            AscendC::Add(accLocal, accLocal, tmpLocal, count);
        } else if (p == 2.0f) {
            AscendC::Mul(tmp2Local, tmpLocal, tmpLocal, count);
            AscendC::Add(accLocal, accLocal, tmp2Local, count);
        } else if (p == 3.0f) {
            AscendC::Mul(tmp2Local, tmpLocal, tmpLocal, count);
            AscendC::Mul(tmp2Local, tmp2Local, tmpLocal, count);
            AscendC::Add(accLocal, accLocal, tmp2Local, count);
        } else if (p == 4.0f) {
            AscendC::Mul(tmp2Local, tmpLocal, tmpLocal, count);
            AscendC::Mul(tmp2Local, tmp2Local, tmp2Local, count);
            AscendC::Add(accLocal, accLocal, tmp2Local, count);
        } else if (p == 0.5f) {
            AscendC::Sqrt(tmp2Local, tmpLocal, count);
            AscendC::Add(accLocal, accLocal, tmp2Local, count);
        } else if (p == 1.5f) {
            AscendC::Sqrt(tmp2Local, tmpLocal, count);
            AscendC::Mul(tmp2Local, tmp2Local, tmpLocal, count);
            AscendC::Add(accLocal, accLocal, tmp2Local, count);
        } else if (p == 2.5f) {
            AscendC::Sqrt(tmp2Local, tmpLocal, count);
            AscendC::Mul(tmpLocal, tmpLocal, tmpLocal, count);
            AscendC::Mul(tmpLocal, tmpLocal, tmp2Local, count);
            AscendC::Add(accLocal, accLocal, tmpLocal, count);
        } else {
            AscendC::Ln(tmpLocal, tmpLocal, count);
            AscendC::Muls(tmpLocal, tmpLocal, p, count);
            AscendC::Exp(tmpLocal, tmpLocal, count);
            AscendC::Add(accLocal, accLocal, tmpLocal, count);
        }
        offset += count;
        remain -= count;
    }

    AscendC::LocalTensor<float> resLocal = outQueue.AllocTensor<float>();
    if (mode == NORM_MODE_INF) {
        AscendC::ReduceMax<float>(resLocal, accLocal, tmpLocal, tileLen);
    } else {
        AscendC::ReduceSum<float>(resLocal, accLocal, tmpLocal, tileLen);
    }
    outQueue.EnQue(resLocal);
    resLocal = outQueue.DeQue<float>();
    AscendC::DataCopyExtParams wsParams{1, 4u, 0, 0, 0};
    int64_t wsOffset = tIdx * static_cast<int64_t>(numBlocksPerTensor) + localBid;
    AscendC::DataCopyPad(wsGm[wsOffset], resLocal, wsParams);
    outQueue.FreeTensor(resLocal);
}

template <typename T>
__global__ __aicore__ void foreach_norm_finalize_batched(
    GM_ADDR workspace, GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
    int32_t numBlocksPerTensor, int32_t numTensors,
    float p, int32_t mode)
{
    int64_t tIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    if (tIdx >= static_cast<int64_t>(numTensors)) {
        return;
    }

    GM_ADDR ySel = y0;
    if (tIdx == 1) {
        ySel = y1;
    } else if (tIdx == 2) {
        ySel = y2;
    } else if (tIdx == 3) {
        ySel = y3;
    }

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBuf;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueueF;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueueT;

    uint32_t wsBytes = static_cast<uint32_t>(numBlocksPerTensor) * 4u;
    pipe.InitBuffer(inQueue, 1, wsBytes);
    pipe.InitBuffer(workBuf, wsBytes);
    pipe.InitBuffer(outQueueF, 1, 32u);
    pipe.InitBuffer(outQueueT, 1, 32u);

    AscendC::GlobalTensor<float> wsGm;
    wsGm.SetGlobalBuffer((__gm__ float *)workspace);
    AscendC::GlobalTensor<T> yGm;
    yGm.SetGlobalBuffer((__gm__ T *)ySel);

    int64_t wsBase = tIdx * static_cast<int64_t>(numBlocksPerTensor);

    AscendC::LocalTensor<float> inLocal = inQueue.AllocTensor<float>();
    AscendC::DataCopyExtParams copyParams{1, wsBytes, 0, 0, 0};
    AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};
    AscendC::DataCopyPad(inLocal, wsGm[wsBase], copyParams, padParams);
    inQueue.EnQue(inLocal);
    inLocal = inQueue.DeQue<float>();

    AscendC::LocalTensor<float> workLocal = workBuf.Get<float>();
    AscendC::LocalTensor<float> outLocalF = outQueueF.AllocTensor<float>();
    if (mode == NORM_MODE_INF) {
        AscendC::ReduceMax<float>(outLocalF, inLocal, workLocal, numBlocksPerTensor);
    } else {
        AscendC::ReduceSum<float>(outLocalF, inLocal, workLocal, numBlocksPerTensor);
    }
    inQueue.FreeTensor(inLocal);

    if (mode == NORM_MODE_FINITE) {
        if (p == 1.0f) {
            /* nothing */
        } else if (p == 2.0f) {
            AscendC::Sqrt(outLocalF, outLocalF, 1);
        } else if (p == 0.5f) {
            AscendC::Mul(outLocalF, outLocalF, outLocalF, 1);
        } else {
            AscendC::Ln(outLocalF, outLocalF, 1);
            AscendC::Muls(outLocalF, outLocalF, 1.0f / p, 1);
            AscendC::Exp(outLocalF, outLocalF, 1);
        }
    }
    outQueueF.EnQue(outLocalF);

    if constexpr (std::is_same<T, float>::value) {
        AscendC::LocalTensor<float> o = outQueueF.DeQue<float>();
        AscendC::DataCopyExtParams outParams{1, 4u, 0, 0, 0};
        AscendC::DataCopyPad(yGm[0], o, outParams);
        outQueueF.FreeTensor(o);
    } else {
        AscendC::LocalTensor<float> oF = outQueueF.DeQue<float>();
        AscendC::LocalTensor<T> oT = outQueueT.AllocTensor<T>();
        ForeachNormCastFromFloat(oT, oF, 1);
        outQueueT.EnQue(oT);
        outQueueF.FreeTensor(oF);
        AscendC::LocalTensor<T> oT2 = outQueueT.DeQue<T>();
        AscendC::DataCopyExtParams outParams{1, static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[0], oT2, outParams);
        outQueueT.FreeTensor(oT2);
    }
}

std::tuple<int64_t, int64_t, int32_t> calc_foreach_norm_tiling_params(int64_t totalLength,
                                                                     int64_t elemSizeBytes)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (coreNum > 128) {
        coreNum = 128;
    }
    constexpr int64_t MIN_ELEMS_PER_CORE = 8192;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    if (blockLength < 1) {
        blockLength = 1;
    }
    int32_t tileLen = 8192;
    if (elemSizeBytes == 2) {
        tileLen = 8192;
    } else if (elemSizeBytes == 1) {
        tileLen = 16384;
    }
    return std::make_tuple(numBlocks, blockLength, tileLen);
}

extern "C" {
void launch_foreach_norm_reduce_batched_float(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
                                              GM_ADDR ws, int64_t totalLength, int64_t blockLength,
                                              int32_t numBlocksPerTensor, int32_t numTensors,
                                              int32_t tileLen, float p, int32_t mode, void *stream)
{
    int64_t grid = static_cast<int64_t>(numBlocksPerTensor) * static_cast<int64_t>(numTensors);
    foreach_norm_reduce_batched<float><<<grid, nullptr, stream>>>(x0, x1, x2, x3, ws, totalLength,
        blockLength, numBlocksPerTensor, numTensors, tileLen, p, mode);
}

void launch_foreach_norm_reduce_batched_half(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
                                             GM_ADDR ws, int64_t totalLength, int64_t blockLength,
                                             int32_t numBlocksPerTensor, int32_t numTensors,
                                             int32_t tileLen, float p, int32_t mode, void *stream)
{
    int64_t grid = static_cast<int64_t>(numBlocksPerTensor) * static_cast<int64_t>(numTensors);
    foreach_norm_reduce_batched<half><<<grid, nullptr, stream>>>(x0, x1, x2, x3, ws, totalLength,
        blockLength, numBlocksPerTensor, numTensors, tileLen, p, mode);
}

void launch_foreach_norm_reduce_batched_bfloat16(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
                                                 GM_ADDR ws, int64_t totalLength, int64_t blockLength,
                                                 int32_t numBlocksPerTensor, int32_t numTensors,
                                                 int32_t tileLen, float p, int32_t mode, void *stream)
{
    int64_t grid = static_cast<int64_t>(numBlocksPerTensor) * static_cast<int64_t>(numTensors);
    foreach_norm_reduce_batched<bfloat16_t><<<grid, nullptr, stream>>>(x0, x1, x2, x3, ws, totalLength,
        blockLength, numBlocksPerTensor, numTensors, tileLen, p, mode);
}

void launch_foreach_norm_finalize_batched_float(GM_ADDR ws, GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
                                                int32_t numBlocksPerTensor, int32_t numTensors,
                                                float p, int32_t mode, void *stream)
{
    foreach_norm_finalize_batched<float><<<numTensors, nullptr, stream>>>(ws, y0, y1, y2, y3,
        numBlocksPerTensor, numTensors, p, mode);
}

void launch_foreach_norm_finalize_batched_half(GM_ADDR ws, GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
                                               int32_t numBlocksPerTensor, int32_t numTensors,
                                               float p, int32_t mode, void *stream)
{
    foreach_norm_finalize_batched<half><<<numTensors, nullptr, stream>>>(ws, y0, y1, y2, y3,
        numBlocksPerTensor, numTensors, p, mode);
}

void launch_foreach_norm_finalize_batched_bfloat16(GM_ADDR ws, GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
                                                   int32_t numBlocksPerTensor, int32_t numTensors,
                                                   float p, int32_t mode, void *stream)
{
    foreach_norm_finalize_batched<bfloat16_t><<<numTensors, nullptr, stream>>>(ws, y0, y1, y2, y3,
        numBlocksPerTensor, numTensors, p, mode);
}
}
