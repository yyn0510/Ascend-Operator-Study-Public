/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_launch.h
 * \brief Host side declarations for ForeachNorm direct launch (batched)
 */

#ifndef FOREACH_NORM_LAUNCH_H
#define FOREACH_NORM_LAUNCH_H

#include <cstdint>
#include <tuple>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

constexpr int32_t FOREACH_NORM_MODE_FINITE = 0;
constexpr int32_t FOREACH_NORM_MODE_INF = 1;
constexpr int32_t FOREACH_NORM_MODE_ZERO = 2;

std::tuple<int64_t, int64_t, int32_t> calc_foreach_norm_tiling_params(int64_t totalLength,
                                                                     int64_t elemSizeBytes);

extern "C" {
void launch_foreach_norm_reduce_batched_float(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
                                              GM_ADDR ws, int64_t totalLength, int64_t blockLength,
                                              int32_t numBlocksPerTensor, int32_t numTensors,
                                              int32_t tileLen, float p, int32_t mode, void *stream);
void launch_foreach_norm_reduce_batched_half(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
                                             GM_ADDR ws, int64_t totalLength, int64_t blockLength,
                                             int32_t numBlocksPerTensor, int32_t numTensors,
                                             int32_t tileLen, float p, int32_t mode, void *stream);
void launch_foreach_norm_reduce_batched_bfloat16(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
                                                 GM_ADDR ws, int64_t totalLength, int64_t blockLength,
                                                 int32_t numBlocksPerTensor, int32_t numTensors,
                                                 int32_t tileLen, float p, int32_t mode, void *stream);

void launch_foreach_norm_finalize_batched_float(GM_ADDR ws, GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
                                                int32_t numBlocksPerTensor, int32_t numTensors,
                                                float p, int32_t mode, void *stream);
void launch_foreach_norm_finalize_batched_half(GM_ADDR ws, GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
                                               int32_t numBlocksPerTensor, int32_t numTensors,
                                               float p, int32_t mode, void *stream);
void launch_foreach_norm_finalize_batched_bfloat16(GM_ADDR ws, GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
                                                   int32_t numBlocksPerTensor, int32_t numTensors,
                                                   float p, int32_t mode, void *stream);
}

#endif // FOREACH_NORM_LAUNCH_H
