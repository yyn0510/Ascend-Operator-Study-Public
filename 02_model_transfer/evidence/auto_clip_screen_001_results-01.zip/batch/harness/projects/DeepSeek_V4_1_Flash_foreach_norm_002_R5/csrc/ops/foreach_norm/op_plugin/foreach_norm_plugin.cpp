/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_plugin.cpp
 * \brief ForeachNorm API layer - torch bindings (batched reduce + finalize)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"
#include "../op_kernel/foreach_norm_launch.h"

#include <algorithm>
#include <cmath>
#include <tuple>
#include <vector>

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<torch::Tensor> foreach_norm_meta(at::TensorList x, double scalar)
{
    (void)scalar;
    std::vector<torch::Tensor> y;
    y.reserve(x.size());
    for (const auto &t : x) {
        y.push_back(torch::empty({}, t.options()));
    }
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

std::vector<torch::Tensor> foreach_norm_npu(at::TensorList x, double scalar)
{
    TORCH_CHECK(x.size() > 0, "foreach_norm: input tensor list must not be empty.");
    const c10::OptionalDeviceGuard guard(x[0].device());

    std::vector<torch::Tensor> y = foreach_norm_meta(x, scalar);
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int32_t mode = FOREACH_NORM_MODE_FINITE;
    if (std::isinf(scalar)) {
        mode = FOREACH_NORM_MODE_INF;
    } else if (scalar == 0.0) {
        mode = FOREACH_NORM_MODE_ZERO;
    }
    float p = static_cast<float>(scalar);

    auto dtype = x[0].scalar_type();
    size_t L = x.size();
    size_t i = 0;
    while (i < L) {
        size_t batch = std::min<size_t>(static_cast<size_t>(4), L - i);

        std::vector<torch::Tensor> xb;
        std::vector<torch::Tensor> yb;
        xb.reserve(batch);
        yb.reserve(batch);
        for (size_t k = 0; k < batch; ++k) {
            TORCH_CHECK(x[i + k].scalar_type() == dtype,
                        "foreach_norm: dtypes of the list must match.");
            TORCH_CHECK(x[i + k].device() == x[i].device(),
                        "foreach_norm: devices of the list must match.");
            xb.push_back(x[i + k].contiguous());
            yb.push_back(y[i + k]);
        }

        int64_t totalLength = xb[0].numel();
        int64_t numBlocks = 1;
        int64_t blockLength = 1;
        int32_t tileLen = 8192;
        std::tie(numBlocks, blockLength, tileLen) =
            calc_foreach_norm_tiling_params(totalLength, static_cast<int64_t>(xb[0].element_size()));

        if (batch > 1) {
            int64_t nbt = numBlocks / static_cast<int64_t>(batch);
            if (nbt < 1) {
                nbt = 1;
            }
            numBlocks = nbt;
            blockLength = (totalLength + numBlocks - 1) / numBlocks;
            if (blockLength < 1) {
                blockLength = 1;
            }
        }

        int32_t nbt32 = static_cast<int32_t>(numBlocks);
        int32_t batch32 = static_cast<int32_t>(batch);
        int32_t wsLen = nbt32 * batch32;

        torch::Tensor ws = torch::empty({static_cast<int64_t>(wsLen)},
                                        xb[0].options().dtype(torch::kFloat32));

        GM_ADDR x0 = batch > 0 ? (GM_ADDR)xb[0].data_ptr() : nullptr;
        GM_ADDR x1 = batch > 1 ? (GM_ADDR)xb[1].data_ptr() : nullptr;
        GM_ADDR x2 = batch > 2 ? (GM_ADDR)xb[2].data_ptr() : nullptr;
        GM_ADDR x3 = batch > 3 ? (GM_ADDR)xb[3].data_ptr() : nullptr;
        GM_ADDR y0 = batch > 0 ? (GM_ADDR)yb[0].data_ptr() : nullptr;
        GM_ADDR y1 = batch > 1 ? (GM_ADDR)yb[1].data_ptr() : nullptr;
        GM_ADDR y2 = batch > 2 ? (GM_ADDR)yb[2].data_ptr() : nullptr;
        GM_ADDR y3 = batch > 3 ? (GM_ADDR)yb[3].data_ptr() : nullptr;
        GM_ADDR ws_ptr = (GM_ADDR)ws.data_ptr();

        auto acl_call = [=]() -> int {
            if (dtype == torch::kFloat32) {
                launch_foreach_norm_reduce_batched_float(x0, x1, x2, x3, ws_ptr,
                    totalLength, blockLength, nbt32, batch32, tileLen, p, mode, stream);
                launch_foreach_norm_finalize_batched_float(ws_ptr, y0, y1, y2, y3,
                    nbt32, batch32, p, mode, stream);
            } else if (dtype == torch::kFloat16) {
                launch_foreach_norm_reduce_batched_half(x0, x1, x2, x3, ws_ptr,
                    totalLength, blockLength, nbt32, batch32, tileLen, p, mode, stream);
                launch_foreach_norm_finalize_batched_half(ws_ptr, y0, y1, y2, y3,
                    nbt32, batch32, p, mode, stream);
            } else if (dtype == torch::kBFloat16) {
                launch_foreach_norm_reduce_batched_bfloat16(x0, x1, x2, x3, ws_ptr,
                    totalLength, blockLength, nbt32, batch32, tileLen, p, mode, stream);
                launch_foreach_norm_finalize_batched_bfloat16(ws_ptr, y0, y1, y2, y3,
                    nbt32, batch32, p, mode, stream);
            } else {
                TORCH_CHECK(false, "foreach_norm: unsupported dtype.");
            }
            return 0;
        };
        at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);

        i += batch;
    }
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

} // namespace cann_bench
