/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file gelu_plugin.cpp
 * \brief Gelu API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/gelu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("gelu(Tensor x, str approximate=\"none\") -> Tensor");
}

torch::Tensor gelu_meta(const torch::Tensor &x, c10::string_view approximate)
{
    TORCH_CHECK(approximate == "none" || approximate == "tanh",
                "gelu: approximate must be 'none' or 'tanh'");
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 || x.scalar_type() == torch::kFloat16 ||
                    x.scalar_type() == torch::kBFloat16,
                "gelu: only float32, float16 and bfloat16 are supported");
    return torch::empty(x.sizes(), x.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("gelu", gelu_meta);
}

torch::Tensor gelu_npu(const torch::Tensor &x, c10::string_view approximate)
{
    const c10::OptionalDeviceGuard guard(x.device());
    TORCH_CHECK(approximate == "none" || approximate == "tanh",
                "gelu: approximate must be 'none' or 'tanh'");
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 || x.scalar_type() == torch::kFloat16 ||
                    x.scalar_type() == torch::kBFloat16,
                "gelu: only float32, float16 and bfloat16 are supported");

    auto xContiguous = x.contiguous();
    auto y = torch::empty(xContiguous.sizes(), xContiguous.options());
    int64_t totalLength = xContiguous.numel();
    if (totalLength == 0) {
        return y;
    }

    int32_t approxMode = (approximate == "tanh") ? 1 : 0;
    int64_t sizeofT = static_cast<int64_t>(xContiguous.element_size());
    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    int64_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_gelu_tiling_params(totalLength, sizeofT);

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    auto xPtr = (GM_ADDR)xContiguous.data_ptr();
    auto yPtr = (GM_ADDR)y.data_ptr();
    auto dtype = xContiguous.scalar_type();

    auto acl_call = [=]() -> int {
        if (dtype == torch::kFloat32) {
            launch_gelu_kernel_float(xPtr, yPtr, totalLength, numBlocks, blockLength,
                                     static_cast<uint32_t>(tileSize), approxMode, stream);
        } else if (dtype == torch::kFloat16) {
            launch_gelu_kernel_half(xPtr, yPtr, totalLength, numBlocks, blockLength,
                                    static_cast<uint32_t>(tileSize), approxMode, stream);
        } else {
            launch_gelu_kernel_bf16(xPtr, yPtr, totalLength, numBlocks, blockLength,
                                    static_cast<uint32_t>(tileSize), approxMode, stream);
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Gelu", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("gelu", gelu_npu);
}

} // namespace cann_bench
