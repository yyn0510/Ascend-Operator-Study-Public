/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file gelu_kernel.cpp
 * \brief Gelu kernel, tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int32_t APPROX_NONE = 0;
constexpr static int32_t APPROX_TANH = 1;

__aicore__ inline void GeluNoneFp32(const AscendC::LocalTensor<float> &dst,
                                    const AscendC::LocalTensor<float> &src,
                                    const AscendC::LocalTensor<float> &tmp1,
                                    const AscendC::LocalTensor<float> &tmp2,
                                    uint32_t count)
{
    constexpr float kP = 0.3275911f;
    constexpr float kA1 = 0.254829592f;
    constexpr float kA2 = -0.284496736f;
    constexpr float kA3 = 1.421413741f;
    constexpr float kA4 = -1.453152027f;
    constexpr float kA5 = 1.061405429f;
    constexpr float kInvSqrt2 = 0.7071067811865476f;
    constexpr float kNegHalf = -0.5f;
    constexpr float kExpClamp = -80.0f;
    constexpr float kAbsClamp = 16.0f;

    AscendC::Abs(tmp1, src, count);
    AscendC::Mins(tmp1, tmp1, kAbsClamp, count);
    AscendC::Muls(tmp2, tmp1, kInvSqrt2, count);
    AscendC::Muls(tmp2, tmp2, kP, count);
    AscendC::Adds(tmp2, tmp2, 1.0f, count);
    AscendC::Duplicate(dst, 1.0f, count);
    AscendC::Div(dst, dst, tmp2, count);

    AscendC::Muls(tmp2, dst, kA5, count);
    AscendC::Adds(tmp2, tmp2, kA4, count);
    AscendC::Mul(tmp2, tmp2, dst, count);
    AscendC::Adds(tmp2, tmp2, kA3, count);
    AscendC::Mul(tmp2, tmp2, dst, count);
    AscendC::Adds(tmp2, tmp2, kA2, count);
    AscendC::Mul(tmp2, tmp2, dst, count);
    AscendC::Adds(tmp2, tmp2, kA1, count);
    AscendC::Mul(tmp2, tmp2, dst, count);

    AscendC::Mul(dst, src, src, count);
    AscendC::Muls(dst, dst, kNegHalf, count);
    AscendC::Maxs(dst, dst, kExpClamp, count);
    AscendC::Exp(dst, dst, count);

    AscendC::Mul(tmp2, tmp2, dst, count);
    AscendC::Muls(tmp1, tmp1, 0.5f, count);
    AscendC::Mul(tmp1, tmp1, tmp2, count);
    AscendC::Maxs(dst, src, 0.0f, count);
    AscendC::Sub(dst, dst, tmp1, count);
}

__aicore__ inline void GeluTanhFp32(const AscendC::LocalTensor<float> &dst,
                                    const AscendC::LocalTensor<float> &src,
                                    const AscendC::LocalTensor<float> &tmp,
                                    uint32_t count)
{
    constexpr float kCoeff = 0.044715f;
    constexpr float kSqrt2OverPi = 0.7978845608028654f;

    AscendC::Mul(tmp, src, src, count);
    AscendC::Mul(tmp, tmp, src, count);
    AscendC::Muls(tmp, tmp, kCoeff, count);
    AscendC::Add(tmp, src, tmp, count);
    AscendC::Muls(tmp, tmp, kSqrt2OverPi, count);
    AscendC::Tanh(tmp, tmp, count);
    AscendC::Adds(tmp, tmp, 1.0f, count);
    AscendC::Muls(tmp, tmp, 0.5f, count);
    AscendC::Mul(dst, src, tmp, count);

    // PyTorch: 0.5*(-inf)*(1+tanh(-inf)) = (-inf)*0 = NaN. min(x,0)-min(x,0) yields NaN iff x is -inf.
    AscendC::Mins(tmp, src, 0.0f, count);
    AscendC::Sub(tmp, tmp, tmp, count);
    AscendC::Add(dst, dst, tmp, count);
}

template <typename T, int APPROX>
__aicore__ inline void ComputeGeluTile(const AscendC::LocalTensor<T> &xLocal,
                                       const AscendC::LocalTensor<T> &yLocal,
                                       AscendC::TBuf<AscendC::TPosition::VECCALC> &xCalcBuf,
                                       AscendC::TBuf<AscendC::TPosition::VECCALC> &innerBuf,
                                       AscendC::TBuf<AscendC::TPosition::VECCALC> &innerBuf2,
                                       AscendC::TBuf<AscendC::TPosition::VECCALC> &outCalcBuf,
                                       uint32_t count)
{
    if constexpr (sizeof(T) == sizeof(float)) {
        auto tmp1 = innerBuf.Get<float>();
        auto tmp2 = innerBuf2.Get<float>();
        auto dst = yLocal.template ReinterpretCast<float>();
        auto src = xLocal.template ReinterpretCast<float>();
        if constexpr (APPROX == APPROX_TANH) {
            GeluTanhFp32(dst, src, tmp1, count);
        } else {
            GeluNoneFp32(dst, src, tmp1, tmp2, count);
        }
    } else {
        auto xF = xCalcBuf.Get<float>();
        auto tmp1 = innerBuf.Get<float>();
        auto tmp2 = innerBuf2.Get<float>();
        auto yF = outCalcBuf.Get<float>();
        AscendC::Cast(xF, xLocal, AscendC::RoundMode::CAST_NONE, count);
        if constexpr (APPROX == APPROX_TANH) {
            GeluTanhFp32(yF, xF, tmp1, count);
        } else {
            GeluNoneFp32(yF, xF, tmp1, tmp2, count);
        }
        AscendC::Cast(yLocal, yF, AscendC::RoundMode::CAST_RINT, count);
    }
}

template <typename T, int APPROX>
__aicore__ inline void ProcessGeluTile(AscendC::GlobalTensor<T> &xGm,
                                       AscendC::GlobalTensor<T> &yGm,
                                       AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> &inQueueX,
                                       AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> &outQueueY,
                                       AscendC::TBuf<AscendC::TPosition::VECCALC> &xCalcBuf,
                                       AscendC::TBuf<AscendC::TPosition::VECCALC> &innerBuf,
                                       AscendC::TBuf<AscendC::TPosition::VECCALC> &innerBuf2,
                                       AscendC::TBuf<AscendC::TPosition::VECCALC> &outCalcBuf,
                                       int64_t offset,
                                       int64_t count)
{
    uint32_t copyBytes = static_cast<uint32_t>(count * sizeof(T));
    AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    auto xLocal = inQueueX.AllocTensor<T>();
    AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
    inQueueX.EnQue(xLocal);
    xLocal = inQueueX.DeQue<T>();

    auto yLocal = outQueueY.AllocTensor<T>();
    ComputeGeluTile<T, APPROX>(xLocal, yLocal, xCalcBuf, innerBuf, innerBuf2, outCalcBuf,
                               static_cast<uint32_t>(count));

    outQueueY.EnQue(yLocal);
    inQueueX.FreeTensor(xLocal);
    yLocal = outQueueY.DeQue<T>();
    AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
    outQueueY.FreeTensor(yLocal);
}

template <typename T, int APPROX>
__global__ __aicore__ void gelu_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> xCalcBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> innerBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> innerBuf2;
    AscendC::TBuf<AscendC::TPosition::VECCALC> outCalcBuf;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);

    uint32_t floatBufSize = static_cast<uint32_t>(tileSize / sizeof(T) * sizeof(float));
    pipe.InitBuffer(innerBuf, floatBufSize);
    pipe.InitBuffer(innerBuf2, floatBufSize);
    if constexpr (sizeof(T) != sizeof(float)) {
        pipe.InitBuffer(xCalcBuf, floatBufSize);
        pipe.InitBuffer(outCalcBuf, floatBufSize);
    }

    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t offsetBase = blockIdx * blockLength;
    if (offsetBase >= totalLength) {
        return;
    }
    int64_t currentBlockLength = totalLength - offsetBase;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    xGm.SetGlobalBuffer((__gm__ T *)x + offsetBase, currentBlockLength);
    yGm.SetGlobalBuffer((__gm__ T *)y + offsetBase, currentBlockLength);

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize / sizeof(T));
    if (elementNumPerTile < 8) {
        elementNumPerTile = 8;
    }
    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        ProcessGeluTile<T, APPROX>(xGm, yGm, inQueueX, outQueueY, xCalcBuf, innerBuf, innerBuf2, outCalcBuf, offset,
                                   elementNumPerTile);
    }
    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        ProcessGeluTile<T, APPROX>(xGm, yGm, inQueueX, outQueueY, xCalcBuf, innerBuf, innerBuf2, outCalcBuf, offset,
                                   tailTileElementNum);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_gelu_tiling_params(int64_t totalLength, int64_t sizeofT)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr int64_t ALIGN = 32;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 192 * 1024;
    int64_t coreNum = 48;
    if (ascendcPlatform != nullptr) {
        uint64_t queried = 0;
        ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, queried);
        if (queried > 0) {
            ubSize = queried;
        }
        int64_t n = ascendcPlatform->GetCoreNumAiv();
        if (n > 0) {
            coreNum = n;
        }
    }

    if (totalLength < 1) {
        totalLength = 1;
    }
    if (sizeofT < 2) {
        sizeofT = 4;
    }

    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    int64_t factor = (sizeofT == 4) ? 8 : 16;
    int64_t tileSize = static_cast<int64_t>(ubSize / static_cast<uint64_t>(factor));
    tileSize = tileSize / ALIGN * ALIGN;
    if (tileSize < 256) {
        tileSize = 256;
    }
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_gelu_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                              uint32_t tileSize, int32_t approximate, void *stream)
{
    if (approximate == APPROX_TANH) {
        gelu_kernel<float, APPROX_TANH><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
    } else {
        gelu_kernel<float, APPROX_NONE><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
    }
}

void launch_gelu_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, int32_t approximate, void *stream)
{
    if (approximate == APPROX_TANH) {
        gelu_kernel<half, APPROX_TANH><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
    } else {
        gelu_kernel<half, APPROX_NONE><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
    }
}

void launch_gelu_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, int32_t approximate, void *stream)
{
    if (approximate == APPROX_TANH) {
        gelu_kernel<bfloat16_t, APPROX_TANH><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
    } else {
        gelu_kernel<bfloat16_t, APPROX_NONE><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
    }
}

}
