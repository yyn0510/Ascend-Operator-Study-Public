# OpenCLIP可行性批次

状态：completed_with_ineligible_candidates

12个AI2D开发图像组及原问题文本仅用于输入校准。没有检索标签、正式任务分数或性能结论。
原生重复和两种包装对照必须保持输出完全一致，否则停止。候选不能通过宿主一致性时保留排除，不自动替换候选或调整阈值。

| 候选 | 准入阶段 | 通过/总数 | 准入 |
|---|---|---:|---|
| Grok_4_6_gelu_001_R4 | real_input_replay | 0/18 | False |
| Kimi_K3_gelu_002_R3 | real_input_replay | 0/18 | False |
| DeepSeek_V4_1_Flash_foreach_norm_002_R5 | real_input_replay | 6/6 | True |
| Grok_4_6_foreach_norm_003_R5 | real_input_replay | 6/6 | True |

返回包保留回放指标、模型输出误差、身份、协议、日志与来源代码；不含张量、权重、wheel和图片。完整张量与wheel留在云端结果目录。
若状态为stopped_requires_review，请连同结果包分析停止原因，不原地覆盖重跑。