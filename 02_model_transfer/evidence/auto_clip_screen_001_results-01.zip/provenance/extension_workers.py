"""Fresh-process NPU pilot workers. No generated source repair, fallback or task accuracy claims."""
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');tmp.replace(p)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def metrics(actual, reference, atol=1e-5,rtol=.016):
    import torch
    if actual.shape!=reference.shape or actual.dtype!=reference.dtype:
        return {'passed':False,'reason':'shape_or_dtype','shape':list(actual.shape),'dtype':str(actual.dtype)}
    a=actual.detach().cpu().double();b=reference.detach().cpu().double()
    if not bool(torch.isfinite(a).all() and torch.isfinite(b).all()):return {'passed':False,'reason':'nonfinite'}
    d=(a-b).abs();bad=d>atol+rtol*b.abs()
    return {'passed':not bool(bad.any()),'elements':a.numel(),'failed_elements':int(bad.sum()),'max_abs':d.max().item(),'mean_abs':d.mean().item(),'relative_l2':(torch.linalg.vector_norm(d)/torch.linalg.vector_norm(b).clamp_min(1e-30)).item(),'exact_equal':bool(torch.equal(actual.cpu(),reference.cpu()))}
def high_metrics(actual,reference):
    # Reference may be FP64; same mathematical criterion, without dtype compatibility gate.
    return metrics(actual.double(),reference.double())
def tensor_sha(t):
    return hashlib.sha256(t.detach().cpu().contiguous().view(__import__('torch').uint8).numpy().tobytes()).hexdigest()

def dispatch(action,cfg):
    sys.path.insert(0,cfg['harness'])
    if action=='preflight':return preflight(cfg)
    if action=='install':
        import subprocess
        receipt=read(cfg['receipt'])
        if sha(receipt['wheel'])!=receipt['wheel_sha256']:raise ValueError('Wheel modified')
        subprocess.run([sys.executable,'-m','pip','install','--force-reinstall','--no-deps',receipt['wheel']],check=True)
        return
    if action=='native':return native(cfg)
    if action=='control':return model_probe(cfg,control=True)
    if action=='gate':return gate(cfg)
    if action=='candidate':return model_probe(cfg,control=False)
    raise ValueError(action)

def preflight(cfg):
    from host import environment,record_device_status
    from common import load_rows
    from prepare_model import valid
    import transformers
    from transformers.models.clip import modeling_clip
    if transformers.__version__!='4.51.3':raise ValueError('Requires existing Transformers 4.51.3; do not upgrade original environment')
    env=environment(cfg['device'])
    prior=read(Path(cfg['old_root'])/'results/auto_formal_001/protocol.frozen.json')['environment']
    if env!=prior:raise ValueError('Current environment differs from original formal batch; review before running extension')
    if sha(modeling_clip.__file__)!=cfg['upstream_source_sha256']:raise ValueError('Unexpected Transformers CLIP source file')
    source=read(cfg['model_source']);checks={r['rfilename']:valid(Path(cfg['model'])/r['rfilename'],r) for r in source['siblings']}
    if not checks or not all(checks.values()):raise ValueError('Model file verification failed: '+str(checks))
    rows=load_rows(Path(cfg['old_root'])/'data/ai2d_100dev_1000eval/samples.jsonl')
    unique={}
    for r in rows:
        if r['split']=='dev':unique.setdefault(r['group_id'],r)
    if len(unique)<12:raise ValueError('Fewer than twelve dev image groups')
    selected=[]
    for g in sorted(unique)[:12]:
        r=unique[g];selected.append({'id':r['id'],'group_id':g,'image':str((Path(cfg['old_root'])/'data/ai2d_100dev_1000eval'/r['image']).resolve()),'image_sha256':r['image_sha256'],'text':r['question']})
    protocol=read(cfg['template'])
    protocol.update({'state':'frozen_pilot','environment':env,'model_files_sha256':{r['rfilename']:sha(Path(cfg['model'])/r['rfilename']) for r in source['siblings']},'calibration':selected,'source_code_sha256':{n:sha(Path(cfg['package'])/n) for n in ('run_extension_batch.py','extension_workers.py','clip_adapter.py')},'upstream_source_sha256':cfg['upstream_source_sha256']})
    protocol['fingerprint']=hashlib.sha256(json.dumps(protocol,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    save(cfg['output'],protocol);record_device_status(Path(cfg['output']).parent)
    print('FROZEN PILOT: 12 dev image groups; no task labels or quality scoring',flush=True)

def setup(cfg,candidate=False):
    import torch
    import torch_npu
    from host import environment
    from transformers import CLIPModel,CLIPProcessor
    from transformers.models.clip import modeling_clip
    p=read(cfg['protocol']);expected=p['fingerprint']
    if hashlib.sha256(json.dumps({k:v for k,v in p.items() if k!='fingerprint'},sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()!=expected:raise ValueError('Pilot protocol modified')
    if environment(cfg['device'])!=p['environment']:raise ValueError('Environment changed')
    for n,h in p['source_code_sha256'].items():
        if sha(Path(cfg['package'])/n)!=h:raise ValueError('Runner changed: '+n)
    if sha(modeling_clip.__file__)!=p['upstream_source_sha256']:raise ValueError('Host code changed')
    for n,h in p['model_files_sha256'].items():
        if sha(Path(cfg['model'])/n)!=h:raise ValueError('Model changed: '+n)
    identity=None
    if candidate:
        from common import verify_loaded
        identity=verify_loaded(cfg['candidate'],cfg['operator'],cfg['receipt'])
    torch.manual_seed(p['seed']);torch.npu.config.allow_internal_format=False;device=f'npu:{cfg["device"]}'
    model=CLIPModel.from_pretrained(cfg['model'],torch_dtype=torch.bfloat16,attn_implementation='eager',local_files_only=True).to(device).eval()
    processor=CLIPProcessor.from_pretrained(cfg['model'],local_files_only=True,use_fast=False)
    if model.config.text_config.hidden_act!='gelu' or model.config.vision_config.hidden_act!='gelu':raise ValueError('Checkpoint activation differs')
    return p,model,processor,device,identity

def inputs(p,processor,device):
    from PIL import Image
    import torch
    for start in range(0,len(p['calibration']),p['batch_size']):
        rows=p['calibration'][start:start+p['batch_size']];images=[]
        for row in rows:
            if sha(row['image'])!=row['image_sha256']:raise ValueError('Calibration image modified')
            with Image.open(row['image']) as im:images.append(im.convert('RGB'))
        batch=processor(images=images,text=[r['text'] for r in rows],padding='max_length',max_length=77,truncation=True,return_tensors='pt')
        cpu_hashes={k:{'shape':list(v.shape),'dtype':str(v.dtype),'sha256':tensor_sha(v)} for k,v in batch.items()}
        moved={k:v.to(device=device,dtype=torch.bfloat16) if v.is_floating_point() else v.to(device) for k,v in batch.items()}
        yield start//p['batch_size'],rows,moved,cpu_hashes

def output_tensors(output):
    return {k:getattr(output,k).detach().cpu() for k in ('image_embeds','text_embeds','logits_per_image','logits_per_text')}

def native(cfg):
    import torch
    from transformers.models.clip import modeling_clip
    p,model,processor,device,_=setup(cfg)
    out=Path(cfg['output']);out.mkdir(exist_ok=False,parents=True)
    allrecords=[];batches=[];current={};counter=0
    selected=set(p['capture_gelu_modules'])
    handles=[]
    def persist(operator,module,x,ref):
        nonlocal counter
        if not bool(torch.isfinite(x).all() and torch.isfinite(ref).all()):raise ValueError('Nonfinite native capture')
        directory=out/'captures'/operator;directory.mkdir(parents=True,exist_ok=True)
        name=f'{counter:04}.pt';counter+=1
        row={'file':name,'operator':operator,'module':module,'batch':current['batch'],'group_ids':current['groups'],'shape':list(x.shape),'dtype':str(x.dtype)}
        torch.save({'input':x.detach().cpu(),'reference':ref.detach().cpu()},directory/name)
        row['sha256']=sha(directory/name);allrecords.append(row)
    for name,module in model.named_modules():
        if name in selected:
            def hook(m,args,value,name=name):persist('gelu',name,args[0],value)
            handles.append(module.register_forward_hook(hook))
    if len(handles)!=6:raise ValueError('Expected six sampled GELU module hooks')
    original=modeling_clip._get_vector_norm
    def norm(x):
        value=original(x);persist('foreach_norm','final_feature_norm',x,value);return value
    modeling_clip._get_vector_norm=norm
    try:
        with torch.inference_mode():
            for i,rows,batch,hashes in inputs(p,processor,device):
                current.update({'batch':i,'groups':[r['group_id'] for r in rows]})
                values=output_tensors(model(**batch));batches.append({'batch':i,'inputs':hashes,'values':values})
                print('NATIVE CAPTURE BATCH',i,flush=True)
    finally:
        modeling_clip._get_vector_norm=original
        for h in handles:h.remove()
    torch.save(batches,out/'outputs.pt')
    for operator in ('gelu','foreach_norm'):
        rows=[r for r in allrecords if r['operator']==operator]
        save(out/'captures'/operator/'index.json',{'protocol_sha256':sha(cfg['protocol']),'records':rows})
    save(out/'status.json',{'status':'completed','batches':len(batches),'images':12,'gelu_records':sum(r['operator']=='gelu' for r in allrecords),'norm_records':sum(r['operator']=='foreach_norm' for r in allrecords)})

def model_probe(cfg,control):
    import contextlib
    import torch
    from clip_adapter import clip_norm_scope,install_clip_gelu
    p,model,processor,device,identity=setup(cfg,candidate=not control)
    out=Path(cfg['output']);out.mkdir(exist_ok=False,parents=True)
    native=torch.load(Path(cfg['native'])/'outputs.pt',weights_only=True,map_location='cpu')
    calls={};target_list=[]
    if not control:
        import cann_bench
    if cfg['operator']=='gelu':
        implementation=(lambda x,a:torch.nn.functional.gelu(x,approximate=a)) if control else cann_bench.gelu
        target_list=install_clip_gelu(model,implementation)
    scope=clip_norm_scope(None,'wrapper') if control and cfg['operator']=='foreach_norm' else (clip_norm_scope(cann_bench.foreach_norm) if not control and cfg['operator']=='foreach_norm' else contextlib.nullcontext([]))
    batches=[];report={'scope':'calibration output drift only; these questions are not caption-retrieval labels','identity':identity,'batches':[]}
    with scope as norm_calls,torch.inference_mode():
        for i,rows,batch,hashes in inputs(p,processor,device):
            if hashes!=native[i]['inputs']:raise ValueError('Processor inputs differ from baseline')
            actual=output_tensors(model(**batch));scores={k:metrics(actual[k],native[i]['values'][k]) for k in actual}
            if control and not all(s.get('exact_equal',False) for s in scores.values()):
                save(out/'control_failure.json',scores);raise ValueError('Native repeat or wrapper changes output; stop before candidates')
            if not control and any(s.get('reason')=='nonfinite' for s in scores.values()):
                save(out/'nonfinite_output.json',scores);raise ValueError('Nonfinite candidate model output requires review')
            report['batches'].append({'batch':i,'comparisons':scores});batches.append({'batch':i,'values':actual})
    if cfg['operator']=='gelu':
        calls={n:m.calls for n,m in model.named_modules() if type(m).__name__=='CandidateGelu'}
        if len(calls)!=24 or any(v!=3 for v in calls.values()):raise ValueError('Not all GELU targets executed')
    elif cfg['operator']=='foreach_norm':
        calls={'final_norm_invocations':len(norm_calls)}
        if len(norm_calls)!=6:raise ValueError('Expected six normalization calls')
    report['calls']=calls;report['gelu_targets']=target_list
    torch.save(batches,out/'outputs.pt');save(out/'comparison.json',report)
    save(out/'status.json',{'status':'completed','control_exact':True if control else None,'note':'No task accuracy or retrieval score is computed'})

def gate(cfg):
    import torch
    import torch_npu
    import cann_bench
    from host import environment
    from common import verify_loaded
    from clip_adapter import rowwise_foreach_norm
    p=read(cfg['protocol'])
    expected=p['fingerprint']
    if hashlib.sha256(json.dumps({k:v for k,v in p.items() if k!='fingerprint'},sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()!=expected:raise ValueError('Pilot protocol modified')
    if p['tolerance']!={'atol':1e-5,'rtol':.016}:raise ValueError('Unexpected tolerance')
    torch.npu.config.allow_internal_format=False
    # Validate frozen runner/model/environment before replay as well.
    env=environment(cfg['device'])
    if env!=p['environment']:raise ValueError('Replay environment changed')
    for n,h in p['source_code_sha256'].items():
        if sha(Path(cfg['package'])/n)!=h:raise ValueError('Runner changed')
    identity=verify_loaded(cfg['candidate'],cfg['operator'],cfg['receipt'])
    from transformers.models.clip import modeling_clip
    if sha(modeling_clip.__file__)!=p['upstream_source_sha256']:raise ValueError('Host source changed')
    directory=Path(cfg['captures']);index=read(directory/'index.json')
    if index['protocol_sha256']!=sha(cfg['protocol']):raise ValueError('Capture contract mismatch')
    out=Path(cfg['output']);out.mkdir(exist_ok=False,parents=True)
    result={'candidate_id':cfg['candidate'],'identity':identity,'criterion':p['tolerance'],'records':[],'index_sha256':sha(directory/'index.json')}
    timings=[]
    with torch.inference_mode():
        for row in index['records']:
            path=directory/row['file']
            if sha(path)!=row['sha256']:raise ValueError('Capture changed')
            data=torch.load(path,weights_only=True,map_location='cpu');x=data['input'].to(f'npu:{cfg["device"]}');reference=data['reference']
            if cfg['operator']=='gelu':
                functions={'native':lambda:torch.nn.functional.gelu(x,approximate='none'),'wrapper':lambda:torch.nn.functional.gelu(x,approximate='none'),'candidate':lambda:cann_bench.gelu(x,'none')}
                xd=data['input'].double();high=.5*xd*torch.erfc(-xd/(2.**.5))
            else:
                functions={'native':lambda:modeling_clip._get_vector_norm(x),'wrapper':lambda:rowwise_foreach_norm(x,lambda xs,p:[modeling_clip._get_vector_norm(v).reshape(()) for v in xs]),'candidate':lambda:rowwise_foreach_norm(x,cann_bench.foreach_norm)}
                high=torch.linalg.vector_norm(data['input'].double(),ord=2,dim=-1,keepdim=True)
            comparisons={};values={}
            for mode,fn in functions.items():
                values[mode]=fn().detach().cpu();comparisons[mode]=metrics(values[mode],reference)
                if mode!='candidate' and not comparisons[mode].get('exact_equal'):
                    save(out/'control_failure.json',{'record':row,'comparisons':comparisons});raise ValueError('Replay control differs from capture')
            item={'capture':row,'comparisons':comparisons,'formula_reference':{'native':high_metrics(values['native'],high),'candidate':high_metrics(values['candidate'],high)},'formula_reference_is_not_host_eligibility':True}
            result['records'].append(item);save(out/'replay.json',result)
        result['passed']=sum(r['comparisons']['candidate']['passed'] for r in result['records']);result['total']=len(result['records']);result['eligible']=result['total']>0 and result['passed']==result['total']
        save(out/'replay.json',result);save(out/'eligibility.json',{k:result[k] for k in ('eligible','passed','total')})
    print('HOST ELIGIBILITY',result['passed'],'/',result['total'],flush=True)
