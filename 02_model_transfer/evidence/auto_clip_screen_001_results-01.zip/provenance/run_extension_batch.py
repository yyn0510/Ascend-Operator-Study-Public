"""One-command detached CLIP feasibility batch. No formal retrieval evaluation or package upgrades."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback
import zipfile
from run_transfer_batch import Batch,read,write,sha,ensure_benchmark

HERE=Path(__file__).resolve().parent
CANDIDATES=[('Grok_4_6_gelu_001_R4','gelu'),('Kimi_K3_gelu_002_R3','gelu'),('DeepSeek_V4_1_Flash_foreach_norm_002_R5','foreach_norm'),('Grok_4_6_foreach_norm_003_R5','foreach_norm')]

def verified_package():
    files=read(HERE/'PACKAGE_MANIFEST.json')
    for name,info in files.items():
        path=(HERE/name).resolve()
        if not path.is_relative_to(HERE) or not path.is_file() or sha(path)!=info['sha256'] or path.stat().st_size!=info['bytes']:
            raise ValueError('Package integrity failed: '+name)

class ExtensionBatch(Batch):
    def __init__(self,args):
        self.a=args;self.old=args.old_root.resolve();self.out=(self.old/args.output).resolve()
        if not self.out.is_relative_to(self.old/'results'):raise ValueError('Output must stay inside old experiment results')
        self.out.mkdir(parents=True,exist_ok=False)
        self.root=self.out/'harness';shutil.copytree(HERE/'harness',self.root)
        self.protocol=self.out/'protocol.pilot.json'
        self.state={'status':'running','started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'scope':'Fixed CLIP checkpoint, 12 unique AI2D dev images and question texts for calibration only; no task quality score; four unchanged V3 candidates','steps':[],'eligibility':{},'comparisons':{},'error':None}
        self.save()
    def task(self,name,action,**cfg):
        request={'harness':str(self.root),'package':str(HERE),'old_root':str(self.old),'model':str(self.a.model_path.resolve()),'device':self.a.device_id,'protocol':str(self.protocol),**cfg}
        path=self.out/'requests'/(name+'.json');write(path,request)
        self.command(name,[sys.executable,HERE/'run_extension_batch.py','--worker',action,'--request',path])
    def run(self):
        self.task('preflight','preflight',template=str(HERE/'protocol.screen.json'),model_source=str(HERE/'model_source.api.json'),upstream_source_sha256=read(HERE/'protocol.screen.json')['upstream_source_sha256'],output=str(self.protocol))
        native=self.out/'native_capture'
        self.task('native_capture','native',output=str(native))
        for mode in ('native','gelu','foreach_norm'):
            self.task('control_'+mode,'control',operator=mode,native=str(native),output=str(self.out/('control_'+mode)))
        for cid,operator in CANDIDATES:
            build=self.out/('build_'+cid)
            self.job('build_'+cid,'build_candidate.py',['--candidate-id',cid,'--soc',self.a.soc,'--device-id',self.a.device_id,'--output',build])
            receipt=build/'receipt.json';verify=self.out/('verify_'+cid)
            self.job('verify_'+cid,'verify_benchmark.py',['--candidate-id',cid,'--operator',operator,'--receipt',receipt,'--device-id',self.a.device_id,'--output',verify])
            reports=sorted((verify/'reports').glob('*_eval_*.json'))
            if len(reports)!=1:raise ValueError('Original benchmark report missing/ambiguous')
            report=read(reports[0])
            if report.get('total_cases')!=20:raise ValueError('Unexpected original benchmark denominator')
            if report.get('passed_cases')!=20:
                self.state['eligibility'][cid]={'eligible':False,'stage':'original_benchmark','passed':report.get('passed_cases'),'total':20};self.save();continue
            ensure_benchmark(verify)
            replay=self.out/('replay_'+cid)
            self.task('gate_'+cid,'gate',operator=operator,candidate=cid,receipt=str(receipt),captures=str(native/'captures'/operator),output=str(replay))
            gate=read(replay/'eligibility.json');self.state['eligibility'][cid]={**gate,'stage':'real_input_replay'};self.save()
            if not gate['eligible']:continue
            probe=self.out/('candidate_'+cid)
            self.task('candidate_'+cid,'candidate',operator=operator,candidate=cid,receipt=str(receipt),native=str(native),output=str(probe))
            self.state['comparisons'][cid]=read(probe/'comparison.json');self.save()
        self.state['status']='completed' if all(v['eligible'] for v in self.state['eligibility'].values()) else 'completed_with_ineligible_candidates'
        self.save()
    def package(self):
        self.state['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());self.save()
        lines=['# OpenCLIP可行性批次','',f'状态：{self.state["status"]}','','12个AI2D开发图像组及原问题文本仅用于输入校准。没有检索标签、正式任务分数或性能结论。','原生重复和两种包装对照必须保持输出完全一致，否则停止。候选不能通过宿主一致性时保留排除，不自动替换候选或调整阈值。','','| 候选 | 准入阶段 | 通过/总数 | 准入 |','|---|---|---:|---|']
        for cid,r in self.state['eligibility'].items():lines.append(f'| {cid} | {r["stage"]} | {r["passed"]}/{r["total"]} | {r["eligible"]} |')
        lines+=['','返回包保留回放指标、模型输出误差、身份、协议、日志与来源代码；不含张量、权重、wheel和图片。完整张量与wheel留在云端结果目录。','若状态为stopped_requires_review，请连同结果包分析停止原因，不原地覆盖重跑。']
        (self.out/'SUMMARY.md').write_text('\n'.join(lines),encoding='utf-8')
        members={}
        for path in sorted(self.out.rglob('*')):
            rel=path.relative_to(self.out)
            if not path.is_file() or any(p in ('build','dist','__pycache__') or p.endswith('.egg-info') for p in rel.parts):continue
            if path.suffix not in ('.json','.jsonl','.md','.log','.txt','.py','.cpp','.h','.yaml','.csv','.toml','.sh') and path.name not in ('LICENSE','VERSION'):continue
            members['batch/'+rel.as_posix()]=path
        for name in ('run_extension_batch.py','extension_workers.py','clip_adapter.py','protocol.screen.json','model_source.api.json','PACKAGE_MANIFEST.json','run_transfer_batch.py'):
            members['provenance/'+name]=HERE/name
        manifest={name:{'sha256':sha(path),'bytes':path.stat().st_size} for name,path in members.items()}
        archive=self.a.model_path.resolve().parent/(self.out.name+'_results.zip')
        tmp=archive.with_suffix('.zip.part')
        if archive.exists() or tmp.exists():raise FileExistsError('Refusing to overwrite existing result archive')
        with zipfile.ZipFile(tmp,'x',compression=zipfile.ZIP_DEFLATED) as z:
            for name,path in members.items():z.write(path,name)
            z.writestr('EXPORT_MANIFEST.json',json.dumps(manifest,indent=2))
        tmp.rename(archive)
        print(f'BATCH_STATUS: {self.state["status"]}\nDOWNLOAD: {archive}',flush=True)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--old-root',type=Path,default=Path('/mnt/workspace/v3_model_transfer'))
    p.add_argument('--model-path',type=Path,default=Path('/mnt/workspace/gitCode/cann/cann-learning-hub/build/CLIP-ViT-B-32-laion2B-s34B-b79K'))
    p.add_argument('--output',type=Path,default=Path('results/auto_clip_screen_001'))
    p.add_argument('--soc',default='ascend910b',choices=['ascend910b','ascend910_93','ascend950'])
    p.add_argument('--device-id',type=int,default=0)
    p.add_argument('--timeout',type=int,default=3600)
    p.add_argument('--background',action='store_true')
    p.add_argument('--plan',action='store_true')
    p.add_argument('--worker',choices=['preflight','install','native','control','gate','candidate'],help=argparse.SUPPRESS)
    p.add_argument('--request',type=Path,help=argparse.SUPPRESS)
    a=p.parse_args()
    if a.worker:
        from extension_workers import dispatch
        dispatch(a.worker,read(a.request));return 0
    if a.plan:
        print(json.dumps({'candidates':CANDIDATES,'calibration_image_groups':12,'batch_size':4,'formal_task_evaluation':False,'timing':False,'on_failure':'stop infrastructure/control errors; record candidate ineligibility without fallback','model':str(a.model_path)},indent=2));return 0
    if os.name!='posix':raise RuntimeError('Run actual workers on Linux Ascend NPU; --plan is offline')
    verified_package()
    if a.background:
        out=(a.old_root.resolve()/a.output).resolve()
        if not out.is_relative_to(a.old_root.resolve()/'results'):raise ValueError('Unsafe output path')
        if out.exists():raise FileExistsError(out)
        console=out.with_suffix('.console.log');console.parent.mkdir(parents=True,exist_ok=True)
        with console.open('x',encoding='utf-8') as f:
            child=subprocess.Popen([sys.executable,'-u',str(HERE/'run_extension_batch.py'),*[s for s in sys.argv[1:] if s!='--background']],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,cwd=HERE,start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1'))
        print(f'BACKGROUND_PID: {child.pid}\nLOG: {console}\nDOWNLOAD_WHEN_FINISHED: {a.model_path.resolve().parent / (out.name+"_results.zip")}');return 0
    import fcntl
    with (a.old_root.resolve()/'.transfer_batch.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('Another old/extension batch is running; no concurrent wheel installation') from None
        batch=ExtensionBatch(a);code=0
        def stop(signum,frame):raise KeyboardInterrupt(f'Received signal {signum}')
        signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
        try:batch.run()
        except BaseException:
            batch.state.update({'status':'stopped_requires_review','error':traceback.format_exc()});print(batch.state['error'],flush=True);code=1
        finally:batch.package()
        return code
if __name__=='__main__':raise SystemExit(main())
