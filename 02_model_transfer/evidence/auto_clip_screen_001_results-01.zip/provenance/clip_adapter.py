"""Explicit CLIP inference adapters. No candidate implementation or fallback is supplied here."""
from contextlib import contextmanager
import torch


def rowwise_foreach_norm(features, implementation):
    """Map [B,D] to equal-length TensorList; keep all results on the original device."""
    if features.ndim != 2 or not features.is_floating_point() or min(features.shape) == 0:
        raise ValueError('Expected nonempty floating-point [B,D] features')
    values = implementation(list(features.unbind(0)), 2.0)
    if len(values) != features.shape[0]:
        raise ValueError('Wrong TensorList length')
    if any(v.numel() != 1 or v.device != features.device or v.dtype != features.dtype for v in values):
        raise ValueError('Norm results must be same-device, same-dtype scalars')
    return torch.stack([v.reshape(()) for v in values]).reshape(-1, 1)


@contextmanager
def clip_norm_scope(implementation, mode='candidate'):
    """Replace only HF CLIP's private helper in one sequential inference process.

    This scope is not thread-safe. Never use it for concurrent different modes.
    Native division, scale and logits remain in the unchanged upstream forward.
    """
    from transformers.models.clip import modeling_clip
    original = modeling_clip._get_vector_norm
    calls = []
    if mode not in ('candidate', 'wrapper'):
        raise ValueError(mode)
    def replacement(features):
        calls.append({'shape': list(features.shape), 'dtype': str(features.dtype), 'mode': mode})
        if mode == 'wrapper':
            # Keep native arithmetic, including BF16 intermediate rounding.
            def native_rows(xs, p):
                return [original(x).reshape(()) for x in xs]
            return rowwise_foreach_norm(features, native_rows)
        return rowwise_foreach_norm(features, implementation)
    modeling_clip._get_vector_norm = replacement
    try:
        yield calls
    finally:
        modeling_clip._get_vector_norm = original


class CandidateGelu(torch.nn.Module):
    def __init__(self, implementation, approximate='none'):
        super().__init__()
        if approximate not in ('none', 'tanh'):
            raise ValueError(approximate)
        self.implementation = implementation
        self.approximate = approximate
        self.calls = 0
    def forward(self, x):
        self.calls += 1
        return self.implementation(x, self.approximate)


def install_clip_gelu(model, implementation):
    from transformers.models.clip.modeling_clip import CLIPMLP
    from transformers.activations import GELUActivation
    if model.config.model_type != 'clip':
        raise ValueError('Only the inspected HF CLIP model is supported')
    for config in (model.config.text_config, model.config.vision_config):
        if config.hidden_act != 'gelu':
            raise ValueError('Checkpoint does not use exact GELU; no silent QuickGELU conversion')
    targets=[]
    for name, module in model.named_modules():
        if isinstance(module, CLIPMLP):
            if not isinstance(module.activation_fn, GELUActivation):
                raise ValueError('Unexpected activation class')
            module.activation_fn = CandidateGelu(implementation, 'none')
            targets.append(name+'.activation_fn')
    if not targets:
        raise ValueError('No GELU targets')
    return targets
