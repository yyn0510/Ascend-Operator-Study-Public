"""One-command DEVELOPMENT batch; delegates to the unchanged V3 transfer runners.

Upload this file separately. No kernel edits, package upgrades, tolerance selection,
formal held-out evaluation, or performance claims are made by this batch.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
import zipfile


CANDIDATES = [
    ('Grok_4_6_gelu_001_R4', 'gelu', 'build_grok_gelu_001', 'verify_grok_gelu_001'),
    ('Kimi_K3_gelu_002_R3', 'gelu', 'build_kimi_gelu_001', 'verify_kimi_gelu_001'),
    ('Kimi_K3_swi_glu_003_R5', 'swi_glu', 'build_kimi_swiglu_001', 'verify_kimi_swiglu_001'),
    ('DeepSeek_V4_1_Flash_swi_glu_002_R4', 'swi_glu', None, None),
]
PRIOR = [
    'environment_001', 'host_inventory_001', 'native_pilot1_001',
    'native_gelu_capture10_001', 'native_pilot10_repeat_001',
    'wrapper_gelu_pilot10_001', 'kimi_gelu_pilot10_001',
    'kimi_gelu_pilot10_repeat_001', 'kimi_gelu_real_inputs_diagnostic_001.json',
] + [name for _, _, b, v in CANDIDATES for name in (b, v) if name]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    temp.replace(path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def ensure_benchmark(path):
    reports = sorted((Path(path) / 'reports').glob('*_eval_*.json'))
    if len(reports) != 1:
        raise ValueError(f'Expected one original benchmark report: {path}')
    report = read(reports[0])
    if report.get('total_cases') != 20 or report.get('passed_cases') != 20:
        raise ValueError(f'Original benchmark is not 20/20: {reports[0]}')
    return {'report': str(reports[0]), 'sha256': sha(reports[0]), 'passed': 20, 'total': 20}


def worker(action, cfg):
    """Each worker gets a fresh Python process and installed candidate identity."""
    root = Path(cfg['root'])
    sys.path.insert(0, str(root))
    os.chdir(root)
    if action == 'preflight':
        from prepare_model import valid
        from common import load_rows, load_protocol
        from host import environment, runner_hashes
        model = Path(cfg['model'])
        source = read(root / 'model_source.api.json')
        checks = {r['rfilename']: valid(model / r['rfilename'], r)
                  for r in source['siblings'] if r['rfilename'] != '.gitattributes'}
        if not checks or not all(checks.values()):
            raise ValueError(f'Model verification failed: {checks}')
        rows = load_rows(root / 'data/ai2d_100dev_1000eval/samples.jsonl')
        counts = {s: sum(r['split'] == s for r in rows) for s in ('dev', 'eval')}
        if counts != {'dev': 100, 'eval': 1000}:
            raise ValueError(f'Unexpected dataset: {counts}')
        protocol = load_protocol(Path(cfg['protocol']), 'dev')
        if protocol['state'] != 'draft':
            raise ValueError('This batch expects the development protocol')
        import transformers
        if transformers.__version__ != '4.51.3':
            raise ValueError('Unexpected Transformers version')
        result = {'environment': environment(cfg['device']), 'runner_sha256': runner_hashes(),
                  'model_revision': source['sha'], 'verified_model_files': checks,
                  'dataset_counts': counts, 'dev_image_groups': len({r['group_id'] for r in rows if r['split'] == 'dev'})}
        write(cfg['output'], result)
        return
    if action == 'install':
        from common import verify_project, verify_loaded
        receipt = read(cfg['receipt'])
        row = next(r for r in read(root / 'candidates.json') if r['candidate_id'] == cfg['candidate'])
        project = verify_project(root / 'projects' / cfg['candidate'], row)
        for rel, expected in read(root / 'files.sha256.json').items():
            if rel.startswith('projects/' + cfg['candidate'] + '/') and sha(root / rel) != expected:
                raise ValueError(f'Candidate source changed: {rel}')
        if receipt['candidate_id'] != cfg['candidate'] or receipt['soc'] != cfg['soc']:
            raise ValueError('Candidate or SoC differs from receipt')
        wheel = Path(receipt['wheel'])
        if sha(wheel) != receipt['wheel_sha256']:
            raise ValueError('Candidate wheel hash mismatch')
        if Path(receipt['project']).resolve() != project.resolve():
            raise ValueError('Receipt project path differs')
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--force-reinstall', '--no-deps', str(wheel)], check=True)
        write(cfg['output'], verify_loaded(cfg['candidate'], cfg['operator'], cfg['receipt']))
        return
    if action == 'numerics':
        import torch
        import torch_npu
        import cann_bench
        from common import verify_loaded, load_protocol
        from host import environment
        from numerics import capture_index, check_capture_source, functions
        identity = verify_loaded(cfg['candidate'], cfg['operator'], cfg['receipt'])
        path = Path(cfg['inputs'])
        rows, source = capture_index(path, cfg['operator'])
        check_capture_source(load_protocol(Path(cfg['protocol'])), source, environment(cfg['device']))
        data_result = {'candidate_id': cfg['candidate'], 'operator': cfg['operator'], 'identity': identity,
                       'capture_index_sha256': sha(path / 'index.jsonl'), 'capture_source': source,
                       'criterion': 'descriptive only; no pass tolerance selected', 'records': []}
        kernel = getattr(cann_bench, cfg['operator'])
        with torch.inference_mode():
            for row in rows:
                data = torch.load(path / row['file'], map_location='cpu', weights_only=True)
                if data['attrs'] != row['attrs'] or data['operator'] != cfg['operator']:
                    raise ValueError('Capture tensor/index mismatch')
                xs = [x.to(f"npu:{cfg['device']}") for x in data['inputs']]
                ref_raw = data['reference']
                if not bool(torch.isfinite(ref_raw).all()):
                    raise ValueError('Nonfinite host reference requires review')
                ref = ref_raw.float()
                item = {k: row[k] for k in ('file', 'sample_id', 'group_id', 'shape', 'dtype', 'module', 'phase', 'attrs')}
                fns = functions(cfg['operator'], xs, data['attrs'], kernel)
                for name in ('native', 'wrapper', 'candidate'):
                    actual = fns[name]().detach().cpu()
                    if actual.shape != ref_raw.shape or actual.dtype != ref_raw.dtype:
                        raise ValueError('Output shape/dtype mismatch')
                    if not bool(torch.isfinite(actual).all()):
                        raise ValueError('Nonfinite candidate/control output requires review')
                    diff = (actual.float() - ref).abs()
                    item[name] = {'max_abs': diff.max().item(), 'mean_abs': diff.mean().item(),
                                  'p99_abs': torch.quantile(diff.reshape(-1), .99).item(),
                                  'relative_l2': (torch.linalg.vector_norm(diff) / torch.linalg.vector_norm(ref).clamp_min(1e-12)).item(),
                                  'unequal_fraction': (actual != ref_raw).float().mean().item(), 'finite': True}
                data_result['records'].append(item)
                write(cfg['output'], data_result)
                print(f"Numerics {len(data_result['records'])}/{len(rows)}: {row['file']}", flush=True)
        return
    raise ValueError(action)


class Batch:
    def __init__(self, args):
        self.a = args
        self.root = args.root.resolve()
        self.out = (self.root / args.output).resolve()
        if not self.out.is_relative_to(self.root / 'results'):
            raise ValueError('Batch output must stay inside the experiment results directory')
        self.out.mkdir(parents=True, exist_ok=False)
        self.protocol = self.out / 'protocol.dev.json'
        self.protocol.write_bytes((self.root / 'protocol.template.json').read_bytes())
        self.state = {'status': 'running', 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                      'scope': '100 dev questions; 10-question captures; four fixed candidates; no held-out eval or timing',
                      'steps': [], 'comparisons': {}, 'benchmark_checks': {}, 'artifacts': {}, 'error': None}
        self.save()

    def save(self):
        write(self.out / 'batch_status.json', self.state)

    def command(self, name, command, timeout=None):
        item = {'name': name, 'command': [str(x) for x in command], 'status': 'running', 'start_unix': time.time()}
        self.state['steps'].append(item)
        self.save()
        print(f'[{len(self.state["steps"]):02}] START {name}', flush=True)
        log_path = self.out / 'logs' / (name + '.log')
        log_path.parent.mkdir(exist_ok=True)
        proc = None
        try:
            with log_path.open('w', encoding='utf-8') as log:
                proc = subprocess.Popen(item['command'], cwd=self.root, stdout=log, stderr=subprocess.STDOUT,
                                        env=dict(os.environ, PYTHONUNBUFFERED='1'), start_new_session=True)
                deadline = time.monotonic() + (timeout or self.a.timeout)
                last_ping = time.monotonic()
                while proc.poll() is None:
                    if time.monotonic() >= deadline:
                        raise TimeoutError(f'Stage time limit: {name}')
                    if time.monotonic() - last_ping >= 60:
                        print(f'    RUNNING {name}; log={log_path.name}', flush=True)
                        last_ping = time.monotonic()
                    time.sleep(1)
                item['returncode'] = proc.returncode
                if proc.returncode:
                    raise RuntimeError(f'Stage failed: {name}; see {log_path}')
            item['status'] = 'completed'
            print(f'    DONE {name}', flush=True)
        except BaseException:
            if proc is not None and proc.poll() is None:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
            item['status'] = 'failed'
            if log_path.exists():
                print('\n'.join(log_path.read_text(encoding='utf-8', errors='replace').splitlines()[-25:]), flush=True)
            raise
        finally:
            item['end_unix'] = time.time()
            self.save()

    def job(self, name, script, args):
        self.command(name, [sys.executable, self.root / script, *map(str, args)])

    def task(self, name, action, **cfg):
        config = {'root': str(self.root), 'model': str(self.a.model_path.resolve()),
                  'protocol': str(self.protocol), 'device': self.a.device_id, 'soc': self.a.soc, **cfg}
        path = self.out / 'requests' / (name + '.json')
        write(path, config)
        self.command(name, [sys.executable, Path(__file__).resolve(), '--worker', action, '--request', path])

    def quality(self, name, mode='native', operator='gelu', capture=False, candidate=None, receipt=None):
        output = self.out / name
        cmd = ['--protocol', self.protocol, '--model-path', self.a.model_path.resolve(),
               '--samples', self.root / 'data/ai2d_100dev_1000eval/samples.jsonl', '--split', 'dev',
               '--mode', mode, '--operator', operator, '--device-id', self.a.device_id, '--output', output]
        if capture:
            cmd += ['--capture', '--max-samples', 10]
        if candidate:
            cmd += ['--candidate-id', candidate, '--receipt', receipt]
        self.job(name, 'run_npu.py', cmd)
        status = read(output / 'status.json')
        if status.get('status') != 'completed' or status.get('samples') != (10 if capture else 100):
            raise ValueError(f'Incomplete quality run: {name}')
        self.state['artifacts'][name] = str(output)
        self.save()
        return output

    def paired(self, label, baseline, other):
        output = self.out / 'comparisons' / (label + '.json')
        output.parent.mkdir(exist_ok=True)
        self.job('score_' + label, 'score.py', ['--baseline', baseline / 'predictions.jsonl',
                 '--candidate', other / 'predictions.jsonl', '--samples',
                 self.root / 'data/ai2d_100dev_1000eval/samples.jsonl', '--split', 'dev', '--output', output])
        self.state['comparisons'][label] = read(output)
        self.save()
        return self.state['comparisons'][label]

    def run(self):
        self.job('bundle_integrity', 'verify_bundle.py', [])
        self.task('preflight', 'preflight', output=str(self.out / 'preflight.json'))
        baseline = self.quality('native_dev100')
        captures = {}
        for op in ('gelu', 'swi_glu'):
            # Fresh captures for this batch keep model/data/runner provenance together.
            cap = self.quality('capture_' + op + '_dev10', operator=op, capture=True)
            captures[op] = cap / 'inputs'
            control = self.quality('wrapper_' + op + '_dev100', mode='wrapper', operator=op)
            comparison = self.paired('wrapper_' + op, baseline, control)
            if comparison['changed_valid_answers'] or comparison['candidate_failed'] or comparison['candidate_invalid_answer']:
                raise ValueError(f'{op} wrapper control differs from native; review before candidate runs')
        for cid, op, old_build, old_verify in CANDIDATES:
            build = self.root / 'results' / old_build if old_build else self.out / ('build_' + cid)
            receipt = build / 'receipt.json'
            if not receipt.is_file():
                if build.exists():
                    raise ValueError(f'Incomplete existing build requires review: {build}')
                self.job('build_' + cid, 'build_candidate.py', ['--candidate-id', cid, '--soc', self.a.soc,
                         '--device-id', self.a.device_id, '--output', build])
            if read(build / 'status.json').get('status') != 'built_installed_identity_verified':
                raise ValueError(f'Build did not complete: {build}')
            self.task('install_' + cid, 'install', candidate=cid, operator=op, receipt=str(receipt),
                      output=str(self.out / ('identity_' + cid + '.json')))
            original = self.root / 'results' / old_verify if old_verify else self.out / ('verify_' + cid)
            if not original.exists():
                self.job('verify_' + cid, 'verify_benchmark.py', ['--candidate-id', cid, '--operator', op,
                         '--receipt', receipt, '--device-id', self.a.device_id, '--output', original])
            self.state['benchmark_checks'][cid] = ensure_benchmark(original)
            self.state['artifacts']['build_' + cid] = str(build)
            self.state['artifacts']['verify_' + cid] = str(original)
            self.save()
            self.task('numerics_' + cid, 'numerics', candidate=cid, operator=op, receipt=str(receipt),
                      inputs=str(captures[op]), output=str(self.out / ('numerics_' + cid + '.json')))
            result = self.quality('candidate_' + cid + '_dev100', 'candidate', op, candidate=cid, receipt=receipt)
            self.paired(cid, baseline, result)
        self.state['status'] = 'completed'

    def package(self):
        self.state['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        self.save()
        lines = ['# 真实模型替换：开发阶段批处理结果', '', '状态：' + self.state['status'], '',
                 '本批使用100道开发题。正式1000道留出评测未运行；未测量性能；未按观察误差反推通过阈值。', '',
                 '数值误差仅作描述统计，不能视作精度认证。运行失败时停止，保留全部已完成与部分结果。', '',
                 '| 配置 | 原模型准确率 | 本配置准确率 | 差值（百分点） | 答案变化 | 图像组数 |',
                 '|---|---:|---:|---:|---:|---:|']
        csv_rows = []
        for label, result in self.state['comparisons'].items():
            lines.append(f"| {label} | {result['baseline_accuracy']:.2%} | {result['candidate_accuracy']:.2%} | "
                         f"{result['difference_percentage_points']:+.2f} | {result['changed_valid_answers']} | {result['image_groups']} |")
            csv_rows.append({'configuration': label, **{k: v for k, v in result.items() if not isinstance(v, (dict, list))}})
        if self.state['error']:
            lines += ['', '停止原因：', '', '```text', self.state['error'], '```']
        lines += ['', '比较结果JSON含按图像分组的bootstrap区间；各候选比较属于描述性分析，不能据此宣称等效。', '',
                  '归档包含日志、逐题预测、参数、身份记录、输入索引及校验清单；不包含权重、轮包或捕获张量本体。',
                  '输入张量保留在服务器，后续重放与性能实验仍需使用。历史pilot10记录单独保存在 prior_results 下。']
        (self.out / 'SUMMARY.md').write_text('\n'.join(lines), encoding='utf-8')
        if csv_rows:
            fields = sorted({k for r in csv_rows for k in r})
            with (self.out / 'summary.csv').open('w', encoding='utf-8-sig', newline='') as f:
                w = csv.DictWriter(f, fieldnames=fields)
                w.writeheader()
                w.writerows(csv_rows)
        archive = self.a.model_path.resolve().parent / (self.out.name + '_results.zip')
        if archive.exists():
            raise FileExistsError(f'Refusing to overwrite export: {archive}')
        allowed = {'.json', '.jsonl', '.log', '.txt', '.md', '.csv'}
        members = {}
        def add_tree(base, prefix):
            base = Path(base)
            paths = [base] if base.is_file() else sorted(base.rglob('*')) if base.exists() else []
            for p in paths:
                if p.is_file() and not p.is_symlink() and p.suffix.lower() in allowed:
                    rel = p.name if base.is_file() else p.relative_to(base).as_posix()
                    members[prefix + '/' + rel] = p
        add_tree(self.out, 'batch')
        for name in PRIOR:
            add_tree(self.root / 'results' / name, 'prior_results/' + name)
        for label, path in self.state['artifacts'].items():
            if label.startswith(('build_', 'verify_')) and not Path(path).is_relative_to(self.out):
                add_tree(path, 'reused/' + label)
        for name in ('model_source.api.json', 'files.sha256.json', 'candidates.json'):
            members['provenance/' + name] = self.root / name
        members['provenance/run_transfer_batch.py'] = Path(__file__).resolve()
        for name in ('common.py', 'host.py', 'capture.py', 'numerics.py', 'run_npu.py', 'score.py',
                     'build_candidate.py', 'verify_benchmark.py'):
            members['provenance/' + name] = self.root / name
        manifest = {name: {'sha256': sha(p), 'bytes': p.stat().st_size} for name, p in members.items()}
        tmp = archive.with_suffix('.zip.part')
        with zipfile.ZipFile(tmp, 'x', zipfile.ZIP_DEFLATED) as z:
            for name, path in members.items():
                z.write(path, name)
            z.writestr('EXPORT_MANIFEST.json', json.dumps(manifest, indent=2))
        tmp.rename(archive)
        print(f'\nBATCH_STATUS: {self.state["status"]}\nSUMMARY: {self.out / "SUMMARY.md"}\nDOWNLOAD: {archive}', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/mnt/workspace/v3_model_transfer'))
    parser.add_argument('--model-path', type=Path, default=Path('/mnt/workspace/gitCode/cann/cann-learning-hub/build/Qwen2.5-VL-3B-Instruct'))
    parser.add_argument('--soc', choices=['ascend910b', 'ascend910_93', 'ascend950'], default='ascend910b')
    parser.add_argument('--device-id', type=int, default=0)
    parser.add_argument('--output', type=Path, default=Path('results/auto_dev_001'))
    parser.add_argument('--timeout', type=int, default=7200, help='Per-stage time limit in seconds')
    parser.add_argument('--plan', action='store_true', help='Print scope without importing torch or modifying files')
    parser.add_argument('--background', action='store_true', help='Detach batch and write a persistent console log')
    parser.add_argument('--worker', choices=['preflight', 'install', 'numerics'], help=argparse.SUPPRESS)
    parser.add_argument('--request', type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        worker(args.worker, read(args.request))
        return 0
    if args.plan:
        print(json.dumps({'root': str(args.root), 'model': str(args.model_path), 'candidates': CANDIDATES,
                          'dev_questions': 100, 'capture_questions': 10, 'held_out_eval': False,
                          'timing': False, 'on_error': 'stop and export evidence'}, indent=2))
        return 0
    if os.name != 'posix':
        raise RuntimeError('Run the actual batch on the Linux NPU server; --plan works locally')
    if args.background:
        root = args.root.resolve()
        output = (root / args.output).resolve()
        if not output.is_relative_to(root / 'results'):
            raise ValueError('Output must stay in results')
        if output.exists():
            raise FileExistsError(f'Output exists; do not rerun or overwrite: {output}')
        if not (root / 'run_npu.py').is_file():
            raise FileNotFoundError(f'Experiment runner missing in {root}')
        console = output.with_suffix('.console.log')
        console.parent.mkdir(parents=True, exist_ok=True)
        with console.open('x', encoding='utf-8') as log:
            child = subprocess.Popen([sys.executable, '-u', str(Path(__file__).resolve()),
                                      *[x for x in sys.argv[1:] if x != '--background']],
                                     stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                     start_new_session=True, cwd=root,
                                     env=dict(os.environ, PYTHONUNBUFFERED='1'))
        print(f'BACKGROUND_PID: {child.pid}\nLOG: {console}\n'
              f'DOWNLOAD_WHEN_FINISHED: {args.model_path.resolve().parent / (output.name + "_results.zip")}')
        return 0
    import fcntl
    args.root = args.root.resolve()
    lock_path = args.root / '.transfer_batch.lock'
    with lock_path.open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('Another transfer batch is already running') from None
        batch = Batch(args)
        code = 0
        def stop(signum, frame):
            raise KeyboardInterrupt(f'Received signal {signum}')
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        try:
            batch.run()
        except BaseException:
            batch.state['status'] = 'stopped_requires_review'
            batch.state['error'] = traceback.format_exc()
            print(batch.state['error'], flush=True)
            code = 1
        finally:
            batch.package()
        return code


if __name__ == '__main__':
    raise SystemExit(main())
