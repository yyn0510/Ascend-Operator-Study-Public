# GELU语义核查

状态：completed
原包恢复：restored_and_verified

比较CPU/NPU的none、tanh、FP32再转低精度，以及两份生成候选的两个模式。复用Qwen与CLIP原捕获输入，未运行模型或修改原实验。
误差标准保持atol=1e-5、rtol=.016，只作语义诊断；误差更小、模式输出接近或符号存在不能独立证明实际API调用路径。

Profiler：completed