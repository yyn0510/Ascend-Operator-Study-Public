"""One-file, offline-on-server GELU semantic diagnostic. No kernel edits or model inference."""
import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback
import zipfile

ATOL=1e-5
RTOL=.016
SEED=20261016
IDS=['Grok_4_6_gelu_001_R4','Kimi_K3_gelu_002_R3']
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix(p.suffix+'.tmp')
    q.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');q.replace(p)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def fp(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def formulas(x):
    import torch
    x=x.detach().cpu().double()
    return {'erf':.5*x*torch.erfc(-x/math.sqrt(2)),
            'tanh':.5*x*(1+torch.tanh(math.sqrt(2/math.pi)*(x+.044715*x**3)))}
def bit_equal(a,b):
    import torch
    if a.shape!=b.shape or a.dtype!=b.dtype:return False
    return bool(torch.equal(a.detach().cpu().contiguous().reshape(-1).view(torch.uint8),b.detach().cpu().contiguous().reshape(-1).view(torch.uint8)))
def error(a,b,mask=None):
    import torch
    if a.shape!=b.shape:raise ValueError('Shape mismatch')
    a=a.detach().cpu();b=b.detach().cpu()
    if mask is not None:a=a[mask];b=b[mask]
    bits=bit_equal(a,b) if a.dtype==b.dtype else None
    a=a.double();b=b.double()
    if not a.numel():return {'elements':0,'finite':True,'failed':0,'max_abs':None,'mean_abs':None,'relative_l2':None}
    if not bool(torch.isfinite(a).all() and torch.isfinite(b).all()):return {'elements':a.numel(),'finite':False,'failed':None}
    d=(a-b).abs();bad=d>ATOL+RTOL*b.abs()
    return {'elements':a.numel(),'finite':True,'failed':int(bad.sum()),'max_abs':d.max().item(),'mean_abs':d.mean().item(),'relative_l2':(torch.linalg.vector_norm(d)/torch.linalg.vector_norm(b).clamp_min(1e-30)).item(),'exact_value_equal':bool(torch.equal(a,b)),'bitwise_equal_same_dtype':bits}
def separated_mask(refs,dtype):
    a=refs['erf'].to(dtype).double();b=refs['tanh'].to(dtype).double()
    return (a-b).abs()>(ATOL+RTOL*a.abs())+(ATOL+RTOL*b.abs())
def synthetic():
    import torch
    special=torch.tensor([-12.,-10.,-8.,-6.,-5.,-4.,-3.453125,-3.,-2.5,-2.,-1.,-1e-4,-1e-8,0.,1e-8,1e-4,1.,2.,3.,4.,6.,8.,10.,12.],dtype=torch.float64)
    rng=torch.Generator(device='cpu').manual_seed(SEED)
    return [('grid_and_special',torch.cat((torch.linspace(-8,8,4097,dtype=torch.float64),special))),
            ('random_tail_65537',torch.randn(65537,generator=rng,dtype=torch.float64)*2.5),
            ('matrix_7x513',torch.randn(7,513,generator=rng,dtype=torch.float64)*2.5)]
def point_examples(x,values):
    if x.numel()<24:return []
    indexes=range(x.numel()-24,x.numel())
    flat=x.reshape(-1).double()
    return [{'x':flat[i].item(),**{k:v.reshape(-1)[i].double().item() for k,v in values.items()}} for i in indexes]
def summarize(x,values,refs):
    mask=separated_mask(refs,x.dtype);result={}
    for name,value in values.items():
        result[name]={'against_formula_fp64':{k:error(value,r) for k,r in refs.items()},
                      'against_formula_rounded':{k:error(value,r.to(x.dtype)) for k,r in refs.items()},
                      'on_separated_subset':{k:error(value,r.to(x.dtype),mask) for k,r in refs.items()}}
    return {'shape':list(x.shape),'dtype':str(x.dtype),'elements':x.numel(),'separated_elements':int(mask.sum()),'formula_separation_rule':'Rounded erf/tanh error tolerance bands do not overlap','values':result}

def frozen(cfg):
    sys.path.insert(0,cfg['harness'])
    import torch
    import torch_npu
    from host import environment
    torch.set_num_threads(4);torch.npu.set_device(cfg['device']);torch.npu.config.allow_internal_format=False
    p=read(cfg['protocol'])
    if p['fingerprint']!=fp({k:v for k,v in p.items() if k!='fingerprint'}):raise ValueError('Diagnostic protocol changed')
    if p['tolerance']!={'atol':ATOL,'rtol':RTOL}:raise ValueError('Tolerance differs from recorded diagnostic')
    if sha(Path(__file__))!=p['script_sha256']:raise ValueError('Diagnostic code changed')
    if environment(cfg['device'])!=p['environment']:raise ValueError('Environment differs from existing CLIP pilot')
    return p

def collect_metadata(out):
    import torch
    import torch_npu
    result={'torch_git_version':getattr(torch.version,'git_version',None),'torch_npu_package':torch_npu.__file__,
            'torch_npu_version':getattr(torch_npu,'__version__',None),'symbols_are_not_dispatch_proof':True}
    try:
        import torch_npu.version as version
        result['torch_npu_git_version']=getattr(version,'git_version',None)
        result['torch_npu_version_source']=Path(version.__file__).read_text(encoding='utf-8',errors='replace')[:24000]
    except Exception as e:result['version_source_error']=repr(e)
    for name in ('_dispatch_dump_table','_dispatch_dump'):
        try:result[name]=getattr(torch._C,name)('aten::gelu')
        except Exception as e:result[name]=repr(e)
    for name in ('npu_gelu','gelu'):
        try:result['npu_schema_'+name]=str(getattr(torch.ops.npu,name).default._schema)
        except Exception as e:result['npu_schema_'+name]=repr(e)
    libs=[];root=Path(torch_npu.__file__).resolve().parent/'lib'
    if root.is_dir():
        for path in sorted(root.glob('*.so')):
            if 'plugin' in path.name or path.name in ('libtorch_npu.so',):
                libs.append({'file':str(path),'bytes':path.stat().st_size,'sha256':sha(path) if path.stat().st_size<512*1024*1024 else 'not hashed: >512MiB'})
    result['adapter_libraries']=libs
    result['environment_flags']={n:os.environ.get(n) for n in ('ASCEND_HOME_PATH','ASCEND_OPP_PATH','TASK_QUEUE_ENABLE','ACL_OP_COMPILER_CACHE_MODE')}
    save(out/'runtime_metadata.json',result)

def preflight(cfg):
    sys.path.insert(0,cfg['harness'])
    import torch
    import torch_npu
    import cann_bench
    from host import environment
    from common import verify_loaded
    env=environment(cfg['device']);prior=read(cfg['clip_root']+'/protocol.pilot.json')
    if env!=prior['environment']:raise ValueError('Environment changed since CLIP pilot')
    harness_manifest=read(Path(cfg['harness'])/'files.sha256.json')
    for rel,expected in harness_manifest.items():
        path=(Path(cfg['harness'])/rel).resolve()
        if not path.is_relative_to(Path(cfg['harness']).resolve()) or sha(path)!=expected:raise ValueError('Existing harness source changed: '+rel)
    for cid in IDS:
        row=read(Path(cfg['clip_root'])/('build_'+cid)/'receipt.json')
        if sha(row['wheel'])!=row['wheel_sha256']:raise ValueError('Original candidate wheel modified')
    binary=sha(Path(cann_bench._C.__file__));wrapper=sha(Path(cann_bench.__file__))
    matching=[]
    for path in Path(cfg['clip_root']).glob('build_*/receipt.json'):
        r=read(path)
        if r['binary_sha256']==binary and r['wrapper_sha256']==wrapper:matching.append(path)
    if len(matching)!=1:raise ValueError('Cannot uniquely identify current installed package for restoration')
    restore=matching[0];r=read(restore)
    selected=next(v for v in read(Path(cfg['harness'])/'candidates.json') if v['candidate_id']==r['candidate_id'])
    identity=verify_loaded(r['candidate_id'],selected['operator'],str(restore))
    inputs=[]
    clip=Path(cfg['clip_root'])/'native_capture/captures/gelu'
    for row in read(clip/'index.json')['records']:inputs.append({'source':'clip','path':str(clip/row['file']),'sha256':row['sha256'],'metadata':row})
    qwen=Path(cfg['old_root'])/'results/auto_dev_001/capture_gelu_dev10/inputs'
    for line in (qwen/'index.jsonl').read_text(encoding='utf-8').splitlines():
        if line.strip():
            row=json.loads(line);inputs.append({'source':'qwen','path':str(qwen/row['file']),'sha256':row['sha256'],'metadata':row})
    if sum(r['source']=='clip' for r in inputs)!=18 or sum(r['source']=='qwen' for r in inputs)!=10:raise ValueError('Unexpected historical capture coverage')
    for r in inputs:
        if sha(r['path'])!=r['sha256']:raise ValueError('Historical capture modified')
    p={'schema_version':1,'seed':SEED,'environment':env,'tolerance':{'atol':ATOL,'rtol':RTOL},'script_sha256':sha(__file__),
       'candidate_ids':IDS,'inputs':inputs,'restore':{'receipt':str(restore),'candidate_id':selected['candidate_id'],'operator':selected['operator'],'identity':identity},
       'scope':'Semantic diagnostic only; no candidate eligibility changes, source fixes, software upgrades, task scores or performance claims',
       'formula_inputs':'References computed in FP64 at the SAME quantized dtype inputs; CPU F.gelu remains a separately measured implementation',
       'harness_manifest_sha256':sha(Path(cfg['harness'])/'files.sha256.json'),
       'historical_protocol_sha256':sha(Path(cfg['clip_root'])/'protocol.pilot.json')}
    p['fingerprint']=fp(p);save(cfg['protocol'],p)

def input_cases(p):
    import torch
    for name,base in synthetic():
        for dtype in (torch.float32,torch.float16,torch.bfloat16):
            yield {'id':name+'_'+str(dtype).split('.')[-1],'source':'synthetic'},base.to(dtype),None
    for i,row in enumerate(p['inputs']):
        if sha(row['path'])!=row['sha256']:raise ValueError('Capture changed')
        data=torch.load(row['path'],weights_only=True,map_location='cpu')
        x=data['input'] if row['source']=='clip' else data['inputs'][0]
        if row['source']=='qwen' and data['attrs']['approximate']!='none':raise ValueError('Unexpected original approximation mode')
        yield {'id':f'{row["source"]}_{i:03}','source':row['source'],'input_source':row},x,data['reference']

def native(cfg):
    import torch
    p=frozen(cfg);out=Path(cfg['output']);out.mkdir(parents=True,exist_ok=False);collect_metadata(out)
    report={'criterion':p['tolerance'],'records':[]};raw=[]
    with torch.inference_mode():
        for metadata,x,captured in input_cases(p):
            npu=x.to(f'npu:{cfg["device"]}');refs=formulas(x);values={}
            for mode in ('none','tanh'):
                values['cpu_functional_'+mode]=torch.nn.functional.gelu(x,approximate=mode)
                values['npu_functional_'+mode]=torch.nn.functional.gelu(npu,approximate=mode).cpu()
                values['npu_fp32_then_dtype_'+mode]=torch.nn.functional.gelu(npu.float(),approximate=mode).to(x.dtype).cpu()
                if metadata['source']=='synthetic':
                    values['npu_module_'+mode]=torch.nn.GELU(approximate=mode)(npu).cpu()
                    values['npu_aten_'+mode]=torch.ops.aten.gelu.default(npu,approximate=mode).cpu()
            if captured is not None and not bit_equal(values['npu_functional_none'],captured):raise ValueError('Historical host output not bitwise reproduced')
            item={**metadata,**summarize(x,values,refs),'none_vs_tanh':error(values['npu_functional_none'],values['npu_functional_tanh'])}
            if metadata['id'].startswith('grid_and_special'):item['points']=point_examples(x,{**values,**{'formula_'+k:v for k,v in refs.items()}})
            if metadata['source']=='synthetic':raw.append({'metadata':metadata,'input':x,'outputs':values,'references':refs})
            report['records'].append(item);save(out/'comparison.json',report)
            print('NATIVE',metadata['id'],'separated=',item['separated_elements'],flush=True)
    torch.save(raw,out/'synthetic_outputs.pt');save(out/'status.json',{'status':'completed','records':len(report['records'])})

def install(cfg):
    p=frozen(cfg);receipt=read(cfg['receipt'])
    if sha(receipt['wheel'])!=receipt['wheel_sha256']:raise ValueError('Wheel changed')
    subprocess.run([sys.executable,'-m','pip','install','--force-reinstall','--no-deps',receipt['wheel']],check=True)
    from common import verify_loaded
    identity=verify_loaded(cfg['candidate'],cfg['operator'],cfg['receipt'])
    save(cfg['output'],identity)

def candidate(cfg):
    import torch
    p=frozen(cfg)
    import cann_bench
    from common import verify_loaded
    identity=verify_loaded(cfg['candidate'],'gelu',cfg['receipt'])
    out=Path(cfg['output']);out.mkdir(parents=True,exist_ok=False)
    result={'candidate_id':cfg['candidate'],'identity':identity,'criterion':p['tolerance'],'records':[]};raw=[]
    with torch.inference_mode():
        for metadata,x,captured in input_cases(p):
            npu=x.to(f'npu:{cfg["device"]}');refs=formulas(x);values={};host={}
            for mode in ('none','tanh'):
                values['candidate_'+mode]=cann_bench.gelu(npu,mode).cpu()
                host[mode]=torch.nn.functional.gelu(npu,approximate=mode).cpu()
            if captured is not None and not bit_equal(host['none'],captured):raise ValueError('Historical host not bitwise reproduced during candidate replay')
            item={**metadata,**summarize(x,values,refs),'against_host':{requested:{mode:error(value,host[mode]) for mode in host} for requested,value in values.items()}}
            if metadata['id'].startswith('grid_and_special'):item['points']=point_examples(x,{**values,**{'host_'+k:v for k,v in host.items()}})
            if metadata['source']=='synthetic':raw.append({'metadata':metadata,'input':x,'outputs':values,'host_outputs':host,'references':refs})
            result['records'].append(item);save(out/'comparison.json',result)
            print('CANDIDATE',cfg['candidate'],metadata['id'],flush=True)
    torch.save(raw,out/'synthetic_outputs.pt');save(out/'status.json',{'status':'completed','records':len(result['records'])})

def profile_worker(cfg):
    import torch
    import torch_npu
    frozen(cfg);out=Path(cfg['output']);out.mkdir(parents=True,exist_ok=False)
    result={'status':'not_started','purpose':'Call-route evidence, not timing benchmark. Kernel names alone may not identify the complete API route.'}
    try:
        profiler=torch_npu.profiler
        for mode in ('none','tanh'):
            directory=out/mode;directory.mkdir()
            x=torch.linspace(-6,6,8192,device=f'npu:{cfg["device"]}',dtype=torch.float32)
            for _ in range(3):torch.nn.functional.gelu(x,approximate=mode)
            torch.npu.synchronize()
            with profiler.profile(activities=[profiler.ProfilerActivity.CPU,profiler.ProfilerActivity.NPU],record_shapes=True,with_stack=False,
                                  on_trace_ready=profiler.tensorboard_trace_handler(str(directory))) as prof:
                with torch.profiler.record_function('gelu_semantics_'+mode):
                    for _ in range(3):torch.nn.functional.gelu(x,approximate=mode)
                    torch.npu.synchronize()
                prof.step()
        result['status']='completed'
    except Exception:
        result.update({'status':'unavailable_or_failed','error':traceback.format_exc()})
    evidence=[]
    for path in sorted(out.rglob('*')):
        if not path.is_file() or path.suffix not in ('.json','.csv','.txt') or path.stat().st_size>32*1024*1024:continue
        if path.suffix=='.json':
            try:
                d=read(path);events=d.get('traceEvents',[]) if isinstance(d,dict) else (d if isinstance(d,list) else [])
                hits=[e for e in events if isinstance(e,dict) and ('gelu' in str(e.get('name','')).lower() or 'aclnn' in str(e.get('name','')).lower())]
                if hits:evidence.append({'file':str(path.relative_to(out)),'events':hits[:300]})
            except (ValueError,UnicodeError):pass
        else:
            hits=[s for s in path.read_text(encoding='utf-8',errors='replace').splitlines() if 'gelu' in s.lower() or 'aclnn' in s.lower()]
            if hits:evidence.append({'file':str(path.relative_to(out)),'lines':hits[:300]})
    result['filtered_evidence']=evidence;save(out/'profiler_status.json',result)
    print('PROFILER',result['status'],flush=True)

class Driver:
    def __init__(self,a,Batch):
        self.a=a;self.helper=Batch;self.old=a.old_root.resolve();self.clip=self.old/'results/auto_clip_screen_001';self.root=self.clip/'harness'
        self.out=(self.old/a.output).resolve()
        if not self.out.is_relative_to(self.old/'results'):raise ValueError('Output must stay under results')
        self.out.mkdir(parents=True,exist_ok=False)
        self.script=self.out/'provenance/run_gelu_semantics.py';self.script.parent.mkdir();shutil.copyfile(Path(__file__),self.script)
        self.protocol=self.out/'protocol.json';self.state={'status':'running','steps':[],'error':None,'restoration':None,'scope':'GELU semantic diagnostics, not a corrected replacement experiment'};self.save()
    def save(self):save(self.out/'batch_status.json',self.state)
    def command(self,*args,**kwargs):return self.helper.command(self,*args,**kwargs)
    def task(self,name,action,**kw):
        cfg={'harness':str(self.root),'clip_root':str(self.clip),'old_root':str(self.old),'protocol':str(self.protocol),'device':self.a.device_id,**kw}
        path=self.out/'requests'/(name+'.json');save(path,cfg)
        self.command(name,[sys.executable,self.script,'--worker',action,'--request',path])
    def run(self):
        self.task('preflight','preflight')
        self.task('native_modes','native',output=str(self.out/'native_modes'))
        self.task('profile_native_modes','profile',output=str(self.out/'profiler'))
        for cid in IDS:
            receipt=self.clip/('build_'+cid)/'receipt.json'
            self.task('install_'+cid,'install',candidate=cid,operator='gelu',receipt=str(receipt),output=str(self.out/('identity_'+cid+'.json')))
            self.task('candidate_'+cid,'candidate',candidate=cid,receipt=str(receipt),output=str(self.out/('candidate_'+cid)))
        ps=read(self.out/'profiler/profiler_status.json')
        self.state['profiler_status']=ps['status']
        self.state['status']='completed' if ps['status']=='completed' else 'completed_with_profiler_gap';self.save()
    def restore(self):
        if not self.protocol.exists():return
        r=read(self.protocol)['restore']
        try:
            self.task('restore_original_package','install',candidate=r['candidate_id'],operator=r['operator'],receipt=r['receipt'],output=str(self.out/'restored_identity.json'))
            self.state['restoration']='restored_and_verified'
        except BaseException:
            self.state['restoration']=traceback.format_exc();self.state['status']='stopped_requires_review'
        self.save()
    def package(self):
        summary=['# GELU语义核查','',f'状态：{self.state["status"]}',f'原包恢复：{self.state["restoration"]}','','比较CPU/NPU的none、tanh、FP32再转低精度，以及两份生成候选的两个模式。复用Qwen与CLIP原捕获输入，未运行模型或修改原实验。','误差标准保持atol=1e-5、rtol=.016，只作语义诊断；误差更小、模式输出接近或符号存在不能独立证明实际API调用路径。']
        profile=self.out/'profiler/profiler_status.json'
        if profile.exists():summary+=['',f'Profiler：{read(profile)["status"]}']
        if self.state['error']:summary+=['','错误：',self.state['error']]
        (self.out/'SUMMARY.md').write_text('\n'.join(summary),encoding='utf-8')
        members={};omitted=[];total=0
        for path in sorted(self.out.rglob('*')):
            if not path.is_file():continue
            rel=path.relative_to(self.out).as_posix()
            include=path.suffix in ('.json','.csv','.txt','.md','.log','.py') or path.name=='synthetic_outputs.pt'
            if not include:continue
            size=path.stat().st_size
            if size>40*1024*1024 or total+size>120*1024*1024:omitted.append({'file':rel,'bytes':size,'reason':'return archive size cap; full file remains on server'});continue
            members['batch/'+rel]=path;total+=size
        manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in members.items()}
        omitted_bytes=json.dumps(omitted,indent=2).encode()
        manifest['OMITTED_FILES.json']={'bytes':len(omitted_bytes),'sha256':hashlib.sha256(omitted_bytes).hexdigest()}
        archive=self.a.download_dir.resolve()/(self.out.name+'_results.zip')
        if archive.exists():raise FileExistsError(archive)
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
            for n,p in members.items():z.write(p,n)
            z.writestr('EXPORT_MANIFEST.json',json.dumps(manifest,indent=2));z.writestr('OMITTED_FILES.json',omitted_bytes)
        print(f'BATCH_STATUS: {self.state["status"]}\nDOWNLOAD: {archive}',flush=True)

def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--old-root',type=Path,default=Path('/mnt/workspace/v3_model_transfer'))
    a.add_argument('--package',type=Path,default=Path('/mnt/workspace/v3_clip_extension'))
    a.add_argument('--download-dir',type=Path,default=Path('/mnt/workspace/gitCode/cann/cann-learning-hub/build'))
    a.add_argument('--output',type=Path,default=Path('results/gelu_semantics_001'))
    a.add_argument('--device-id',type=int,default=0);a.add_argument('--timeout',type=int,default=3600)
    a.add_argument('--background',action='store_true');a.add_argument('--plan',action='store_true')
    a.add_argument('--worker',choices=['preflight','native','install','candidate','profile'],help=argparse.SUPPRESS);a.add_argument('--request',type=Path,help=argparse.SUPPRESS)
    cfg=a.parse_args()
    if cfg.worker:
        request=read(cfg.request)
        globals()[{'preflight':'preflight','native':'native','install':'install','candidate':'candidate','profile':'profile_worker'}[cfg.worker]](request);return 0
    if cfg.plan:
        print(json.dumps({'dtypes':['float32','float16','bfloat16'],'synthetic_sets':3,'historical_captures':{'qwen':10,'clip':18},'candidates':IDS,'approximation_modes':['none','tanh'],'threshold_change':False,'new_model_inference':False,'profiler':'optional evidence; failure explicitly recorded','restore_installed_package':True},indent=2));return 0
    if os.name!='posix':raise RuntimeError('Actual diagnostic requires Linux NPU server')
    out=(cfg.old_root.resolve()/cfg.output).resolve()
    if not out.is_relative_to(cfg.old_root.resolve()/'results'):raise ValueError('Unsafe output')
    if out.exists():raise FileExistsError('Do not overwrite an existing diagnostic batch')
    if cfg.background:
        console=out.with_suffix('.console.log');console.parent.mkdir(parents=True,exist_ok=True)
        with console.open('x',encoding='utf-8') as f:
            child=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),*[v for v in sys.argv[1:] if v!='--background']],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,cwd=cfg.old_root,env=dict(os.environ,PYTHONUNBUFFERED='1'))
        print(f'BACKGROUND_PID: {child.pid}\nLOG: {console}\nDOWNLOAD_WHEN_FINISHED: {cfg.download_dir / (out.name+"_results.zip")}');return 0
    helper=cfg.package.resolve()/'run_transfer_batch.py'
    manifest=read(cfg.package/'PACKAGE_MANIFEST.json')
    if sha(helper)!=manifest['run_transfer_batch.py']['sha256']:raise ValueError('Existing batch helper changed')
    sys.path.insert(0,str(cfg.package.resolve()));from run_transfer_batch import Batch
    import fcntl
    with (cfg.old_root/'.transfer_batch.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('Another experimental batch is running') from None
        driver=Driver(cfg,Batch);code=0
        def stop(signum,frame):raise KeyboardInterrupt(f'Received signal {signum}')
        signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
        try:driver.run()
        except BaseException:
            driver.state.update({'status':'stopped_requires_review','error':traceback.format_exc()});print(driver.state['error'],flush=True);code=1
        finally:
            driver.restore();driver.package()
        if driver.state['status']=='stopped_requires_review':code=1
        return code
if __name__=='__main__':raise SystemExit(main())
