# 正式质量与效率批次

状态：completed_with_ineligible_candidates

固定名单、严格答案解析、官方BF16默认数值标准；未按候选放宽；不作质量等效声明。

| 候选 | 数值回放 | 正式质量 |
|---|---|---|
| Grok_4_6_gelu_001_R4 | 0/10; excluded_by_fixed_numerical_gate | 未测/未完成，见准入状态及日志 |
| Kimi_K3_gelu_002_R3 | 0/10; excluded_by_fixed_numerical_gate | 未测/未完成，见准入状态及日志 |
| Kimi_K3_swi_glu_003_R5 | 47/47; eligible | 原模型79.20%；候选79.30%；差值+0.10个百分点 |
| DeepSeek_V4_1_Flash_swi_glu_002_R4 | 47/47; eligible | 原模型79.20%；候选79.30%；差值+0.10个百分点 |

效率原始记录在 timing_* 目录，包含逐工作负载、逐块、逐模式耗时。
计时包含Python调用及接入成本；decode使用固定原模型token及新KV缓存，属于受控计时。
数值失败的候选不进入正式质量与性能比较；原始失败记录不删除。
所有捕获仍限于原开发批次记录，覆盖限制见rules.json；不宣称所有输入精度认证。

| 计时任务 | 阶段 | 模式 | 工作负载数 | 相对原生几何平均加速比 |
|---|---|---|---:|---:|
| timing_operator_Kimi_K3_swi_glu_003_R5 | decode | wrapper | 13 | 0.6261× |
| timing_operator_Kimi_K3_swi_glu_003_R5 | decode | candidate | 13 | 0.7920× |
| timing_operator_Kimi_K3_swi_glu_003_R5 | prefill | wrapper | 17 | 0.6566× |
| timing_operator_Kimi_K3_swi_glu_003_R5 | prefill | candidate | 17 | 0.9155× |
| timing_model_Kimi_K3_swi_glu_003_R5 | fixed_teacher_forced_decode | wrapper | 30 | 0.9709× |
| timing_model_Kimi_K3_swi_glu_003_R5 | fixed_teacher_forced_decode | candidate | 30 | 0.9778× |
| timing_model_Kimi_K3_swi_glu_003_R5 | prefill | wrapper | 30 | 0.9879× |
| timing_model_Kimi_K3_swi_glu_003_R5 | prefill | candidate | 30 | 0.9910× |
| timing_operator_DeepSeek_V4_1_Flash_swi_glu_002_R4 | decode | wrapper | 13 | 0.6834× |
| timing_operator_DeepSeek_V4_1_Flash_swi_glu_002_R4 | decode | candidate | 13 | 0.8288× |
| timing_operator_DeepSeek_V4_1_Flash_swi_glu_002_R4 | prefill | wrapper | 17 | 0.6451× |
| timing_operator_DeepSeek_V4_1_Flash_swi_glu_002_R4 | prefill | candidate | 17 | 0.9188× |
| timing_model_DeepSeek_V4_1_Flash_swi_glu_002_R4 | fixed_teacher_forced_decode | wrapper | 30 | 0.9767× |
| timing_model_DeepSeek_V4_1_Flash_swi_glu_002_R4 | fixed_teacher_forced_decode | candidate | 30 | 0.9759× |
| timing_model_DeepSeek_V4_1_Flash_swi_glu_002_R4 | prefill | wrapper | 30 | 0.9915× |
| timing_model_DeepSeek_V4_1_Flash_swi_glu_002_R4 | prefill | candidate | 30 | 0.9972× |