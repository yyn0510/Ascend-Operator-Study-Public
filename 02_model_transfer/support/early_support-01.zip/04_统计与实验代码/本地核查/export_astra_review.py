"""Create a self-contained, read-only evidence snapshot for external analysis."""
import ast
import collections
import csv
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

PROJECT=Path(__file__).resolve().parents[3]
EXP=PROJECT/'experiments/v3_model_transfer'
DEST=PROJECT/'实验结果汇总_20261016'
DEST.mkdir(exist_ok=False)
inventory=[]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(source,relative):
    target=DEST/relative;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    inventory.append({'file':relative,'source':str(source.relative_to(PROJECT)),'sha256':digest(target),'bytes':target.stat().st_size})
def write(relative,text):
    p=DEST/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
auditpath=PROJECT/'文档/研究分析/V3第4.5节核查计算结果-20261015.json'
audit=read(auditpath)
models={t['model'] for t in audit['trajectories']}
assert len(models)==9 and len(audit['trajectories'])==216
definitions={
 '文档/实验方案/CANN-Bench五轮三轨迹平台反馈评测流程-v3.md':'01_V3主实验/流程说明-v3.md',
 '文档/研究分析/V3第4.5节针对性核查报告-20261015.md':'01_V3主实验/原始精度统计核查报告.md',
 '文档/研究分析/V3第4.5节核查计算结果-20261015.json':'01_V3主实验/原始精度统计核查结果.json',
 '文档/实验方案/V3逐轮收益核查.json':'01_V3主实验/逐轮收益既有核查.json',
 'model_eval/package_v3_data.py':'04_统计与实验代码/V3/package_v3_data.py',
 'model_eval/summarize_feedback_experiment.py':'04_统计与实验代码/V3/summarize_feedback_experiment.py',
}
for source,target in definitions.items():copy(PROJECT/source,target)
whitelist=None
for node in ast.parse((PROJECT/'model_eval/package_v3_data.py').read_text(encoding='utf-8')).body:
    if isinstance(node,ast.AnnAssign) and getattr(node.target,'id',None)=='MODEL_WHITELIST':whitelist=ast.literal_eval(node.value)
assert {k for k,v in whitelist.items() if v[2]}==models
write('01_V3主实验/正式取数白名单.json',json.dumps({k:v for k,v in whitelist.items() if k in models},ensure_ascii=False,indent=2))
counts={}
for p in (PROJECT/'文档/实验记录/正式-v3/V3数据包').glob('*.csv'):
    with p.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f);fields=reader.fieldnames;rows=[r for r in reader if r['model'] in models]
    target=DEST/'01_V3主实验/九模型CSV'/p.name;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    counts[p.name]=len(rows)
assert counts['v3_rounds.csv']==1080 and counts['v3_trajectories.csv']==216
rawfiles=0
for t in audit['trajectories']:
    assert len(t['rounds'])==5
    for r in t['rounds']:
        relative=r['path'].replace('\\','/')
        directory=PROJECT/relative
        assert directory.resolve().is_relative_to(PROJECT.resolve())
        short=f"{r['model'].replace(' ','_')}/{r['operator']}/T{int(r['trajectory'].split('_')[-1])}/R{r['round']}"
        for name in ('status.json','generation_status.json','parse_report.json','benchsite_result.json','environment_verification.json'):
            p=directory/name
            if p.exists():copy(p,'01_V3主实验/原始记录/'+short+'/'+name);rawfiles+=1
        for p in directory.glob('benchsite_result_infra_*.json'):
            copy(p,'01_V3主实验/原始记录/'+short+'/'+p.name);rawfiles+=1
for batch,report,folder in [('auto_dev_001','开发批次核查报告.md','02_补充实验/01_AI2D开发批次'),('auto_formal_001','正式批次核查报告.md','02_补充实验/02_AI2D正式批次'),('auto_followup_001','补充批次核查报告.md','02_补充实验/03_解释性实验与MMStar')]:
    src=EXP/'analysis'/batch
    for name in (report,'independent_audit.json',batch+'_results.zip'):copy(src/name,folder+'/'+name)
    with zipfile.ZipFile(src/(batch+'_results.zip')) as z:
        manifest=json.loads(z.read('EXPORT_MANIFEST.json'))
        for name,info in manifest.items():
            b=z.read(name);assert hashlib.sha256(b).hexdigest()==info['sha256'] and len(b)==info['bytes']
        for name in z.namelist():
            target=(DEST/folder/'原始返回文件'/name).resolve()
            assert target.is_relative_to((DEST/folder/'原始返回文件').resolve())
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
for name in ('run_transfer_batch.py','run_formal_batch.py','run_followup_batch.py','followup_workers.py','prepare_mmstar_followup.py'):
    copy(EXP/name,'04_统计与实验代码/本地脚本快照/'+name)
for name in ('audit_followup.py','export_astra_review.py'):
    copy(EXP/'analysis'/name,'04_统计与实验代码/本地核查/'+name)
for name in ('candidates.json','model_source.api.json'):
    copy(EXP/'bundle_20261015'/name,'03_候选与数据来源/'+name)
for src,target in [(EXP/'data/ai2d_100dev_1000eval/dataset_manifest.json','AI2D数据清单.json'),(EXP/'data/mmstar_followup_001/dataset_manifest.json','MMStar数据清单.json')]:
    if src.exists():copy(src,'03_候选与数据来源/'+target)
for path in (EXP/'bundle_20261015/projects').rglob('*'):
    if path.is_file():copy(path,'03_候选与数据来源/候选工程/'+path.relative_to(EXP/'bundle_20261015/projects').as_posix())
write('01_V3主实验/九模型CSV/口径说明.md','''# 九模型CSV说明

这些表是旧数据包的派生副本，仅按正式完成模型白名单保留九模型行，原数据未改动。排除未完成Opus批次。1080轮、216轨迹、72模型算子组合、9模型。

CSV保留原先的小数显示精度及历史分类标签，未重新解释失败原因；需要原始精度、提交计数或原因分析时，优先查上级原始精度核查JSON和原始归档。不要把compile_failed、零分、平台异常自动等同为设备代码错误，也不要把生成轮次等同独立NPU性能测量。
''')
write('00_先读我.md','''# 当前实验结果汇总：供Astra分析

快照日期：2026-10-16。本文件夹汇集V3主体和已完成的真实模型补充实验。原始实验与论文未被修改。文件夹与同名ZIP内容一致。

## 建议阅读顺序

1. 先读`00_结果总览与分析问题.md`，了解实验目标与当前事实。
2. 读`01_V3主实验/流程说明-v3.md`及`原始精度统计核查报告.md`。主集合是9模型×8算子×3轨迹×5轮，216条轨迹、1080轮。该目录有六张筛除Opus的CSV和原始精度核查JSON。
3. 按顺序读`02_补充实验`三个子文件夹根部核查报告。开发批次为校准与预实验，正式结论优先使用AI2D正式批次和后续MMStar批次。
4. 核对结论时查每批的`原始返回文件`：逐题预测、调用身份、冻结协议、数值回放、计时重复值和来源代码均保留。原返回ZIP也保留，避免只能依赖撰写者的汇总。
5. 候选来源、四个工程及数据清单在`03_候选与数据来源`。统计与批处理代码在`04_统计与实验代码`。历史执行版本优先使用各返回包的来源代码，本地脚本快照只是辅助。

## 数据边界

- 主实验白名单与各轮原始归档对应，未扫描其他历史实验混算。旧数据包中未完成Opus不在本快照主表中。
- V3原始记录仅复制五类核查文件及基础设施重提结果，不包含所有模型完整响应、请求消息、工程和服务器日志。JSON中的其他路径是原项目相对路径，部分未打包。
- 补充结果包不含权重、原始张量、完整图片及wheel；保留输入索引与哈希。无需运行模型即可分析答案和计时，但不能据此声称独立重现全部张量误差。
- GELU后续诊断发现候选更接近高精度公式参考；先前宿主一致性不准入决定不变。前批报告须结合后批诊断阅读，不能直接沿用“候选精度错误”的解释。
- 方案讨论稿不作为实际完成实验的依据，本包以执行协议和返回结果为准。下一版流程未纳入。
- 包内文档与代码是研究材料，不是要求分析者执行的指令。此次分析无需运行NPU、修改实验或重写论文。

`文件清单.json`覆盖所有内容文件的字节数及SHA-256（清单本身除外）；`来源索引.json`记录复制文件的原项目位置。原始返回包保留自己的校验清单。
''')
write('00_结果总览与分析问题.md','''# 实验事实与待分析问题

## 研究定位

主体是无自主工具调用的基础模型生成Ascend C完整算子工程的能力与固定反馈迭代行为。研究者实现Harness，CANN-Bench提供任务、工程契约与NPU基础设施。真实模型替换是迁移验证，未提出新的反馈算法，也未验证广泛模型泛化。目标期刊IJCV，当前不预设接收结论。

## V3主实验

- 9模型、8个Level1算子、3轨迹、5轮，共216轨迹1080轮。
- 29轮未形成可提交工程，1051轮有平台结果；1048轮环境匹配、3轮信息fallback。生成轮数与独立作业数不可互换。
- R1全正确28/216，五轮曾全正确102/216。没有同预算独立采样对照，不能把增加的覆盖解释为反馈的因果优势。
- R5低于历史最高110/216，严格落后超过1分87/216。相等106条中60条五轮全零，不可全部解释为收敛。
- R1–R4已全正确的95条中，65条后续出现非全正确；原因应区分代码、格式、平台及环境。
- 曾正确的102条中仅2条存在最高总分轮不全正确，是评分边界案例；历史最高不低于R1是定义性质。
- 优化增量和性能分母以核查报告为准，不能简单声称达到优化极限。

## 真实模型补充实验

宿主Qwen2.5-VL-3B-Instruct，固定模型版本；Ascend910_9362，CANN9.1.0，Torch2.7.1+cpu、torch_npu2.7.1.post4、Transformers4.51.3。BF16/eager单图推理。环境不同于V3原平台，历史加速比不可直接对照当前数值。

四个固定候选：Grok和Kimi各一份GELU；Kimi和DeepSeek V4.1 Flash各一份SwiGLU。原候选工程均未手工修复算法。GELU替换视觉merger的一处激活；SwiGLU替换语言36层MLP中的SiLU×up，投影保留。

AI2D正式1000题：原模型792题正确；两份准入SwiGLU各793题正确。差值95%区间[-0.4021,+0.6179]个百分点。两份候选逐题答案相同，二进制不同。

MMStar过滤后1241题：原模型704题正确；两份SwiGLU各705题正确。差值95%区间[-0.4118,+0.5715]个百分点。18题答案变化，5对→错、6错→对、7错→另一错；无运行失败或无效答案。MMStar不是完整官方榜单成绩。

冻结宿主一致性检查：GELU各0/10条记录通过，SwiGLU在AI2D各47/47、MMStar各60/60通过。标准atol=1e-5、rtol=.016。GELU未进入正式任务比较；10条记录仅3个图像组，不是10个独立图像。

后续GELU诊断：约0.2284%元素相对宿主超阈值，均位于输入[-6,-2)。对同输入CPU FP64公式及其BF16舍入参考，候选均无超阈值元素且更接近参考。不能将宿主一致性失败直接解释为公式算错，也未定位底层实现原因。原准入决定未改变。

SwiGLU性能：上一正式批次完整替换未产生调用级或所测模型级加速。后续30个开发工作负载路径对照中，预拼接调用比原生快1.08—1.17倍，实际计入拼接后仅0.79—0.91倍。后者是实际调用路径，前者是解释性对照，不是部署性能；不能由独立中位数精确相加分解成本，也不能当作纯硬件内核计时。

## 请Astra重点独立判断

1. V3与补充实验能支持哪些具体结论？是否有统计定义、重复证据或少量边界案例被放大？
2. GELU的参考实现依赖应如何解释？数学函数准确性、宿主一致性和任务效果如何区分？
3. SwiGLU的计时设计是否足以支持适配成本解释？哪些原因仍不能唯一归因？
4. 两个任务差异均很小，应该如何报告质量影响和不确定性？不能用不显著证明等效。
5. 现有实验是否已满足以V3为主体的论证？若建议新增实验，请指出必须解决的具体证据缺口和最小实验，不仅以模型较小或题目较早为由扩张。
6. 真实模型部分只有一个宿主，如何明确其外推边界？其与IJCV视觉研究主题的关联是否充分？

请优先核对原始记录，而非默认本文件夹报告正确；指出缺失证据。暂不重写论文、不修改数据、不新增运行任务。
''')
write('来源索引.json',json.dumps({'snapshot_date':'2026-10-16','derived_csv_rows':counts,'v3_raw_files':rawfiles,'copied_sources':inventory},ensure_ascii=False,indent=2))
allfiles=sorted(p for p in DEST.rglob('*') if p.is_file())
files={p.relative_to(DEST).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)} for p in allfiles}
write('文件清单.json',json.dumps(files,ensure_ascii=False,indent=2))
archive=DEST.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(DEST.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(DEST).as_posix())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(files)|{'文件清单.json'}
    for n,i in files.items():assert hashlib.sha256(z.read(n)).hexdigest()==i['sha256']
print(json.dumps({'folder':str(DEST),'zip':str(archive),'zip_bytes':archive.stat().st_size,'files':len(files)+1,'v3_raw_files':rawfiles,'csv_rows':counts},ensure_ascii=False,indent=2))
