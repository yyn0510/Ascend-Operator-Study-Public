"""Offline independent audit of the returned followup ZIP. Never executes ZIP code."""
import collections
import hashlib
import json
import math
from pathlib import Path
import random
import re
import shutil
import statistics
import zipfile

BASE = Path(__file__).resolve().parent
SOURCE = Path('PUBLIC_HOME/Downloads/auto_followup_001_results.zip')
OUT = BASE / 'auto_followup_001'
OUT.mkdir(exist_ok=True)
def sha(b):
    return hashlib.sha256(b).hexdigest()
def fingerprint(v):
    return sha(json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode())
def quantile(v, q):
    v = sorted(v); p = (len(v)-1)*q; a = math.floor(p); b = math.ceil(p)
    return v[a]+(v[b]-v[a])*(p-a)
def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-11, abs_tol=1e-12), (a,b)

with zipfile.ZipFile(SOURCE) as z:
    def read(n): return json.loads(z.read(n))
    def rows(n): return [json.loads(s) for s in z.read(n).decode().splitlines() if s.strip()]
    assert len(z.namelist()) == len(set(z.namelist()))
    manifest = read('EXPORT_MANIFEST.json')
    assert set(manifest) == set(z.namelist())-{'EXPORT_MANIFEST.json'}
    for name, info in manifest.items():
        data = z.read(name)
        assert len(data) == info['bytes'] and sha(data) == info['sha256'], name
    # Preserve evidence, with path traversal checks, without importing its code.
    evidence = OUT / 'evidence'
    evidence.mkdir(exist_ok=True)
    for name in z.namelist():
        dest = (evidence/name).resolve()
        assert dest.is_relative_to(evidence.resolve())
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(z.read(name))
    shutil.copyfile(SOURCE, OUT/SOURCE.name)
    status = read('batch/batch_status.json')
    assert status['status']=='completed' and status['error'] is None
    assert all(s['status']=='completed' and s['returncode']==0 for s in status['steps'])
    protocol = read('batch/mmstar_protocol.frozen.json')
    assert protocol['protocol_fingerprint'] == fingerprint({k:v for k,v in protocol.items() if k!='protocol_fingerprint'})
    for name, digest in protocol['runner_sha256'].items():
        assert sha(z.read('batch/mmstar_harness/'+name))==digest
    for name in ('run_followup_batch.py','followup_workers.py','prepare_mmstar_followup.py','run_transfer_batch.py','run_formal_batch.py'):
        assert sha(z.read('provenance/'+name))==sha((BASE.parent/'followup_20261016'/name).read_bytes())
    data = rows('mmstar_data/samples.jsonl')
    assert sha(z.read('mmstar_data/samples.jsonl'))==protocol['dataset']['samples_sha256']
    assert z.read('mmstar_data/samples.jsonl')==(BASE.parent/'data/mmstar_followup_001/samples.jsonl').read_bytes()
    evals = {r['id']:r for r in data if r['split']=='eval'}
    devs = {r['group_id'] for r in data if r['split']=='dev'}
    assert len(evals)==1241 and not devs & {r['group_id'] for r in evals.values()}
    control = read('batch/mmstar_wrapper_control.json')
    assert control=={'samples':10,'raw_text_changes':0,'runtime_errors':0}
    a=rows('batch/mmstar_capture_dev10/predictions.jsonl'); b=rows('batch/mmstar_wrapper_dev10/predictions.jsonl')
    assert a==b and len(a)==10
    native = {r['id']:r for r in rows('batch/mmstar_native_eval/predictions.jsonl')}
    assert native.keys()==evals.keys()
    results={}; identities={}; preds={}
    candidates=['Kimi_K3_swi_glu_003_R5','DeepSeek_V4_1_Flash_swi_glu_002_R4']
    for cid in candidates:
        prefix='batch/mmstar_candidate_'+cid+'/'
        candidate={r['id']:r for r in rows(prefix+'predictions.jsonl')}
        assert candidate.keys()==evals.keys()
        for runrows in (native,candidate):
            for i,r in runrows.items():
                sample=evals[i]
                assert r['status']=='success' and r['answer']==sample['answer'] and r['group_id']==sample['group_id']
                match=re.fullmatch(r'\s*([A-Z])\.?\s*',r['text'])
                prediction=match[1] if match and ord(match[1])-65<len(sample['choices']) else None
                assert prediction==r['prediction'] and bool(r['correct'])==(prediction==sample['answer'])
        priorrun=read('batch/mmstar_native_eval/run.json'); candrun=read(prefix+'run.json')
        for k in ('protocol_sha256','data','model_files_fingerprint','environment','runner_sha256','scope','split'):
            assert priorrun[k]==candrun[k],k
        assert priorrun['protocol_sha256']==sha(z.read('batch/mmstar_protocol.frozen.json'))
        replay=read('batch/mmstar_replay_'+cid+'/replay.json')
        assert replay['passed']==replay['total']==len(replay['inputs'])==60
        assert all(r['passed'] and r['wrapper']['passed'] and r['wrapper']['max_abs']==0 for r in replay['inputs'])
        identity=read(prefix+'loaded_candidate.json'); identities[cid]=identity
        assert identity['binary_sha256']==replay['identity']['binary_sha256']
        calls=read(prefix+'calls_00000.json')
        assert len(calls)==36 and set(calls)==set(protocol['targets']['swi_glu']) and min(calls.values())>0
        groups=collections.defaultdict(list)
        for i in sorted(native): groups[native[i]['group_id']].append(i)
        delta={i:int(candidate[i]['correct'])-int(native[i]['correct']) for i in native}
        agg=[(sum(delta[i] for i in ids),len(ids)) for ids in groups.values()]
        rng=random.Random(20261015); boot=[]
        for _ in range(5000):
            sample=rng.choices(agg,k=len(agg)); boot.append(sum(x for x,n in sample)/sum(n for x,n in sample))
        ci=[quantile(boot,.025),quantile(boot,.975)]
        saved=read('batch/comparisons/'+cid+'.json')
        for x,y in zip(ci,saved['paired_image_cluster_bootstrap_95pct']): close(x,y)
        n=len(native); basecorrect=sum(r['correct'] for r in native.values()); candcorrect=sum(r['correct'] for r in candidate.values())
        close(basecorrect/n,saved['baseline_accuracy']);close(candcorrect/n,saved['candidate_accuracy'])
        changes=[i for i in native if native[i]['prediction']!=candidate[i]['prediction']]
        assert len(changes)==saved['parsed_changes_including_invalid']==18
        categories=[]
        for category in sorted({r['category'] for r in evals.values()}):
            ids=[i for i,r in evals.items() if r['category']==category]
            categories.append({'category':category,'n':len(ids),'baseline_correct':sum(native[i]['correct'] for i in ids),'candidate_correct':sum(candidate[i]['correct'] for i in ids)})
        for c,s in zip(categories,saved['category_results']):
            assert all(c[k]==s[k] for k in c)
        results[cid]={'n':n,'groups':len(groups),'baseline_correct':basecorrect,'candidate_correct':candcorrect,'ci_pp':[v*100 for v in ci],'correct_to_wrong':sum(v<0 for v in delta.values()),'wrong_to_correct':sum(v>0 for v in delta.values()),'changed_answers':len(changes),'changed_wrong_to_other_wrong':sum(not native[i]['correct'] and not candidate[i]['correct'] for i in changes),'invalid':sum(r['prediction'] is None for r in candidate.values()),'categories':categories,'changed_ids':changes,'capture_records':60,'call_count_per_layer':sorted(set(calls.values()))}
        preds[cid]=candidate
    assert identities[candidates[0]]['binary_sha256']!=identities[candidates[1]]['binary_sha256']
    identical=preds[candidates[0]]==preds[candidates[1]]
    gelu={}
    for cid in ('Grok_4_6_gelu_001_R4','Kimi_K3_gelu_002_R3'):
        d=read('batch/gelu_'+cid+'/diagnostic.json');records=d['records'];assert len(records)==10
        modes={}
        for mode in records[0]['modes']:
            modes[mode]={}
            for reference in ('vs_host','vs_cpu_fp64','vs_cpu_fp64_rounded_bf16'):
                ms=[r['modes'][mode][reference] for r in records]
                modes[mode][reference]={'elements':sum(m['elements'] for m in ms),'failed':sum(m['failed_elements'] for m in ms),'max_abs':max(m['max_abs'] for m in ms),'relative_l2_range':[min(m['relative_l2'] for m in ms),max(m['relative_l2'] for m in ms)]}
        for r in records:
            assert sum(b['failed'] for b in r['failure_by_input_interval'])==r['modes']['candidate']['vs_host']['failed_elements']
            for e in r['largest_error_over_bound_examples']:
                close(.5*e['x']*math.erfc(-e['x']/math.sqrt(2)),e['cpu_fp64'])
        intervals={}
        for r in records:
            for b in r['failure_by_input_interval']:
                key=b['lower']+','+b['upper'];intervals[key]=intervals.get(key,0)+b['failed']
        gelu[cid]={'records':len(records),'unique_image_groups':len({r['group_id'] for r in records}),'modes':modes,'failed_by_input_interval':intervals,'example':records[0]['largest_error_over_bound_examples'][0]}
    costs={}
    for cid in candidates:
        root='batch/swiglu_cost_'+cid+'/'
        timings=rows(root+'timings.jsonl');assert len(timings)==450
        cells=collections.defaultdict(list)
        for r in timings:
            assert len(r['raw_milliseconds'])==r['iterations']==50
            close(statistics.median(r['raw_milliseconds']),r['milliseconds_per_call'])
            cells[r['workload'],r['phase'],r['mode']].append(r)
        lookup={}
        for key,rs in cells.items():
            assert {r['block'] for r in rs}=={0,1,2} and len(rs)==3
            lookup[key]=statistics.median(r['milliseconds_per_call'] for r in rs)
        saved=read(root+'summary.json')
        for r in saved['workload_results']:close(lookup[r['workload'],r['phase'],r['mode']],r['median_ms'])
        phase_results=[]
        for phase in ('decode','prefill'):
            workloads=sorted({w for w,p,m in lookup if p==phase})
            def ratio(m1,m2): return math.exp(statistics.mean(math.log(lookup[w,phase,m1]/lookup[w,phase,m2]) for w in workloads))
            d={'phase':phase,'workloads':len(workloads),'native_over_replacement_full':ratio('native','replacement_full'),'native_over_kernel_prepacked':ratio('native','kernel_prepacked'),'replacement_full_over_kernel_prepacked':ratio('replacement_full','kernel_prepacked'),'wrapper_over_replacement_full':ratio('wrapper','replacement_full')}
            original=next(s for s in saved['matched_summary'] if s['phase']==phase)
            for k in d:
                if k not in ('phase','workloads'):close(d[k],original[k])
            phase_results.append(d)
        costs[cid]={'timing_rows':len(timings),'raw_samples':len(timings)*50,'phases':phase_results}
    audit={'source_zip_sha256':sha(SOURCE.read_bytes()),'manifest_files_verified':len(manifest),'steps_completed':len(status['steps']),'status':status['status'],'source_code_matches_local_package':True,'frozen_protocol_and_runner_hashes_verified':True,'mmstar':results,'candidate_predictions_identical':identical,'candidate_binary_hashes_distinct':True,'gelu':gelu,'swiglu_cost':costs,'limits':['Raw input/output tensors and NPU access unavailable in this ZIP: tensor metrics cannot be recomputed elementwise locally. Stored aggregates, example formulas, timing repeats, predictions, provenance were independently checked.','GELU 10 records represent only 3 image groups; element counts include repeated images.','MMStar is a filtered 1241-question internal evaluation subset, not the full official benchmark.','Prepacked timings include synchronized invocation overhead; not hardware-only kernel time or actual replacement speed.']}
    (OUT/'independent_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'verified_files':len(manifest),'completed_steps':len(status['steps']),'quality':results,'costs':costs,'gelu':gelu},ensure_ascii=False,indent=2))
