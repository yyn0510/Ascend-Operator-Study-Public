# C及收尾：质量比较与默认模型效率

数值直接读取已核验归档。质量差值单位为百分点；计时比为候选/原生墙钟延迟，低于1表示更快。计时条件与质量样本不同，不能互相替代。

## 生成式任务（正式eval）

| 任务/候选 | 原生 | 候选 | 差值(pp) | 观测输出变化 |
| --- | ---: | ---: | ---: | ---: |
| internvl_ai2d_DeepSeek_V4_1_Flash_swi_glu_002_R4 (accuracy) | 77.0000 | 77.4000 | +0.4000 | 6 |
| internvl_ai2d_Kimi_K3_swi_glu_003_R5 (accuracy) | 77.0000 | 77.4000 | +0.4000 | 6 |
| internvl_docvqa_DeepSeek_V4_1_Flash_swi_glu_002_R4 (anls) | 90.7438 | 90.6916 | -0.0522 | 14 |
| internvl_docvqa_Kimi_K3_swi_glu_003_R5 (anls) | 90.7438 | 90.6916 | -0.0522 | 14 |
| qwen3b_ai2d_DeepSeek_V4_1_Flash_gelu_002_R5 (accuracy) | 79.2000 | 78.9000 | -0.3000 | 34 |
| qwen3b_ai2d_DeepSeek_V4_1_Flash_gelu_003_R5 (accuracy) | 79.2000 | 78.9000 | -0.3000 | 34 |
| qwen3b_ai2d_DeepSeek_V4_1_Flash_swi_glu_002_R4 (accuracy) | 79.2000 | 79.3000 | +0.1000 | 24 |
| qwen3b_ai2d_DeepSeek_V4_Flash_swi_glu_001_R2 (accuracy) | 79.2000 | 79.3000 | +0.1000 | 24 |
| qwen3b_ai2d_DeepSeek_V4_Flash_swi_glu_002_R3 (accuracy) | 79.2000 | 79.0000 | -0.2000 | 26 |
| qwen3b_ai2d_DeepSeek_V4_Flash_swi_glu_003_R1 (accuracy) | 79.2000 | 79.0000 | -0.2000 | 26 |
| qwen3b_ai2d_GLM_5_3_swi_glu_003_R3 (accuracy) | 79.2000 | 79.0000 | -0.2000 | 26 |
| qwen3b_ai2d_Grok_4_6_gelu_001_R4 (accuracy) | 79.2000 | 78.9000 | -0.3000 | 34 |
| qwen3b_ai2d_Grok_4_6_gelu_003_R2 (accuracy) | 79.2000 | 78.9000 | -0.3000 | 34 |
| qwen3b_ai2d_Grok_4_6_swi_glu_003_R2 (accuracy) | 79.2000 | 79.2000 | +0.0000 | 23 |
| qwen3b_ai2d_Kimi_K3_gelu_001_R4 (accuracy) | 79.2000 | 78.9000 | -0.3000 | 34 |
| qwen3b_ai2d_Kimi_K3_gelu_002_R3 (accuracy) | 79.2000 | 79.2000 | +0.0000 | 0 |
| qwen3b_ai2d_Kimi_K3_gelu_003_R4 (accuracy) | 79.2000 | 78.9000 | -0.3000 | 34 |
| qwen3b_ai2d_Kimi_K3_swi_glu_002_R4 (accuracy) | 79.2000 | 79.3000 | +0.1000 | 24 |
| qwen3b_ai2d_Kimi_K3_swi_glu_003_R5 (accuracy) | 79.2000 | 79.3000 | +0.1000 | 24 |
| qwen3b_ai2d_Qwen3_8_Max_gelu_001_R2 (accuracy) | 79.2000 | 78.9000 | -0.3000 | 34 |
| qwen3b_docvqa_DeepSeek_V4_1_Flash_swi_glu_002_R4 (anls) | 86.7592 | 86.7753 | +0.0161 | 29 |
| qwen3b_docvqa_Grok_4_6_gelu_001_R4 (anls) | 86.7592 | 86.9844 | +0.2251 | 29 |
| qwen3b_docvqa_Kimi_K3_gelu_002_R3 (anls) | 86.7592 | 86.7592 | +0.0000 | 0 |
| qwen3b_docvqa_Kimi_K3_swi_glu_003_R5 (anls) | 86.7592 | 86.7753 | +0.0161 | 29 |
| qwen7b_ai2d_DeepSeek_V4_1_Flash_swi_glu_002_R4 (accuracy) | 78.1000 | 77.9000 | -0.2000 | 16 |
| qwen7b_ai2d_Grok_4_6_gelu_001_R4 (accuracy) | 78.1000 | 78.4000 | +0.3000 | 15 |
| qwen7b_ai2d_Kimi_K3_gelu_002_R3 (accuracy) | 78.1000 | 78.1000 | +0.0000 | 0 |
| qwen7b_ai2d_Kimi_K3_swi_glu_003_R5 (accuracy) | 78.1000 | 77.9000 | -0.2000 | 16 |
| qwen7b_docvqa_DeepSeek_V4_1_Flash_swi_glu_002_R4 (anls) | 89.9088 | 89.5384 | -0.3704 | 59 |
| qwen7b_docvqa_Grok_4_6_gelu_001_R4 (anls) | 89.9088 | 89.8973 | -0.0115 | 62 |
| qwen7b_docvqa_Kimi_K3_gelu_002_R3 (anls) | 89.9088 | 89.9088 | +0.0000 | 0 |
| qwen7b_docvqa_Kimi_K3_swi_glu_003_R5 (anls) | 89.9088 | 89.5384 | -0.3704 | 59 |

## COCO固定候选库检索

| 候选/宿主 | 图→文原生R@1 | 候选R@1 | 文→图原生R@1 | 候选R@1 |
| --- | ---: | ---: | ---: | ---: |
| clip_coco_DeepSeek_V4_1_Flash_foreach_norm_002_R5 | 74.3000 | 74.5000 | 58.2367 | 58.1967 |
| clip_coco_DeepSeek_V4_1_Flash_foreach_norm_003_R5 | 74.3000 | 74.5000 | 58.2367 | 58.1967 |
| clip_coco_DeepSeek_V4_1_Flash_gelu_002_R5 | 74.3000 | 74.0000 | 58.2367 | 58.1967 |
| clip_coco_DeepSeek_V4_1_Flash_gelu_003_R5 | 74.3000 | 74.0000 | 58.2367 | 58.1967 |
| clip_coco_GLM_5_3_foreach_norm_003_R5 | 74.3000 | 74.5000 | 58.2367 | 58.1967 |
| clip_coco_Grok_4_6_foreach_norm_001_R5 | 74.3000 | 74.5000 | 58.2367 | 58.1967 |
| clip_coco_Grok_4_6_foreach_norm_003_R5 | 74.3000 | 74.5000 | 58.2367 | 58.1967 |
| clip_coco_Grok_4_6_gelu_001_R4 | 74.3000 | 74.0000 | 58.2367 | 58.1967 |
| clip_coco_Grok_4_6_gelu_003_R2 | 74.3000 | 74.0000 | 58.2367 | 58.1967 |
| clip_coco_Kimi_K3_foreach_norm_002_R2 | 74.3000 | 74.5000 | 58.2367 | 58.1967 |
| clip_coco_Kimi_K3_gelu_001_R4 | 74.3000 | 74.0000 | 58.2367 | 58.1967 |
| clip_coco_Kimi_K3_gelu_002_R3 | 74.3000 | 74.3000 | 58.2367 | 58.2367 |
| clip_coco_Kimi_K3_gelu_003_R4 | 74.3000 | 74.0000 | 58.2367 | 58.1967 |
| clip_coco_Qwen3_8_Max_foreach_norm_003_R4 | 74.3000 | 74.5000 | 58.2367 | 58.1967 |
| clip_coco_Qwen3_8_Max_gelu_001_R2 | 74.3000 | 73.9000 | 58.2367 | 58.2367 |
| quick_clip_coco_DeepSeek_V4_1_Flash_sigmoid_001_R5 | 68.7000 | 68.7000 | 49.3003 | 49.3003 |
| quick_clip_coco_DeepSeek_V4_1_Flash_sigmoid_003_R1 | 68.7000 | 68.7000 | 49.3003 | 49.3003 |
| quick_clip_coco_GLM_5_3_sigmoid_003_R5 | 68.7000 | 68.5000 | 49.3003 | 48.9404 |
| quick_clip_coco_Grok_4_6_sigmoid_001_R5 | 68.7000 | 68.7000 | 49.3003 | 49.3003 |
| quick_clip_coco_Grok_4_6_sigmoid_002_R4 | 68.7000 | 68.7000 | 49.3003 | 49.3003 |
| quick_clip_coco_Kimi_K3_sigmoid_003_R4 | 68.7000 | 68.5000 | 49.3003 | 48.9404 |
| quick_clip_coco_MiniMax_M3_sigmoid_003_R2 | 68.7000 | 68.7000 | 49.3003 | 49.3003 |
| quick_clip_coco_Qwen3_8_Max_sigmoid_001_R4 | 68.7000 | 68.7000 | 49.3003 | 49.3003 |

## 默认条件模型延迟

| 宿主/候选 | 候选/原生延迟比（3时段几何均值） | 候选/包装延迟比 |
| --- | ---: | ---: |
| clip / DeepSeek_V4_1_Flash_foreach_norm_002_R5 | 1.02584 | 0.87681 |
| clip / DeepSeek_V4_1_Flash_foreach_norm_003_R5 | 1.05285 | 0.89328 |
| clip / DeepSeek_V4_1_Flash_gelu_002_R5 | 1.02768 | 1.02651 |
| clip / DeepSeek_V4_1_Flash_gelu_003_R5 | 1.03701 | 1.03326 |
| clip / GLM_5_3_foreach_norm_003_R5 | 1.11319 | 0.94684 |
| clip / Grok_4_6_foreach_norm_001_R5 | 1.05016 | 0.88805 |
| clip / Grok_4_6_foreach_norm_003_R5 | 1.03966 | 0.88726 |
| clip / Grok_4_6_gelu_001_R4 | 1.02214 | 1.02182 |
| clip / Grok_4_6_gelu_003_R2 | 1.03083 | 1.02933 |
| clip / Kimi_K3_foreach_norm_002_R2 | 1.05607 | 0.90100 |
| clip / Kimi_K3_gelu_001_R4 | 1.03603 | 1.03567 |
| clip / Kimi_K3_gelu_002_R3 | 1.02698 | 1.02272 |
| clip / Kimi_K3_gelu_003_R4 | 1.03982 | 1.03523 |
| clip / Qwen3_8_Max_foreach_norm_003_R4 | 1.08750 | 0.92328 |
| clip / Qwen3_8_Max_gelu_001_R2 | 1.03740 | 1.03547 |
| internvl / DeepSeek_V4_1_Flash_swi_glu_002_R4 | 0.99053 | 0.99146 |
| internvl / Kimi_K3_swi_glu_003_R5 | 0.99081 | 0.99193 |
| quick_clip / DeepSeek_V4_1_Flash_sigmoid_001_R5 | 1.04727 | 1.04983 |
| quick_clip / DeepSeek_V4_1_Flash_sigmoid_003_R1 | 1.08047 | 1.08002 |
| quick_clip / GLM_5_3_sigmoid_003_R5 | 1.05087 | 1.04834 |
| quick_clip / Grok_4_6_sigmoid_001_R5 | 1.05453 | 1.05110 |
| quick_clip / Grok_4_6_sigmoid_002_R4 | 1.03843 | 1.03934 |
| quick_clip / Kimi_K3_sigmoid_003_R4 | 1.05866 | 1.05742 |
| quick_clip / MiniMax_M3_sigmoid_003_R2 | 1.05072 | 1.04934 |
| quick_clip / Qwen3_8_Max_sigmoid_001_R4 | 1.04420 | 1.04367 |
| qwen3b / DeepSeek_V4_1_Flash_gelu_002_R5 | 0.98304 | 0.99608 |
| qwen3b / DeepSeek_V4_1_Flash_gelu_003_R5 | 1.01734 | 0.99968 |
| qwen3b / DeepSeek_V4_1_Flash_swi_glu_002_R4 | 1.01301 | 1.00395 |
| qwen3b / DeepSeek_V4_Flash_swi_glu_001_R2 | 1.01256 | 0.99287 |
| qwen3b / DeepSeek_V4_Flash_swi_glu_002_R3 | 1.01132 | 1.00622 |
| qwen3b / DeepSeek_V4_Flash_swi_glu_003_R1 | 1.01876 | 0.99797 |
| qwen3b / GLM_5_3_swi_glu_003_R3 | 1.01542 | 0.99737 |
| qwen3b / Grok_4_6_gelu_001_R4 | 1.00221 | 1.00329 |
| qwen3b / Grok_4_6_gelu_003_R2 | 1.00690 | 1.00825 |
| qwen3b / Grok_4_6_swi_glu_003_R2 | 1.03111 | 1.01816 |
| qwen3b / Kimi_K3_gelu_001_R4 | 0.99905 | 0.95460 |
| qwen3b / Kimi_K3_gelu_002_R3 | 1.00091 | 0.99999 |
| qwen3b / Kimi_K3_gelu_003_R4 | 0.99655 | 0.99759 |
| qwen3b / Kimi_K3_swi_glu_002_R4 | 1.00341 | 0.98893 |
| qwen3b / Kimi_K3_swi_glu_003_R5 | 1.01514 | 0.97952 |
| qwen3b / Qwen3_8_Max_gelu_001_R2 | 1.00332 | 1.00051 |
| qwen7b / DeepSeek_V4_1_Flash_swi_glu_002_R4 | 1.02052 | 1.01575 |
| qwen7b / Grok_4_6_gelu_001_R4 | 0.99983 | 0.99825 |
| qwen7b / Kimi_K3_gelu_002_R3 | 0.99604 | 0.99506 |
| qwen7b / Kimi_K3_swi_glu_003_R5 | 1.00300 | 0.98838 |

全部配对区间、任务状态、分辨率dev结果、输入扫描及每时段原始汇总见同目录JSON。这里只作描述性汇总，不从小幅均值差直接推断显著加速。
