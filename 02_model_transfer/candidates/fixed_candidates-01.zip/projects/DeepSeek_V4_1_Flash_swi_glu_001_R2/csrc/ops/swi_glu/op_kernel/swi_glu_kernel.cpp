/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGLU kernel implementation - Ascend C Direct Launch
 */

#include <tuple>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

namespace {
constexpr int64_t SWI_GLU_QUEUE_DEPTH = 2;
constexpr int64_t SWI_GLU_UB_RESERVE = 4096;
constexpr int64_t SWI_GLU_MAX_TILE_ELEMS = 32768;
}  // namespace

template <typename T>
__global__ __aicore__ void swi_glu_kernel(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOut, int64_t blockSize, int64_t tileElems)
{
    using namespace AscendC;

    TPipe pipe;
    TQue<QuePosition::VECIN, SWI_GLU_QUEUE_DEPTH> inQ0;
    TQue<QuePosition::VECIN, SWI_GLU_QUEUE_DEPTH> inQ1;
    TQue<QuePosition::VECOUT, SWI_GLU_QUEUE_DEPTH> outQ;
    pipe.InitBuffer(inQ0, SWI_GLU_QUEUE_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(inQ1, SWI_GLU_QUEUE_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(outQ, SWI_GLU_QUEUE_DEPTH, tileElems * sizeof(T));

    TBuf<TPosition::VECCALC> buf0;
    TBuf<TPosition::VECCALC> buf1;
    TBuf<TPosition::VECCALC> buf2;
    TBuf<TPosition::VECCALC> buf3;
    if constexpr (std::is_same<T, float>::value) {
        pipe.InitBuffer(buf0, tileElems * sizeof(float));
    } else {
        pipe.InitBuffer(buf0, tileElems * sizeof(float));
        pipe.InitBuffer(buf1, tileElems * sizeof(float));
        pipe.InitBuffer(buf2, tileElems * sizeof(float));
        pipe.InitBuffer(buf3, tileElems * sizeof(float));
    }

    GlobalTensor<T> inGm;
    GlobalTensor<T> outGm;
    inGm.SetGlobalBuffer(reinterpret_cast<__gm__ T*>(input));
    outGm.SetGlobalBuffer(reinterpret_cast<__gm__ T*>(output));

    int64_t coreNum = GetBlockNum();
    if (coreNum <= 0) coreNum = 1;
    int64_t coreId = GetBlockIdx();

    int64_t perCore = (totalOut + coreNum - 1) / coreNum;
    int64_t myStart = coreId * perCore;
    int64_t myEnd = myStart + perCore;
    if (myEnd > totalOut) myEnd = totalOut;
    if (myStart >= myEnd) return;

    int64_t n = myStart;
    while (n < myEnd) {
        int64_t o = n / blockSize;
        int64_t r = n - o * blockSize;
        int64_t chunk = blockSize - r;
        int64_t avail = myEnd - n;
        if (chunk > avail) chunk = avail;
        if (chunk > tileElems) chunk = tileElems;

        int64_t xBase = o * 2 * blockSize + r;

        LocalTensor<T> x0L = inQ0.AllocTensor<T>();
        LocalTensor<T> x1L = inQ1.AllocTensor<T>();
        LocalTensor<T> outL = outQ.AllocTensor<T>();

        DataCopyExtParams cp;
        cp.blockCount = 1;
        cp.blockLen = static_cast<uint32_t>(chunk * sizeof(T));
        cp.srcStride = 0;
        cp.dstStride = 0;
        cp.rsv = 0;

        DataCopyPadExtParams<T> pad;
        pad.isPad = false;
        pad.leftPadding = 0;
        pad.rightPadding = 0;
        pad.paddingValue = 0;

        DataCopyPad(x0L, inGm[xBase], cp, pad);
        DataCopyPad(x1L, inGm[xBase + blockSize], cp, pad);
        inQ0.EnQue(x0L);
        inQ1.EnQue(x1L);
        x0L = inQ0.DeQue<T>();
        x1L = inQ1.DeQue<T>();

        if constexpr (std::is_same<T, float>::value) {
            LocalTensor<float> tmp = buf0.Get<float>();
            Muls(tmp, x0L, static_cast<float>(-1.0), chunk);
            Exp(tmp, tmp, chunk);
            Adds(tmp, tmp, static_cast<float>(1.0), chunk);
            Div(outL, x0L, tmp, chunk);
            Mul(outL, outL, x1L, chunk);
        } else {
            LocalTensor<float> x0f = buf0.Get<float>();
            LocalTensor<float> x1f = buf1.Get<float>();
            LocalTensor<float> of = buf2.Get<float>();
            LocalTensor<float> tmp = buf3.Get<float>();
            Cast(x0f, x0L, RoundMode::CAST_NONE, chunk);
            Cast(x1f, x1L, RoundMode::CAST_NONE, chunk);
            Muls(tmp, x0f, static_cast<float>(-1.0), chunk);
            Exp(tmp, tmp, chunk);
            Adds(tmp, tmp, static_cast<float>(1.0), chunk);
            Div(of, x0f, tmp, chunk);
            Mul(of, of, x1f, chunk);
            Cast(outL, of, RoundMode::CAST_RINT, chunk);
        }

        outQ.EnQue(outL);
        inQ0.FreeTensor(x0L);
        inQ1.FreeTensor(x1L);
        outL = outQ.DeQue<T>();

        DataCopyExtParams cpOut;
        cpOut.blockCount = 1;
        cpOut.blockLen = static_cast<uint32_t>(chunk * sizeof(T));
        cpOut.srcStride = 0;
        cpOut.dstStride = 0;
        cpOut.rsv = 0;
        DataCopyPad(outGm[n], outL, cpOut);
        outQ.FreeTensor(outL);

        n += chunk;
    }
}

std::tuple<int64_t, int64_t> calc_swi_glu_tiling_params(int64_t dtypeSize)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    // UB bytes consumed per element with double buffering:
    //   in0(2*dtypeSize) + in1(2*dtypeSize) + out(2*dtypeSize) + fp32 scratch
    // fp32:  2*4 + 2*4 + 2*4 + 4   = 28
    // fp16/bf16: 2*2 + 2*2 + 2*2 + 4*4 = 28
    (void)dtypeSize;
    constexpr int64_t kBytesPerElem = 28;

    int64_t usable = static_cast<int64_t>(ubSize) - SWI_GLU_UB_RESERVE;
    if (usable < 8192) usable = 8192;
    int64_t tileElems = usable / kBytesPerElem;
    tileElems = (tileElems / 32) * 32;
    if (tileElems < 32) tileElems = 32;
    if (tileElems > SWI_GLU_MAX_TILE_ELEMS) tileElems = SWI_GLU_MAX_TILE_ELEMS;

    return std::make_tuple(coreNum, tileElems);
}

extern "C" {
void launch_swi_glu_kernel_float(GM_ADDR input, GM_ADDR output, int64_t totalOut, int64_t blockSize,
                                 int64_t tileElems, int64_t numBlocks, void* stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(input, output, totalOut, blockSize, tileElems);
}

void launch_swi_glu_kernel_half(GM_ADDR input, GM_ADDR output, int64_t totalOut, int64_t blockSize,
                                int64_t tileElems, int64_t numBlocks, void* stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(input, output, totalOut, blockSize, tileElems);
}

void launch_swi_glu_kernel_bfloat16(GM_ADDR input, GM_ADDR output, int64_t totalOut, int64_t blockSize,
                                    int64_t tileElems, int64_t numBlocks, void* stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(input, output, totalOut, blockSize, tileElems);
}
}
