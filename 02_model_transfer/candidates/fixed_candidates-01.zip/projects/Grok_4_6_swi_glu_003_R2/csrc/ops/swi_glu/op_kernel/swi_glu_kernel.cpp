/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGlu kernel, tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t MAX_BLOCK_COUNT = 4095;
constexpr static int64_t MAX_TILE_ELEMS = 4096;
constexpr static int64_t MIN_ELEMS_PER_CORE = 512;
constexpr static int64_t ALIGN_BYTES = 32;

template <typename T>
class KernelSwiGlu {
public:
    __aicore__ inline KernelSwiGlu() {}

    __aicore__ inline void Init(GM_ADDR input, GM_ADDR output, int64_t totalOutIn,
                                int64_t halfInnerIn, int64_t blockLength, uint32_t tileElemsIn)
    {
        totalOut = totalOutIn;
        halfInner = halfInnerIn;
        tileElems = tileElemsIn;
        startIdx = AscendC::GetBlockIdx() * blockLength;
        endIdx = startIdx + blockLength;
        if (endIdx > totalOut) {
            endIdx = totalOut;
        }

        inGm.SetGlobalBuffer((__gm__ T *)input, totalOut * 2);
        outGm.SetGlobalBuffer((__gm__ T *)output, totalOut);

        uint32_t tileBytes = (tileElems + static_cast<uint32_t>(ALIGN_BYTES)) * static_cast<uint32_t>(sizeof(T));
        uint32_t calcBytes = (tileElems + static_cast<uint32_t>(ALIGN_BYTES)) * static_cast<uint32_t>(sizeof(float));
        pipe.InitBuffer(inQueueX0, PIPELINE_DEPTH, tileBytes);
        pipe.InitBuffer(inQueueX1, PIPELINE_DEPTH, tileBytes);
        pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileBytes);
        pipe.InitBuffer(calcBuf0, calcBytes);
        pipe.InitBuffer(calcBuf1, calcBytes);
    }

    __aicore__ inline void Process()
    {
        if (startIdx >= endIdx || halfInner <= 0) {
            return;
        }

        int64_t idx = startIdx;
        int64_t local = idx % halfInner;
        if (local != 0) {
            int64_t chunk = halfInner - local;
            if (chunk > endIdx - idx) {
                chunk = endIdx - idx;
            }
            int64_t group = idx / halfInner;
            int64_t x0Off = group * 2 * halfInner + local;
            ProcessContiguousRange(x0Off, x0Off + halfInner, idx, chunk);
            idx += chunk;
        }

        if (idx < endIdx) {
            int64_t alignedEnd = endIdx - (endIdx % halfInner);
            if (alignedEnd > idx) {
                int64_t nGroups = (alignedEnd - idx) / halfInner;
                int64_t groupBegin = idx / halfInner;
                ProcessCompleteGroups(groupBegin, nGroups);
                idx = alignedEnd;
            }
        }

        if (idx < endIdx) {
            int64_t chunk = endIdx - idx;
            int64_t group = idx / halfInner;
            int64_t localTail = idx % halfInner;
            int64_t x0Off = group * 2 * halfInner + localTail;
            ProcessContiguousRange(x0Off, x0Off + halfInner, idx, chunk);
        }
    }

private:
    __aicore__ inline uint32_t AlignCount(uint32_t n)
    {
        uint32_t align = static_cast<uint32_t>(ALIGN_BYTES / sizeof(T));
        if (align < 8) {
            align = 8;
        }
        uint32_t aligned = (n + align - 1) / align * align;
        uint32_t maxCount = tileElems + static_cast<uint32_t>(ALIGN_BYTES);
        if (aligned > maxCount) {
            aligned = maxCount;
        }
        if (aligned < n) {
            aligned = n;
        }
        return aligned;
    }

    __aicore__ inline bool IsInnerAligned()
    {
        return ((halfInner * static_cast<int64_t>(sizeof(T))) % ALIGN_BYTES) == 0;
    }

    __aicore__ inline void ProcessContiguousRange(int64_t x0Off, int64_t x1Off, int64_t outOff, int64_t count)
    {
        int64_t done = 0;
        while (done < count) {
            uint32_t n = tileElems;
            if (count - done < static_cast<int64_t>(tileElems)) {
                n = static_cast<uint32_t>(count - done);
            }
            RunTile(x0Off + done, x1Off + done, outOff + done, n, 1,
                    static_cast<uint32_t>(n * sizeof(T)), false);
            done += static_cast<int64_t>(n);
        }
    }

    __aicore__ inline void ProcessCompleteGroups(int64_t groupBegin, int64_t nGroups)
    {
        int64_t tile = static_cast<int64_t>(tileElems);
        if (halfInner > tile || !IsInnerAligned()) {
            for (int64_t g = 0; g < nGroups; ++g) {
                int64_t x0Off = (groupBegin + g) * 2 * halfInner;
                int64_t outOff = (groupBegin + g) * halfInner;
                ProcessContiguousRange(x0Off, x0Off + halfInner, outOff, halfInner);
            }
            return;
        }

        int64_t maxBatch = tile / halfInner;
        if (maxBatch > MAX_BLOCK_COUNT) {
            maxBatch = MAX_BLOCK_COUNT;
        }
        if (maxBatch < 1) {
            maxBatch = 1;
        }

        int64_t g = 0;
        while (g < nGroups) {
            int64_t batch = nGroups - g;
            if (batch > maxBatch) {
                batch = maxBatch;
            }
            int64_t x0Off = (groupBegin + g) * 2 * halfInner;
            int64_t x1Off = x0Off + halfInner;
            int64_t outOff = (groupBegin + g) * halfInner;
            uint32_t n = static_cast<uint32_t>(batch * halfInner);
            if (batch == 1) {
                RunTile(x0Off, x1Off, outOff, n, 1, static_cast<uint32_t>(n * sizeof(T)), false);
            } else {
                uint16_t blockCount = static_cast<uint16_t>(batch);
                uint32_t blockLenBytes = static_cast<uint32_t>(halfInner * sizeof(T));
                RunTile(x0Off, x1Off, outOff, n, blockCount, blockLenBytes, true);
            }
            g += batch;
        }
    }

    __aicore__ inline void RunTile(int64_t x0Off, int64_t x1Off, int64_t outOff, uint32_t n,
                                   uint16_t blockCount, uint32_t blockLenBytes, bool strided)
    {
        AscendC::LocalTensor<T> x0Local = inQueueX0.AllocTensor<T>();
        AscendC::LocalTensor<T> x1Local = inQueueX1.AllocTensor<T>();
        AscendC::DataCopyPadExtParams<T> padParams{true, 0, 0, static_cast<T>(0)};
        if (!strided) {
            AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(n * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPad(x0Local, inGm[x0Off], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, inGm[x1Off], copyParams, padParams);
        } else {
            AscendC::DataCopyExtParams copyParams{blockCount, blockLenBytes, blockLenBytes, 0, 0};
            AscendC::DataCopyPad(x0Local, inGm[x0Off], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, inGm[x1Off], copyParams, padParams);
        }
        inQueueX0.EnQue(x0Local);
        inQueueX1.EnQue(x1Local);

        x0Local = inQueueX0.DeQue<T>();
        x1Local = inQueueX1.DeQue<T>();
        AscendC::LocalTensor<T> outLocal = outQueue.AllocTensor<T>();
        Compute(outLocal, x0Local, x1Local, n);
        outQueue.EnQue(outLocal);
        inQueueX0.FreeTensor(x0Local);
        inQueueX1.FreeTensor(x1Local);

        outLocal = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams outParams{1, static_cast<uint32_t>(n * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(outGm[outOff], outLocal, outParams);
        outQueue.FreeTensor(outLocal);
    }

    __aicore__ inline void Compute(const AscendC::LocalTensor<T> &outLocal,
                                   const AscendC::LocalTensor<T> &x0Local,
                                   const AscendC::LocalTensor<T> &x1Local, uint32_t n)
    {
        uint32_t calcN = AlignCount(n);
        if constexpr (sizeof(T) == sizeof(float)) {
            AscendC::Sigmoid(outLocal, x0Local, calcN);
            AscendC::Mul(outLocal, outLocal, x0Local, calcN);
            AscendC::Mul(outLocal, outLocal, x1Local, calcN);
        } else {
            AscendC::LocalTensor<float> buf0 = calcBuf0.Get<float>();
            AscendC::LocalTensor<float> buf1 = calcBuf1.Get<float>();
            AscendC::Cast(buf0, x0Local, AscendC::RoundMode::CAST_NONE, calcN);
            AscendC::Sigmoid(buf1, buf0, calcN);
            AscendC::Mul(buf1, buf1, buf0, calcN);
            AscendC::Cast(buf0, x1Local, AscendC::RoundMode::CAST_NONE, calcN);
            AscendC::Mul(buf1, buf1, buf0, calcN);
            AscendC::Cast(outLocal, buf1, AscendC::RoundMode::CAST_RINT, calcN);
        }
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> inGm;
    AscendC::GlobalTensor<T> outGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf0;
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf1;
    int64_t totalOut = 0;
    int64_t halfInner = 0;
    int64_t startIdx = 0;
    int64_t endIdx = 0;
    uint32_t tileElems = 0;
};

template <typename T>
__global__ __aicore__ void swi_glu_kernel(GM_ADDR input, GM_ADDR output, int64_t totalOut,
                                          int64_t halfInner, int64_t blockLength, uint32_t tileElems)
{
    KernelSwiGlu<T> op;
    op.Init(input, output, totalOut, halfInner, blockLength, tileElems);
    op.Process();
}

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_tiling_params(int64_t totalOut, int64_t dtypeSize)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = 1;
    if (totalOut > 0) {
        numBlocks = (totalOut + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
        if (numBlocks < 1) {
            numBlocks = 1;
        }
        if (numBlocks > coreNum) {
            numBlocks = coreNum;
        }
    }
    int64_t blockLength = (totalOut + numBlocks - 1) / numBlocks;
    if (blockLength < 1) {
        blockLength = 1;
    }

    int64_t reserve = 16384;
    int64_t usable = static_cast<int64_t>(ubSize) - reserve;
    if (usable < 32768) {
        usable = 32768;
    }
    int64_t denom = PIPELINE_DEPTH * 3 * dtypeSize + 2 * static_cast<int64_t>(sizeof(float));
    if (denom < 16) {
        denom = 16;
    }
    int64_t tileElems = usable / denom;
    if (tileElems > MAX_TILE_ELEMS) {
        tileElems = MAX_TILE_ELEMS;
    }
    tileElems = tileElems / 16 * 16;
    if (tileElems < 16) {
        tileElems = 16;
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileElems));
}

extern "C" {

void launch_swi_glu_kernel_float(GM_ADDR input, GM_ADDR output, int64_t totalOut, int64_t halfInner,
                                 int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(input, output, totalOut, halfInner, blockLength, tileElems);
}

void launch_swi_glu_kernel_half(GM_ADDR input, GM_ADDR output, int64_t totalOut, int64_t halfInner,
                                int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(input, output, totalOut, halfInner, blockLength, tileElems);
}

void launch_swi_glu_kernel_bf16(GM_ADDR input, GM_ADDR output, int64_t totalOut, int64_t halfInner,
                                int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(input, output, totalOut, halfInner, blockLength, tileElems);
}

}
