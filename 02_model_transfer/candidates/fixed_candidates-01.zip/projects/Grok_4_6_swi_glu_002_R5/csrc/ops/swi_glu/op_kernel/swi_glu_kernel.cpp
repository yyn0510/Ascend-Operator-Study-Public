/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGlu kernel, host tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <algorithm>
#include <cstdint>
#include <tuple>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t COUNT_ALIGN = 16;
constexpr static float SILU_NEG_CLAMP = -3.402823466e38f;

template <typename T>
__aicore__ inline void SwiGluCompute(const AscendC::LocalTensor<T> &yLocal,
                                     const AscendC::LocalTensor<T> &x0Local,
                                     const AscendC::LocalTensor<T> &x1Local,
                                     const AscendC::LocalTensor<float> &tmpX0,
                                     const AscendC::LocalTensor<float> &tmpX1,
                                     const AscendC::LocalTensor<float> &work,
                                     uint32_t count)
{
    if constexpr (sizeof(T) == sizeof(float)) {
        AscendC::Maxs(tmpX0, x0Local, SILU_NEG_CLAMP, count);
        AscendC::Sigmoid(work, tmpX0, count);
        AscendC::Mul(work, work, tmpX0, count);
        AscendC::Mul(yLocal, work, x1Local, count);
    } else {
        AscendC::Cast(tmpX0, x0Local, AscendC::RoundMode::CAST_NONE, count);
        AscendC::Cast(tmpX1, x1Local, AscendC::RoundMode::CAST_NONE, count);
        AscendC::Maxs(tmpX0, tmpX0, SILU_NEG_CLAMP, count);
        AscendC::Sigmoid(work, tmpX0, count);
        AscendC::Mul(work, work, tmpX0, count);
        AscendC::Mul(work, work, tmpX1, count);
        AscendC::Cast(yLocal, work, AscendC::RoundMode::CAST_RINT, count);
    }
}

template <typename T>
__global__ __aicore__ void swi_glu_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength,
                                          int64_t pairLen, int64_t tileElems)
{
    if (tileElems <= 0 || pairLen <= 0 || totalLength <= 0) {
        return;
    }

    int64_t offset = blockLength * static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t curLength = totalLength - offset;
    if (curLength > blockLength) {
        curLength = blockLength;
    }
    if (curLength <= 0) {
        return;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpX0Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpX1Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpWorkBuf;

    uint32_t tileBytes = static_cast<uint32_t>(tileElems * sizeof(T) + 64);
    uint32_t calcBytes = static_cast<uint32_t>(tileElems * sizeof(float) + 64);
    pipe.InitBuffer(inQueueX0, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(inQueueX1, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(tmpX0Buf, calcBytes);
    pipe.InitBuffer(tmpX1Buf, calcBytes);
    pipe.InitBuffer(tmpWorkBuf, calcBytes);

    xGm.SetGlobalBuffer((__gm__ T *)x);
    yGm.SetGlobalBuffer((__gm__ T *)y);

    AscendC::LocalTensor<float> tmpX0 = tmpX0Buf.Get<float>();
    AscendC::LocalTensor<float> tmpX1 = tmpX1Buf.Get<float>();
    AscendC::LocalTensor<float> work = tmpWorkBuf.Get<float>();
    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    int64_t idx = offset;
    int64_t end = offset + curLength;
    while (idx < end) {
        int64_t localOff = idx % pairLen;
        int64_t remainInPair = pairLen - localOff;
        int64_t n = end - idx;
        if (n > remainInPair) {
            n = remainInPair;
        }
        if (n > tileElems) {
            n = tileElems;
        }

        int64_t blockId = idx / pairLen;
        int64_t x0Off = blockId * (pairLen * 2) + localOff;
        int64_t x1Off = x0Off + pairLen;
        uint32_t bytes = static_cast<uint32_t>(n * sizeof(T));
        AscendC::DataCopyExtParams copyParams{1, bytes, 0, 0, 0};

        AscendC::LocalTensor<T> x0Local = inQueueX0.AllocTensor<T>();
        AscendC::LocalTensor<T> x1Local = inQueueX1.AllocTensor<T>();
        AscendC::DataCopyPad(x0Local, xGm[x0Off], copyParams, padParams);
        AscendC::DataCopyPad(x1Local, xGm[x1Off], copyParams, padParams);
        inQueueX0.EnQue(x0Local);
        inQueueX1.EnQue(x1Local);
        x0Local = inQueueX0.DeQue<T>();
        x1Local = inQueueX1.DeQue<T>();
        AscendC::LocalTensor<T> yLocal = outQueueY.AllocTensor<T>();

        SwiGluCompute<T>(yLocal, x0Local, x1Local, tmpX0, tmpX1, work, static_cast<uint32_t>(n));

        outQueueY.EnQue(yLocal);
        inQueueX0.FreeTensor(x0Local);
        inQueueX1.FreeTensor(x1Local);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[idx], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
        idx += n;
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_swi_glu_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 512;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 192 * 1024;
    int64_t coreNum = 1;
    if (ascendcPlatform != nullptr) {
        ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
        coreNum = ascendcPlatform->GetCoreNumAiv();
        if (coreNum <= 0) {
            coreNum = 1;
        }
    }
    if (ubSize < 32 * 1024) {
        ubSize = 192 * 1024;
    }
    if (dtypeSize < 2) {
        dtypeSize = 2;
    }
    if (totalLength < 1) {
        totalLength = 1;
    }

    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    int64_t perElem = PIPELINE_DEPTH * 3 * dtypeSize + 3 * static_cast<int64_t>(sizeof(float)) + 16;
    int64_t usable = static_cast<int64_t>(ubSize) - 8192;
    if (usable < perElem) {
        usable = perElem;
    }
    int64_t tileElems = usable / perElem;
    tileElems = (tileElems / COUNT_ALIGN) * COUNT_ALIGN;
    if (tileElems < COUNT_ALIGN) {
        tileElems = COUNT_ALIGN;
    }
    if (tileElems > 8192) {
        tileElems = 8192;
    }
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

extern "C" {

void launch_swi_glu_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                 int64_t blockLength, int64_t pairLen, int64_t tileElems, void *stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, pairLen, tileElems);
}

void launch_swi_glu_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                int64_t blockLength, int64_t pairLen, int64_t tileElems, void *stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, pairLen, tileElems);
}

void launch_swi_glu_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                int64_t blockLength, int64_t pairLen, int64_t tileElems, void *stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, pairLen, tileElems);
}

}
