/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_kernel.cpp
 * \brief ForeachNorm Ascend C kernel, host tiling and launch wrappers.
 */

#include <tuple>
#include <algorithm>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int PIPELINE_DEPTH = 3;
constexpr static int32_t MAX_WS_BLOCKS = 8192;

template <int MODE>
__aicore__ inline void foreach_norm_apply(
    AscendC::LocalTensor<float>& work,
    AscendC::LocalTensor<float>& accF,
    AscendC::LocalTensor<float>& tmp1,
    AscendC::LocalTensor<float>& tmp2,
    int32_t cnt,
    float p)
{
    if (MODE == 1) {
        AscendC::Abs(tmp1, work, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    } else if (MODE == 2) {
        AscendC::Mul(tmp1, work, work, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    } else if (MODE == 3) {
        AscendC::Mul(tmp1, work, work, cnt);
        AscendC::Abs(tmp2, work, cnt);
        AscendC::Mul(tmp1, tmp1, tmp2, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    } else if (MODE == 4) {
        AscendC::Mul(tmp1, work, work, cnt);
        AscendC::Mul(tmp1, tmp1, tmp1, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    } else if (MODE == 5) {
        AscendC::Mul(tmp1, work, work, cnt);
        AscendC::Mul(tmp1, tmp1, tmp1, cnt);
        AscendC::Abs(tmp2, work, cnt);
        AscendC::Mul(tmp1, tmp1, tmp2, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    } else if (MODE == 6) {
        AscendC::Abs(tmp1, work, cnt);
        AscendC::Sqrt(tmp2, tmp1, cnt);
        AscendC::Mul(tmp1, tmp1, tmp2, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    } else if (MODE == 7) {
        AscendC::Mul(tmp1, work, work, cnt);
        AscendC::Abs(tmp2, work, cnt);
        AscendC::Sqrt(tmp2, tmp2, cnt);
        AscendC::Mul(tmp1, tmp1, tmp2, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    } else if (MODE == 8) {
        AscendC::Abs(tmp1, work, cnt);
        AscendC::Max(accF, accF, tmp1, cnt);
    } else if (MODE == 9) {
        AscendC::Abs(tmp1, work, cnt);
        AscendC::Min(accF, accF, tmp1, cnt);
    } else if (MODE == 10) {
        AscendC::Abs(tmp1, work, cnt);
        AscendC::Muls(tmp1, tmp1, 3.0e38f, cnt);
        AscendC::Muls(tmp1, tmp1, 3.0e38f, cnt);
        AscendC::Mins(tmp1, tmp1, 1.0f, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    } else if (MODE == 11) {
        AscendC::Abs(tmp1, work, cnt);
        AscendC::Div(tmp1, tmp2, tmp1, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    } else {
        AscendC::Abs(tmp1, work, cnt);
        AscendC::Ln(tmp2, tmp1, cnt);
        AscendC::Muls(tmp2, tmp2, p, cnt);
        AscendC::Exp(tmp1, tmp2, cnt);
        AscendC::Add(accF, accF, tmp1, cnt);
    }
}

template <typename T, int MODE>
__global__ __aicore__ void foreach_norm_partial_kernel(
    GM_ADDR x,
    GM_ADDR workspace,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileElements,
    float p)
{
    const int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    const int64_t base = blockIdx * blockLength;
    if (base >= totalLength) {
        return;
    }
    int64_t curLen = totalLength - base;
    if (curLen > blockLength) {
        curLen = blockLength;
    }

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueT;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufAll;

    const uint32_t inBytes = tileElements * static_cast<uint32_t>(sizeof(T));
    const uint32_t floatBytes = tileElements * static_cast<uint32_t>(sizeof(float));
    pipe.InitBuffer(inQueueT, PIPELINE_DEPTH, inBytes);
    pipe.InitBuffer(outQueue, 1, 32);
    pipe.InitBuffer(bufAll, floatBytes * 4);

    AscendC::LocalTensor<float> bufBase = bufAll.Get<float>();
    AscendC::LocalTensor<float> accF = bufBase;
    AscendC::LocalTensor<float> calcF = bufBase[tileElements];
    AscendC::LocalTensor<float> tmp1 = bufBase[tileElements * 2];
    AscendC::LocalTensor<float> tmp2 = bufBase[tileElements * 3];

    if (MODE == 9) {
        AscendC::Duplicate(accF, 3.0e38f, static_cast<int32_t>(tileElements));
    } else {
        AscendC::Duplicate(accF, 0.0f, static_cast<int32_t>(tileElements));
    }
    if (MODE == 11) {
        AscendC::Duplicate(tmp2, 1.0f, static_cast<int32_t>(tileElements));
    }

    AscendC::GlobalTensor<T> xGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + base);

    const int64_t tileNum = (curLen + static_cast<int64_t>(tileElements) - 1) / static_cast<int64_t>(tileElements);
    for (int64_t i = 0; i < tileNum; ++i) {
        const int64_t off = i * static_cast<int64_t>(tileElements);
        const int64_t remain = curLen - off;
        const int32_t cnt = static_cast<int32_t>(remain > static_cast<int64_t>(tileElements) ? tileElements : remain);

        AscendC::DataCopyExtParams cpy{1, static_cast<uint32_t>(cnt * static_cast<int32_t>(sizeof(T))), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> pad{false, 0, 0, 0};

        AscendC::LocalTensor<T> tLoc = inQueueT.AllocTensor<T>();
        AscendC::DataCopyPad(tLoc, xGm[off], cpy, pad);
        inQueueT.EnQue(tLoc);
        tLoc = inQueueT.DeQue<T>();

        if constexpr (sizeof(T) == 4) {
            foreach_norm_apply<MODE>(tLoc, accF, tmp1, tmp2, cnt, p);
        } else {
            AscendC::Cast<float, T>(calcF, tLoc, AscendC::RoundMode::CAST_NONE, cnt);
            foreach_norm_apply<MODE>(calcF, accF, tmp1, tmp2, cnt, p);
        }

        inQueueT.FreeTensor(tLoc);
    }

    AscendC::LocalTensor<float> oLoc = outQueue.AllocTensor<float>();
    if (MODE == 8) {
        AscendC::ReduceMax<float>(oLoc, accF, tmp2, static_cast<int32_t>(tileElements));
    } else if (MODE == 9) {
        AscendC::ReduceMin<float>(oLoc, accF, tmp2, static_cast<int32_t>(tileElements));
    } else {
        AscendC::ReduceSum<float>(oLoc, accF, tmp2, static_cast<int32_t>(tileElements));
    }
    outQueue.EnQue(oLoc);
    oLoc = outQueue.DeQue<float>();

    AscendC::GlobalTensor<float> wsGm;
    wsGm.SetGlobalBuffer((__gm__ float *)workspace);
    AscendC::DataCopyExtParams outParams{1, static_cast<uint32_t>(sizeof(float)), 0, 0, 0};
    AscendC::DataCopyPad(wsGm[blockIdx], oLoc, outParams);
    outQueue.FreeTensor(oLoc);
}

template <typename T>
__global__ __aicore__ void foreach_norm_finalize_kernel(
    GM_ADDR workspace,
    GM_ADDR y,
    int32_t numBlocks,
    float p,
    int32_t mode)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufRed;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufTmp;

    const int32_t aligned = ((numBlocks + 31) / 32) * 32;
    const uint32_t inBytes = static_cast<uint32_t>(aligned) * static_cast<uint32_t>(sizeof(float));

    pipe.InitBuffer(inQueue, 1, inBytes);
    pipe.InitBuffer(outQueue, 1, 32);
    pipe.InitBuffer(bufRed, 32);
    pipe.InitBuffer(bufTmp, inBytes + 256);

    AscendC::LocalTensor<float> wsLoc = inQueue.AllocTensor<float>();
    AscendC::GlobalTensor<float> wsGm;
    wsGm.SetGlobalBuffer((__gm__ float *)workspace);
    AscendC::DataCopyExtParams cp{1, static_cast<uint32_t>(numBlocks * static_cast<int32_t>(sizeof(float))), 0, 0, 0};
    AscendC::DataCopyPadExtParams<float> pp{false, 0, 0, 0};
    AscendC::DataCopyPad(wsLoc, wsGm[0], cp, pp);
    inQueue.EnQue(wsLoc);
    wsLoc = inQueue.DeQue<float>();

    AscendC::LocalTensor<float> redT = bufRed.Get<float>();
    AscendC::LocalTensor<float> tmpW = bufTmp.Get<float>();

    if (mode == 8) {
        AscendC::ReduceMax<float>(redT, wsLoc, tmpW, numBlocks);
    } else if (mode == 9) {
        AscendC::ReduceMin<float>(redT, wsLoc, tmpW, numBlocks);
    } else {
        AscendC::ReduceSum<float>(redT, wsLoc, tmpW, numBlocks);
    }
    inQueue.FreeTensor(wsLoc);

    const bool needRoot = !(mode == 1 || mode == 8 || mode == 9 || mode == 10);
    if (needRoot) {
        if (mode == 2) {
            AscendC::Sqrt(redT, redT, 1);
        } else {
            AscendC::Ln(tmpW, redT, 1);
            AscendC::Muls(tmpW, tmpW, 1.0f / p, 1);
            AscendC::Exp(redT, tmpW, 1);
        }
    }

    AscendC::LocalTensor<T> oLoc = outQueue.AllocTensor<T>();
    if constexpr (sizeof(T) == 4) {
        AscendC::Adds(oLoc, redT, 0.0f, 1);
    } else {
        AscendC::Cast<T, float>(oLoc, redT, AscendC::RoundMode::CAST_RINT, 1);
    }
    outQueue.EnQue(oLoc);
    oLoc = outQueue.DeQue<T>();

    AscendC::GlobalTensor<T> yGm;
    yGm.SetGlobalBuffer((__gm__ T *)y);
    AscendC::DataCopyExtParams op{1, static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
    AscendC::DataCopyPad(yGm[0], oLoc, op);
    outQueue.FreeTensor(oLoc);
}

template <typename T>
void launch_foreach_norm_partial(
    GM_ADDR x,
    GM_ADDR workspace,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElements,
    float p,
    int32_t mode,
    void *stream)
{
    switch (mode) {
        case 1:
            foreach_norm_partial_kernel<T, 1><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 2:
            foreach_norm_partial_kernel<T, 2><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 3:
            foreach_norm_partial_kernel<T, 3><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 4:
            foreach_norm_partial_kernel<T, 4><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 5:
            foreach_norm_partial_kernel<T, 5><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 6:
            foreach_norm_partial_kernel<T, 6><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 7:
            foreach_norm_partial_kernel<T, 7><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 8:
            foreach_norm_partial_kernel<T, 8><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 9:
            foreach_norm_partial_kernel<T, 9><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 10:
            foreach_norm_partial_kernel<T, 10><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        case 11:
            foreach_norm_partial_kernel<T, 11><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
        default:
            foreach_norm_partial_kernel<T, 0><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElements, p);
            break;
    }
}

template <typename T>
void launch_foreach_norm_finalize(
    GM_ADDR workspace,
    GM_ADDR y,
    int32_t numBlocks,
    float p,
    int32_t mode,
    void *stream)
{
    foreach_norm_finalize_kernel<T><<<1, nullptr, stream>>>(workspace, y, numBlocks, p, mode);
}

std::tuple<int64_t, int64_t, uint32_t> calc_foreach_norm_tiling_params(int64_t totalLength)
{
    uint64_t ubSize = 196608ULL;
    int64_t coreNum = 1;
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    if (platform != nullptr) {
        platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
        int32_t cn = platform->GetCoreNumAiv();
        if (cn > 0) {
            coreNum = static_cast<int64_t>(cn);
        }
    }
    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    if (numBlocks > MAX_WS_BLOCKS) {
        numBlocks = MAX_WS_BLOCKS;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    int64_t tileElems = static_cast<int64_t>((ubSize * 9ULL) / 10ULL) / 28;
    tileElems = (tileElems / 8) * 8;
    if (tileElems < 32) {
        tileElems = 32;
    }
    if (tileElems > 16384) {
        tileElems = 16384;
    }
    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileElems));
}

extern "C" {
void launch_foreach_norm_partial_float(GM_ADDR x, GM_ADDR workspace, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElements, float p, int32_t mode, void *stream)
{
    launch_foreach_norm_partial<float>(x, workspace, totalLength, numBlocks, blockLength, tileElements, p, mode, stream);
}
void launch_foreach_norm_partial_half(GM_ADDR x, GM_ADDR workspace, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElements, float p, int32_t mode, void *stream)
{
    launch_foreach_norm_partial<half>(x, workspace, totalLength, numBlocks, blockLength, tileElements, p, mode, stream);
}
void launch_foreach_norm_partial_bf16(GM_ADDR x, GM_ADDR workspace, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElements, float p, int32_t mode, void *stream)
{
    launch_foreach_norm_partial<bfloat16_t>(x, workspace, totalLength, numBlocks, blockLength, tileElements, p, mode, stream);
}
void launch_foreach_norm_finalize_float(GM_ADDR workspace, GM_ADDR y, int32_t numBlocks, float p, int32_t mode, void *stream)
{
    launch_foreach_norm_finalize<float>(workspace, y, numBlocks, p, mode, stream);
}
void launch_foreach_norm_finalize_half(GM_ADDR workspace, GM_ADDR y, int32_t numBlocks, float p, int32_t mode, void *stream)
{
    launch_foreach_norm_finalize<half>(workspace, y, numBlocks, p, mode, stream);
}
void launch_foreach_norm_finalize_bf16(GM_ADDR workspace, GM_ADDR y, int32_t numBlocks, float p, int32_t mode, void *stream)
{
    launch_foreach_norm_finalize<bfloat16_t>(workspace, y, numBlocks, p, mode, stream);
}
}
