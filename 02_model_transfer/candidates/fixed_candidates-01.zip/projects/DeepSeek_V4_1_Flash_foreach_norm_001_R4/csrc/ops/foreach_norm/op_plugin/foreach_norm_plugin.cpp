/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_plugin.cpp
 * \brief ForeachNorm API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include <cmath>
#include <cstdint>
#include <tuple>
#include <vector>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"
#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

static int32_t foreach_norm_get_mode(float p)
{
    if (std::isinf(p)) {
        return p > 0.0f ? 8 : 9;
    }
    if (p == 1.0f) {
        return 1;
    }
    if (p == 2.0f) {
        return 2;
    }
    if (p == 3.0f) {
        return 3;
    }
    if (p == 4.0f) {
        return 4;
    }
    if (p == 5.0f) {
        return 5;
    }
    if (p == 1.5f) {
        return 6;
    }
    if (p == 2.5f) {
        return 7;
    }
    if (p == 0.0f) {
        return 10;
    }
    if (p == -1.0f) {
        return 11;
    }
    return 0;
}

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<torch::Tensor> foreach_norm_meta(const std::vector<torch::Tensor> &x, double scalar)
{
    (void)scalar;
    std::vector<torch::Tensor> y;
    y.reserve(x.size());
    for (const auto &t : x) {
        y.push_back(torch::empty({}, t.options()));
    }
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

std::vector<torch::Tensor> foreach_norm_npu(const std::vector<torch::Tensor> &x, double scalar)
{
    TORCH_CHECK(!x.empty(), "foreach_norm: input tensor list must not be empty.");
    for (size_t i = 1; i < x.size(); ++i) {
        TORCH_CHECK(x[i].scalar_type() == x[0].scalar_type(), "foreach_norm: all tensors must share the same dtype.");
        TORCH_CHECK(x[i].device() == x[0].device(), "foreach_norm: all tensors must share the same device.");
    }

    const c10::OptionalDeviceGuard guard(x[0].device());

    std::vector<torch::Tensor> y = foreach_norm_meta(x, scalar);

    const float p = static_cast<float>(scalar);
    const int32_t mode = foreach_norm_get_mode(p);

    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    constexpr int64_t MAX_WS_BLOCKS = 8192;
    static torch::Tensor ws_tensor;
    if (!ws_tensor.defined() || ws_tensor.numel() < MAX_WS_BLOCKS ||
        ws_tensor.device() != x[0].device()) {
        ws_tensor = torch::empty({MAX_WS_BLOCKS},
                                 torch::dtype(torch::kFloat32).device(x[0].device()));
    }
    auto ws_ptr = (GM_ADDR)ws_tensor.data_ptr();

    for (size_t i = 0; i < x.size(); ++i) {
        const torch::Tensor &t = x[i];
        torch::Tensor &out = y[i];
        const int64_t totalLength = t.numel();
        if (totalLength <= 0) {
            continue;
        }

        const auto dtype = t.scalar_type();

        int64_t numBlocks = 1;
        int64_t blockLength = totalLength;
        uint32_t tileElements = 32;
        std::tie(numBlocks, blockLength, tileElements) =
            calc_foreach_norm_tiling_params(totalLength);
        if (numBlocks < 1) {
            numBlocks = 1;
        }
        if (numBlocks > MAX_WS_BLOCKS) {
            numBlocks = MAX_WS_BLOCKS;
        }
        const int32_t nb = static_cast<int32_t>(numBlocks);

        auto x_ptr = (GM_ADDR)t.data_ptr();
        auto out_ptr = (GM_ADDR)out.data_ptr();

        auto acl_call = [=]() -> int {
            if (dtype == torch::kFloat32) {
                launch_foreach_norm_partial_float(x_ptr, ws_ptr, totalLength, numBlocks, blockLength, tileElements, p, mode, stream);
                launch_foreach_norm_finalize_float(ws_ptr, out_ptr, nb, p, mode, stream);
            } else if (dtype == torch::kFloat16) {
                launch_foreach_norm_partial_half(x_ptr, ws_ptr, totalLength, numBlocks, blockLength, tileElements, p, mode, stream);
                launch_foreach_norm_finalize_half(ws_ptr, out_ptr, nb, p, mode, stream);
            } else if (dtype == torch::kBFloat16) {
                launch_foreach_norm_partial_bf16(x_ptr, ws_ptr, totalLength, numBlocks, blockLength, tileElements, p, mode, stream);
                launch_foreach_norm_finalize_bf16(ws_ptr, out_ptr, nb, p, mode, stream);
            } else {
                TORCH_CHECK(false, "foreach_norm: unsupported dtype.");
            }
            return 0;
        };
        at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
    }

    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

} // namespace cann_bench
