/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file gelu_kernel.cpp
 * \brief Gelu host code - kernel launch and tiling (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

// 1 / sqrt(2)
constexpr static float GELU_INV_SQRT2 = 0.70710678118654752440f;
// sqrt(2 / pi)
constexpr static float GELU_SQRT_2_OVER_PI = 0.79788456080286535588f;
// 0.044715
constexpr static float GELU_TANH_COEF = 0.044715f;

// Numerical Recipes erfc approximation coefficients.
// erfc(a) ~= t * exp(-a*a + poly(t)), t = 1/(1 + 0.5*a), relative error < 1.2e-7 for a >= 0.
constexpr static float ERFC_C0 = -1.26551223f;
constexpr static float ERFC_C1 = 1.00002368f;
constexpr static float ERFC_C2 = 0.37409196f;
constexpr static float ERFC_C3 = 0.09678418f;
constexpr static float ERFC_C4 = -0.18628806f;
constexpr static float ERFC_C5 = 0.27886807f;
constexpr static float ERFC_C6 = -1.13520398f;
constexpr static float ERFC_C7 = 1.48851587f;
constexpr static float ERFC_C8 = -0.82215223f;
constexpr static float ERFC_C9 = 0.17087277f;

// Small positive constant used to obtain sign(z) without a branch.
constexpr static float SIGN_EPS = 1.0e-30f;

__aicore__ inline void ComputeGeluTanhFloat(
    AscendC::LocalTensor<float> &dst,
    AscendC::LocalTensor<float> &x,
    AscendC::LocalTensor<float> &tmp,
    int64_t count)
{
    AscendC::Mul(tmp, x, x, count);
    AscendC::Mul(tmp, tmp, x, count);
    AscendC::Muls(tmp, tmp, GELU_TANH_COEF, count);
    AscendC::Add(tmp, tmp, x, count);
    AscendC::Muls(tmp, tmp, GELU_SQRT_2_OVER_PI, count);
    AscendC::Tanh(tmp, tmp, count);
    AscendC::Adds(tmp, tmp, 1.0f, count);
    AscendC::Mul(tmp, tmp, x, count);
    AscendC::Muls(dst, tmp, 0.5f, count);
}

__aicore__ inline void ComputeGeluExactFloat(
    AscendC::LocalTensor<float> &dst,
    AscendC::LocalTensor<float> &x,
    AscendC::LocalTensor<float> &b0,
    AscendC::LocalTensor<float> &b1,
    AscendC::LocalTensor<float> &b2,
    AscendC::LocalTensor<float> &b3,
    AscendC::LocalTensor<float> &b4,
    int64_t count)
{
    // z = -x / sqrt(2)
    AscendC::Muls(b0, x, -GELU_INV_SQRT2, count);
    // a = |z| = |x| / sqrt(2)
    AscendC::Abs(b1, b0, count);

    // u = 0.5 * (1 - sign(z)) without branch; u is only relevant when (2 - 2*E) is non-negligible,
    // i.e. when a is not tiny, so the small SIGN_EPS is harmless.
    AscendC::Adds(b4, b1, SIGN_EPS, count);
    AscendC::Div(b4, b0, b4, count);
    AscendC::Muls(b4, b4, -1.0f, count);
    AscendC::Adds(b4, b4, 1.0f, count);
    AscendC::Muls(b4, b4, 0.5f, count);

    // t = 1 / (1 + 0.5 * a)
    AscendC::Muls(b2, b1, 0.5f, count);
    AscendC::Adds(b2, b2, 1.0f, count);
    AscendC::Duplicate(b0, 1.0f, count);
    AscendC::Div(b2, b0, b2, count);

    // Horner polynomial in t: p = c0 + t*(c1 + t*(c2 + ... + t*(c8 + t*c9)))
    AscendC::Muls(b3, b2, ERFC_C9, count);
    AscendC::Adds(b3, b3, ERFC_C8, count);
    AscendC::Mul(b3, b3, b2, count);
    AscendC::Adds(b3, b3, ERFC_C7, count);
    AscendC::Mul(b3, b3, b2, count);
    AscendC::Adds(b3, b3, ERFC_C6, count);
    AscendC::Mul(b3, b3, b2, count);
    AscendC::Adds(b3, b3, ERFC_C5, count);
    AscendC::Mul(b3, b3, b2, count);
    AscendC::Adds(b3, b3, ERFC_C4, count);
    AscendC::Mul(b3, b3, b2, count);
    AscendC::Adds(b3, b3, ERFC_C3, count);
    AscendC::Mul(b3, b3, b2, count);
    AscendC::Adds(b3, b3, ERFC_C2, count);
    AscendC::Mul(b3, b3, b2, count);
    AscendC::Adds(b3, b3, ERFC_C1, count);
    AscendC::Mul(b3, b3, b2, count);
    AscendC::Adds(b3, b3, ERFC_C0, count);

    // exponent argument: p - a*a
    AscendC::Mul(b1, b1, b1, count);
    AscendC::Muls(b1, b1, -1.0f, count);
    AscendC::Add(b3, b3, b1, count);

    // E = erfc(a) = t * exp(p - a*a)
    AscendC::Exp(b3, b3, count);
    AscendC::Mul(b3, b3, b2, count);

    // erfc(z) = E + u * (2 - 2*E); for z >= 0 (x <= 0) u = 0 -> erfc = E = erfc(|z|)
    //                          for z < 0  (x >  0) u = 1 -> erfc = 2 - E
    AscendC::Muls(b1, b3, -2.0f, count);
    AscendC::Adds(b1, b1, 2.0f, count);
    AscendC::Mul(b1, b1, b4, count);
    AscendC::Add(b1, b1, b3, count);

    // y = 0.5 * x * erfc(z)   (safe when dst aliases x)
    AscendC::Mul(dst, x, b1, count);
    AscendC::Muls(dst, dst, 0.5f, count);
}

template <typename T>
__aicore__ inline void GeluCompute(
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> &inQueue,
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> &outQueue,
    AscendC::TBuf<AscendC::TPosition::VECCALC> &xFBuf,
    AscendC::TBuf<AscendC::TPosition::VECCALC> &b0Buf,
    AscendC::TBuf<AscendC::TPosition::VECCALC> &b1Buf,
    AscendC::TBuf<AscendC::TPosition::VECCALC> &b2Buf,
    AscendC::TBuf<AscendC::TPosition::VECCALC> &b3Buf,
    AscendC::TBuf<AscendC::TPosition::VECCALC> &b4Buf,
    AscendC::GlobalTensor<T> &xGm,
    AscendC::GlobalTensor<T> &yGm,
    int64_t offset,
    int64_t count,
    int64_t approximate)
{
    AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    auto xLocal = inQueue.AllocTensor<T>();
    AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
    inQueue.EnQue(xLocal);
    xLocal = inQueue.DeQue<T>();

    auto outLocal = outQueue.AllocTensor<T>();

    auto b0 = b0Buf.Get<float>();
    auto b1 = b1Buf.Get<float>();
    auto b2 = b2Buf.Get<float>();
    auto b3 = b3Buf.Get<float>();
    auto b4 = b4Buf.Get<float>();

    if constexpr (std::is_same<T, float>::value) {
        if (approximate == 0) {
            ComputeGeluExactFloat(outLocal, xLocal, b0, b1, b2, b3, b4, count);
        } else {
            ComputeGeluTanhFloat(outLocal, xLocal, b0, count);
        }
    } else {
        auto xF = xFBuf.Get<float>();
        AscendC::Cast(xF, xLocal, AscendC::RoundMode::CAST_NONE, count);
        if (approximate == 0) {
            ComputeGeluExactFloat(xF, xF, b0, b1, b2, b3, b4, count);
        } else {
            ComputeGeluTanhFloat(xF, xF, b0, count);
        }
        AscendC::Cast(outLocal, xF, AscendC::RoundMode::CAST_RINT, count);
    }

    outQueue.EnQue(outLocal);
    inQueue.FreeTensor(xLocal);
    outLocal = outQueue.DeQue<T>();
    AscendC::DataCopyPad(yGm[offset], outLocal, copyParams);
    outQueue.FreeTensor(outLocal);
}

template <typename T>
__global__ __aicore__ void gelu_kernel(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize,
    int64_t approximate)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> xFBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> b0Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> b1Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> b2Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> b3Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> b4Buf;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elementNumPerTile <= 0) {
        elementNumPerTile = 1;
    }
    uint32_t floatBufSize = static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float)));
    pipe.InitBuffer(xFBuf, floatBufSize);
    pipe.InitBuffer(b0Buf, floatBufSize);
    pipe.InitBuffer(b1Buf, floatBufSize);
    pipe.InitBuffer(b2Buf, floatBufSize);
    pipe.InitBuffer(b3Buf, floatBufSize);
    pipe.InitBuffer(b4Buf, floatBufSize);

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - AscendC::GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        GeluCompute<T>(inQueue, outQueue, xFBuf, b0Buf, b1Buf, b2Buf, b3Buf, b4Buf,
                       xGm, yGm, offset, elementNumPerTile, approximate);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        GeluCompute<T>(inQueue, outQueue, xFBuf, b0Buf, b1Buf, b2Buf, b3Buf, b4Buf,
                       xGm, yGm, offset, tailTileElementNum, approximate);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_gelu_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 192 * 1024;
    }
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    // Worst case UB usage (half/bf16): inQueue 2*tileSize + outQueue 2*tileSize +
    // 6 float buffers, each 2*tileSize (since elementNumPerTile = tileSize/2) => 16*tileSize.
    // Using tileSize = ubSize/32 keeps total <= 0.5 * ubSize.
    int64_t tileSize = static_cast<int64_t>(ubSize) / 32;
    tileSize = tileSize / 32 * 32;
    if (tileSize < 32) {
        tileSize = 32;
    }
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {
void launch_gelu_kernel_float(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize,
    int64_t approximate, void *stream)
{
    gelu_kernel<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, approximate);
}

void launch_gelu_kernel_half(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize,
    int64_t approximate, void *stream)
{
    gelu_kernel<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, approximate);
}

void launch_gelu_kernel_bfloat16(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize,
    int64_t approximate, void *stream)
{
    gelu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, approximate);
}
}
