/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_plugin.cpp
 * \brief SwiGlu API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    TORCH_CHECK(input.scalar_type() == torch::kFloat16 || input.scalar_type() == torch::kFloat32 ||
                    input.scalar_type() == torch::kBFloat16,
                "swi_glu: only float16, float32 and bfloat16 are supported");
    TORCH_CHECK(input.dim() >= 1, "swi_glu: input must have at least 1 dimension");
    int64_t rank = input.dim();
    int64_t splitDim = dim;
    if (splitDim < 0) {
        splitDim += rank;
    }
    TORCH_CHECK(splitDim >= 0 && splitDim < rank, "swi_glu: dim out of range");
    auto outSizes = input.sizes().vec();
    TORCH_CHECK(outSizes[splitDim] % 2 == 0, "swi_glu: size of split dim must be even");
    outSizes[splitDim] = outSizes[splitDim] / 2;
    return torch::empty(outSizes, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto inputCont = input.contiguous();
    auto output = swi_glu_meta(inputCont, dim);
    if (output.numel() == 0) {
        return output;
    }

    int64_t rank = inputCont.dim();
    int64_t splitDim = dim;
    if (splitDim < 0) {
        splitDim += rank;
    }
    int64_t nOuter = 1;
    for (int64_t i = 0; i < splitDim; ++i) {
        nOuter *= inputCont.size(i);
    }
    int64_t nInner = 1;
    for (int64_t i = splitDim + 1; i < rank; ++i) {
        nInner *= inputCont.size(i);
    }
    int64_t pairSize = (inputCont.size(splitDim) / 2) * nInner;
    int64_t totalLength = output.numel();
    int64_t typeSize = inputCont.element_size();
    int64_t numBlocks = 1;
    int64_t blockLength = totalLength;
    uint32_t tileElem = 64;
    std::tie(numBlocks, blockLength, tileElem) = calc_swi_glu_tiling_params(totalLength, typeSize);

    auto inputPtr = (GM_ADDR)inputCont.data_ptr();
    auto outputPtr = (GM_ADDR)output.data_ptr();
    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    auto dtype = inputCont.scalar_type();

    auto acl_call = [=]() -> int {
        if (dtype == torch::kFloat32) {
            launch_swi_glu_kernel_float(inputPtr, outputPtr, nOuter, pairSize, totalLength, numBlocks, blockLength,
                                        tileElem, stream);
        } else if (dtype == torch::kFloat16) {
            launch_swi_glu_kernel_half(inputPtr, outputPtr, nOuter, pairSize, totalLength, numBlocks, blockLength,
                                       tileElem, stream);
        } else if (dtype == torch::kBFloat16) {
            launch_swi_glu_kernel_bf16(inputPtr, outputPtr, nOuter, pairSize, totalLength, numBlocks, blockLength,
                                       tileElem, stream);
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return output;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
