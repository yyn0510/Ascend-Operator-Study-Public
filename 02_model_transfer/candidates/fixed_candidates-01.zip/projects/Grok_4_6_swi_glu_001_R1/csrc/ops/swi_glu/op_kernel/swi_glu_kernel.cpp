/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGlu kernel, tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <cstdint>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t SMALL_PAIR = 16;
constexpr static int64_t MIN_ELEMS_PER_CORE = 256;
constexpr static int64_t MAX_TILE_ELEM = 2048;

template <typename T>
class KernelSwiGlu {
public:
    __aicore__ inline KernelSwiGlu() {}

    __aicore__ inline void Init(GM_ADDR input, GM_ADDR output, int64_t nOuterIn, int64_t pairSizeIn,
                                int64_t totalLength, int64_t blockLength, uint32_t tileElemIn)
    {
        nOuter = nOuterIn;
        pairSize = pairSizeIn;
        tileElem = static_cast<int64_t>(tileElemIn);
        if (tileElem < 8) {
            tileElem = 8;
        }

        int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
        start = blockIdx * blockLength;
        int64_t current = totalLength - start;
        if (current > blockLength) {
            current = blockLength;
        }
        if (current < 0) {
            current = 0;
        }
        end = start + current;
        if (start >= totalLength) {
            start = totalLength;
            end = totalLength;
        }

        int64_t inputNum = nOuter * 2 * pairSize;
        int64_t outputNum = nOuter * pairSize;
        if (inputNum < 0) {
            inputNum = 0;
        }
        if (outputNum < 0) {
            outputNum = 0;
        }
        inputGm.SetGlobalBuffer((__gm__ T *)input, inputNum);
        outputGm.SetGlobalBuffer((__gm__ T *)output, outputNum);

        uint32_t tileBytes = static_cast<uint32_t>(tileElem) * static_cast<uint32_t>(sizeof(T));
        tileBytes = (tileBytes + 31u) / 32u * 32u;
        pipe.InitBuffer(inQueueX0, PIPELINE_DEPTH, tileBytes * 2u);
        pipe.InitBuffer(inQueueX1, PIPELINE_DEPTH, tileBytes);
        pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileBytes);

        calcTile = static_cast<uint32_t>((tileElem + 7) / 8 * 8);
        if (calcTile < 8u) {
            calcTile = 8u;
        }
        pipe.InitBuffer(calcBuf, 5u * calcTile * static_cast<uint32_t>(sizeof(float)));
    }

    __aicore__ inline void Process()
    {
        if (start >= end || pairSize <= 0) {
            return;
        }

        auto calc = calcBuf.Get<float>();
        fp0 = calc[0];
        fp1 = calc[calcTile];
        fp2 = calc[calcTile * 2];
        mixedFp = calc[calcTile * 3];

        int64_t idx = start;
        while (idx < end) {
            int64_t outer = idx / pairSize;
            int64_t off = idx % pairSize;
            int64_t remain = end - idx;
            if (off == 0 && pairSize <= SMALL_PAIR) {
                int64_t nPairs = remain / pairSize;
                int64_t maxPairs = tileElem / pairSize;
                if (nPairs > maxPairs) {
                    nPairs = maxPairs;
                }
                if (nPairs > 1) {
                    ProcessMixed(outer, nPairs);
                    idx += nPairs * pairSize;
                    continue;
                }
            }
            int64_t len = pairSize - off;
            if (len > remain) {
                len = remain;
            }
            if (len > tileElem) {
                len = tileElem;
            }
            if (len <= 0) {
                break;
            }
            ProcessContiguous(outer, off, len);
            idx += len;
        }
    }

private:
    __aicore__ inline void CopyFpToDst(AscendC::LocalTensor<T> dst, AscendC::LocalTensor<float> src, int32_t len)
    {
        if constexpr (std::is_same<T, float>::value) {
            AscendC::Adds(dst, src, static_cast<float>(0), len);
        } else {
            AscendC::Cast(dst, src, AscendC::RoundMode::CAST_RINT, len);
        }
    }

    __aicore__ inline void ComputeFromFp(AscendC::LocalTensor<T> dst, int32_t len)
    {
        AscendC::Sigmoid(fp2, fp0, len);
        AscendC::Mul(fp2, fp2, fp0, len);
        AscendC::Mul(fp2, fp2, fp1, len);
        CopyFpToDst(dst, fp2, len);
    }

    __aicore__ inline void UnpackPairs(const AscendC::LocalTensor<float> &mixed, int64_t nPairs)
    {
        for (int64_t p = 0; p < nPairs; ++p) {
            int64_t src0 = p * 2 * pairSize;
            int64_t src1 = src0 + pairSize;
            int64_t dst = p * pairSize;
            for (int64_t j = 0; j < pairSize; ++j) {
                fp0.SetValue(dst + j, mixed.GetValue(src0 + j));
                fp1.SetValue(dst + j, mixed.GetValue(src1 + j));
            }
        }
    }

    __aicore__ inline void ProcessContiguous(int64_t outer, int64_t off, int64_t len)
    {
        int64_t x0Off = outer * 2 * pairSize + off;
        int64_t x1Off = x0Off + pairSize;
        int64_t outOff = outer * pairSize + off;
        int32_t count = static_cast<int32_t>(len);

        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto x0Local = inQueueX0.AllocTensor<T>();
        auto x1Local = inQueueX1.AllocTensor<T>();
        AscendC::DataCopyPad(x0Local, inputGm[x0Off], copyParams, padParams);
        AscendC::DataCopyPad(x1Local, inputGm[x1Off], copyParams, padParams);
        inQueueX0.EnQue(x0Local);
        inQueueX1.EnQue(x1Local);
        x0Local = inQueueX0.DeQue<T>();
        x1Local = inQueueX1.DeQue<T>();

        if constexpr (std::is_same<T, float>::value) {
            AscendC::Sigmoid(fp2, x0Local, count);
            AscendC::Mul(fp2, fp2, x0Local, count);
            auto outLocal = outQueue.AllocTensor<T>();
            AscendC::Mul(outLocal, fp2, x1Local, count);
            outQueue.EnQue(outLocal);
            inQueueX0.FreeTensor(x0Local);
            inQueueX1.FreeTensor(x1Local);
            outLocal = outQueue.DeQue<T>();
            AscendC::DataCopyPad(outputGm[outOff], outLocal, copyParams);
            outQueue.FreeTensor(outLocal);
        } else {
            AscendC::Cast(fp0, x0Local, AscendC::RoundMode::CAST_NONE, count);
            AscendC::Cast(fp1, x1Local, AscendC::RoundMode::CAST_NONE, count);
            inQueueX0.FreeTensor(x0Local);
            inQueueX1.FreeTensor(x1Local);
            auto outLocal = outQueue.AllocTensor<T>();
            ComputeFromFp(outLocal, count);
            outQueue.EnQue(outLocal);
            outLocal = outQueue.DeQue<T>();
            AscendC::DataCopyPad(outputGm[outOff], outLocal, copyParams);
            outQueue.FreeTensor(outLocal);
        }
    }

    __aicore__ inline void ProcessMixed(int64_t outer, int64_t nPairs)
    {
        int64_t mixedLen = nPairs * 2 * pairSize;
        int64_t outLen = nPairs * pairSize;
        int64_t inOff = outer * 2 * pairSize;
        int64_t outOff = outer * pairSize;
        int32_t mixedCount = static_cast<int32_t>(mixedLen);
        int32_t outCount = static_cast<int32_t>(outLen);

        AscendC::DataCopyExtParams inParams{1, static_cast<uint32_t>(mixedLen * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto mixedLocal = inQueueX0.AllocTensor<T>();
        AscendC::DataCopyPad(mixedLocal, inputGm[inOff], inParams, padParams);
        inQueueX0.EnQue(mixedLocal);
        mixedLocal = inQueueX0.DeQue<T>();

        if constexpr (std::is_same<T, float>::value) {
            AscendC::PipeBarrier<PIPE_ALL>();
            UnpackPairs(mixedLocal, nPairs);
        } else {
            AscendC::Cast(mixedFp, mixedLocal, AscendC::RoundMode::CAST_NONE, mixedCount);
            AscendC::PipeBarrier<PIPE_ALL>();
            UnpackPairs(mixedFp, nPairs);
        }
        inQueueX0.FreeTensor(mixedLocal);
        AscendC::PipeBarrier<PIPE_ALL>();

        auto outLocal = outQueue.AllocTensor<T>();
        ComputeFromFp(outLocal, outCount);
        outQueue.EnQue(outLocal);
        outLocal = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams outParams{1, static_cast<uint32_t>(outLen * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(outputGm[outOff], outLocal, outParams);
        outQueue.FreeTensor(outLocal);
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> inputGm;
    AscendC::GlobalTensor<T> outputGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf;
    AscendC::LocalTensor<float> fp0;
    AscendC::LocalTensor<float> fp1;
    AscendC::LocalTensor<float> fp2;
    AscendC::LocalTensor<float> mixedFp;
    int64_t nOuter = 0;
    int64_t pairSize = 0;
    int64_t tileElem = 0;
    int64_t start = 0;
    int64_t end = 0;
    uint32_t calcTile = 0;
};

template <typename T>
__global__ __aicore__ void swi_glu_kernel(GM_ADDR input, GM_ADDR output, int64_t nOuter, int64_t pairSize,
                                          int64_t totalLength, int64_t blockLength, uint32_t tileElem)
{
    KernelSwiGlu<T> op;
    op.Init(input, output, nOuter, pairSize, totalLength, blockLength, tileElem);
    op.Process();
}

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_tiling_params(int64_t totalLength, int64_t typeSize)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 192 * 1024;
    int64_t coreNum = 48;
    if (ascendcPlatform != nullptr) {
        ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
        coreNum = ascendcPlatform->GetCoreNumAiv();
    }
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (typeSize <= 0) {
        typeSize = 4;
    }
    if (totalLength <= 0) {
        return std::make_tuple(1, 0, 64);
    }

    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    int64_t reserved = 16384;
    int64_t avail = static_cast<int64_t>(ubSize) > reserved ? static_cast<int64_t>(ubSize) - reserved
                                                            : static_cast<int64_t>(ubSize) / 2;
    int64_t bytesPerElem = PIPELINE_DEPTH * (2 + 1 + 1) * typeSize + 5 * 4;
    if (bytesPerElem <= 0) {
        bytesPerElem = 48;
    }
    int64_t tileElem = avail / bytesPerElem;
    tileElem = (tileElem / 64) * 64;
    if (tileElem > MAX_TILE_ELEM) {
        tileElem = MAX_TILE_ELEM;
    }
    if (tileElem < 64) {
        tileElem = 64;
    }
    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileElem));
}

extern "C" {

void launch_swi_glu_kernel_float(GM_ADDR input, GM_ADDR output, int64_t nOuter, int64_t pairSize, int64_t totalLength,
                                 int64_t numBlocks, int64_t blockLength, uint32_t tileElem, void *stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(input, output, nOuter, pairSize, totalLength, blockLength,
                                                          tileElem);
}

void launch_swi_glu_kernel_half(GM_ADDR input, GM_ADDR output, int64_t nOuter, int64_t pairSize, int64_t totalLength,
                                int64_t numBlocks, int64_t blockLength, uint32_t tileElem, void *stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(input, output, nOuter, pairSize, totalLength, blockLength,
                                                         tileElem);
}

void launch_swi_glu_kernel_bf16(GM_ADDR input, GM_ADDR output, int64_t nOuter, int64_t pairSize, int64_t totalLength,
                                int64_t numBlocks, int64_t blockLength, uint32_t tileElem, void *stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(input, output, nOuter, pairSize, totalLength,
                                                              blockLength, tileElem);
}

}
