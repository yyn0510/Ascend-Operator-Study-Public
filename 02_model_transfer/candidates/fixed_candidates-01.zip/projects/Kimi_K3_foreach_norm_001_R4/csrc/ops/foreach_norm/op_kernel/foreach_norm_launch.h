/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_launch.h
 * \brief Launch function declarations for g++
 */

#ifndef FOREACH_NORM_LAUNCH_H
#define FOREACH_NORM_LAUNCH_H

#include <cstdint>
#include <tuple>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

// Tiling function declaration: returns (numBlocks, blockLength) for one tensor
std::tuple<int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength);

// Launch function declarations
extern "C" {
void launch_foreach_norm_partial_float(
    GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
    GM_ADDR x4, GM_ADDR x5, GM_ADDR x6, GM_ADDR x7,
    GM_ADDR workspace, int64_t numBlocks, int32_t numTensors,
    int64_t len0, int64_t len1, int64_t len2, int64_t len3,
    int64_t len4, int64_t len5, int64_t len6, int64_t len7,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t pCode, float p, void *stream);
void launch_foreach_norm_partial_half(
    GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
    GM_ADDR x4, GM_ADDR x5, GM_ADDR x6, GM_ADDR x7,
    GM_ADDR workspace, int64_t numBlocks, int32_t numTensors,
    int64_t len0, int64_t len1, int64_t len2, int64_t len3,
    int64_t len4, int64_t len5, int64_t len6, int64_t len7,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t pCode, float p, void *stream);
void launch_foreach_norm_partial_bfloat16(
    GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
    GM_ADDR x4, GM_ADDR x5, GM_ADDR x6, GM_ADDR x7,
    GM_ADDR workspace, int64_t numBlocks, int32_t numTensors,
    int64_t len0, int64_t len1, int64_t len2, int64_t len3,
    int64_t len4, int64_t len5, int64_t len6, int64_t len7,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t pCode, float p, void *stream);

void launch_foreach_norm_final_float(
    GM_ADDR workspace,
    GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
    GM_ADDR y4, GM_ADDR y5, GM_ADDR y6, GM_ADDR y7,
    int32_t numTensors,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t invpCode, float invp, void *stream);
void launch_foreach_norm_final_half(
    GM_ADDR workspace,
    GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
    GM_ADDR y4, GM_ADDR y5, GM_ADDR y6, GM_ADDR y7,
    int32_t numTensors,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t invpCode, float invp, void *stream);
void launch_foreach_norm_final_bfloat16(
    GM_ADDR workspace,
    GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
    GM_ADDR y4, GM_ADDR y5, GM_ADDR y6, GM_ADDR y7,
    int32_t numTensors,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t invpCode, float invp, void *stream);
}

#endif // FOREACH_NORM_LAUNCH_H
