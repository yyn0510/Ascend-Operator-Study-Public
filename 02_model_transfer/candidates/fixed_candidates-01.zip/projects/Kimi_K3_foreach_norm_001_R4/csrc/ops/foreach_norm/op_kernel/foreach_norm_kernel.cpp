/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_kernel.cpp
 * \brief ForeachNorm kernel, host tiling and launch wrappers (compiled with bisheng + -xasc)
 *
 * Two-stage reduction, fused across the whole tensor list (up to 8 tensors per launch group):
 *   Stage 1 (partial): blocks are distributed across all tensors of the group; each block
 *                      accumulates |x|^p elementwise into a float32 vector accumulator and
 *                      reduces it once with ReduceSum into a float partial in the workspace.
 *   Stage 2 (final):   one core reduces the partials of every tensor, applies the 1/p
 *                      power, casts to the output dtype and writes one scalar per tensor.
 * All math is done in float32 (fp16/bf16 inputs are cast first).
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;
constexpr static int32_t MAX_PARTIAL_BLOCKS = 2048;
constexpr static int32_t REDUCE_LANES = 64;
constexpr static int32_t MAX_TENSORS_PER_LAUNCH = 8;
constexpr static float FP32_MAX_VAL = 3.402823466e38f;
constexpr static float TWO_POW_64 = 18446744073709551616.0f;
constexpr static float TWO_POW_32 = 4294967296.0f;

// mode: 0 -> p-norm (sum of |x|^p then power 1/p), 1 -> +inf norm (max|x|), 2 -> -inf norm (min|x|)
// pCode selects the |x|^p transform (mode 0 only):
//   0:p==1  1:p==2  2:p==0.5  3:p==1.5  4:p==2.5  5:p==3  6:p==4  7:p==5  8:p==0 (L0 count)  9:general exp(p*ln|x|)
template <typename T>
__global__ __aicore__ void foreach_norm_partial_kernel(
    GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
    GM_ADDR x4, GM_ADDR x5, GM_ADDR x6, GM_ADDR x7,
    GM_ADDR workspace,
    int32_t numTensors,
    int64_t len0, int64_t len1, int64_t len2, int64_t len3,
    int64_t len4, int64_t len5, int64_t len6, int64_t len7,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t pCode, float p)
{
    constexpr int32_t TILE = (sizeof(T) == 4) ? 4096 : 8192;

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> accQueue;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> f32Buf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> reduceWorkBuf;
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, TILE * sizeof(T));
    pipe.InitBuffer(accQueue, 1, TILE * sizeof(float));
    pipe.InitBuffer(f32Buf, TILE * sizeof(float));
    pipe.InitBuffer(tmpBuf, TILE * sizeof(float));
    pipe.InitBuffer(reduceWorkBuf, TILE * sizeof(float));

    GM_ADDR xs[MAX_TENSORS_PER_LAUNCH] = {x0, x1, x2, x3, x4, x5, x6, x7};
    int64_t lens[MAX_TENSORS_PER_LAUNCH] = {len0, len1, len2, len3, len4, len5, len6, len7};
    int32_t blks[MAX_TENSORS_PER_LAUNCH] = {blk0, blk1, blk2, blk3, blk4, blk5, blk6, blk7};

    // locate which tensor this block belongs to
    const int32_t bid = AscendC::GetBlockIdx();
    int32_t t = 0;
    int32_t prev = 0;
    while (t < numTensors - 1 && bid >= prev + blks[t]) {
        prev += blks[t];
        ++t;
    }
    const int32_t localBlk = bid - prev;
    const int64_t len = lens[t];
    const int32_t nb = blks[t];
    const int64_t blockLength = (len + nb - 1) / nb;
    const int64_t start = blockLength * static_cast<int64_t>(localBlk);
    int64_t count64 = len - start;
    if (count64 > blockLength) count64 = blockLength;
    if (count64 < 0) count64 = 0;
    const int32_t wsOffset = prev + localBlk;

    AscendC::GlobalTensor<T> xGm;
    xGm.SetGlobalBuffer((__gm__ T *)xs[t] + start);
    AscendC::GlobalTensor<float> wsGm;
    wsGm.SetGlobalBuffer((__gm__ float *)workspace);

    auto f32Local = f32Buf.Get<float>();
    auto tmpLocal = tmpBuf.Get<float>();
    auto reduceWork = reduceWorkBuf.Get<float>();
    auto accLocal = accQueue.AllocTensor<float>();
    AscendC::Duplicate(accLocal, 0.0f, TILE);

    const int64_t tileNum = (count64 + TILE - 1) / TILE;
    for (int64_t i = 0; i < tileNum; ++i) {
        const int64_t remain = count64 - i * TILE;
        const int32_t count = static_cast<int32_t>(remain > TILE ? TILE : remain);

        auto inLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        AscendC::DataCopyPad(inLocal, xGm[i * TILE], copyParams, padParams);
        inQueue.EnQue(inLocal);
        inLocal = inQueue.DeQue<T>();

        if (mode == 0 && (pCode == 1 || pCode == 6)) {
            // even integer order: x^2 == |x|^2, skip Abs
            if constexpr (std::is_same_v<T, float>) {
                AscendC::Mul(f32Local, inLocal, inLocal, count);
            } else {
                AscendC::Cast(f32Local, inLocal, AscendC::RoundMode::CAST_NONE, count);
                AscendC::Mul(f32Local, f32Local, f32Local, count);
            }
        } else {
            if constexpr (std::is_same_v<T, float>) {
                AscendC::Abs(f32Local, inLocal, count);
            } else {
                AscendC::Cast(f32Local, inLocal, AscendC::RoundMode::CAST_NONE, count);
                AscendC::Abs(f32Local, f32Local, count);
            }
        }
        inQueue.FreeTensor(inLocal);

        if (mode == 0) {
            switch (pCode) {
                case 0: // p == 1 : f32 already |x|
                case 1: // p == 2 : f32 already x^2
                    break;
                case 2: // p == 0.5
                    AscendC::Sqrt(f32Local, f32Local, count);
                    break;
                case 3: // p == 1.5 : |x| * sqrt(|x|)
                    AscendC::Sqrt(tmpLocal, f32Local, count);
                    AscendC::Mul(f32Local, f32Local, tmpLocal, count);
                    break;
                case 4: // p == 2.5 : |x|^2 * sqrt(|x|)
                    AscendC::Mul(tmpLocal, f32Local, f32Local, count);
                    AscendC::Sqrt(f32Local, f32Local, count);
                    AscendC::Mul(f32Local, f32Local, tmpLocal, count);
                    break;
                case 5: // p == 3
                    AscendC::Mul(tmpLocal, f32Local, f32Local, count);
                    AscendC::Mul(f32Local, f32Local, tmpLocal, count);
                    break;
                case 6: // p == 4 : f32 already x^2, square again
                    AscendC::Mul(f32Local, f32Local, f32Local, count);
                    break;
                case 7: // p == 5
                    AscendC::Mul(tmpLocal, f32Local, f32Local, count);
                    AscendC::Mul(f32Local, f32Local, f32Local, count);
                    AscendC::Mul(f32Local, f32Local, tmpLocal, count);
                    break;
                case 8: // p == 0 : nonzero indicator = min(|x| * 2^160, 1)
                    AscendC::Muls(f32Local, f32Local, TWO_POW_64, count);
                    AscendC::Muls(f32Local, f32Local, TWO_POW_64, count);
                    AscendC::Muls(f32Local, f32Local, TWO_POW_32, count);
                    AscendC::Mins(f32Local, f32Local, 1.0f, count);
                    break;
                default: // general p (including negative): exp(p * ln(|x|))
                    AscendC::Ln(tmpLocal, f32Local, count);
                    AscendC::Muls(tmpLocal, tmpLocal, p, count);
                    AscendC::Exp(f32Local, tmpLocal, count);
                    break;
            }
            AscendC::Add(accLocal, accLocal, f32Local, count);
        } else if (mode == 1) {
            AscendC::Max(accLocal, accLocal, f32Local, count);
        } else {
            AscendC::Min(accLocal, accLocal, f32Local, count);
        }
    }

    // reduce the lane accumulator once per block; dst/src/work are all base-aligned UB tensors
    if (mode == 0) {
        AscendC::ReduceSum<float>(tmpLocal, accLocal, reduceWork, TILE);
    } else if (mode == 1) {
        AscendC::ReduceMax<float>(tmpLocal, accLocal, reduceWork, TILE);
    } else {
        // min over lanes; lanes beyond real data may hold 0 from Duplicate, so only
        // mode 2 must guard: recompute with per-tile min already applied, lanes hold
        // min of processed data or 0. Since 0 <= min would corrupt result, lanes were
        // accumulated with Min against 0-init; fix by using ReduceMin on tmp copy is
        // unsafe, so fall back: reduce via repeated vector Min on aligned halves.
        AscendC::Duplicate(f32Local, FP32_MAX_VAL, TILE);
        AscendC::Min(f32Local, f32Local, accLocal, TILE);
        AscendC::ReduceMin<float>(tmpLocal, f32Local, reduceWork, TILE);
    }

    accQueue.EnQue(accLocal);
    auto outLocal = accQueue.DeQue<float>();
    AscendC::DataCopyExtParams outParams{1, static_cast<uint32_t>(sizeof(float)), 0, 0, 0};
    AscendC::DataCopyPad(wsGm[wsOffset], tmpLocal, outParams);
    accQueue.FreeTensor(outLocal);
}

// invpCode: 0 -> keep, 1 -> sqrt, 2 -> exp(invp*ln(s)), 3 -> s*s
template <typename T>
__global__ __aicore__ void foreach_norm_final_kernel(
    GM_ADDR workspace,
    GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
    GM_ADDR y4, GM_ADDR y5, GM_ADDR y6, GM_ADDR y7,
    int32_t numTensors,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t invpCode, float invp)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> f32Buf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> workBuf;
    pipe.InitBuffer(inQueue, 1, MAX_PARTIAL_BLOCKS * sizeof(float));
    pipe.InitBuffer(outQueue, 1, REDUCE_LANES * sizeof(float));
    pipe.InitBuffer(f32Buf, REDUCE_LANES * sizeof(float));
    pipe.InitBuffer(tmpBuf, REDUCE_LANES * sizeof(float));
    pipe.InitBuffer(workBuf, MAX_PARTIAL_BLOCKS * sizeof(float));

    GM_ADDR ys[MAX_TENSORS_PER_LAUNCH] = {y0, y1, y2, y3, y4, y5, y6, y7};
    int32_t blks[MAX_TENSORS_PER_LAUNCH] = {blk0, blk1, blk2, blk3, blk4, blk5, blk6, blk7};

    auto f32Local = f32Buf.Get<float>();
    auto tmpLocal = tmpBuf.Get<float>();
    auto workLocal = workBuf.Get<float>();
    AscendC::GlobalTensor<float> wsGm;
    wsGm.SetGlobalBuffer((__gm__ float *)workspace);

    int32_t wsBase = 0;
    for (int32_t t = 0; t < numTensors; ++t) {
        const int32_t nb = blks[t];
        auto inLocal = inQueue.AllocTensor<float>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(nb * sizeof(float)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};
        AscendC::DataCopyPad(inLocal, wsGm[wsBase], copyParams, padParams);
        inQueue.EnQue(inLocal);
        inLocal = inQueue.DeQue<float>();
        if (mode == 0) {
            AscendC::ReduceSum<float>(f32Local, inLocal, workLocal, nb);
        } else if (mode == 1) {
            AscendC::ReduceMax<float>(f32Local, inLocal, workLocal, nb);
        } else {
            AscendC::ReduceMin<float>(f32Local, inLocal, workLocal, nb);
        }
        inQueue.FreeTensor(inLocal);

        if (mode == 0) {
            if (invpCode == 1) {
                AscendC::Sqrt(f32Local, f32Local, REDUCE_LANES);
            } else if (invpCode == 3) {
                AscendC::Mul(f32Local, f32Local, f32Local, REDUCE_LANES);
            } else if (invpCode == 2) {
                AscendC::Ln(tmpLocal, f32Local, REDUCE_LANES);
                AscendC::Muls(tmpLocal, tmpLocal, invp, REDUCE_LANES);
                AscendC::Exp(f32Local, tmpLocal, REDUCE_LANES);
            }
        }

        auto outLocal = outQueue.AllocTensor<T>();
        if constexpr (std::is_same_v<T, float>) {
            AscendC::Adds(outLocal, f32Local, 0.0f, REDUCE_LANES);
        } else if constexpr (std::is_same_v<T, half>) {
            AscendC::Cast(outLocal, f32Local, AscendC::RoundMode::CAST_NONE, REDUCE_LANES);
        } else {
            // float32 -> bfloat16 requires round-to-nearest-even (CAST_RINT)
            AscendC::Cast(outLocal, f32Local, AscendC::RoundMode::CAST_RINT, REDUCE_LANES);
        }
        outQueue.EnQue(outLocal);
        outLocal = outQueue.DeQue<T>();
        AscendC::GlobalTensor<T> yGm;
        yGm.SetGlobalBuffer((__gm__ T *)ys[t]);
        AscendC::DataCopyExtParams outParams{1, static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[0], outLocal, outParams);
        outQueue.FreeTensor(outLocal);
        wsBase += nb;
    }
}

// Tiling function: returns (numBlocks, blockLength) for one tensor
std::tuple<int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 8192;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    int64_t want = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    int64_t numBlocks = std::min(coreNum, want);
    if (numBlocks < 1) numBlocks = 1;
    if (numBlocks > MAX_PARTIAL_BLOCKS) numBlocks = MAX_PARTIAL_BLOCKS;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    return std::make_tuple(numBlocks, blockLength);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_foreach_norm_partial_float(
    GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
    GM_ADDR x4, GM_ADDR x5, GM_ADDR x6, GM_ADDR x7,
    GM_ADDR workspace, int64_t numBlocks, int32_t numTensors,
    int64_t len0, int64_t len1, int64_t len2, int64_t len3,
    int64_t len4, int64_t len5, int64_t len6, int64_t len7,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t pCode, float p, void *stream)
{
    foreach_norm_partial_kernel<float><<<numBlocks, nullptr, stream>>>(
        x0, x1, x2, x3, x4, x5, x6, x7, workspace, numTensors,
        len0, len1, len2, len3, len4, len5, len6, len7,
        blk0, blk1, blk2, blk3, blk4, blk5, blk6, blk7,
        mode, pCode, p);
}

void launch_foreach_norm_partial_half(
    GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
    GM_ADDR x4, GM_ADDR x5, GM_ADDR x6, GM_ADDR x7,
    GM_ADDR workspace, int64_t numBlocks, int32_t numTensors,
    int64_t len0, int64_t len1, int64_t len2, int64_t len3,
    int64_t len4, int64_t len5, int64_t len6, int64_t len7,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t pCode, float p, void *stream)
{
    foreach_norm_partial_kernel<half><<<numBlocks, nullptr, stream>>>(
        x0, x1, x2, x3, x4, x5, x6, x7, workspace, numTensors,
        len0, len1, len2, len3, len4, len5, len6, len7,
        blk0, blk1, blk2, blk3, blk4, blk5, blk6, blk7,
        mode, pCode, p);
}

void launch_foreach_norm_partial_bfloat16(
    GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
    GM_ADDR x4, GM_ADDR x5, GM_ADDR x6, GM_ADDR x7,
    GM_ADDR workspace, int64_t numBlocks, int32_t numTensors,
    int64_t len0, int64_t len1, int64_t len2, int64_t len3,
    int64_t len4, int64_t len5, int64_t len6, int64_t len7,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t pCode, float p, void *stream)
{
    foreach_norm_partial_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x0, x1, x2, x3, x4, x5, x6, x7, workspace, numTensors,
        len0, len1, len2, len3, len4, len5, len6, len7,
        blk0, blk1, blk2, blk3, blk4, blk5, blk6, blk7,
        mode, pCode, p);
}

void launch_foreach_norm_final_float(
    GM_ADDR workspace,
    GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
    GM_ADDR y4, GM_ADDR y5, GM_ADDR y6, GM_ADDR y7,
    int32_t numTensors,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t invpCode, float invp, void *stream)
{
    foreach_norm_final_kernel<float><<<1, nullptr, stream>>>(
        workspace, y0, y1, y2, y3, y4, y5, y6, y7, numTensors,
        blk0, blk1, blk2, blk3, blk4, blk5, blk6, blk7,
        mode, invpCode, invp);
}

void launch_foreach_norm_final_half(
    GM_ADDR workspace,
    GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
    GM_ADDR y4, GM_ADDR y5, GM_ADDR y6, GM_ADDR y7,
    int32_t numTensors,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t invpCode, float invp, void *stream)
{
    foreach_norm_final_kernel<half><<<1, nullptr, stream>>>(
        workspace, y0, y1, y2, y3, y4, y5, y6, y7, numTensors,
        blk0, blk1, blk2, blk3, blk4, blk5, blk6, blk7,
        mode, invpCode, invp);
}

void launch_foreach_norm_final_bfloat16(
    GM_ADDR workspace,
    GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
    GM_ADDR y4, GM_ADDR y5, GM_ADDR y6, GM_ADDR y7,
    int32_t numTensors,
    int32_t blk0, int32_t blk1, int32_t blk2, int32_t blk3,
    int32_t blk4, int32_t blk5, int32_t blk6, int32_t blk7,
    int32_t mode, int32_t invpCode, float invp, void *stream)
{
    foreach_norm_final_kernel<bfloat16_t><<<1, nullptr, stream>>>(
        workspace, y0, y1, y2, y3, y4, y5, y6, y7, numTensors,
        blk0, blk1, blk2, blk3, blk4, blk5, blk6, blk7,
        mode, invpCode, invp);
}

}
