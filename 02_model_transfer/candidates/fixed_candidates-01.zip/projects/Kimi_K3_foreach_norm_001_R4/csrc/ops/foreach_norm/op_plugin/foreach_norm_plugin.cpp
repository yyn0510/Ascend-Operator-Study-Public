/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_plugin.cpp
 * \brief ForeachNorm API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include <cmath>
#include <vector>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

constexpr static int32_t MAX_TENSORS_PER_LAUNCH = 8;

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<torch::Tensor> foreach_norm_meta(const std::vector<torch::Tensor> &x, double scalar)
{
    std::vector<torch::Tensor> outs;
    outs.reserve(x.size());
    for (const auto &t : x) {
        outs.emplace_back(torch::empty({}, t.options()));
    }
    return outs;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

std::vector<torch::Tensor> foreach_norm_npu(const std::vector<torch::Tensor> &x, double scalar)
{
    TORCH_CHECK(!x.empty(), "foreach_norm: input tensor list must not be empty.");
    const auto dtype = x[0].scalar_type();
    TORCH_CHECK(
        dtype == torch::kFloat32 || dtype == torch::kFloat16 || dtype == torch::kBFloat16,
        "foreach_norm: only float32, float16 and bfloat16 are supported.");
    for (const auto &t : x) {
        TORCH_CHECK(t.scalar_type() == dtype, "foreach_norm: all tensors must share the same dtype.");
    }

    const c10::OptionalDeviceGuard guard(x[0].device());
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    // mode: 0 -> p-norm, 1 -> +inf norm, 2 -> -inf norm
    int32_t mode = 0;
    if (std::isinf(scalar)) {
        mode = (scalar > 0) ? 1 : 2;
    }
    const float p = static_cast<float>(scalar);
    int32_t pCode = 9;
    if (scalar == 0.0) {
        pCode = 8;
    } else if (p == 1.0f) {
        pCode = 0;
    } else if (p == 2.0f) {
        pCode = 1;
    } else if (p == 0.5f) {
        pCode = 2;
    } else if (p == 1.5f) {
        pCode = 3;
    } else if (p == 2.5f) {
        pCode = 4;
    } else if (p == 3.0f) {
        pCode = 5;
    } else if (p == 4.0f) {
        pCode = 6;
    } else if (p == 5.0f) {
        pCode = 7;
    }

    const float invp = (scalar != 0.0) ? static_cast<float>(1.0 / scalar) : 1.0f;
    int32_t invpCode = 2;
    if (invp == 1.0f) {
        invpCode = 0;
    } else if (invp == 0.5f) {
        invpCode = 1;
    } else if (invp == 2.0f) {
        invpCode = 3;
    }

    std::vector<torch::Tensor> outs = foreach_norm_meta(x, scalar);
    std::vector<torch::Tensor> keepAlive;
    keepAlive.reserve(x.size() + 1);

    const size_t n = x.size();
    size_t pos = 0;
    while (true) {
        // gather up to MAX_TENSORS_PER_LAUNCH non-empty tensors
        int idxs[MAX_TENSORS_PER_LAUNCH] = {0};
        int32_t nt = 0;
        while (pos < n && nt < MAX_TENSORS_PER_LAUNCH) {
            if (x[pos].numel() > 0) {
                idxs[nt++] = static_cast<int>(pos);
            } else {
                outs[pos].zero_();
            }
            ++pos;
        }
        if (nt == 0) {
            break;
        }

        GM_ADDR xs[MAX_TENSORS_PER_LAUNCH] = {nullptr};
        GM_ADDR ys[MAX_TENSORS_PER_LAUNCH] = {nullptr};
        int64_t lens[MAX_TENSORS_PER_LAUNCH] = {0};
        int32_t blks[MAX_TENSORS_PER_LAUNCH] = {0};
        int64_t totalBlocks = 0;
        for (int32_t i = 0; i < nt; ++i) {
            auto t = x[idxs[i]].contiguous();
            int64_t b, blockLen;
            std::tie(b, blockLen) = calc_foreach_norm_tiling_params(t.numel());
            xs[i] = (GM_ADDR)t.data_ptr();
            lens[i] = t.numel();
            blks[i] = static_cast<int32_t>(b);
            ys[i] = (GM_ADDR)outs[idxs[i]].data_ptr();
            totalBlocks += b;
            keepAlive.emplace_back(std::move(t));
        }
        auto ws = torch::empty({totalBlocks}, x[idxs[0]].options().dtype(torch::kFloat32));
        GM_ADDR ws_ptr = (GM_ADDR)ws.data_ptr();
        keepAlive.emplace_back(std::move(ws));

        auto acl_call = [=]() -> int {
            if (dtype == torch::kFloat32) {
                launch_foreach_norm_partial_float(
                    xs[0], xs[1], xs[2], xs[3], xs[4], xs[5], xs[6], xs[7],
                    ws_ptr, totalBlocks, nt,
                    lens[0], lens[1], lens[2], lens[3], lens[4], lens[5], lens[6], lens[7],
                    blks[0], blks[1], blks[2], blks[3], blks[4], blks[5], blks[6], blks[7],
                    mode, pCode, p, stream);
                launch_foreach_norm_final_float(
                    ws_ptr,
                    ys[0], ys[1], ys[2], ys[3], ys[4], ys[5], ys[6], ys[7],
                    nt,
                    blks[0], blks[1], blks[2], blks[3], blks[4], blks[5], blks[6], blks[7],
                    mode, invpCode, invp, stream);
            } else if (dtype == torch::kFloat16) {
                launch_foreach_norm_partial_half(
                    xs[0], xs[1], xs[2], xs[3], xs[4], xs[5], xs[6], xs[7],
                    ws_ptr, totalBlocks, nt,
                    lens[0], lens[1], lens[2], lens[3], lens[4], lens[5], lens[6], lens[7],
                    blks[0], blks[1], blks[2], blks[3], blks[4], blks[5], blks[6], blks[7],
                    mode, pCode, p, stream);
                launch_foreach_norm_final_half(
                    ws_ptr,
                    ys[0], ys[1], ys[2], ys[3], ys[4], ys[5], ys[6], ys[7],
                    nt,
                    blks[0], blks[1], blks[2], blks[3], blks[4], blks[5], blks[6], blks[7],
                    mode, invpCode, invp, stream);
            } else {
                launch_foreach_norm_partial_bfloat16(
                    xs[0], xs[1], xs[2], xs[3], xs[4], xs[5], xs[6], xs[7],
                    ws_ptr, totalBlocks, nt,
                    lens[0], lens[1], lens[2], lens[3], lens[4], lens[5], lens[6], lens[7],
                    blks[0], blks[1], blks[2], blks[3], blks[4], blks[5], blks[6], blks[7],
                    mode, pCode, p, stream);
                launch_foreach_norm_final_bfloat16(
                    ws_ptr,
                    ys[0], ys[1], ys[2], ys[3], ys[4], ys[5], ys[6], ys[7],
                    nt,
                    blks[0], blks[1], blks[2], blks[3], blks[4], blks[5], blks[6], blks[7],
                    mode, invpCode, invp, stream);
            }
            return 0;
        };
        at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
    }
    return outs;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

} // namespace cann_bench
