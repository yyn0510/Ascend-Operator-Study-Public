/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_plugin.cpp
 * \brief ForeachNorm API layer - torch bindings (compiled with g++)
 */

#include <cmath>
#include <vector>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<torch::Tensor> foreach_norm_meta(const std::vector<torch::Tensor> &x, double scalar)
{
    TORCH_CHECK(!x.empty(), "foreach_norm: input tensor list must not be empty.");
    std::vector<torch::Tensor> outs;
    outs.reserve(x.size());
    for (const auto &t : x) {
        outs.push_back(torch::empty(c10::IntArrayRef{}, t.options()));
    }
    return outs;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

std::vector<torch::Tensor> foreach_norm_npu(const std::vector<torch::Tensor> &x, double scalar)
{
    TORCH_CHECK(!x.empty(), "foreach_norm: input tensor list must not be empty.");
    auto dtype = x[0].scalar_type();
    TORCH_CHECK(dtype == torch::kFloat32 || dtype == torch::kFloat16 || dtype == torch::kBFloat16,
                "foreach_norm: only float32, float16 and bfloat16 are supported.");
    for (const auto &t : x) {
        TORCH_CHECK(t.scalar_type() == dtype, "foreach_norm: all tensors in the list must share the same dtype.");
    }

    int32_t mode = 0;
    float p = 0.0f;
    float invP = 0.0f;
    if (std::isinf(scalar)) {
        mode = (scalar > 0) ? 1 : 2; // +inf: max|x|, -inf: min|x|
    } else if (scalar == 0.0) {
        mode = 3; // L0: count of non-zero elements
    } else {
        mode = 0;
        p = static_cast<float>(scalar);
        invP = static_cast<float>(1.0 / scalar);
    }

    std::vector<torch::Tensor> outs;
    outs.reserve(x.size());
    for (size_t i = 0; i < x.size(); ++i) {
        const c10::OptionalDeviceGuard guard(x[i].device());
        auto contig = x[i].contiguous();
        auto out = torch::empty(c10::IntArrayRef{}, x[i].options());
        int64_t totalLength = contig.numel();
        if (totalLength == 0) {
            out.zero_();
            outs.push_back(out);
            continue;
        }
        int64_t numBlocks, blockLength, tileElems;
        std::tie(numBlocks, blockLength, tileElems) = calc_foreach_norm_tiling_params(totalLength, mode);
        auto partial = torch::empty({numBlocks}, x[i].options().dtype(torch::kFloat32));
        auto stream = c10_npu::getCurrentNPUStream().stream(false);

        auto x_ptr = (GM_ADDR)contig.data_ptr();
        auto p_ptr = (GM_ADDR)partial.data_ptr();
        auto o_ptr = (GM_ADDR)out.data_ptr();
        uint32_t tileSz = static_cast<uint32_t>(tileElems);

        auto acl_call = [=]() -> int {
            if (dtype == torch::kFloat32) {
                launch_foreach_norm_partial_float(x_ptr, p_ptr, totalLength, numBlocks, blockLength, tileSz, p, mode, stream);
                launch_foreach_norm_final_float(p_ptr, o_ptr, numBlocks, invP, mode, stream);
            } else if (dtype == torch::kFloat16) {
                launch_foreach_norm_partial_half(x_ptr, p_ptr, totalLength, numBlocks, blockLength, tileSz, p, mode, stream);
                launch_foreach_norm_final_half(p_ptr, o_ptr, numBlocks, invP, mode, stream);
            } else {
                launch_foreach_norm_partial_bfloat16(x_ptr, p_ptr, totalLength, numBlocks, blockLength, tileSz, p, mode, stream);
                launch_foreach_norm_final_bfloat16(p_ptr, o_ptr, numBlocks, invP, mode, stream);
            }
            return 0;
        };
        at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
        outs.push_back(out);
    }
    return outs;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

} // namespace cann_bench
