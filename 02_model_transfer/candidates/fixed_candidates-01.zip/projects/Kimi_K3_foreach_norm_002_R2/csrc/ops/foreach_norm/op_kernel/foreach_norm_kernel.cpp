/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_kernel.cpp
 * \brief ForeachNorm host code - kernel launch and tiling (compiled with bisheng + -xasc)
 *
 * Two-stage reduction:
 *  stage1 (multi-core): each AI core reduces its chunk of one tensor into a float partial
 *                       (sum(|x|^p) / max|x| / min|x| / count(x!=0)) and writes it to a
 *                       float workspace in GM. Per-tile results are folded into a vector
 *                       accumulator (Add/Max/Min) to keep the pipeline busy; only one
 *                       scalar reduction is done per block at the end.
 *  stage2 (single core): reduces the partials and applies the final power 1/p, then casts
 *                       the scalar result back to the input dtype.
 * All element computation is done in float32 for precision.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;

// Elementwise transform: tmp = |src|^p (mode 0), tmp = |src| (mode 1/2), tmp = (src != 0) (mode 3)
__aicore__ inline void TransformF32(
    const AscendC::LocalTensor<float> &src,
    const AscendC::LocalTensor<float> &tmp,
    const AscendC::LocalTensor<float> &aux,
    const AscendC::LocalTensor<float> &ones,
    const AscendC::LocalTensor<uint8_t> &mask,
    uint32_t count, float p, int32_t mode)
{
    if (mode == 1 || mode == 2) {
        AscendC::Abs(tmp, src, count);
    } else if (mode == 3) {
        AscendC::Abs(tmp, src, count);
        AscendC::Duplicate(aux, 0.0f, count);
        AscendC::Compare(mask, tmp, aux, AscendC::CMPMODE::NE, count);
        AscendC::Select(tmp, mask, ones, aux, AscendC::SELMODE::VSEL_TENSOR_TENSOR_MODE, count);
    } else if (p == 1.0f) {
        AscendC::Abs(tmp, src, count);
    } else if (p == 2.0f) {
        AscendC::Mul(tmp, src, src, count);
    } else if (p == 3.0f) {
        AscendC::Abs(aux, src, count);
        AscendC::Mul(tmp, src, src, count);
        AscendC::Mul(tmp, tmp, aux, count);
    } else if (p == 4.0f) {
        AscendC::Mul(tmp, src, src, count);
        AscendC::Mul(tmp, tmp, tmp, count);
    } else if (p == 5.0f) {
        AscendC::Abs(aux, src, count);
        AscendC::Mul(tmp, src, src, count);
        AscendC::Mul(tmp, tmp, tmp, count);
        AscendC::Mul(tmp, tmp, aux, count);
    } else if (p == 0.5f) {
        AscendC::Abs(tmp, src, count);
        AscendC::Sqrt(tmp, tmp, count);
    } else if (p == 1.5f) {
        AscendC::Abs(aux, src, count);
        AscendC::Sqrt(tmp, aux, count);
        AscendC::Mul(tmp, tmp, aux, count);
    } else if (p == 2.5f) {
        AscendC::Abs(aux, src, count);
        AscendC::Mul(tmp, src, src, count);
        AscendC::Sqrt(aux, aux, count);
        AscendC::Mul(tmp, tmp, aux, count);
    } else if (p == -1.0f) {
        AscendC::Abs(tmp, src, count);
        AscendC::Reciprocal(tmp, tmp, count);
    } else if (p == -2.0f) {
        AscendC::Mul(tmp, src, src, count);
        AscendC::Reciprocal(tmp, tmp, count);
    } else {
        AscendC::Abs(tmp, src, count);
        AscendC::Ln(tmp, tmp, count);
        AscendC::Muls(tmp, tmp, p, count);
        AscendC::Exp(tmp, tmp, count);
    }
}

template <typename T>
__aicore__ inline void TransformTile(
    const AscendC::LocalTensor<T> &inLocal,
    const AscendC::LocalTensor<float> &f32Local,
    const AscendC::LocalTensor<float> &tmpLocal,
    const AscendC::LocalTensor<float> &auxLocal,
    const AscendC::LocalTensor<float> &onesLocal,
    const AscendC::LocalTensor<uint8_t> &maskLocal,
    uint32_t count, float p, int32_t mode)
{
    if constexpr (std::is_same_v<T, float>) {
        TransformF32(inLocal, tmpLocal, auxLocal, onesLocal, maskLocal, count, p, mode);
    } else {
        AscendC::Cast(f32Local, inLocal, AscendC::RoundMode::CAST_NONE, count);
        TransformF32(f32Local, tmpLocal, auxLocal, onesLocal, maskLocal, count, p, mode);
    }
}

// Stage 1: per-block partial reduction, result written to partial[blockIdx]
template <typename T>
__global__ __aicore__ void foreach_norm_partial_kernel(
    GM_ADDR x, GM_ADDR partial,
    int64_t totalLength, int64_t blockLength, uint32_t tileElems,
    float p, int32_t mode)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> f32Buf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> auxBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> accBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> onesBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> maskBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> sumBuf;
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileElems * sizeof(T));
    if constexpr (std::is_same_v<T, float>) {
        pipe.InitBuffer(f32Buf, 256);
    } else {
        pipe.InitBuffer(f32Buf, tileElems * sizeof(float));
    }
    pipe.InitBuffer(tmpBuf, tileElems * sizeof(float));
    pipe.InitBuffer(auxBuf, tileElems * sizeof(float));
    pipe.InitBuffer(accBuf, tileElems * sizeof(float));
    if (mode == 3) {
        pipe.InitBuffer(onesBuf, tileElems * sizeof(float));
        pipe.InitBuffer(maskBuf, tileElems);
    } else {
        pipe.InitBuffer(onesBuf, 64);
        pipe.InitBuffer(maskBuf, 64);
    }
    pipe.InitBuffer(sumBuf, 256);

    auto f32Local = f32Buf.Get<float>();
    auto tmpLocal = tmpBuf.Get<float>();
    auto auxLocal = auxBuf.Get<float>();
    auto accLocal = accBuf.Get<float>();
    auto onesLocal = onesBuf.Get<float>();
    auto maskLocal = maskBuf.Get<uint8_t>();
    auto sumLocal = sumBuf.Get<float>();

    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t start = blockIdx * blockLength;
    int64_t curLen = totalLength - start;
    if (curLen > blockLength) curLen = blockLength;

    AscendC::GlobalTensor<T> xGm;
    xGm.SetGlobalBuffer((__gm__ T *)x);
    AscendC::GlobalTensor<float> partialGm;
    partialGm.SetGlobalBuffer((__gm__ float *)partial);

    // init vector accumulator
    float initVal = (mode == 2) ? 3.402823466e38f : 0.0f;
    AscendC::Duplicate(accLocal, initVal, tileElems);
    if (mode == 3) {
        AscendC::Duplicate(onesLocal, 1.0f, tileElems);
    }

    if (curLen > 0) {
        int64_t tileNum = (curLen + (int64_t)tileElems - 1) / (int64_t)tileElems;
        for (int64_t i = 0; i < tileNum; ++i) {
            int64_t offset = start + i * (int64_t)tileElems;
            int64_t cnt64 = curLen - i * (int64_t)tileElems;
            if (cnt64 > (int64_t)tileElems) cnt64 = (int64_t)tileElems;
            uint32_t count = (uint32_t)cnt64;

            auto inLocal = inQueue.AllocTensor<T>();
            AscendC::DataCopyExtParams copyParams{1, count * (uint32_t)sizeof(T), 0, 0, 0};
            AscendC::DataCopyPadExtParams<T> padParams{true, 0, 0, 0};
            AscendC::DataCopyPad(inLocal, xGm[offset], copyParams, padParams);
            inQueue.EnQue(inLocal);
            inLocal = inQueue.DeQue<T>();

            TransformTile<T>(inLocal, f32Local, tmpLocal, auxLocal, onesLocal, maskLocal, count, p, mode);
            inQueue.FreeTensor(inLocal);

            // fold tile result into the vector accumulator (no pipeline stall)
            if (mode == 1) {
                AscendC::Max(accLocal, accLocal, tmpLocal, count);
            } else if (mode == 2) {
                AscendC::Min(accLocal, accLocal, tmpLocal, count);
            } else {
                AscendC::Add(accLocal, accLocal, tmpLocal, count);
            }
        }
    }

    // single scalar reduction per block
    if (mode == 1) {
        AscendC::ReduceMax(sumLocal, accLocal, auxLocal, tileElems);
    } else if (mode == 2) {
        AscendC::ReduceMin(sumLocal, accLocal, auxLocal, tileElems);
    } else {
        AscendC::ReduceSum(sumLocal, accLocal, auxLocal, tileElems);
    }
    AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(EVENT_ID0);
    AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(EVENT_ID0);
    AscendC::DataCopyExtParams outParams{1, (uint32_t)sizeof(float), 0, 0, 0};
    AscendC::DataCopyPad(partialGm[blockIdx], sumLocal, outParams);
}

// Stage 2: single block; reduce partials and apply final power, cast back to T
template <typename T>
__global__ __aicore__ void foreach_norm_final_kernel(
    GM_ADDR partial, GM_ADDR out, int64_t partialNum, float invP, int32_t mode)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> workBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> calcBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> outFBuf;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> outTBuf;
    pipe.InitBuffer(inQueue, 1, 4096);
    pipe.InitBuffer(workBuf, 4096);
    pipe.InitBuffer(calcBuf, 256);
    pipe.InitBuffer(outFBuf, 256);
    pipe.InitBuffer(outTBuf, 256);

    auto workLocal = workBuf.Get<float>();
    auto calcLocal = calcBuf.Get<float>();
    auto outFLocal = outFBuf.Get<float>();
    auto outTLocal = outTBuf.Get<T>();

    AscendC::GlobalTensor<float> partialGm;
    partialGm.SetGlobalBuffer((__gm__ float *)partial);
    AscendC::GlobalTensor<T> outGm;
    outGm.SetGlobalBuffer((__gm__ T *)out);

    auto inLocal = inQueue.AllocTensor<float>();
    AscendC::DataCopyExtParams copyParams{1, (uint32_t)(partialNum * (int64_t)sizeof(float)), 0, 0, 0};
    AscendC::DataCopyPadExtParams<float> padParams{true, 0, 0, 0};
    AscendC::DataCopyPad(inLocal, partialGm, copyParams, padParams);
    inQueue.EnQue(inLocal);
    inLocal = inQueue.DeQue<float>();

    float result = 0.0f;
    if (mode == 1) {
        AscendC::ReduceMax(calcLocal, inLocal, workLocal, (int32_t)partialNum);
        AscendC::SetFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
        AscendC::WaitFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
        result = calcLocal.GetValue(0);
    } else if (mode == 2) {
        AscendC::ReduceMin(calcLocal, inLocal, workLocal, (int32_t)partialNum);
        AscendC::SetFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
        AscendC::WaitFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
        result = calcLocal.GetValue(0);
    } else {
        AscendC::ReduceSum(calcLocal, inLocal, workLocal, (int32_t)partialNum);
        AscendC::SetFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
        AscendC::WaitFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
        float v = calcLocal.GetValue(0);
        if (mode == 3) {
            result = v;
        } else if (v <= 0.0f) {
            if (invP < 0.0f) {
                uint32_t infBits = 0x7f800000u;
                result = *reinterpret_cast<float *>(&infBits);
            } else {
                result = 0.0f;
            }
        } else {
            calcLocal.SetValue(0, v);
            AscendC::SetFlag<AscendC::HardEvent::S_V>(EVENT_ID0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(EVENT_ID0);
            AscendC::Ln(calcLocal, calcLocal, 8);
            AscendC::Muls(calcLocal, calcLocal, invP, 8);
            AscendC::Exp(calcLocal, calcLocal, 8);
            AscendC::SetFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
            result = calcLocal.GetValue(0);
        }
    }
    inQueue.FreeTensor(inLocal);

    outFLocal.SetValue(0, result);
    AscendC::SetFlag<AscendC::HardEvent::S_V>(EVENT_ID0);
    AscendC::WaitFlag<AscendC::HardEvent::S_V>(EVENT_ID0);
    if constexpr (std::is_same_v<T, float>) {
        AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(EVENT_ID0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(EVENT_ID0);
        AscendC::DataCopyExtParams outParams{1, (uint32_t)sizeof(float), 0, 0, 0};
        AscendC::DataCopyPad(outGm, outFLocal, outParams);
    } else {
        AscendC::Cast(outTLocal, outFLocal, AscendC::RoundMode::CAST_RINT, 8);
        AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(EVENT_ID0);
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(EVENT_ID0);
        AscendC::DataCopyExtParams outParams{1, (uint32_t)sizeof(T), 0, 0, 0};
        AscendC::DataCopyPad(outGm, outTLocal, outParams);
    }
}

// Tiling function: returns (numBlocks, blockLength, tileElems)
std::tuple<int64_t, int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength, int32_t mode)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    if (coreNum > 256) coreNum = 256;
    constexpr static int64_t MIN_ELEMS_PER_CORE = 2048;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) numBlocks = coreNum;
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    // worst-case UB budget per element: 20 bytes (25 for L0 which needs ones+mask)
    int64_t bytesPerElem = (mode == 3) ? 25 : 20;
    int64_t usable = (int64_t)ubSize - 8192;
    if (usable < 20480) usable = 20480;
    int64_t tileElems = usable / bytesPerElem;
    tileElems = (tileElems / 256) * 256;
    if (tileElems > 8192) tileElems = 8192;
    if (tileElems < 1024) tileElems = 1024;
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_foreach_norm_partial_float(GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t numBlocks,
                                       int64_t blockLength, uint32_t tileElems, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<float><<<numBlocks, nullptr, stream>>>(
        x, partial, totalLength, blockLength, tileElems, p, mode);
}

void launch_foreach_norm_partial_half(GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t numBlocks,
                                      int64_t blockLength, uint32_t tileElems, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<half><<<numBlocks, nullptr, stream>>>(
        x, partial, totalLength, blockLength, tileElems, p, mode);
}

void launch_foreach_norm_partial_bfloat16(GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t numBlocks,
                                          int64_t blockLength, uint32_t tileElems, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, partial, totalLength, blockLength, tileElems, p, mode);
}

void launch_foreach_norm_final_float(GM_ADDR partial, GM_ADDR out, int64_t partialNum,
                                     float invP, int32_t mode, void *stream)
{
    foreach_norm_final_kernel<float><<<1, nullptr, stream>>>(partial, out, partialNum, invP, mode);
}

void launch_foreach_norm_final_half(GM_ADDR partial, GM_ADDR out, int64_t partialNum,
                                    float invP, int32_t mode, void *stream)
{
    foreach_norm_final_kernel<half><<<1, nullptr, stream>>>(partial, out, partialNum, invP, mode);
}

void launch_foreach_norm_final_bfloat16(GM_ADDR partial, GM_ADDR out, int64_t partialNum,
                                        float invP, int32_t mode, void *stream)
{
    foreach_norm_final_kernel<bfloat16_t><<<1, nullptr, stream>>>(partial, out, partialNum, invP, mode);
}

}
