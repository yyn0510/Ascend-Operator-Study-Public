/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_launch.h
 * \brief Launch function declarations for g++
 */

#ifndef FOREACH_NORM_LAUNCH_H
#define FOREACH_NORM_LAUNCH_H

#include <cstdint>
#include <tuple>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

// Tiling function declaration: returns (numBlocks, blockLength, tileElems)
std::tuple<int64_t, int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength);

// Launch function declarations
extern "C" {
void launch_foreach_norm_partial_float(GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t numBlocks,
                                       int64_t blockLength, uint32_t tileElems, int32_t mode, float p,
                                       int32_t pInt, void *stream);
void launch_foreach_norm_partial_half(GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t numBlocks,
                                      int64_t blockLength, uint32_t tileElems, int32_t mode, float p,
                                      int32_t pInt, void *stream);
void launch_foreach_norm_partial_bfloat16(GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t numBlocks,
                                          int64_t blockLength, uint32_t tileElems, int32_t mode, float p,
                                          int32_t pInt, void *stream);
void launch_foreach_norm_final_float(GM_ADDR partial, GM_ADDR y, int64_t numPartials, int32_t mode, float invP, void *stream);
void launch_foreach_norm_final_half(GM_ADDR partial, GM_ADDR y, int64_t numPartials, int32_t mode, float invP, void *stream);
void launch_foreach_norm_final_bfloat16(GM_ADDR partial, GM_ADDR y, int64_t numPartials, int32_t mode, float invP, void *stream);
}

#endif // FOREACH_NORM_LAUNCH_H
