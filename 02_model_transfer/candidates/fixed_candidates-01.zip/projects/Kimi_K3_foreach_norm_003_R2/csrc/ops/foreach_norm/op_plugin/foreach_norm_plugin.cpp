/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_plugin.cpp
 * \brief ForeachNorm API layer - torch bindings (compiled with g++)
 */

#include <cmath>
#include <tuple>
#include <vector>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<torch::Tensor> foreach_norm_meta(const std::vector<torch::Tensor> &x, double scalar)
{
    TORCH_CHECK(!x.empty(), "foreach_norm expects a non-empty tensor list.");
    std::vector<torch::Tensor> outs;
    outs.reserve(x.size());
    for (const auto &t : x) {
        outs.push_back(torch::empty({}, t.options()));
    }
    return outs;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

static int32_t select_norm_mode(double p, int32_t &pInt)
{
    pInt = 0;
    if (std::isinf(p)) {
        return p > 0 ? 4 : 5;
    }
    if (p == 0.0) return 0;
    if (p == 1.0) return 1;
    if (p == 2.0) return 2;
    double rp = std::round(p);
    if (p == rp && p >= 3.0 && p <= 8.0) {
        pInt = static_cast<int32_t>(p);
        return 6;
    }
    if (p == rp && p <= -1.0 && p >= -8.0) {
        pInt = static_cast<int32_t>(-p);
        return 8;
    }
    double k = std::floor(p);
    if (p > 0.0 && (p - k) == 0.5 && k >= 1.0 && k <= 8.0) {
        pInt = static_cast<int32_t>(k);
        return 7;
    }
    return 3;
}

std::vector<torch::Tensor> foreach_norm_npu(const std::vector<torch::Tensor> &x, double scalar)
{
    TORCH_CHECK(!x.empty(), "foreach_norm expects a non-empty tensor list.");
    auto dtype = x[0].scalar_type();
    for (const auto &t : x) {
        TORCH_CHECK(t.scalar_type() == dtype, "All tensors in the list must have the same dtype.");
        TORCH_CHECK(dtype == torch::kFloat32 || dtype == torch::kFloat16 || dtype == torch::kBFloat16,
                    "foreach_norm only supports float32, float16 and bfloat16.");
    }

    const c10::OptionalDeviceGuard guard(x[0].device());
    auto outs = foreach_norm_meta(x, scalar);
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int32_t pInt = 0;
    int32_t mode = select_norm_mode(scalar, pInt);
    float p = static_cast<float>(scalar);
    float invP = static_cast<float>(1.0 / scalar);

    std::vector<torch::Tensor> contig;
    std::vector<torch::Tensor> workspaces;
    std::vector<int64_t> numBlocksList;
    std::vector<int64_t> blockLenList;
    std::vector<uint32_t> tileElemsList;
    contig.reserve(x.size());
    workspaces.reserve(x.size());
    for (size_t i = 0; i < x.size(); ++i) {
        auto t = x[i].contiguous();
        int64_t totalLength = t.numel();
        int64_t numBlocks, blockLength, tileElems;
        std::tie(numBlocks, blockLength, tileElems) = calc_foreach_norm_tiling_params(totalLength);
        auto ws = torch::empty({numBlocks}, torch::TensorOptions().dtype(torch::kFloat32).device(t.device()));
        contig.push_back(t);
        workspaces.push_back(ws);
        numBlocksList.push_back(numBlocks);
        blockLenList.push_back(blockLength);
        tileElemsList.push_back(static_cast<uint32_t>(tileElems));
    }

    auto acl_call = [=]() -> int {
        for (size_t i = 0; i < contig.size(); ++i) {
            int64_t totalLength = contig[i].numel();
            GM_ADDR x_ptr = (GM_ADDR)contig[i].data_ptr();
            GM_ADDR ws_ptr = (GM_ADDR)workspaces[i].data_ptr();
            GM_ADDR y_ptr = (GM_ADDR)outs[i].data_ptr();
            int64_t numBlocks = numBlocksList[i];
            int64_t blockLength = blockLenList[i];
            uint32_t tileElems = tileElemsList[i];
            if (dtype == torch::kFloat32) {
                launch_foreach_norm_partial_float(x_ptr, ws_ptr, totalLength, numBlocks, blockLength, tileElems, mode, p, pInt, stream);
                launch_foreach_norm_final_float(ws_ptr, y_ptr, numBlocks, mode, invP, stream);
            } else if (dtype == torch::kFloat16) {
                launch_foreach_norm_partial_half(x_ptr, ws_ptr, totalLength, numBlocks, blockLength, tileElems, mode, p, pInt, stream);
                launch_foreach_norm_final_half(ws_ptr, y_ptr, numBlocks, mode, invP, stream);
            } else {
                launch_foreach_norm_partial_bfloat16(x_ptr, ws_ptr, totalLength, numBlocks, blockLength, tileElems, mode, p, pInt, stream);
                launch_foreach_norm_final_bfloat16(ws_ptr, y_ptr, numBlocks, mode, invP, stream);
            }
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
    return outs;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

} // namespace cann_bench
