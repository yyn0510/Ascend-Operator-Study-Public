/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_kernel.cpp
 * \brief ForeachNorm kernel, host tiling and launch wrappers.
 */

#include <tuple>
#include <algorithm>
#include <cmath>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr int32_t FN_MODE_SUM = 0;
constexpr int32_t FN_MODE_MAX = 1;
constexpr int32_t FN_MODE_MIN = 2;
constexpr int32_t FN_LANES = 8;

__aicore__ inline float FnStartValue(int32_t mode)
{
    if (mode == FN_MODE_MAX) {
        return -1.0e38f;
    }
    if (mode == FN_MODE_MIN) {
        return 1.0e38f;
    }
    return 0.0f;
}

__aicore__ inline void FnAccumulate(
    const AscendC::LocalTensor<float>& acc,
    const AscendC::LocalTensor<float>& data,
    const AscendC::LocalTensor<float>& t1,
    const AscendC::LocalTensor<float>& t2,
    const AscendC::LocalTensor<float>& t3,
    int32_t c, float p, int32_t mode)
{
    if (mode == FN_MODE_MAX) {
        AscendC::Max(acc, acc, data, c);
    } else if (mode == FN_MODE_MIN) {
        AscendC::Min(acc, acc, data, c);
    } else if (p == 1.0f) {
        AscendC::Add(acc, acc, data, c);
    } else if (p == 2.0f) {
        AscendC::Mul(t1, data, data, c);
        AscendC::Add(acc, acc, t1, c);
    } else if (p == 3.0f) {
        AscendC::Mul(t1, data, data, c);
        AscendC::Mul(t2, t1, data, c);
        AscendC::Add(acc, acc, t2, c);
    } else if (p == 4.0f) {
        AscendC::Mul(t1, data, data, c);
        AscendC::Mul(t2, t1, t1, c);
        AscendC::Add(acc, acc, t2, c);
    } else if (p == 5.0f) {
        AscendC::Mul(t1, data, data, c);
        AscendC::Mul(t2, t1, t1, c);
        AscendC::Mul(t3, t2, data, c);
        AscendC::Add(acc, acc, t3, c);
    } else if (p == 0.5f) {
        AscendC::Sqrt(t1, data, c);
        AscendC::Add(acc, acc, t1, c);
    } else if (p == 1.5f) {
        AscendC::Sqrt(t1, data, c);
        AscendC::Mul(t2, t1, data, c);
        AscendC::Add(acc, acc, t2, c);
    } else if (p == 2.5f) {
        AscendC::Sqrt(t1, data, c);
        AscendC::Mul(t2, data, data, c);
        AscendC::Mul(t3, t1, t2, c);
        AscendC::Add(acc, acc, t3, c);
    } else if (p == -1.0f) {
        AscendC::Duplicate(t1, 1.0f, c);
        AscendC::Div(t2, t1, data, c);
        AscendC::Add(acc, acc, t2, c);
    } else if (p == 0.0f) {
        AscendC::Adds(t1, data, 1.0e-30f, c);
        AscendC::Div(t2, data, t1, c);
        AscendC::Add(acc, acc, t2, c);
    } else {
        AscendC::Maxs(t1, data, 1.0e-30f, c);
        AscendC::Ln(t2, t1, c);
        AscendC::Muls(t3, t2, p, c);
        AscendC::Exp(t1, t3, c);
        AscendC::Add(acc, acc, t1, c);
    }
}

__aicore__ inline void FnFinalize(
    const AscendC::LocalTensor<float>& out,
    const AscendC::LocalTensor<float>& b0,
    const AscendC::LocalTensor<float>& b1,
    const AscendC::LocalTensor<float>& b2,
    float s, float p, int32_t mode)
{
    AscendC::Duplicate(b0, s, FN_LANES);
    if (mode != FN_MODE_SUM) {
        AscendC::Adds(out, b0, 0.0f, FN_LANES);
        return;
    }
    if (p == 1.0f || p == 0.0f) {
        AscendC::Adds(out, b0, 0.0f, FN_LANES);
    } else if (p == 2.0f) {
        AscendC::Sqrt(out, b0, FN_LANES);
    } else if (p == 0.5f) {
        AscendC::Mul(out, b0, b0, FN_LANES);
    } else if (p == 4.0f) {
        AscendC::Sqrt(b1, b0, FN_LANES);
        AscendC::Sqrt(out, b1, FN_LANES);
    } else if (p == -1.0f) {
        AscendC::Duplicate(b1, 1.0f, FN_LANES);
        AscendC::Div(out, b1, b0, FN_LANES);
    } else {
        AscendC::Maxs(b1, b0, 1.0e-38f, FN_LANES);
        AscendC::Ln(b2, b1, FN_LANES);
        AscendC::Muls(b1, b2, 1.0f / p, FN_LANES);
        AscendC::Exp(out, b1, FN_LANES);
    }
}

template <typename T>
__aicore__ inline void FnStage2Body(GM_ADDR ws, GM_ADDR y, int64_t nb, float p, int32_t mode)
{
    int32_t nn = static_cast<int32_t>(nb);
    if (nn < 1) {
        nn = 1;
    }
    if (nn > 256) {
        nn = 256;
    }

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQ;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQ;
    AscendC::TBuf<AscendC::TPosition::VECCALC> rBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> cBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> dBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> eBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> wBuf;
    pipe.InitBuffer(inQ, 1, 1024);
    pipe.InitBuffer(outQ, 1, 32);
    pipe.InitBuffer(rBuf, 32);
    pipe.InitBuffer(cBuf, 32);
    pipe.InitBuffer(dBuf, 32);
    pipe.InitBuffer(eBuf, 32);
    pipe.InitBuffer(wBuf, 1024);

    AscendC::GlobalTensor<float> wsGm;
    wsGm.SetGlobalBuffer((__gm__ float*)ws);
    auto inL = inQ.AllocTensor<float>();
    AscendC::DataCopyExtParams cp;
    cp.blockCount = 1;
    cp.blockLen = static_cast<uint32_t>(nn) * 4u;
    cp.srcStride = 0;
    cp.dstStride = 0;
    cp.rsv = 0;
    AscendC::DataCopyPadExtParams<float> pp;
    pp.isPad = false;
    pp.leftPadding = 0;
    pp.rightPadding = 0;
    pp.paddingValue = 0;
    AscendC::DataCopyPad(inL, wsGm[0], cp, pp);
    inQ.EnQue(inL);
    inL = inQ.DeQue<float>();

    auto rL = rBuf.Get<float>();
    auto wL = wBuf.Get<float>();
    if (mode == FN_MODE_MAX) {
        AscendC::ReduceMax<float>(rL, inL, wL, nn);
    } else if (mode == FN_MODE_MIN) {
        AscendC::ReduceMin<float>(rL, inL, wL, nn);
    } else {
        AscendC::ReduceSum<float>(rL, inL, wL, nn);
    }
    inQ.FreeTensor(inL);

    auto aL = cBuf.Get<float>();
    auto b1L = dBuf.Get<float>();
    auto b2L = eBuf.Get<float>();
    float s = rL.GetValue(0);
    FnFinalize(aL, b1L, b2L, rL, s, p, mode);

    auto oL = outQ.AllocTensor<T>();
    if constexpr (std::is_same_v<T, float>) {
        AscendC::Adds(oL, aL, 0.0f, FN_LANES);
    } else {
        AscendC::Cast(oL, aL, AscendC::RoundMode::CAST_RINT, FN_LANES);
    }
    outQ.EnQue(oL);
    oL = outQ.DeQue<T>();

    AscendC::GlobalTensor<T> yGm;
    yGm.SetGlobalBuffer((__gm__ T*)y);
    AscendC::DataCopyExtParams cy;
    cy.blockCount = 1;
    cy.blockLen = static_cast<uint32_t>(sizeof(T));
    cy.srcStride = 0;
    cy.dstStride = 0;
    cy.rsv = 0;
    AscendC::DataCopyPad(yGm[0], oL, cy);
    outQ.FreeTensor(oL);
}

template <typename T>
__global__ __aicore__ void fn_direct_s1(
    GM_ADDR x, GM_ADDR ws, int64_t len, int64_t nb,
    uint32_t tileSize, float p, int32_t mode)
{
    int64_t bId = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t nbi = (nb > 0) ? nb : 1;
    int64_t bl = (len + nbi - 1) / nbi;
    int64_t start = bId * bl;
    int64_t end = start + bl;
    if (end > len) {
        end = len;
    }
    int64_t curLen = (end > start) ? (end - start) : 0;

    int64_t elemPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elemPerTile < 1) {
        elemPerTile = 1;
    }
    uint32_t inBytes = static_cast<uint32_t>(elemPerTile * static_cast<int64_t>(sizeof(T)));
    uint32_t fBytes = static_cast<uint32_t>(elemPerTile * 4);
    int32_t full = static_cast<int32_t>(elemPerTile);

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 2> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> dataBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> auxBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> accBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBuf;
    pipe.InitBuffer(inQueue, 2, inBytes);
    pipe.InitBuffer(outQueue, 1, 32);
    pipe.InitBuffer(dataBuf, fBytes);
    pipe.InitBuffer(tmpBuf, fBytes);
    pipe.InitBuffer(auxBuf, fBytes);
    pipe.InitBuffer(accBuf, fBytes);
    pipe.InitBuffer(workBuf, fBytes);

    auto dataLocal = dataBuf.Get<float>();
    auto tmpLocal = tmpBuf.Get<float>();
    auto auxLocal = auxBuf.Get<float>();
    auto accLocal = accBuf.Get<float>();
    auto workLocal = workBuf.Get<float>();
    AscendC::Duplicate(accLocal, FnStartValue(mode), full);

    if (curLen > 0) {
        AscendC::GlobalTensor<T> xGm;
        xGm.SetGlobalBuffer((__gm__ T*)x + start);
        int64_t tileNum = curLen / elemPerTile;
        int64_t tail = curLen - tileNum * elemPerTile;
        int64_t iter = tileNum + ((tail > 0) ? 1 : 0);
        for (int64_t t = 0; t < iter; ++t) {
            int64_t cnt = (t < tileNum) ? elemPerTile : tail;
            int32_t c = static_cast<int32_t>(cnt);
            int64_t off = t * elemPerTile;
            auto xLocal = inQueue.AllocTensor<T>();
            AscendC::DataCopyExtParams cp;
            cp.blockCount = 1;
            cp.blockLen = static_cast<uint32_t>(cnt * static_cast<int64_t>(sizeof(T)));
            cp.srcStride = 0;
            cp.dstStride = 0;
            cp.rsv = 0;
            AscendC::DataCopyPadExtParams<T> padParams;
            padParams.isPad = false;
            padParams.leftPadding = 0;
            padParams.rightPadding = 0;
            padParams.paddingValue = 0;
            AscendC::DataCopyPad(xLocal, xGm[off], cp, padParams);
            inQueue.EnQue(xLocal);
            xLocal = inQueue.DeQue<T>();
            if constexpr (std::is_same_v<T, float>) {
                AscendC::Abs(dataLocal, xLocal, c);
            } else {
                AscendC::Cast(tmpLocal, xLocal, AscendC::RoundMode::CAST_NONE, c);
                AscendC::Abs(dataLocal, tmpLocal, c);
            }
            FnAccumulate(accLocal, dataLocal, tmpLocal, auxLocal, workLocal, c, p, mode);
            inQueue.FreeTensor(xLocal);
        }
    }

    auto outLocal = outQueue.AllocTensor<float>();
    if (mode == FN_MODE_MAX) {
        AscendC::ReduceMax<float>(outLocal, accLocal, workLocal, full);
    } else if (mode == FN_MODE_MIN) {
        AscendC::ReduceMin<float>(outLocal, accLocal, workLocal, full);
    } else {
        AscendC::ReduceSum<float>(outLocal, accLocal, workLocal, full);
    }
    outQueue.EnQue(outLocal);
    outLocal = outQueue.DeQue<float>();

    AscendC::GlobalTensor<float> wsGm;
    wsGm.SetGlobalBuffer((__gm__ float*)ws + bId);
    AscendC::DataCopyExtParams cpo;
    cpo.blockCount = 1;
    cpo.blockLen = 4u;
    cpo.srcStride = 0;
    cpo.dstStride = 0;
    cpo.rsv = 0;
    AscendC::DataCopyPad(wsGm[0], outLocal, cpo);
    outQueue.FreeTensor(outLocal);
}

template <typename T>
__global__ __aicore__ void fn_direct_s2(
    GM_ADDR ws, GM_ADDR y, int64_t nb, float p, int32_t mode)
{
    FnStage2Body<T>(ws, y, nb, p, mode);
}

template <typename T>
__global__ __aicore__ void fn_merged_s1(
    GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3,
    GM_ADDR ws,
    int64_t l0, int64_t l1, int64_t l2, int64_t l3,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3,
    uint32_t tileSize, float p, int32_t mode)
{
    int64_t bId = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t nbs[4];
    nbs[0] = b0;
    nbs[1] = b1;
    nbs[2] = b2;
    nbs[3] = b3;

    int64_t prefix = 0;
    int64_t ti = -1;
    int64_t localBlk = 0;
    for (int32_t k = 0; k < 4; ++k) {
        if (bId < prefix + nbs[k]) {
            ti = k;
            localBlk = bId - prefix;
            break;
        }
        prefix += nbs[k];
    }
    if (ti < 0) {
        return;
    }

    int64_t len = l0;
    int64_t nbi = b0;
    GM_ADDR xp = x0;
    if (ti == 1) {
        len = l1;
        nbi = b1;
        xp = x1;
    } else if (ti == 2) {
        len = l2;
        nbi = b2;
        xp = x2;
    } else if (ti == 3) {
        len = l3;
        nbi = b3;
        xp = x3;
    }
    if (nbi < 1) {
        return;
    }

    int64_t bl = (len + nbi - 1) / nbi;
    int64_t start = localBlk * bl;
    int64_t end = start + bl;
    if (end > len) {
        end = len;
    }
    int64_t curLen = (end > start) ? (end - start) : 0;

    int64_t elemPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elemPerTile < 1) {
        elemPerTile = 1;
    }
    uint32_t inBytes = static_cast<uint32_t>(elemPerTile * static_cast<int64_t>(sizeof(T)));
    uint32_t fBytes = static_cast<uint32_t>(elemPerTile * 4);
    int32_t full = static_cast<int32_t>(elemPerTile);

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 2> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> dataBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> auxBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> accBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBuf;
    pipe.InitBuffer(inQueue, 2, inBytes);
    pipe.InitBuffer(outQueue, 1, 32);
    pipe.InitBuffer(dataBuf, fBytes);
    pipe.InitBuffer(tmpBuf, fBytes);
    pipe.InitBuffer(auxBuf, fBytes);
    pipe.InitBuffer(accBuf, fBytes);
    pipe.InitBuffer(workBuf, fBytes);

    auto dataLocal = dataBuf.Get<float>();
    auto tmpLocal = tmpBuf.Get<float>();
    auto auxLocal = auxBuf.Get<float>();
    auto accLocal = accBuf.Get<float>();
    auto workLocal = workBuf.Get<float>();
    AscendC::Duplicate(accLocal, FnStartValue(mode), full);

    if (curLen > 0) {
        AscendC::GlobalTensor<T> xGm;
        xGm.SetGlobalBuffer((__gm__ T*)xp + start);
        int64_t tileNum = curLen / elemPerTile;
        int64_t tail = curLen - tileNum * elemPerTile;
        int64_t iter = tileNum + ((tail > 0) ? 1 : 0);
        for (int64_t t = 0; t < iter; ++t) {
            int64_t cnt = (t < tileNum) ? elemPerTile : tail;
            int32_t c = static_cast<int32_t>(cnt);
            int64_t off = t * elemPerTile;
            auto xLocal = inQueue.AllocTensor<T>();
            AscendC::DataCopyExtParams cp;
            cp.blockCount = 1;
            cp.blockLen = static_cast<uint32_t>(cnt * static_cast<int64_t>(sizeof(T)));
            cp.srcStride = 0;
            cp.dstStride = 0;
            cp.rsv = 0;
            AscendC::DataCopyPadExtParams<T> padParams;
            padParams.isPad = false;
            padParams.leftPadding = 0;
            padParams.rightPadding = 0;
            padParams.paddingValue = 0;
            AscendC::DataCopyPad(xLocal, xGm[off], cp, padParams);
            inQueue.EnQue(xLocal);
            xLocal = inQueue.DeQue<T>();
            if constexpr (std::is_same_v<T, float>) {
                AscendC::Abs(dataLocal, xLocal, c);
            } else {
                AscendC::Cast(tmpLocal, xLocal, AscendC::RoundMode::CAST_NONE, c);
                AscendC::Abs(dataLocal, tmpLocal, c);
            }
            FnAccumulate(accLocal, dataLocal, tmpLocal, auxLocal, workLocal, c, p, mode);
            inQueue.FreeTensor(xLocal);
        }
    }

    auto outLocal = outQueue.AllocTensor<float>();
    if (mode == FN_MODE_MAX) {
        AscendC::ReduceMax<float>(outLocal, accLocal, workLocal, full);
    } else if (mode == FN_MODE_MIN) {
        AscendC::ReduceMin<float>(outLocal, accLocal, workLocal, full);
    } else {
        AscendC::ReduceSum<float>(outLocal, accLocal, workLocal, full);
    }
    outQueue.EnQue(outLocal);
    outLocal = outQueue.DeQue<float>();

    AscendC::GlobalTensor<float> wsGm;
    wsGm.SetGlobalBuffer((__gm__ float*)ws + prefix + localBlk);
    AscendC::DataCopyExtParams cpo;
    cpo.blockCount = 1;
    cpo.blockLen = 4u;
    cpo.srcStride = 0;
    cpo.dstStride = 0;
    cpo.rsv = 0;
    AscendC::DataCopyPad(wsGm[0], outLocal, cpo);
    outQueue.FreeTensor(outLocal);
}

template <typename T>
__global__ __aicore__ void fn_merged_s2(
    GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3,
    GM_ADDR ws,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3,
    float p, int32_t mode)
{
    int64_t bId = static_cast<int64_t>(AscendC::GetBlockIdx());
    if (bId > 3) {
        return;
    }
    int64_t nbs[4];
    nbs[0] = b0;
    nbs[1] = b1;
    nbs[2] = b2;
    nbs[3] = b3;
    int64_t nb = nbs[bId];
    if (nb < 1) {
        return;
    }
    int64_t off = 0;
    for (int64_t k = 0; k < bId; ++k) {
        off += nbs[k];
    }
    GM_ADDR yp = y0;
    if (bId == 1) {
        yp = y1;
    } else if (bId == 2) {
        yp = y2;
    } else if (bId == 3) {
        yp = y3;
    }
    FnStage2Body<T>((GM_ADDR)((__gm__ float*)ws + off), yp, nb, p, mode);
}

std::tuple<int64_t, int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (coreNum > 64) {
        coreNum = 64;
    }
    if (ubSize == 0) {
        ubSize = 196608ULL;
    }

    int64_t tileSize = static_cast<int64_t>(ubSize) / 20;
    tileSize = tileSize - (tileSize % 32);
    if (tileSize < 512) {
        tileSize = 512;
    }

    if (totalLength <= 0) {
        return std::make_tuple(static_cast<int64_t>(1), static_cast<int64_t>(1), tileSize);
    }
    constexpr int64_t MIN_ELEMS_PER_CORE = 8192;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_fn_direct_s1_float(GM_ADDR x, GM_ADDR ws, int64_t len, int64_t nb, uint32_t tileSize, float p, int32_t mode, void* stream)
{
    fn_direct_s1<float><<<nb, nullptr, stream>>>(x, ws, len, nb, tileSize, p, mode);
}

void launch_fn_direct_s1_half(GM_ADDR x, GM_ADDR ws, int64_t len, int64_t nb, uint32_t tileSize, float p, int32_t mode, void* stream)
{
    fn_direct_s1<half><<<nb, nullptr, stream>>>(x, ws, len, nb, tileSize, p, mode);
}

void launch_fn_direct_s1_bfloat16(GM_ADDR x, GM_ADDR ws, int64_t len, int64_t nb, uint32_t tileSize, float p, int32_t mode, void* stream)
{
    fn_direct_s1<bfloat16_t><<<nb, nullptr, stream>>>(x, ws, len, nb, tileSize, p, mode);
}

void launch_fn_direct_s2_float(GM_ADDR ws, GM_ADDR y, int64_t nb, float p, int32_t mode, void* stream)
{
    fn_direct_s2<float><<<1, nullptr, stream>>>(ws, y, nb, p, mode);
}

void launch_fn_direct_s2_half(GM_ADDR ws, GM_ADDR y, int64_t nb, float p, int32_t mode, void* stream)
{
    fn_direct_s2<half><<<1, nullptr, stream>>>(ws, y, nb, p, mode);
}

void launch_fn_direct_s2_bfloat16(GM_ADDR ws, GM_ADDR y, int64_t nb, float p, int32_t mode, void* stream)
{
    fn_direct_s2<bfloat16_t><<<1, nullptr, stream>>>(ws, y, nb, p, mode);
}

void launch_fn_merged_s1_float(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR ws,
    int64_t l0, int64_t l1, int64_t l2, int64_t l3,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3,
    int64_t totalBlocks, uint32_t tileSize, float p, int32_t mode, void* stream)
{
    fn_merged_s1<float><<<totalBlocks, nullptr, stream>>>(x0, x1, x2, x3, ws, l0, l1, l2, l3, b0, b1, b2, b3, tileSize, p, mode);
}

void launch_fn_merged_s1_half(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR ws,
    int64_t l0, int64_t l1, int64_t l2, int64_t l3,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3,
    int64_t totalBlocks, uint32_t tileSize, float p, int32_t mode, void* stream)
{
    fn_merged_s1<half><<<totalBlocks, nullptr, stream>>>(x0, x1, x2, x3, ws, l0, l1, l2, l3, b0, b1, b2, b3, tileSize, p, mode);
}

void launch_fn_merged_s1_bfloat16(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR ws,
    int64_t l0, int64_t l1, int64_t l2, int64_t l3,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3,
    int64_t totalBlocks, uint32_t tileSize, float p, int32_t mode, void* stream)
{
    fn_merged_s1<bfloat16_t><<<totalBlocks, nullptr, stream>>>(x0, x1, x2, x3, ws, l0, l1, l2, l3, b0, b1, b2, b3, tileSize, p, mode);
}

void launch_fn_merged_s2_float(GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3, GM_ADDR ws,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3, int64_t numTensors, float p, int32_t mode, void* stream)
{
    fn_merged_s2<float><<<numTensors, nullptr, stream>>>(y0, y1, y2, y3, ws, b0, b1, b2, b3, p, mode);
}

void launch_fn_merged_s2_half(GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3, GM_ADDR ws,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3, int64_t numTensors, float p, int32_t mode, void* stream)
{
    fn_merged_s2<half><<<numTensors, nullptr, stream>>>(y0, y1, y2, y3, ws, b0, b1, b2, b3, p, mode);
}

void launch_fn_merged_s2_bfloat16(GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3, GM_ADDR ws,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3, int64_t numTensors, float p, int32_t mode, void* stream)
{
    fn_merged_s2<bfloat16_t><<<numTensors, nullptr, stream>>>(y0, y1, y2, y3, ws, b0, b1, b2, b3, p, mode);
}

}
