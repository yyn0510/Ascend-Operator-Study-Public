/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_plugin.cpp
 * \brief ForeachNorm API layer - torch bindings (compiled with g++)
 */

#include <cmath>
#include <cstdint>
#include <tuple>
#include <vector>
#include <c10/core/DeviceGuard.h>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"
#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

constexpr int32_t FN_MODE_SUM = 0;
constexpr int32_t FN_MODE_MAX = 1;
constexpr int32_t FN_MODE_MIN = 2;

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<torch::Tensor> foreach_norm_meta(c10::ArrayRef<torch::Tensor> x, double scalar)
{
    std::vector<torch::Tensor> y;
    y.reserve(x.size());
    for (const auto& t : x) {
        y.push_back(torch::empty({}, t.options()));
    }
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

std::vector<torch::Tensor> foreach_norm_npu(c10::ArrayRef<torch::Tensor> x, double scalar)
{
    std::vector<torch::Tensor> y;
    y.reserve(x.size());
    for (const auto& t : x) {
        y.push_back(torch::empty({}, t.options()));
    }
    if (x.empty()) {
        return y;
    }

    const c10::OptionalDeviceGuard guard(x[0].device());
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    float p = static_cast<float>(scalar);
    int32_t mode = FN_MODE_SUM;
    if (std::isinf(p)) {
        mode = (p > 0.0f) ? FN_MODE_MAX : FN_MODE_MIN;
    }

    const size_t n = x.size();
    std::vector<int64_t> nbv(n, 1);
    std::vector<int64_t> lenv(n, 0);
    std::vector<uint32_t> tsv(n, 512);
    std::vector<GM_ADDR> xpv(n, nullptr);
    std::vector<GM_ADDR> ypv(n, nullptr);
    int64_t totalBlocks = 0;
    int32_t dtypeCode = -1;

    for (size_t i = 0; i < n; ++i) {
        int64_t len = x[i].numel();
        lenv[i] = len;
        int64_t a = 1;
        int64_t b = 1;
        int64_t c = 512;
        std::tie(a, b, c) = calc_foreach_norm_tiling_params(len);
        nbv[i] = a;
        tsv[i] = static_cast<uint32_t>(c);
        totalBlocks += a;
        xpv[i] = (GM_ADDR)x[i].data_ptr();
        ypv[i] = (GM_ADDR)y[i].data_ptr();
        int32_t dc = -1;
        if (x[i].scalar_type() == torch::kFloat32) {
            dc = 0;
        } else if (x[i].scalar_type() == torch::kFloat16) {
            dc = 1;
        } else if (x[i].scalar_type() == torch::kBFloat16) {
            dc = 2;
        }
        TORCH_CHECK(dc >= 0, "ForeachNorm only supports float32/float16/bfloat16 inputs");
        if (dtypeCode < 0) {
            dtypeCode = dc;
        } else {
            TORCH_CHECK(dtypeCode == dc, "ForeachNorm requires a uniform dtype across the list");
        }
    }
    if (totalBlocks < 1) {
        totalBlocks = 1;
    }

    auto ws = torch::empty({totalBlocks}, x[0].options().dtype(torch::kFloat32));
    GM_ADDR wsBase = (GM_ADDR)ws.data_ptr();
    const uint32_t tileSize = tsv[0];
    const int64_t numTensors = static_cast<int64_t>(n);

    if (n >= 2 && n <= 4) {
        GM_ADDR x0 = xpv[0];
        GM_ADDR x1 = (n > 1) ? xpv[1] : nullptr;
        GM_ADDR x2 = (n > 2) ? xpv[2] : nullptr;
        GM_ADDR x3 = (n > 3) ? xpv[3] : nullptr;
        GM_ADDR y0 = ypv[0];
        GM_ADDR y1 = (n > 1) ? ypv[1] : nullptr;
        GM_ADDR y2 = (n > 2) ? ypv[2] : nullptr;
        GM_ADDR y3 = (n > 3) ? ypv[3] : nullptr;
        int64_t l0 = lenv[0];
        int64_t l1 = (n > 1) ? lenv[1] : 0;
        int64_t l2 = (n > 2) ? lenv[2] : 0;
        int64_t l3 = (n > 3) ? lenv[3] : 0;
        int64_t b0 = nbv[0];
        int64_t b1 = (n > 1) ? nbv[1] : 0;
        int64_t b2 = (n > 2) ? nbv[2] : 0;
        int64_t b3 = (n > 3) ? nbv[3] : 0;

        auto acl_call = [=]() -> int {
            if (dtypeCode == 0) {
                launch_fn_merged_s1_float(x0, x1, x2, x3, wsBase, l0, l1, l2, l3, b0, b1, b2, b3, totalBlocks, tileSize, p, mode, stream);
                launch_fn_merged_s2_float(y0, y1, y2, y3, wsBase, b0, b1, b2, b3, numTensors, p, mode, stream);
            } else if (dtypeCode == 1) {
                launch_fn_merged_s1_half(x0, x1, x2, x3, wsBase, l0, l1, l2, l3, b0, b1, b2, b3, totalBlocks, tileSize, p, mode, stream);
                launch_fn_merged_s2_half(y0, y1, y2, y3, wsBase, b0, b1, b2, b3, numTensors, p, mode, stream);
            } else {
                launch_fn_merged_s1_bfloat16(x0, x1, x2, x3, wsBase, l0, l1, l2, l3, b0, b1, b2, b3, totalBlocks, tileSize, p, mode, stream);
                launch_fn_merged_s2_bfloat16(y0, y1, y2, y3, wsBase, b0, b1, b2, b3, numTensors, p, mode, stream);
            }
            return 0;
        };
        at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
        return y;
    }

    std::vector<int64_t> nbCopy = nbv;
    std::vector<int64_t> lenCopy = lenv;
    std::vector<GM_ADDR> xpCopy = xpv;
    std::vector<GM_ADDR> ypCopy = ypv;
    const int32_t dcCopy = dtypeCode;

    auto acl_call = [=]() -> int {
        int64_t off = 0;
        for (size_t i = 0; i < n; ++i) {
            GM_ADDR w = (GM_ADDR)((float*)wsBase + off);
            if (dcCopy == 0) {
                launch_fn_direct_s1_float(xpCopy[i], w, lenCopy[i], nbCopy[i], tileSize, p, mode, stream);
            } else if (dcCopy == 1) {
                launch_fn_direct_s1_half(xpCopy[i], w, lenCopy[i], nbCopy[i], tileSize, p, mode, stream);
            } else {
                launch_fn_direct_s1_bfloat16(xpCopy[i], w, lenCopy[i], nbCopy[i], tileSize, p, mode, stream);
            }
            off += nbCopy[i];
        }
        off = 0;
        for (size_t i = 0; i < n; ++i) {
            GM_ADDR w = (GM_ADDR)((float*)wsBase + off);
            if (dcCopy == 0) {
                launch_fn_direct_s2_float(w, ypCopy[i], nbCopy[i], p, mode, stream);
            } else if (dcCopy == 1) {
                launch_fn_direct_s2_half(w, ypCopy[i], nbCopy[i], p, mode, stream);
            } else {
                launch_fn_direct_s2_bfloat16(w, ypCopy[i], nbCopy[i], p, mode, stream);
            }
            off += nbCopy[i];
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

} // namespace cann_bench
