/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_launch.h
 * \brief Launch function declarations for g++
 */

#ifndef FOREACH_NORM_LAUNCH_H
#define FOREACH_NORM_LAUNCH_H

#include <cstdint>
#include <tuple>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

std::tuple<int64_t, int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength);

extern "C" {

void launch_fn_direct_s1_float(GM_ADDR x, GM_ADDR ws, int64_t len, int64_t nb, uint32_t tileSize, float p, int32_t mode, void* stream);
void launch_fn_direct_s1_half(GM_ADDR x, GM_ADDR ws, int64_t len, int64_t nb, uint32_t tileSize, float p, int32_t mode, void* stream);
void launch_fn_direct_s1_bfloat16(GM_ADDR x, GM_ADDR ws, int64_t len, int64_t nb, uint32_t tileSize, float p, int32_t mode, void* stream);

void launch_fn_direct_s2_float(GM_ADDR ws, GM_ADDR y, int64_t nb, float p, int32_t mode, void* stream);
void launch_fn_direct_s2_half(GM_ADDR ws, GM_ADDR y, int64_t nb, float p, int32_t mode, void* stream);
void launch_fn_direct_s2_bfloat16(GM_ADDR ws, GM_ADDR y, int64_t nb, float p, int32_t mode, void* stream);

void launch_fn_merged_s1_float(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR ws,
    int64_t l0, int64_t l1, int64_t l2, int64_t l3,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3,
    int64_t totalBlocks, uint32_t tileSize, float p, int32_t mode, void* stream);
void launch_fn_merged_s1_half(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR ws,
    int64_t l0, int64_t l1, int64_t l2, int64_t l3,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3,
    int64_t totalBlocks, uint32_t tileSize, float p, int32_t mode, void* stream);
void launch_fn_merged_s1_bfloat16(GM_ADDR x0, GM_ADDR x1, GM_ADDR x2, GM_ADDR x3, GM_ADDR ws,
    int64_t l0, int64_t l1, int64_t l2, int64_t l3,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3,
    int64_t totalBlocks, uint32_t tileSize, float p, int32_t mode, void* stream);

void launch_fn_merged_s2_float(GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3, GM_ADDR ws,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3, int64_t numTensors, float p, int32_t mode, void* stream);
void launch_fn_merged_s2_half(GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3, GM_ADDR ws,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3, int64_t numTensors, float p, int32_t mode, void* stream);
void launch_fn_merged_s2_bfloat16(GM_ADDR y0, GM_ADDR y1, GM_ADDR y2, GM_ADDR y3, GM_ADDR ws,
    int64_t b0, int64_t b1, int64_t b2, int64_t b3, int64_t numTensors, float p, int32_t mode, void* stream);

}

#endif // FOREACH_NORM_LAUNCH_H
