/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

using namespace AscendC;

constexpr int32_t QUEUE_DEPTH = 1;

template <typename T>
__global__ __aicore__ void swi_glu_kernel(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOut, int64_t blockLen,
    int64_t blockLength, uint32_t tileSize)
{
    TPipe pipe;
    TQue<QuePosition::VECIN, QUEUE_DEPTH> inQueueX;
    TQue<QuePosition::VECIN, QUEUE_DEPTH> inQueueY;
    TQue<QuePosition::VECOUT, QUEUE_DEPTH> outQueueZ;

    uint32_t tileElems = tileSize / sizeof(T);
    if (tileElems == 0) {
        tileElems = 1;
    }
    uint32_t bufSize = static_cast<uint32_t>(tileElems * sizeof(T));

    pipe.InitBuffer(inQueueX, QUEUE_DEPTH, bufSize);
    pipe.InitBuffer(inQueueY, QUEUE_DEPTH, bufSize);
    pipe.InitBuffer(outQueueZ, QUEUE_DEPTH, bufSize);

    TBuf<TPosition::VECCALC> x0FpBuf;
    TBuf<TPosition::VECCALC> x1FpBuf;
    TBuf<TPosition::VECCALC> siluFpBuf;
    TBuf<TPosition::VECCALC> outFpBuf;
    pipe.InitBuffer(x0FpBuf, static_cast<uint32_t>(tileElems * sizeof(float)));
    pipe.InitBuffer(x1FpBuf, static_cast<uint32_t>(tileElems * sizeof(float)));
    pipe.InitBuffer(siluFpBuf, static_cast<uint32_t>(tileElems * sizeof(float)));
    pipe.InitBuffer(outFpBuf, static_cast<uint32_t>(tileElems * sizeof(float)));

    LocalTensor<float> x0Fp = x0FpBuf.Get<float>();
    LocalTensor<float> x1Fp = x1FpBuf.Get<float>();
    LocalTensor<float> siluFp = siluFpBuf.Get<float>();
    LocalTensor<float> outFp = outFpBuf.Get<float>();

    GlobalTensor<T> inputGm;
    GlobalTensor<T> outputGm;
    inputGm.SetGlobalBuffer((__gm__ T *)input);
    outputGm.SetGlobalBuffer((__gm__ T *)output);

    int64_t start = blockLength * static_cast<int64_t>(GetBlockIdx());
    int64_t end = start + blockLength;
    if (end > totalOut) {
        end = totalOut;
    }
    if (start >= totalOut || start >= end) {
        return;
    }

    int64_t pos = start;
    while (pos < end) {
        int64_t p = pos / blockLen;
        int64_t r = pos % blockLen;
        int64_t segLen = blockLen - r;
        if (segLen > end - pos) {
            segLen = end - pos;
        }

        int64_t inBase = p * 2 * blockLen + r;
        int64_t outBase = pos;
        int64_t done = 0;

        while (done < segLen) {
            int64_t len64 = segLen - done;
            if (len64 > static_cast<int64_t>(tileElems)) {
                len64 = static_cast<int64_t>(tileElems);
            }
            uint32_t len = static_cast<uint32_t>(len64);
            int64_t inOff = inBase + done;
            int64_t outOff = outBase + done;

            DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
            DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

            auto x0Local = inQueueX.AllocTensor<T>();
            auto x1Local = inQueueY.AllocTensor<T>();
            DataCopyPad(x0Local, inputGm[inOff], copyParams, padParams);
            DataCopyPad(x1Local, inputGm[inOff + blockLen], copyParams, padParams);
            inQueueX.EnQue(x0Local);
            inQueueY.EnQue(x1Local);

            x0Local = inQueueX.DeQue<T>();
            x1Local = inQueueY.DeQue<T>();

            auto outLocal = outQueueZ.AllocTensor<T>();

            if constexpr (std::is_same<T, float>::value) {
                Sigmoid(outFp, x0Local, len);
                Mul(siluFp, x0Local, outFp, len);
                Mul(outLocal, siluFp, x1Local, len);
            } else {
                Cast(x0Fp, x0Local, RoundMode::CAST_NONE, len);
                Cast(x1Fp, x1Local, RoundMode::CAST_NONE, len);
                Sigmoid(outFp, x0Fp, len);
                Mul(siluFp, x0Fp, outFp, len);
                Mul(outFp, siluFp, x1Fp, len);
                Cast(outLocal, outFp, RoundMode::CAST_ROUND, len);
            }

            outQueueZ.EnQue(outLocal);
            inQueueX.FreeTensor(x0Local);
            inQueueY.FreeTensor(x1Local);

            outLocal = outQueueZ.DeQue<T>();
            DataCopyPad(outputGm[outOff], outLocal, copyParams);
            outQueueZ.FreeTensor(outLocal);

            done += len64;
        }

        pos += segLen;
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_swi_glu_tiling_params(
    int64_t totalOut, int64_t blockLen, int64_t typeSize)
{
    (void)blockLen;

    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 192 * 1024;
    }

    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t bytesPerElem = 3 * typeSize + 16;
    int64_t tileElems = static_cast<int64_t>(ubSize) / bytesPerElem;
    tileElems = tileElems * 9 / 10;
    if (tileElems < 8) {
        tileElems = 8;
    }
    if (tileElems > 65536) {
        tileElems = 65536;
    }

    int64_t tileSize = tileElems * typeSize;
    int64_t minElemsPerCore = tileElems * 4;
    if (minElemsPerCore <= 0) {
        minElemsPerCore = 1;
    }

    int64_t maxUsefulCores = (totalOut + minElemsPerCore - 1) / minElemsPerCore;
    int64_t numBlocks = std::min(coreNum, maxUsefulCores);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalOut + numBlocks - 1) / numBlocks;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_swi_glu_kernel_float(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOut, int64_t blockLen,
    int64_t numBlocks, int64_t blockLength,
    uint32_t tileSize, void* stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, blockLen, blockLength, tileSize);
}

void launch_swi_glu_kernel_half(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOut, int64_t blockLen,
    int64_t numBlocks, int64_t blockLength,
    uint32_t tileSize, void* stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, blockLen, blockLength, tileSize);
}

void launch_swi_glu_kernel_bfloat16(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOut, int64_t blockLen,
    int64_t numBlocks, int64_t blockLength,
    uint32_t tileSize, void* stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, blockLen, blockLength, tileSize);
}

}
