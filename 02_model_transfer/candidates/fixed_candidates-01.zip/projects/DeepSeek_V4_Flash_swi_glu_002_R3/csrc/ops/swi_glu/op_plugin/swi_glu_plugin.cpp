/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    int64_t rank = input.dim();
    int64_t normDim = dim < 0 ? dim + rank : dim;
    TORCH_CHECK(normDim >= 0 && normDim < rank, "swi_glu: dim out of range");
    TORCH_CHECK(input.scalar_type() == torch::kFloat16 ||
                input.scalar_type() == torch::kFloat32 ||
                input.scalar_type() == torch::kBFloat16,
                "swi_glu: unsupported dtype");
    TORCH_CHECK(input.size(normDim) % 2 == 0, "swi_glu: split dim size must be even");

    auto outputSizes = input.sizes().vec();
    outputSizes[normDim] /= 2;
    return torch::empty(outputSizes, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto inputContig = input.contiguous();
    auto output = swi_glu_meta(inputContig, dim);
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t rank = inputContig.dim();
    int64_t normDim = dim < 0 ? dim + rank : dim;
    auto sizes = inputContig.sizes();
    int64_t splitSize = sizes[normDim] / 2;
    int64_t inner = 1;
    for (int64_t i = normDim + 1; i < rank; ++i) {
        inner *= sizes[i];
    }

    int64_t blockLen = splitSize * inner;
    int64_t totalOut = output.numel();
    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    int64_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) =
        calc_swi_glu_tiling_params(totalOut, blockLen, inputContig.element_size());

    auto inputPtr = (GM_ADDR)inputContig.data_ptr();
    auto outputPtr = (GM_ADDR)output.data_ptr();

    auto acl_call = [=]() -> int {
        if (inputContig.scalar_type() == torch::kFloat32) {
            launch_swi_glu_kernel_float(
                inputPtr, outputPtr, totalOut, blockLen,
                numBlocks, blockLength, static_cast<uint32_t>(tileSize), stream);
        } else if (inputContig.scalar_type() == torch::kFloat16) {
            launch_swi_glu_kernel_half(
                inputPtr, outputPtr, totalOut, blockLen,
                numBlocks, blockLength, static_cast<uint32_t>(tileSize), stream);
        } else if (inputContig.scalar_type() == torch::kBFloat16) {
            launch_swi_glu_kernel_bfloat16(
                inputPtr, outputPtr, totalOut, blockLen,
                numBlocks, blockLength, static_cast<uint32_t>(tileSize), stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return output;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
