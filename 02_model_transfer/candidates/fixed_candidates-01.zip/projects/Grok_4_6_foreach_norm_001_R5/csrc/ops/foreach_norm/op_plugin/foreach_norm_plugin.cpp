/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <cmath>
#include <vector>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

namespace {
int32_t GetForeachNormMode(double scalar)
{
    if (std::isinf(scalar)) {
        return (scalar > 0.0) ? 3 : 4;
    }
    float p = static_cast<float>(scalar);
    if (p == 0.0f) {
        return 0;
    }
    if (p == 1.0f) {
        return 1;
    }
    if (p == 2.0f) {
        return 2;
    }
    return 5;
}
} // namespace

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<torch::Tensor> foreach_norm_meta(at::TensorList x, double scalar)
{
    TORCH_CHECK(x.size() >= 1 && x.size() <= 64, "foreach_norm: TensorList length must be in [1, 64].");
    auto dtype = x[0].scalar_type();
    TORCH_CHECK(dtype == torch::kFloat32 || dtype == torch::kFloat16 || dtype == torch::kBFloat16,
                "foreach_norm: unsupported dtype.");
    std::vector<torch::Tensor> y;
    y.reserve(x.size());
    for (const auto &t : x) {
        TORCH_CHECK(t.scalar_type() == dtype, "foreach_norm: all tensors must have the same dtype.");
        y.push_back(torch::empty({}, t.options()));
    }
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

std::vector<torch::Tensor> foreach_norm_npu(at::TensorList x, double scalar)
{
    TORCH_CHECK(x.size() >= 1, "foreach_norm: x must not be empty.");
    const c10::OptionalDeviceGuard guard(x[0].device());
    auto y = foreach_norm_meta(x, scalar);

    std::vector<torch::Tensor> inputs;
    inputs.reserve(x.size());
    for (const auto &t : x) {
        inputs.push_back(t.is_contiguous() ? t : t.contiguous());
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    float p = static_cast<float>(scalar);
    int32_t mode = GetForeachNormMode(scalar);
    auto workspace = torch::empty({2048}, inputs[0].options().dtype(torch::kFloat32));
    auto ws_ptr = (GM_ADDR)workspace.data_ptr();

    auto acl_call = [=]() -> int {
        for (size_t i = 0; i < inputs.size(); ++i) {
            int64_t totalLength = inputs[i].numel();
            int64_t numBlocks = 1;
            int64_t blockLength = totalLength;
            int64_t tileElems = 1024;
            std::tie(numBlocks, blockLength, tileElems) = calc_foreach_norm_tiling_params(totalLength);
            auto x_ptr = (GM_ADDR)inputs[i].data_ptr();
            auto y_ptr = (GM_ADDR)y[i].data_ptr();
            auto dtype = inputs[i].scalar_type();
            uint32_t tile = static_cast<uint32_t>(tileElems);
            if (dtype == torch::kFloat32) {
                launch_foreach_norm_kernel_float(x_ptr, y_ptr, ws_ptr, totalLength, numBlocks, blockLength, tile, p,
                                                 mode, stream);
            } else if (dtype == torch::kFloat16) {
                launch_foreach_norm_kernel_half(x_ptr, y_ptr, ws_ptr, totalLength, numBlocks, blockLength, tile, p,
                                                mode, stream);
            } else if (dtype == torch::kBFloat16) {
                launch_foreach_norm_kernel_bf16(x_ptr, y_ptr, ws_ptr, totalLength, numBlocks, blockLength, tile, p,
                                                mode, stream);
            }
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

} // namespace cann_bench
