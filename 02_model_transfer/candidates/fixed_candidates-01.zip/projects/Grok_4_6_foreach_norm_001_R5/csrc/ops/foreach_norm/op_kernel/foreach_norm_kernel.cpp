/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr int32_t PIPELINE_DEPTH = 2;
constexpr int32_t WS_PER_CORE = 8;
constexpr int32_t MAX_CORES = 64;
constexpr int32_t TILE_ELEMS = 1024;
constexpr int32_t NORM_L0 = 0;
constexpr int32_t NORM_L1 = 1;
constexpr int32_t NORM_L2 = 2;
constexpr int32_t NORM_INF = 3;
constexpr int32_t NORM_NEG_INF = 4;
constexpr int32_t NORM_GENERAL = 5;
constexpr float POS_MAX = 3.402823466e+38f;

template <typename T>
class ForeachNormPartial {
public:
    __aicore__ inline ForeachNormPartial() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR workspace, int64_t totalLength, int64_t blockLength,
                                uint32_t tileElems, float p, int32_t mode)
    {
        blockIdx_ = AscendC::GetBlockIdx();
        tileElems_ = TILE_ELEMS;
        p_ = p;
        mode_ = mode;

        int64_t current = totalLength - blockIdx_ * blockLength;
        if (current > blockLength) {
            current = blockLength;
        }
        if (current < 0) {
            current = 0;
        }
        currentBlockLength_ = current;

        if (currentBlockLength_ > 0) {
            xGm_.SetGlobalBuffer((__gm__ T *)x + blockIdx_ * blockLength, currentBlockLength_);
        }
        wsGm_.SetGlobalBuffer((__gm__ float *)workspace + blockIdx_ * WS_PER_CORE, WS_PER_CORE);

        uint32_t inBytes = static_cast<uint32_t>(tileElems_) * static_cast<uint32_t>(sizeof(T));
        uint32_t calcBytes = static_cast<uint32_t>(tileElems_) * static_cast<uint32_t>(sizeof(float));
        pipe_.InitBuffer(inQueue_, PIPELINE_DEPTH, inBytes);
        pipe_.InitBuffer(outQueue_, 1, 32);
        pipe_.InitBuffer(fp32Buf_, calcBytes);
        pipe_.InitBuffer(workBuf_, calcBytes);
        pipe_.InitBuffer(accBuf_, 32);

        fp32Local_ = fp32Buf_.Get<float>();
        workLocal_ = workBuf_.Get<float>();
        accLocal_ = accBuf_.Get<float>();
    }

    __aicore__ inline void Process()
    {
        float initVal = (mode_ == NORM_NEG_INF) ? POS_MAX : 0.0f;
        AscendC::Duplicate(accLocal_, initVal, 8);
        if (currentBlockLength_ <= 0) {
            CopyOut();
            return;
        }

        int64_t tileNum = currentBlockLength_ / static_cast<int64_t>(tileElems_);
        int64_t tail = currentBlockLength_ - tileNum * static_cast<int64_t>(tileElems_);

        for (int64_t i = 0; i < tileNum; ++i) {
            int64_t offset = i * static_cast<int64_t>(tileElems_);
            CopyIn(offset, tileElems_);
            ComputeTile(tileElems_);
        }
        if (tail > 0) {
            int64_t offset = tileNum * static_cast<int64_t>(tileElems_);
            CopyIn(offset, tail);
            ComputeTile(static_cast<int32_t>(tail));
        }
        CopyOut();
    }

private:
    __aicore__ inline void CopyIn(int64_t offset, int64_t count)
    {
        AscendC::LocalTensor<T> xLocal = inQueue_.AllocTensor<T>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{true, 0, 0, 0};
        AscendC::DataCopyPad(xLocal, xGm_[offset], copyParams, padParams);
        inQueue_.EnQue(xLocal);
    }

    __aicore__ inline void ComputeTile(int32_t n)
    {
        AscendC::LocalTensor<T> xLocal = inQueue_.DeQue<T>();
        int32_t nAlign = ((n + 7) / 8) * 8;
        if (nAlign > tileElems_) {
            nAlign = tileElems_;
        }
        if (n < tileElems_) {
            float fillVal = (mode_ == NORM_NEG_INF) ? POS_MAX : 0.0f;
            AscendC::Duplicate(fp32Local_, fillVal, tileElems_);
        }
        if constexpr (sizeof(T) == sizeof(float)) {
            AscendC::Adds(fp32Local_, xLocal, 0.0f, nAlign);
        } else {
            AscendC::Cast(fp32Local_, xLocal, AscendC::RoundMode::CAST_NONE, nAlign);
        }
        inQueue_.FreeTensor(xLocal);

        Elementwise(nAlign);
        if (n < nAlign && (mode_ == NORM_NEG_INF || p_ < 0.0f)) {
            float idVal = (mode_ == NORM_NEG_INF) ? POS_MAX : 0.0f;
            AscendC::SetFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
            for (int32_t i = n; i < nAlign; ++i) {
                fp32Local_.SetValue(i, idVal);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_V>(EVENT_ID0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(EVENT_ID0);
        }
        ReduceAligned(nAlign);
    }

    __aicore__ inline void Elementwise(int32_t n)
    {
        if (mode_ == NORM_L0) {
            AscendC::Sign(fp32Local_, fp32Local_, n);
            AscendC::Abs(fp32Local_, fp32Local_, n);
        } else if (mode_ == NORM_L1) {
            AscendC::Abs(fp32Local_, fp32Local_, n);
        } else if (mode_ == NORM_L2) {
            AscendC::Mul(fp32Local_, fp32Local_, fp32Local_, n);
        } else if (mode_ == NORM_INF || mode_ == NORM_NEG_INF) {
            AscendC::Abs(fp32Local_, fp32Local_, n);
        } else if (p_ == 1.5f) {
            AscendC::Abs(fp32Local_, fp32Local_, n);
            AscendC::Sqrt(workLocal_, fp32Local_, n);
            AscendC::Mul(fp32Local_, fp32Local_, workLocal_, n);
        } else if (p_ == 2.5f) {
            AscendC::Abs(fp32Local_, fp32Local_, n);
            AscendC::Mul(workLocal_, fp32Local_, fp32Local_, n);
            AscendC::Sqrt(fp32Local_, fp32Local_, n);
            AscendC::Mul(fp32Local_, workLocal_, fp32Local_, n);
        } else if (p_ == 3.0f) {
            AscendC::Abs(fp32Local_, fp32Local_, n);
            AscendC::Mul(workLocal_, fp32Local_, fp32Local_, n);
            AscendC::Mul(fp32Local_, workLocal_, fp32Local_, n);
        } else if (p_ == 4.0f) {
            AscendC::Mul(fp32Local_, fp32Local_, fp32Local_, n);
            AscendC::Mul(fp32Local_, fp32Local_, fp32Local_, n);
        } else if (p_ == 5.0f) {
            AscendC::Abs(fp32Local_, fp32Local_, n);
            AscendC::Mul(workLocal_, fp32Local_, fp32Local_, n);
            AscendC::Mul(workLocal_, workLocal_, workLocal_, n);
            AscendC::Mul(fp32Local_, workLocal_, fp32Local_, n);
        } else if (p_ == -1.0f) {
            AscendC::Abs(fp32Local_, fp32Local_, n);
            AscendC::Duplicate(workLocal_, 1.0f, n);
            AscendC::Div(fp32Local_, workLocal_, fp32Local_, n);
        } else {
            AscendC::Abs(fp32Local_, fp32Local_, n);
            AscendC::Ln(fp32Local_, fp32Local_, n);
            AscendC::Muls(fp32Local_, fp32Local_, p_, n);
            AscendC::Exp(fp32Local_, fp32Local_, n);
        }
    }

    __aicore__ inline void ReduceAligned(int32_t nAlign)
    {
        if (mode_ == NORM_INF) {
            for (int32_t i = 0; i < nAlign; i += 8) {
                AscendC::Max(accLocal_, accLocal_, fp32Local_[i], 8);
            }
        } else if (mode_ == NORM_NEG_INF) {
            for (int32_t i = 0; i < nAlign; i += 8) {
                AscendC::Min(accLocal_, accLocal_, fp32Local_[i], 8);
            }
        } else {
            for (int32_t i = 0; i < nAlign; i += 8) {
                AscendC::Add(accLocal_, accLocal_, fp32Local_[i], 8);
            }
        }
    }

    __aicore__ inline void CopyOut()
    {
        AscendC::LocalTensor<float> outLocal = outQueue_.AllocTensor<float>();
        AscendC::Adds(outLocal, accLocal_, 0.0f, 8);
        outQueue_.EnQue(outLocal);
        outLocal = outQueue_.DeQue<float>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(WS_PER_CORE * sizeof(float)), 0, 0, 0};
        AscendC::DataCopyPad(wsGm_, outLocal, copyParams);
        outQueue_.FreeTensor(outLocal);
    }

    AscendC::TPipe pipe_;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue_;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> fp32Buf_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBuf_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> accBuf_;
    AscendC::GlobalTensor<T> xGm_;
    AscendC::GlobalTensor<float> wsGm_;
    AscendC::LocalTensor<float> fp32Local_;
    AscendC::LocalTensor<float> workLocal_;
    AscendC::LocalTensor<float> accLocal_;
    int64_t blockIdx_ = 0;
    int64_t currentBlockLength_ = 0;
    int32_t tileElems_ = TILE_ELEMS;
    float p_ = 0.0f;
    int32_t mode_ = 0;
};

template <typename T>
class ForeachNormFinal {
public:
    __aicore__ inline ForeachNormFinal() {}

    __aicore__ inline void Init(GM_ADDR workspace, GM_ADDR y, int64_t numPartials, float p, int32_t mode)
    {
        numPartials_ = numPartials;
        if (numPartials_ < 1) {
            numPartials_ = 1;
        }
        if (numPartials_ > MAX_CORES) {
            numPartials_ = MAX_CORES;
        }
        p_ = p;
        mode_ = mode;
        wsCount_ = static_cast<int32_t>(numPartials_) * WS_PER_CORE;
        wsGm_.SetGlobalBuffer((__gm__ float *)workspace, wsCount_);
        yGm_.SetGlobalBuffer((__gm__ T *)y, 1);

        uint32_t inBytes = static_cast<uint32_t>(MAX_CORES * WS_PER_CORE) * static_cast<uint32_t>(sizeof(float));
        pipe_.InitBuffer(inQueue_, 1, inBytes);
        pipe_.InitBuffer(outQueue_, 1, 32);
        pipe_.InitBuffer(accBuf_, 32);
        pipe_.InitBuffer(tmpBuf_, 32);
        accLocal_ = accBuf_.Get<float>();
        tmpLocal_ = tmpBuf_.Get<float>();
    }

    __aicore__ inline void Process()
    {
        float initVal = (mode_ == NORM_NEG_INF) ? POS_MAX : 0.0f;
        AscendC::LocalTensor<float> src = inQueue_.AllocTensor<float>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(wsCount_ * sizeof(float)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};
        AscendC::DataCopyPad(src, wsGm_, copyParams, padParams);
        inQueue_.EnQue(src);
        src = inQueue_.DeQue<float>();

        AscendC::Duplicate(accLocal_, initVal, 8);
        if (mode_ == NORM_INF) {
            for (int32_t i = 0; i < wsCount_; i += 8) {
                AscendC::Max(accLocal_, accLocal_, src[i], 8);
            }
        } else if (mode_ == NORM_NEG_INF) {
            for (int32_t i = 0; i < wsCount_; i += 8) {
                AscendC::Min(accLocal_, accLocal_, src[i], 8);
            }
        } else {
            for (int32_t i = 0; i < wsCount_; i += 8) {
                AscendC::Add(accLocal_, accLocal_, src[i], 8);
            }
        }
        inQueue_.FreeTensor(src);

        AscendC::SetFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
        AscendC::WaitFlag<AscendC::HardEvent::V_S>(EVENT_ID0);
        float result = accLocal_.GetValue(0);
        if (mode_ == NORM_INF) {
            for (int i = 1; i < 8; ++i) {
                float v = accLocal_.GetValue(i);
                if (v > result) {
                    result = v;
                }
            }
        } else if (mode_ == NORM_NEG_INF) {
            for (int i = 1; i < 8; ++i) {
                float v = accLocal_.GetValue(i);
                if (v < result) {
                    result = v;
                }
            }
        } else {
            for (int i = 1; i < 8; ++i) {
                result += accLocal_.GetValue(i);
            }
            result = ApplyPNorm(result);
        }
        WriteY(result);
    }

private:
    __aicore__ inline float ApplyPNorm(float sum)
    {
        if (mode_ == NORM_L2) {
            AscendC::Duplicate(accLocal_, 0.0f, 8);
            accLocal_.SetValue(0, sum);
            AscendC::SetFlag<AscendC::HardEvent::S_V>(EVENT_ID1);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(EVENT_ID1);
            AscendC::Sqrt(accLocal_, accLocal_, 8);
            AscendC::SetFlag<AscendC::HardEvent::V_S>(EVENT_ID1);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(EVENT_ID1);
            return accLocal_.GetValue(0);
        }
        if (mode_ != NORM_GENERAL) {
            return sum;
        }
        if (sum <= 0.0f) {
            return 0.0f;
        }
        if (p_ == 4.0f) {
            AscendC::Duplicate(accLocal_, 0.0f, 8);
            accLocal_.SetValue(0, sum);
            AscendC::SetFlag<AscendC::HardEvent::S_V>(EVENT_ID1);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(EVENT_ID1);
            AscendC::Sqrt(accLocal_, accLocal_, 8);
            AscendC::Sqrt(accLocal_, accLocal_, 8);
            AscendC::SetFlag<AscendC::HardEvent::V_S>(EVENT_ID1);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(EVENT_ID1);
            return accLocal_.GetValue(0);
        }
        float invP = 1.0f / p_;
        AscendC::Duplicate(accLocal_, 1.0f, 8);
        accLocal_.SetValue(0, sum);
        AscendC::SetFlag<AscendC::HardEvent::S_V>(EVENT_ID1);
        AscendC::WaitFlag<AscendC::HardEvent::S_V>(EVENT_ID1);
        AscendC::Ln(tmpLocal_, accLocal_, 8);
        AscendC::Muls(tmpLocal_, tmpLocal_, invP, 8);
        AscendC::Exp(accLocal_, tmpLocal_, 8);
        AscendC::SetFlag<AscendC::HardEvent::V_S>(EVENT_ID1);
        AscendC::WaitFlag<AscendC::HardEvent::V_S>(EVENT_ID1);
        return accLocal_.GetValue(0);
    }

    __aicore__ inline void WriteY(float result)
    {
        AscendC::Duplicate(accLocal_, 0.0f, 8);
        accLocal_.SetValue(0, result);
        AscendC::SetFlag<AscendC::HardEvent::S_V>(EVENT_ID0);
        AscendC::WaitFlag<AscendC::HardEvent::S_V>(EVENT_ID0);
        AscendC::LocalTensor<T> outLocal = outQueue_.AllocTensor<T>();
        if constexpr (sizeof(T) == sizeof(float)) {
            AscendC::Adds(outLocal, accLocal_, 0.0f, 8);
        } else {
            AscendC::Cast(outLocal, accLocal_, AscendC::RoundMode::CAST_RINT, 8);
        }
        outQueue_.EnQue(outLocal);
        outLocal = outQueue_.DeQue<T>();
        AscendC::DataCopyExtParams outParams{1, static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm_, outLocal, outParams);
        outQueue_.FreeTensor(outLocal);
    }

    AscendC::TPipe pipe_;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue_;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> accBuf_;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf_;
    AscendC::GlobalTensor<float> wsGm_;
    AscendC::GlobalTensor<T> yGm_;
    AscendC::LocalTensor<float> accLocal_;
    AscendC::LocalTensor<float> tmpLocal_;
    int64_t numPartials_ = 0;
    int32_t wsCount_ = 8;
    float p_ = 0.0f;
    int32_t mode_ = 0;
};

template <typename T>
__global__ __aicore__ void foreach_norm_partial_kernel(GM_ADDR x, GM_ADDR workspace, int64_t totalLength,
                                                       int64_t blockLength, uint32_t tileElems, float p, int32_t mode)
{
    ForeachNormPartial<T> op;
    op.Init(x, workspace, totalLength, blockLength, tileElems, p, mode);
    op.Process();
}

template <typename T>
__global__ __aicore__ void foreach_norm_final_kernel(GM_ADDR workspace, GM_ADDR y, int64_t numPartials, float p,
                                                     int32_t mode)
{
    ForeachNormFinal<T> op;
    op.Init(workspace, y, numPartials, p, mode);
    op.Process();
}

std::tuple<int64_t, int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 2048;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (coreNum > MAX_CORES) {
        coreNum = MAX_CORES;
    }
    int64_t tileElems = TILE_ELEMS;
    if (totalLength <= 0) {
        return std::make_tuple(1, 0, tileElems);
    }
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    blockLength = ((blockLength + 7) / 8) * 8;
    if (blockLength < 8) {
        blockLength = 8;
    }
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

extern "C" {

void launch_foreach_norm_kernel_float(GM_ADDR x, GM_ADDR y, GM_ADDR workspace, int64_t totalLength, int64_t numBlocks,
                                      int64_t blockLength, uint32_t tileElems, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<float><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength,
                                                                       tileElems, p, mode);
    foreach_norm_final_kernel<float><<<1, nullptr, stream>>>(workspace, y, numBlocks, p, mode);
}

void launch_foreach_norm_kernel_half(GM_ADDR x, GM_ADDR y, GM_ADDR workspace, int64_t totalLength, int64_t numBlocks,
                                     int64_t blockLength, uint32_t tileElems, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<half><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileElems,
                                                                      p, mode);
    foreach_norm_final_kernel<half><<<1, nullptr, stream>>>(workspace, y, numBlocks, p, mode);
}

void launch_foreach_norm_kernel_bf16(GM_ADDR x, GM_ADDR y, GM_ADDR workspace, int64_t totalLength, int64_t numBlocks,
                                     int64_t blockLength, uint32_t tileElems, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength,
                                                                           tileElems, p, mode);
    foreach_norm_final_kernel<bfloat16_t><<<1, nullptr, stream>>>(workspace, y, numBlocks, p, mode);
}

}
