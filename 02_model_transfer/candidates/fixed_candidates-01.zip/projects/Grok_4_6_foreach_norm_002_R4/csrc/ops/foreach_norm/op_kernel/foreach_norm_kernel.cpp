/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include <cstdint>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

using namespace AscendC;

constexpr int32_t FOREACH_NORM_MODE_L0 = 0;
constexpr int32_t FOREACH_NORM_MODE_L1 = 1;
constexpr int32_t FOREACH_NORM_MODE_L2 = 2;
constexpr int32_t FOREACH_NORM_MODE_INF = 3;
constexpr int32_t FOREACH_NORM_MODE_NEG_INF = 4;
constexpr int32_t FOREACH_NORM_MODE_GENERAL = 5;

constexpr int64_t FOREACH_NORM_WS_STRIDE = 8;
constexpr int64_t FOREACH_NORM_MAX_TILE = 8192;
constexpr int32_t FOREACH_NORM_PIPE_DEPTH = 2;
constexpr float FOREACH_NORM_FMAX = 3.402823466e+38f;

template <typename T>
class ForeachNormPartial {
public:
    __aicore__ inline ForeachNormPartial() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR workspace, int64_t totalLength, int64_t blockLength,
                                uint32_t tileSize, float p, int32_t mode)
    {
        this->p = p;
        this->mode = mode;
        this->blockIdx = GetBlockIdx();

        uint32_t te = tileSize / static_cast<uint32_t>(sizeof(T));
        uint32_t p2 = 256;
        while ((p2 << 1) <= te && (p2 << 1) <= static_cast<uint32_t>(FOREACH_NORM_MAX_TILE)) {
            p2 <<= 1;
        }
        if (p2 < 8) {
            p2 = 8;
        }
        this->tileElems = static_cast<int64_t>(p2);

        int64_t offset = this->blockIdx * blockLength;
        this->currentLen = totalLength - offset;
        if (this->currentLen > blockLength) {
            this->currentLen = blockLength;
        }
        if (this->currentLen < 0 || offset < 0 || offset >= totalLength) {
            this->currentLen = 0;
            offset = 0;
        }

        if (this->currentLen > 0) {
            xGm.SetGlobalBuffer((__gm__ T *)x + offset, this->currentLen);
        } else {
            xGm.SetGlobalBuffer((__gm__ T *)x, 1);
        }
        wsGm.SetGlobalBuffer((__gm__ float *)workspace);

        pipe.InitBuffer(inQueue, FOREACH_NORM_PIPE_DEPTH,
                        static_cast<uint32_t>(this->tileElems * sizeof(T)));
        pipe.InitBuffer(calcBuf, static_cast<uint32_t>(this->tileElems * sizeof(float)));
        pipe.InitBuffer(extraBuf, static_cast<uint32_t>(this->tileElems * sizeof(float)));
        pipe.InitBuffer(accBuf, static_cast<uint32_t>(this->tileElems * sizeof(float)));
        pipe.InitBuffer(outBuf, 32);

        calcLocal = calcBuf.Get<float>();
        extraLocal = extraBuf.Get<float>();
        accLocal = accBuf.Get<float>();
        outLocal = outBuf.Get<float>();
    }

    __aicore__ inline void Process()
    {
        Duplicate(accLocal, IdentityValue(), static_cast<uint32_t>(tileElems));
        PipeBarrier<PIPE_V>();

        if (currentLen > 0) {
            int64_t tileNum = currentLen / tileElems;
            int64_t tail = currentLen - tileNum * tileElems;
            if (tileNum > 0) {
                CopyIn(0, tileElems);
            }
            for (int64_t i = 0; i < tileNum; ++i) {
                if (i + 1 < tileNum) {
                    CopyIn(i + 1, tileElems);
                } else if (tail > 0) {
                    CopyIn(tileNum, tail);
                }
                ComputeMerge(tileElems);
            }
            if (tail > 0) {
                if (tileNum == 0) {
                    CopyIn(0, tail);
                }
                ComputeMerge(tail);
            }
        }

        WritePartial(ReduceAcc());
    }

private:
    __aicore__ inline float IdentityValue()
    {
        return (mode == FOREACH_NORM_MODE_NEG_INF) ? FOREACH_NORM_FMAX : 0.0f;
    }

    __aicore__ inline void CopyIn(int64_t tileIdx, int64_t cnt)
    {
        auto xLocal = inQueue.AllocTensor<T>();
        int64_t offset = tileIdx * tileElems;
        DataCopyExtParams copyParams{1, static_cast<uint32_t>(cnt * sizeof(T)), 0, 0, 0};
        uint32_t alignT = static_cast<uint32_t>(32 / sizeof(T));
        uint32_t rpad = (alignT - (static_cast<uint32_t>(cnt) % alignT)) % alignT;
        DataCopyPadExtParams<T> padParams{rpad > 0, 0, static_cast<uint8_t>(rpad), 0};
        DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
    }

    __aicore__ inline void ComputePow(uint32_t cnt)
    {
        if (p == 3.0f) {
            Mul(extraLocal, calcLocal, calcLocal, cnt);
            Mul(extraLocal, extraLocal, calcLocal, cnt);
        } else if (p == 4.0f) {
            Mul(extraLocal, calcLocal, calcLocal, cnt);
            Mul(extraLocal, extraLocal, extraLocal, cnt);
        } else if (p == 5.0f) {
            Mul(extraLocal, calcLocal, calcLocal, cnt);
            Mul(extraLocal, extraLocal, extraLocal, cnt);
            Mul(extraLocal, extraLocal, calcLocal, cnt);
        } else if (p == 1.5f) {
            Sqrt(extraLocal, calcLocal, cnt);
            Mul(extraLocal, extraLocal, calcLocal, cnt);
        } else if (p == 2.5f) {
            Sqrt(extraLocal, calcLocal, cnt);
            Mul(extraLocal, extraLocal, calcLocal, cnt);
            Mul(extraLocal, extraLocal, calcLocal, cnt);
        } else if (p == -1.0f) {
            Duplicate(extraLocal, 1.0f, cnt);
            PipeBarrier<PIPE_V>();
            Div(extraLocal, extraLocal, calcLocal, cnt);
        } else {
            Ln(extraLocal, calcLocal, cnt);
            Muls(extraLocal, extraLocal, p, cnt);
            Exp(extraLocal, extraLocal, cnt);
        }
    }

    __aicore__ inline void ComputeFeatureSrc(const LocalTensor<float> &src, uint32_t cnt)
    {
        if (mode == FOREACH_NORM_MODE_L0) {
            Abs(extraLocal, src, cnt);
            Sign(extraLocal, extraLocal, cnt);
        } else if (mode == FOREACH_NORM_MODE_L1) {
            Abs(extraLocal, src, cnt);
        } else if (mode == FOREACH_NORM_MODE_L2) {
            Mul(extraLocal, src, src, cnt);
        } else if (mode == FOREACH_NORM_MODE_INF || mode == FOREACH_NORM_MODE_NEG_INF) {
            Abs(extraLocal, src, cnt);
        } else {
            Abs(calcLocal, src, cnt);
            ComputePow(cnt);
        }
    }

    __aicore__ inline uint32_t VecCount(int64_t cnt)
    {
        uint32_t alignT = static_cast<uint32_t>(32 / sizeof(T));
        uint32_t rpad = (alignT - (static_cast<uint32_t>(cnt) % alignT)) % alignT;
        uint32_t vecCnt = static_cast<uint32_t>(cnt) + rpad;
        vecCnt = (vecCnt + 7u) & ~7u;
        if (vecCnt > static_cast<uint32_t>(tileElems)) {
            vecCnt = static_cast<uint32_t>(tileElems);
        }
        if (vecCnt < 8u) {
            vecCnt = 8u;
        }
        return vecCnt;
    }

    __aicore__ inline void ComputeMerge(int64_t cnt)
    {
        auto xLocal = inQueue.DeQue<T>();
        uint32_t vecCnt = VecCount(cnt);
        if constexpr (std::is_same<T, float>::value) {
            ComputeFeatureSrc(xLocal, vecCnt);
        } else {
            Cast(calcLocal, xLocal, RoundMode::CAST_NONE, vecCnt);
            PipeBarrier<PIPE_V>();
            ComputeFeatureSrc(calcLocal, vecCnt);
        }
        inQueue.FreeTensor(xLocal);

        if (vecCnt > static_cast<uint32_t>(cnt)) {
            event_t eventVS = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_S));
            SetFlag<HardEvent::V_S>(eventVS);
            WaitFlag<HardEvent::V_S>(eventVS);
            float padVal = (mode == FOREACH_NORM_MODE_NEG_INF) ? FOREACH_NORM_FMAX : 0.0f;
            for (uint32_t i = static_cast<uint32_t>(cnt); i < vecCnt; ++i) {
                extraLocal.SetValue(i, padVal);
            }
            event_t eventSV = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::S_V));
            SetFlag<HardEvent::S_V>(eventSV);
            WaitFlag<HardEvent::S_V>(eventSV);
        }

        PipeBarrier<PIPE_V>();
        if (mode == FOREACH_NORM_MODE_INF) {
            Max(accLocal, accLocal, extraLocal, vecCnt);
        } else if (mode == FOREACH_NORM_MODE_NEG_INF) {
            Min(accLocal, accLocal, extraLocal, vecCnt);
        } else {
            Add(accLocal, accLocal, extraLocal, vecCnt);
        }
    }

    __aicore__ inline float FoldEight()
    {
        event_t eventVS = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_S));
        SetFlag<HardEvent::V_S>(eventVS);
        WaitFlag<HardEvent::V_S>(eventVS);
        float v0 = accLocal.GetValue(0);
        float v1 = accLocal.GetValue(1);
        float v2 = accLocal.GetValue(2);
        float v3 = accLocal.GetValue(3);
        float v4 = accLocal.GetValue(4);
        float v5 = accLocal.GetValue(5);
        float v6 = accLocal.GetValue(6);
        float v7 = accLocal.GetValue(7);
        if (mode == FOREACH_NORM_MODE_INF) {
            float m = v0;
            if (v1 > m) m = v1;
            if (v2 > m) m = v2;
            if (v3 > m) m = v3;
            if (v4 > m) m = v4;
            if (v5 > m) m = v5;
            if (v6 > m) m = v6;
            if (v7 > m) m = v7;
            return m;
        }
        if (mode == FOREACH_NORM_MODE_NEG_INF) {
            float m = v0;
            if (v1 < m) m = v1;
            if (v2 < m) m = v2;
            if (v3 < m) m = v3;
            if (v4 < m) m = v4;
            if (v5 < m) m = v5;
            if (v6 < m) m = v6;
            if (v7 < m) m = v7;
            return m;
        }
        return v0 + v1 + v2 + v3 + v4 + v5 + v6 + v7;
    }

    __aicore__ inline float ReduceAcc()
    {
        uint32_t n = static_cast<uint32_t>(tileElems);
        PipeBarrier<PIPE_V>();
        while (n > 8) {
            uint32_t n2 = n / 2;
            if (mode == FOREACH_NORM_MODE_INF) {
                Max(extraLocal, accLocal, accLocal[n2], n2);
            } else if (mode == FOREACH_NORM_MODE_NEG_INF) {
                Min(extraLocal, accLocal, accLocal[n2], n2);
            } else {
                Add(extraLocal, accLocal, accLocal[n2], n2);
            }
            PipeBarrier<PIPE_V>();
            Adds(accLocal, extraLocal, 0.0f, n2);
            PipeBarrier<PIPE_V>();
            n = n2;
        }
        return FoldEight();
    }

    __aicore__ inline void WritePartial(float value)
    {
        event_t eventSV = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::S_V));
        SetFlag<HardEvent::S_V>(eventSV);
        WaitFlag<HardEvent::S_V>(eventSV);
        Duplicate(outLocal, value, 8);
        event_t eventVMTE3 = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_MTE3));
        SetFlag<HardEvent::V_MTE3>(eventVMTE3);
        WaitFlag<HardEvent::V_MTE3>(eventVMTE3);
        DataCopyExtParams params{1, static_cast<uint32_t>(8 * sizeof(float)), 0, 0, 0};
        DataCopyPad(wsGm[blockIdx * FOREACH_NORM_WS_STRIDE], outLocal, params);
    }

    TPipe pipe;
    TQue<QuePosition::VECIN, FOREACH_NORM_PIPE_DEPTH> inQueue;
    TBuf<TPosition::VECCALC> calcBuf;
    TBuf<TPosition::VECCALC> extraBuf;
    TBuf<TPosition::VECCALC> accBuf;
    TBuf<TPosition::VECCALC> outBuf;
    GlobalTensor<T> xGm;
    GlobalTensor<float> wsGm;
    LocalTensor<float> calcLocal;
    LocalTensor<float> extraLocal;
    LocalTensor<float> accLocal;
    LocalTensor<float> outLocal;
    int64_t tileElems = 256;
    int64_t currentLen = 0;
    int64_t blockIdx = 0;
    float p = 2.0f;
    int32_t mode = FOREACH_NORM_MODE_L2;
};

template <typename T>
class ForeachNormFinal {
public:
    __aicore__ inline ForeachNormFinal() {}

    __aicore__ inline void Init(GM_ADDR workspace, GM_ADDR y, int64_t numPartials, float p, int32_t mode)
    {
        this->numPartials = numPartials;
        this->p = p;
        this->mode = mode;
        if (this->numPartials < 0) {
            this->numPartials = 0;
        }
        int64_t wsElems = this->numPartials * FOREACH_NORM_WS_STRIDE;
        if (wsElems < 8) {
            wsElems = 8;
        }
        this->alignedWsElems = ((wsElems + 15) / 16) * 16;
        if (this->alignedWsElems < 32) {
            this->alignedWsElems = 32;
        }

        wsGm.SetGlobalBuffer((__gm__ float *)workspace, wsElems);
        yGm.SetGlobalBuffer((__gm__ T *)y, 1);

        pipe.InitBuffer(inBuf, static_cast<uint32_t>(this->alignedWsElems * sizeof(float)));
        pipe.InitBuffer(outBuf, 32);
        pipe.InitBuffer(castBuf, 32);
        inLocal = inBuf.Get<float>();
        outLocal = outBuf.Get<float>();
        castLocal = castBuf.Get<T>();
    }

    __aicore__ inline void Process()
    {
        if (GetBlockIdx() != 0) {
            return;
        }

        float initVal = (mode == FOREACH_NORM_MODE_NEG_INF) ? FOREACH_NORM_FMAX : 0.0f;
        Duplicate(inLocal, initVal, static_cast<uint32_t>(alignedWsElems));
        PipeBarrier<PIPE_V>();
        event_t eventVMTE2 = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_MTE2));
        SetFlag<HardEvent::V_MTE2>(eventVMTE2);
        WaitFlag<HardEvent::V_MTE2>(eventVMTE2);

        if (numPartials > 0) {
            DataCopyExtParams copyParams{
                1, static_cast<uint32_t>(numPartials * FOREACH_NORM_WS_STRIDE * sizeof(float)), 0, 0, 0};
            DataCopyPadExtParams<float> padParams{true, 0, 0, 0};
            DataCopyPad(inLocal, wsGm, copyParams, padParams);
            event_t eventMTE2S = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::MTE2_S));
            SetFlag<HardEvent::MTE2_S>(eventMTE2S);
            WaitFlag<HardEvent::MTE2_S>(eventMTE2S);
        }

        float result = initVal;
        if (mode == FOREACH_NORM_MODE_INF) {
            result = 0.0f;
            for (int64_t i = 0; i < numPartials; ++i) {
                float v = inLocal.GetValue(i * FOREACH_NORM_WS_STRIDE);
                if (v > result) {
                    result = v;
                }
            }
        } else if (mode == FOREACH_NORM_MODE_NEG_INF) {
            result = FOREACH_NORM_FMAX;
            for (int64_t i = 0; i < numPartials; ++i) {
                float v = inLocal.GetValue(i * FOREACH_NORM_WS_STRIDE);
                if (v < result) {
                    result = v;
                }
            }
        } else {
            result = 0.0f;
            for (int64_t i = 0; i < numPartials; ++i) {
                result += inLocal.GetValue(i * FOREACH_NORM_WS_STRIDE);
            }
        }

        event_t eventSV = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::S_V));
        SetFlag<HardEvent::S_V>(eventSV);
        WaitFlag<HardEvent::S_V>(eventSV);
        Duplicate(outLocal, result, 8);
        PipeBarrier<PIPE_V>();
        if (mode == FOREACH_NORM_MODE_L2) {
            Sqrt(outLocal, outLocal, 8);
        } else if (mode == FOREACH_NORM_MODE_GENERAL) {
            if (result > 0.0f) {
                Ln(outLocal, outLocal, 8);
                Muls(outLocal, outLocal, 1.0f / p, 8);
                Exp(outLocal, outLocal, 8);
            }
        }
        PipeBarrier<PIPE_V>();

        if constexpr (std::is_same<T, float>::value) {
            event_t eventVMTE3 = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_MTE3));
            SetFlag<HardEvent::V_MTE3>(eventVMTE3);
            WaitFlag<HardEvent::V_MTE3>(eventVMTE3);
            DataCopyExtParams outParams{1, static_cast<uint32_t>(sizeof(float)), 0, 0, 0};
            DataCopyPad(yGm, outLocal, outParams);
        } else {
            Cast(castLocal, outLocal, RoundMode::CAST_RINT, 8);
            event_t eventVMTE3 = static_cast<event_t>(GetTPipePtr()->FetchEventID(HardEvent::V_MTE3));
            SetFlag<HardEvent::V_MTE3>(eventVMTE3);
            WaitFlag<HardEvent::V_MTE3>(eventVMTE3);
            DataCopyExtParams outParams{1, static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
            DataCopyPad(yGm, castLocal, outParams);
        }
    }

private:
    TPipe pipe;
    TBuf<TPosition::VECCALC> inBuf;
    TBuf<TPosition::VECCALC> outBuf;
    TBuf<TPosition::VECCALC> castBuf;
    GlobalTensor<float> wsGm;
    GlobalTensor<T> yGm;
    LocalTensor<float> inLocal;
    LocalTensor<float> outLocal;
    LocalTensor<T> castLocal;
    int64_t numPartials = 0;
    int64_t alignedWsElems = 32;
    float p = 2.0f;
    int32_t mode = FOREACH_NORM_MODE_L2;
};

template <typename T>
__global__ __aicore__ void foreach_norm_partial_kernel(GM_ADDR x, GM_ADDR workspace, int64_t totalLength,
                                                       int64_t blockLength, uint32_t tileSize, float p, int32_t mode)
{
    ForeachNormPartial<T> op;
    op.Init(x, workspace, totalLength, blockLength, tileSize, p, mode);
    op.Process();
}

template <typename T>
__global__ __aicore__ void foreach_norm_final_kernel(GM_ADDR workspace, GM_ADDR y, int64_t numPartials, float p,
                                                     int32_t mode)
{
    ForeachNormFinal<T> op;
    op.Init(workspace, y, numPartials, p, mode);
    op.Process();
}

std::tuple<int64_t, int64_t, int64_t> calc_foreach_norm_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 192 * 1024;
    int64_t coreNum = 48;
    if (ascendcPlatform != nullptr) {
        uint64_t q = 0;
        ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, q);
        if (q > 64 * 1024) {
            ubSize = q;
        }
        int64_t c = ascendcPlatform->GetCoreNumAiv();
        if (c > 0) {
            coreNum = c;
        }
    }
    if (coreNum > 1024) {
        coreNum = 1024;
    }
    if (dtypeSize <= 0) {
        dtypeSize = 4;
    }

    int64_t avail = static_cast<int64_t>(ubSize) - 8192;
    if (avail < 65536) {
        avail = 65536;
    }
    int64_t per = static_cast<int64_t>(FOREACH_NORM_PIPE_DEPTH) * dtypeSize + 12;
    int64_t maxElems = avail / per;
    int64_t tileElems = 256;
    while (tileElems * 2 <= maxElems && tileElems * 2 <= FOREACH_NORM_MAX_TILE) {
        tileElems *= 2;
    }

    if (totalLength <= 0) {
        return std::make_tuple(1, 0, tileElems * dtypeSize);
    }

    int64_t numBlocks = coreNum;
    if (numBlocks > totalLength) {
        numBlocks = totalLength;
    }
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t align = 32 / dtypeSize;
    if (align < 8) {
        align = 8;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    blockLength = (blockLength + align - 1) / align * align;
    numBlocks = (totalLength + blockLength - 1) / blockLength;
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
        blockLength = (totalLength + numBlocks - 1) / numBlocks;
        blockLength = (blockLength + align - 1) / align * align;
        numBlocks = (totalLength + blockLength - 1) / blockLength;
        if (numBlocks > coreNum) {
            numBlocks = coreNum;
            blockLength = (totalLength + numBlocks - 1) / numBlocks;
        }
    }
    return std::make_tuple(numBlocks, blockLength, tileElems * dtypeSize);
}

extern "C" {

void launch_foreach_norm_partial_float(GM_ADDR x, GM_ADDR workspace, int64_t totalLength, int64_t numBlocks,
                                       int64_t blockLength, uint32_t tileSize, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<float><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileSize,
                                                                       p, mode);
}

void launch_foreach_norm_partial_half(GM_ADDR x, GM_ADDR workspace, int64_t totalLength, int64_t numBlocks,
                                      int64_t blockLength, uint32_t tileSize, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<half><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength, tileSize,
                                                                      p, mode);
}

void launch_foreach_norm_partial_bf16(GM_ADDR x, GM_ADDR workspace, int64_t totalLength, int64_t numBlocks,
                                      int64_t blockLength, uint32_t tileSize, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, workspace, totalLength, blockLength,
                                                                           tileSize, p, mode);
}

void launch_foreach_norm_final_float(GM_ADDR workspace, GM_ADDR y, int64_t numPartials, float p, int32_t mode,
                                     void *stream)
{
    foreach_norm_final_kernel<float><<<1, nullptr, stream>>>(workspace, y, numPartials, p, mode);
}

void launch_foreach_norm_final_half(GM_ADDR workspace, GM_ADDR y, int64_t numPartials, float p, int32_t mode,
                                    void *stream)
{
    foreach_norm_final_kernel<half><<<1, nullptr, stream>>>(workspace, y, numPartials, p, mode);
}

void launch_foreach_norm_final_bf16(GM_ADDR workspace, GM_ADDR y, int64_t numPartials, float p, int32_t mode,
                                    void *stream)
{
    foreach_norm_final_kernel<bfloat16_t><<<1, nullptr, stream>>>(workspace, y, numPartials, p, mode);
}

}
