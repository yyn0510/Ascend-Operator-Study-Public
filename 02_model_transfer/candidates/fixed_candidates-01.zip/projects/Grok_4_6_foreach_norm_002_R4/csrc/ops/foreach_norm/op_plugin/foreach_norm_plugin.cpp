/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include <cmath>
#include <vector>

#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<torch::Tensor> foreach_norm_meta(torch::TensorList x, double scalar)
{
    (void)scalar;
    std::vector<torch::Tensor> y;
    y.reserve(x.size());
    for (const auto &t : x) {
        y.emplace_back(torch::empty({}, t.options()));
    }
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

static int32_t GetForeachNormMode(double scalar)
{
    if (std::isinf(scalar)) {
        return (scalar > 0.0) ? FOREACH_NORM_MODE_INF : FOREACH_NORM_MODE_NEG_INF;
    }
    if (scalar == 0.0) {
        return FOREACH_NORM_MODE_L0;
    }
    if (scalar == 1.0) {
        return FOREACH_NORM_MODE_L1;
    }
    if (scalar == 2.0) {
        return FOREACH_NORM_MODE_L2;
    }
    return FOREACH_NORM_MODE_GENERAL;
}

std::vector<torch::Tensor> foreach_norm_npu(torch::TensorList xList, double scalar)
{
    if (xList.size() == 0) {
        return {};
    }

    const auto dtype = xList[0].scalar_type();
    TORCH_CHECK(dtype == torch::kFloat32 || dtype == torch::kFloat16 || dtype == torch::kBFloat16,
                "foreach_norm: unsupported dtype");

    const c10::OptionalDeviceGuard guard(xList[0].device());

    std::vector<torch::Tensor> inputs;
    std::vector<torch::Tensor> outputs;
    inputs.reserve(xList.size());
    outputs.reserve(xList.size());
    for (const auto &t : xList) {
        TORCH_CHECK(t.defined(), "foreach_norm: input tensor is undefined");
        TORCH_CHECK(t.scalar_type() == dtype, "foreach_norm: all tensors must have the same dtype");
        inputs.push_back(t.contiguous());
        outputs.push_back(torch::empty({}, t.options()));
    }

    const int64_t dtypeSize = static_cast<int64_t>(inputs[0].element_size());
    const int32_t mode = GetForeachNormMode(scalar);
    const float p = static_cast<float>(scalar);
    void *stream = c10_npu::getCurrentNPUStream().stream(false);
    auto workspace = torch::empty({FOREACH_NORM_MAX_CORES * FOREACH_NORM_WS_STRIDE},
                                  torch::TensorOptions().dtype(torch::kFloat32).device(inputs[0].device()));

    auto acl_call = [=]() -> int {
        for (size_t i = 0; i < inputs.size(); ++i) {
            int64_t totalLength = inputs[i].numel();
            int64_t numBlocks = 1;
            int64_t blockLength = totalLength;
            int64_t tileSize = 256;
            std::tie(numBlocks, blockLength, tileSize) = calc_foreach_norm_tiling_params(totalLength, dtypeSize);
            if (numBlocks <= 0) {
                numBlocks = 1;
            }
            if (numBlocks > FOREACH_NORM_MAX_CORES) {
                numBlocks = FOREACH_NORM_MAX_CORES;
                if (totalLength > 0) {
                    blockLength = (totalLength + numBlocks - 1) / numBlocks;
                }
            }
            uint32_t tileSizeU32 = static_cast<uint32_t>(tileSize);
            GM_ADDR xPtr = (GM_ADDR)inputs[i].data_ptr();
            GM_ADDR yPtr = (GM_ADDR)outputs[i].data_ptr();
            GM_ADDR wsPtr = (GM_ADDR)workspace.data_ptr();
            if (dtype == torch::kFloat32) {
                launch_foreach_norm_partial_float(xPtr, wsPtr, totalLength, numBlocks, blockLength, tileSizeU32, p,
                                                  mode, stream);
                launch_foreach_norm_final_float(wsPtr, yPtr, numBlocks, p, mode, stream);
            } else if (dtype == torch::kFloat16) {
                launch_foreach_norm_partial_half(xPtr, wsPtr, totalLength, numBlocks, blockLength, tileSizeU32, p,
                                                 mode, stream);
                launch_foreach_norm_final_half(wsPtr, yPtr, numBlocks, p, mode, stream);
            } else {
                launch_foreach_norm_partial_bf16(xPtr, wsPtr, totalLength, numBlocks, blockLength, tileSizeU32, p,
                                                 mode, stream);
                launch_foreach_norm_final_bf16(wsPtr, yPtr, numBlocks, p, mode, stream);
            }
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
    return outputs;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

}  // namespace cann_bench
