/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file gelu_kernel.cpp
 * \brief Gelu kernel implementation and host launch wrappers
 *
 * Optimized: double buffering (PIPELINE_DEPTH=2) to overlap data movement and compute,
 * unified UB budget calculation with BYTES_PER_ELEM=16, and full core utilization.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static float GELU_INV_SQRT2 = 0.70710678118654752440f;
constexpr static float GELU_TANH_C = 0.79788456080286535587f;
constexpr static float GELU_TANH_A = 0.044715f;

template <typename T>
__global__ __aicore__ void gelu_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize, int32_t approximate)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf1;
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf2;

    int64_t alignElems = 32 / sizeof(T);
    int64_t elementNumPerTile = tileSize / sizeof(T);
    elementNumPerTile = (elementNumPerTile / alignElems) * alignElems;
    if (elementNumPerTile <= 0) return;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, elementNumPerTile * sizeof(T));
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, elementNumPerTile * sizeof(T));

    if constexpr (!std::is_same_v<T, float>) {
        pipe.InitBuffer(calcBuf1, elementNumPerTile * sizeof(float));
        pipe.InitBuffer(calcBuf2, elementNumPerTile * sizeof(float));
    }

    int64_t blockIdx = AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * blockIdx);

    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    if (currentBlockLength <= 0) return;

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailCount = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i <= tileNum; ++i) {
        int64_t count;
        int64_t offset;
        if (i < tileNum) {
            count = elementNumPerTile;
            offset = i * elementNumPerTile;
        } else {
            if (tailCount == 0) break;
            count = tailCount;
            offset = tileNum * elementNumPerTile;
        }

        auto xLocal = inQueue.AllocTensor<T>();
        if (count % alignElems == 0) {
            AscendC::DataCopy(xLocal, xGm[offset], count);
        } else {
            AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
            AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        }
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        int32_t calcCount = static_cast<int32_t>(count);

        if constexpr (std::is_same_v<T, float>) {
            if (approximate == 0) {
                AscendC::Muls(yLocal, xLocal, -GELU_INV_SQRT2, calcCount);
                AscendC::Erfc(yLocal, yLocal, calcCount);
                AscendC::Mul(yLocal, yLocal, xLocal, calcCount);
                AscendC::Muls(yLocal, yLocal, 0.5f, calcCount);
            } else {
                AscendC::Mul(yLocal, xLocal, xLocal, calcCount);
                AscendC::Mul(yLocal, yLocal, xLocal, calcCount);
                AscendC::Muls(yLocal, yLocal, GELU_TANH_A, calcCount);
                AscendC::Add(yLocal, yLocal, xLocal, calcCount);
                AscendC::Muls(yLocal, yLocal, GELU_TANH_C, calcCount);
                AscendC::Tanh(yLocal, yLocal, calcCount);
                AscendC::Adds(yLocal, yLocal, 1.0f, calcCount);
                AscendC::Mul(yLocal, yLocal, xLocal, calcCount);
                AscendC::Muls(yLocal, yLocal, 0.5f, calcCount);
            }
        } else {
            auto xFloat = calcBuf1.Get<float>();
            auto tmpFloat = calcBuf2.Get<float>();
            AscendC::Cast(xFloat, xLocal, AscendC::RoundMode::CAST_NONE, calcCount);

            if (approximate == 0) {
                AscendC::Muls(tmpFloat, xFloat, -GELU_INV_SQRT2, calcCount);
                AscendC::Erfc(tmpFloat, tmpFloat, calcCount);
                AscendC::Mul(tmpFloat, tmpFloat, xFloat, calcCount);
                AscendC::Muls(tmpFloat, tmpFloat, 0.5f, calcCount);
            } else {
                AscendC::Mul(tmpFloat, xFloat, xFloat, calcCount);
                AscendC::Mul(tmpFloat, tmpFloat, xFloat, calcCount);
                AscendC::Muls(tmpFloat, tmpFloat, GELU_TANH_A, calcCount);
                AscendC::Add(tmpFloat, tmpFloat, xFloat, calcCount);
                AscendC::Muls(tmpFloat, tmpFloat, GELU_TANH_C, calcCount);
                AscendC::Tanh(tmpFloat, tmpFloat, calcCount);
                AscendC::Adds(tmpFloat, tmpFloat, 1.0f, calcCount);
                AscendC::Mul(tmpFloat, tmpFloat, xFloat, calcCount);
                AscendC::Muls(tmpFloat, tmpFloat, 0.5f, calcCount);
            }
            if constexpr (std::is_same_v<T, bfloat16_t>) {
                AscendC::Cast(yLocal, tmpFloat, AscendC::RoundMode::CAST_RINT, calcCount);
            } else {
                AscendC::Cast(yLocal, tmpFloat, AscendC::RoundMode::CAST_NONE, calcCount);
            }
        }

        inQueue.FreeTensor(xLocal);
        outQueue.EnQue(yLocal);
        yLocal = outQueue.DeQue<T>();

        if (count % alignElems == 0) {
            AscendC::DataCopy(yGm[offset], yLocal, count);
        } else {
            AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        }
        outQueue.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_gelu_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t alignElems = 32 / dtypeSize;
    int64_t numBlocks = coreNum;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    blockLength = ((blockLength + alignElems - 1) / alignElems) * alignElems;
    if (blockLength <= 0) blockLength = alignElems;

    constexpr int64_t BYTES_PER_ELEM = 16;
    int64_t usableUb = static_cast<int64_t>(ubSize) * 9 / 10;
    int64_t maxElems = usableUb / BYTES_PER_ELEM;
    maxElems = (maxElems / alignElems) * alignElems;
    if (maxElems < alignElems) maxElems = alignElems;
    int64_t tileSize = maxElems * dtypeSize;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" void launch_gelu_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, int32_t approximate, void* stream)
{
    gelu_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, approximate);
}

extern "C" void launch_gelu_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, int32_t approximate, void* stream)
{
    gelu_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, approximate);
}

extern "C" void launch_gelu_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, int32_t approximate, void* stream)
{
    gelu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, approximate);
}
