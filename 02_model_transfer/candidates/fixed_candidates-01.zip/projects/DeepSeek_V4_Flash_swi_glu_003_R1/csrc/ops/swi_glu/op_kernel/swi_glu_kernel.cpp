#include <tuple>
#include <algorithm>
#include <type_traits>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr int32_t PIPELINE_DEPTH = 1;

template <typename T>
__aicore__ inline void ComputeSwiGluFloat(
    AscendC::LocalTensor<T>& x0Local,
    AscendC::LocalTensor<T>& x1Local,
    AscendC::LocalTensor<T>& outLocal,
    uint32_t count)
{
    AscendC::Sigmoid(outLocal, x0Local, count);
    AscendC::Mul(outLocal, x0Local, outLocal, count);
    AscendC::Mul(outLocal, outLocal, x1Local, count);
}

template <typename T>
__aicore__ inline void ComputeSwiGluNonFloat(
    AscendC::LocalTensor<T>& x0Local,
    AscendC::LocalTensor<T>& x1Local,
    AscendC::LocalTensor<T>& outLocal,
    AscendC::LocalTensor<float>& x0F,
    AscendC::LocalTensor<float>& x1F,
    AscendC::LocalTensor<float>& outF,
    uint32_t count)
{
    AscendC::Cast(x0F, x0Local, AscendC::RoundMode::CAST_NONE, count);
    AscendC::Cast(x1F, x1Local, AscendC::RoundMode::CAST_NONE, count);
    AscendC::Sigmoid(outF, x0F, count);
    AscendC::Mul(outF, x0F, outF, count);
    AscendC::Mul(outF, outF, x1F, count);
    AscendC::Cast(outLocal, outF, AscendC::RoundMode::CAST_ROUND, count);
}

template <typename T>
__global__ __aicore__ void swi_glu_kernel(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOutLength, int64_t fullLen, int64_t halfLen,
    int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    pipe.InitBuffer(inQueueX0, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(inQueueX1, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpX0Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpX1Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpOutBuf;
    if constexpr (!std::is_same_v<T, float>) {
        pipe.InitBuffer(tmpX0Buf, tileSize * 2);
        pipe.InitBuffer(tmpX1Buf, tileSize * 2);
        pipe.InitBuffer(tmpOutBuf, tileSize * 2);
    }

    AscendC::GlobalTensor<T> inGm;
    AscendC::GlobalTensor<T> outGm;
    inGm.SetGlobalBuffer((__gm__ T*)input);
    outGm.SetGlobalBuffer((__gm__ T*)output);

    int64_t start = static_cast<int64_t>(AscendC::GetBlockIdx()) * blockLength;
    int64_t end = start + blockLength;
    if (end > totalOutLength) {
        end = totalOutLength;
    }
    if (start >= totalOutLength) {
        return;
    }

    int64_t maxElemsPerTile = static_cast<int64_t>(tileSize / sizeof(T));
    int64_t pos = start;
    while (pos < end) {
        int64_t row = pos / halfLen;
        int64_t rowOffset = pos - row * halfLen;
        int64_t len = end - pos;
        if (len > halfLen - rowOffset) {
            len = halfLen - rowOffset;
        }
        if (len > maxElemsPerTile) {
            len = maxElemsPerTile;
        }

        uint32_t bytes = static_cast<uint32_t>(len * sizeof(T));
        AscendC::DataCopyExtParams copyParams{1, bytes, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto x0Local = inQueueX0.AllocTensor<T>();
        auto x1Local = inQueueX1.AllocTensor<T>();
        AscendC::DataCopyPad(x0Local, inGm[row * fullLen + rowOffset], copyParams, padParams);
        AscendC::DataCopyPad(x1Local, inGm[row * fullLen + rowOffset + halfLen], copyParams, padParams);
        inQueueX0.EnQue(x0Local);
        inQueueX1.EnQue(x1Local);
        x0Local = inQueueX0.DeQue<T>();
        x1Local = inQueueX1.DeQue<T>();

        auto outLocal = outQueue.AllocTensor<T>();
        uint32_t count = static_cast<uint32_t>(len);
        if constexpr (std::is_same_v<T, float>) {
            ComputeSwiGluFloat(x0Local, x1Local, outLocal, count);
        } else {
            auto x0F = tmpX0Buf.Get<float>();
            auto x1F = tmpX1Buf.Get<float>();
            auto outF = tmpOutBuf.Get<float>();
            ComputeSwiGluNonFloat(x0Local, x1Local, outLocal, x0F, x1F, outF, count);
        }

        outQueue.EnQue(outLocal);
        inQueueX0.FreeTensor(x0Local);
        inQueueX1.FreeTensor(x1Local);

        outLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(outGm[pos], outLocal, copyParams);
        outQueue.FreeTensor(outLocal);

        pos += len;
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_tiling_params(int64_t totalOutLength)
{
    constexpr int64_t MIN_ELEMS_PER_BLOCK = 1024;
    constexpr int64_t BUFFER_FACTOR = 10;

    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = (totalOutLength + MIN_ELEMS_PER_BLOCK - 1) / MIN_ELEMS_PER_BLOCK;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalOutLength + numBlocks - 1) / numBlocks;

    int64_t rawTile = static_cast<int64_t>(ubSize / BUFFER_FACTOR);
    rawTile = (rawTile / 32) * 32;
    if (rawTile < 32) {
        rawTile = 32;
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(rawTile));
}

extern "C" {

void launch_swi_glu_kernel_float(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOutLength, int64_t fullLen, int64_t halfLen, void* stream)
{
    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    uint32_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_swi_glu_tiling_params(totalOutLength);
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(
        input, output, totalOutLength, fullLen, halfLen, blockLength, tileSize);
}

void launch_swi_glu_kernel_half(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOutLength, int64_t fullLen, int64_t halfLen, void* stream)
{
    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    uint32_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_swi_glu_tiling_params(totalOutLength);
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(
        input, output, totalOutLength, fullLen, halfLen, blockLength, tileSize);
}

void launch_swi_glu_kernel_bfloat16(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOutLength, int64_t fullLen, int64_t halfLen, void* stream)
{
    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    uint32_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_swi_glu_tiling_params(totalOutLength);
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        input, output, totalOutLength, fullLen, halfLen, blockLength, tileSize);
}

}
