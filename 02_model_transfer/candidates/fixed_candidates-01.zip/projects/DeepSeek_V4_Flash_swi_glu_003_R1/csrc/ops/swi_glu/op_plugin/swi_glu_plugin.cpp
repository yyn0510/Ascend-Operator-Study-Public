#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include <vector>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    TORCH_CHECK(input.dim() >= 1, "swi_glu: input must have at least one dimension");
    int64_t rank = input.dim();
    int64_t normDim = dim < 0 ? dim + rank : dim;
    TORCH_CHECK(normDim >= 0 && normDim < rank, "swi_glu: dim out of range");
    TORCH_CHECK(input.size(normDim) % 2 == 0, "swi_glu: split dimension size must be even");

    std::vector<int64_t> output_shape(input.sizes().begin(), input.sizes().end());
    output_shape[normDim] /= 2;
    return torch::empty(output_shape, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto output = swi_glu_meta(input, dim);
    auto input_contig = input.contiguous();

    int64_t rank = input_contig.dim();
    int64_t normDim = dim < 0 ? dim + rank : dim;
    int64_t outer = 1;
    for (int64_t i = 0; i < normDim; ++i) {
        outer *= input_contig.size(i);
    }
    int64_t inner = 1;
    for (int64_t i = normDim + 1; i < rank; ++i) {
        inner *= input_contig.size(i);
    }

    int64_t splitDim = input_contig.size(normDim);
    int64_t fullLen = splitDim * inner;
    int64_t halfLen = (splitDim / 2) * inner;
    int64_t totalOut = outer * halfLen;

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    auto input_ptr = (GM_ADDR)input_contig.data_ptr();
    auto output_ptr = (GM_ADDR)output.data_ptr();

    auto acl_call = [=]() -> int {
        if (input.scalar_type() == torch::kFloat32) {
            launch_swi_glu_kernel_float(
                input_ptr, output_ptr, totalOut, fullLen, halfLen, stream);
        } else if (input.scalar_type() == torch::kFloat16) {
            launch_swi_glu_kernel_half(
                input_ptr, output_ptr, totalOut, fullLen, halfLen, stream);
        } else if (input.scalar_type() == torch::kBFloat16) {
            launch_swi_glu_kernel_bfloat16(
                input_ptr, output_ptr, totalOut, fullLen, halfLen, stream);
        } else {
            TORCH_CHECK(false, "swi_glu: unsupported input dtype");
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return output;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
