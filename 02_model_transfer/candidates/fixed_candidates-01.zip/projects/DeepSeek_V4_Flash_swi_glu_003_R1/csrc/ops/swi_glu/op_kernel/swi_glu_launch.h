#ifndef SWI_GLU_LAUNCH_H
#define SWI_GLU_LAUNCH_H

#include <cstdint>
#include <tuple>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_tiling_params(int64_t totalOutLength);

extern "C" {
void launch_swi_glu_kernel_float(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOutLength, int64_t fullLen, int64_t halfLen, void* stream);

void launch_swi_glu_kernel_half(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOutLength, int64_t fullLen, int64_t halfLen, void* stream);

void launch_swi_glu_kernel_bfloat16(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOutLength, int64_t fullLen, int64_t halfLen, void* stream);
}

#endif
