#include <algorithm>
#include <cstdint>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"
#include "swi_glu_launch.h"

using namespace AscendC;

template <typename T>
__global__ __aicore__ void swi_glu_kernel(
    GM_ADDR input, GM_ADDR output,
    int64_t blockOut, int64_t chunksPerGroup, int64_t totalTiles,
    int64_t tilesPerBlock, int64_t tileElems)
{
    int64_t tileStart = AscendC::GetBlockIdx() * tilesPerBlock;
    if (tileStart >= totalTiles) {
        return;
    }
    int64_t tileEnd = tileStart + tilesPerBlock;
    if (tileEnd > totalTiles) {
        tileEnd = totalTiles;
    }

    AscendC::GlobalTensor<T> inGm, outGm;
    inGm.SetGlobalBuffer((__gm__ T *)input);
    outGm.SetGlobalBuffer((__gm__ T *)output);

    AscendC::TPipe pipe;
    constexpr int32_t PIPELINE_DEPTH = 2;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueZ;
    AscendC::TBuf<AscendC::TPosition::VECCALC> f0Buf, f1Buf, t0Buf, t1Buf;

    uint32_t xBytes = static_cast<uint32_t>(tileElems * sizeof(T));
    uint32_t floatBytes = static_cast<uint32_t>(tileElems * sizeof(float));

    pipe.InitBuffer(inQueX0, PIPELINE_DEPTH, xBytes);
    pipe.InitBuffer(inQueX1, PIPELINE_DEPTH, xBytes);
    pipe.InitBuffer(outQueZ, 1, xBytes);
    pipe.InitBuffer(f0Buf, floatBytes);
    pipe.InitBuffer(f1Buf, floatBytes);
    pipe.InitBuffer(t0Buf, floatBytes);
    pipe.InitBuffer(t1Buf, floatBytes);

    auto x0F = f0Buf.Get<float>();
    auto x1F = f1Buf.Get<float>();
    auto tmp0 = t0Buf.Get<float>();
    auto tmp1 = t1Buf.Get<float>();

    {
        int64_t group = tileStart / chunksPerGroup;
        int64_t chunk = tileStart % chunksPerGroup;
        int64_t outOffset = group * blockOut + chunk * tileElems;
        int64_t inOffset0 = outOffset + group * blockOut;
        int64_t inOffset1 = inOffset0 + blockOut;
        int64_t count = blockOut - chunk * tileElems;
        if (count > tileElems) {
            count = tileElems;
        }
        if (count > 0) {
            AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
            auto x0Local = inQueX0.AllocTensor<T>();
            AscendC::DataCopyPad(x0Local, inGm[inOffset0], copyParams, padParams);
            inQueX0.EnQue(x0Local);
            auto x1Local = inQueX1.AllocTensor<T>();
            AscendC::DataCopyPad(x1Local, inGm[inOffset1], copyParams, padParams);
            inQueX1.EnQue(x1Local);
        }
    }

    for (int64_t t = tileStart; t < tileEnd; ++t) {
        int64_t next = t + 1;
        if (next < tileEnd) {
            int64_t nGroup = next / chunksPerGroup;
            int64_t nChunk = next % chunksPerGroup;
            int64_t nOutOffset = nGroup * blockOut + nChunk * tileElems;
            int64_t nInOffset0 = nOutOffset + nGroup * blockOut;
            int64_t nInOffset1 = nInOffset0 + blockOut;
            int64_t nCount = blockOut - nChunk * tileElems;
            if (nCount > tileElems) {
                nCount = tileElems;
            }
            if (nCount > 0) {
                AscendC::DataCopyExtParams nCopy{1, static_cast<uint32_t>(nCount * sizeof(T)), 0, 0, 0};
                AscendC::DataCopyPadExtParams<T> nPad{false, 0, 0, 0};
                auto nx0 = inQueX0.AllocTensor<T>();
                AscendC::DataCopyPad(nx0, inGm[nInOffset0], nCopy, nPad);
                inQueX0.EnQue(nx0);
                auto nx1 = inQueX1.AllocTensor<T>();
                AscendC::DataCopyPad(nx1, inGm[nInOffset1], nCopy, nPad);
                inQueX1.EnQue(nx1);
            }
        }

        int64_t group = t / chunksPerGroup;
        int64_t chunk = t % chunksPerGroup;
        int64_t outOffset = group * blockOut + chunk * tileElems;
        int64_t inOffset0 = outOffset + group * blockOut;
        int64_t inOffset1 = inOffset0 + blockOut;
        int64_t count = blockOut - chunk * tileElems;
        if (count > tileElems) {
            count = tileElems;
        }
        uint32_t cnt = static_cast<uint32_t>(count);
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};

        auto x0Local = inQueX0.DeQue<T>();
        auto x1Local = inQueX1.DeQue<T>();

        if constexpr (std::is_same_v<T, float>) {
            AscendC::Muls(tmp0, x0Local, -1.0f, cnt);
            AscendC::Exp(tmp1, tmp0, cnt);
            AscendC::Adds(tmp0, tmp1, 1.0f, cnt);
            AscendC::Div(tmp1, x0Local, tmp0, cnt);
            auto zLocal = outQueZ.AllocTensor<T>();
            AscendC::Mul(zLocal, tmp1, x1Local, cnt);
            outQueZ.EnQue(zLocal);
            inQueX0.FreeTensor(x0Local);
            inQueX1.FreeTensor(x1Local);
            zLocal = outQueZ.DeQue<T>();
            AscendC::DataCopyPad(outGm[outOffset], zLocal, copyParams);
            outQueZ.FreeTensor(zLocal);
        } else {
            AscendC::Cast<float, T>(x0F, x0Local, AscendC::RoundMode::CAST_NONE, cnt);
            AscendC::Cast<float, T>(x1F, x1Local, AscendC::RoundMode::CAST_NONE, cnt);
            AscendC::Muls(tmp0, x0F, -1.0f, cnt);
            AscendC::Exp(tmp1, tmp0, cnt);
            AscendC::Adds(tmp0, tmp1, 1.0f, cnt);
            AscendC::Div(tmp1, x0F, tmp0, cnt);
            AscendC::Mul(tmp0, tmp1, x1F, cnt);
            auto zLocal = outQueZ.AllocTensor<T>();
            AscendC::Cast<T, float>(zLocal, tmp0, AscendC::RoundMode::CAST_RINT, cnt);
            outQueZ.EnQue(zLocal);
            inQueX0.FreeTensor(x0Local);
            inQueX1.FreeTensor(x1Local);
            zLocal = outQueZ.DeQue<T>();
            AscendC::DataCopyPad(outGm[outOffset], zLocal, copyParams);
            outQueZ.FreeTensor(zLocal);
        }
    }
}

SwiGluTiling calc_swi_glu_tiling_params(int64_t outer, int64_t half, int64_t inner)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);

    int64_t coreNum = static_cast<int64_t>(ascendcPlatform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t tileElems = static_cast<int64_t>(ubSize) / 48;
    tileElems = (tileElems / 64) * 64;
    if (tileElems < 64) {
        tileElems = 64;
    }

    int64_t blockOut = half * inner;
    int64_t chunksPerGroup = (blockOut + tileElems - 1) / tileElems;
    if (chunksPerGroup < 1) {
        chunksPerGroup = 1;
    }

    int64_t totalTiles = outer * chunksPerGroup;
    int64_t numBlocks = std::min(coreNum, totalTiles);
    if (numBlocks < 1) {
        numBlocks = 1;
    }

    int64_t tilesPerBlock = (totalTiles + numBlocks - 1) / numBlocks;
    return SwiGluTiling{blockOut, chunksPerGroup, totalTiles, numBlocks, tilesPerBlock, tileElems};
}

extern "C" {

void launch_swi_glu_kernel_float(GM_ADDR input, GM_ADDR output, SwiGluTiling tiling, void *stream)
{
    swi_glu_kernel<float><<<tiling.numBlocks, nullptr, stream>>>(
        input, output, tiling.blockOut, tiling.chunksPerGroup,
        tiling.totalTiles, tiling.tilesPerBlock, tiling.tileElems);
}

void launch_swi_glu_kernel_half(GM_ADDR input, GM_ADDR output, SwiGluTiling tiling, void *stream)
{
    swi_glu_kernel<half><<<tiling.numBlocks, nullptr, stream>>>(
        input, output, tiling.blockOut, tiling.chunksPerGroup,
        tiling.totalTiles, tiling.tilesPerBlock, tiling.tileElems);
}

void launch_swi_glu_kernel_bfloat16(GM_ADDR input, GM_ADDR output, SwiGluTiling tiling, void *stream)
{
    swi_glu_kernel<bfloat16_t><<<tiling.numBlocks, nullptr, stream>>>(
        input, output, tiling.blockOut, tiling.chunksPerGroup,
        tiling.totalTiles, tiling.tilesPerBlock, tiling.tileElems);
}

}
