#ifndef SWI_GLU_LAUNCH_H
#define SWI_GLU_LAUNCH_H

#include <cstdint>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

struct SwiGluTiling {
    int64_t blockOut;
    int64_t chunksPerGroup;
    int64_t totalTiles;
    int64_t numBlocks;
    int64_t tilesPerBlock;
    int64_t tileElems;
};

SwiGluTiling calc_swi_glu_tiling_params(int64_t outer, int64_t half, int64_t inner);

extern "C" {

void launch_swi_glu_kernel_float(GM_ADDR input, GM_ADDR output, SwiGluTiling tiling, void *stream);
void launch_swi_glu_kernel_half(GM_ADDR input, GM_ADDR output, SwiGluTiling tiling, void *stream);
void launch_swi_glu_kernel_bfloat16(GM_ADDR input, GM_ADDR output, SwiGluTiling tiling, void *stream);

}

#define SWI_GLU_KERNEL_LAUNCH_FLOAT(input, output, tiling, stream) \
    launch_swi_glu_kernel_float(input, output, tiling, stream)

#define SWI_GLU_KERNEL_LAUNCH_HALF(input, output, tiling, stream) \
    launch_swi_glu_kernel_half(input, output, tiling, stream)

#define SWI_GLU_KERNEL_LAUNCH_BFLOAT16(input, output, tiling, stream) \
    launch_swi_glu_kernel_bfloat16(input, output, tiling, stream)

#endif // SWI_GLU_LAUNCH_H
