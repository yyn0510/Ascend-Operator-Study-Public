/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_plugin.cpp
 * \brief SwiGlu PyTorch plugin.
 */

#include <vector>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"
#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

static torch::Tensor swi_glu_meta_impl(const torch::Tensor &input, int64_t dim)
{
    int64_t rank = input.dim();
    TORCH_CHECK(rank >= 1, "swi_glu: input must have at least 1 dimension");
    int64_t d = dim;
    if (d < 0) {
        d += rank;
    }
    TORCH_CHECK(d >= 0 && d < rank, "swi_glu: dim out of range");
    int64_t splitSize = input.size(d);
    TORCH_CHECK(splitSize % 2 == 0, "swi_glu: size of split dim must be even");
    std::vector<int64_t> outShape(input.sizes().vec());
    outShape[d] = splitSize / 2;
    return torch::empty(outShape, input.options());
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    return swi_glu_meta_impl(input, dim);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    TORCH_CHECK(input.scalar_type() == torch::kFloat32 ||
                input.scalar_type() == torch::kFloat16 ||
                input.scalar_type() == torch::kBFloat16,
                "swi_glu: unsupported dtype");

    auto x = input.contiguous();
    auto output = swi_glu_meta_impl(x, dim);
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t rank = x.dim();
    int64_t d = dim;
    if (d < 0) {
        d += rank;
    }
    int64_t inner = 1;
    for (int64_t i = d + 1; i < rank; ++i) {
        inner *= x.size(i);
    }
    int64_t outer = 1;
    for (int64_t i = 0; i < d; ++i) {
        outer *= x.size(i);
    }
    int64_t blockLen = (x.size(d) / 2) * inner;
    int64_t totalOut = outer * blockLen;
    int64_t totalRows = outer;
    int64_t elemBytes = static_cast<int64_t>(x.element_size());

    SwiGluTiling tiling = calc_swi_glu_tiling_params(totalOut, blockLen, elemBytes);
    auto inputPtr = (GM_ADDR)x.data_ptr();
    auto outputPtr = (GM_ADDR)output.data_ptr();

    auto aclCall = [=]() -> int {
        if (x.scalar_type() == torch::kFloat32) {
            launch_swi_glu_kernel_float(inputPtr, outputPtr, totalOut, blockLen, totalRows,
                tiling.numBlocks, tiling.tileElems, tiling.batchRows, stream);
        } else if (x.scalar_type() == torch::kFloat16) {
            launch_swi_glu_kernel_half(inputPtr, outputPtr, totalOut, blockLen, totalRows,
                tiling.numBlocks, tiling.tileElems, tiling.batchRows, stream);
        } else {
            launch_swi_glu_kernel_bfloat16(inputPtr, outputPtr, totalOut, blockLen, totalRows,
                tiling.numBlocks, tiling.tileElems, tiling.batchRows, stream);
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("SwiGlu", aclCall);
    return output;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
