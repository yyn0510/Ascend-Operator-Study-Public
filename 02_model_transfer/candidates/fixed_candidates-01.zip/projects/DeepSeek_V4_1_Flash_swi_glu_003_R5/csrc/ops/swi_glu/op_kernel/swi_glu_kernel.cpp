/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGlu kernel, host tiling and launch wrappers.
 *
 * Input is viewed as [rows, 2, blockLen] (row major) and output as [rows, blockLen]:
 *     output[r, j] = silu(input[r, 0, j]) * input[r, 1, j]
 *
 * Two execution paths:
 *   - batched path (blockLenBytes <= SWI_GLU_BATCH_MAX_BLOCK_BYTES): rows are
 *     handled in batches; x0 / x1 of a whole batch are gathered with one
 *     strided DataCopyPad per tensor and the outputs are written back
 *     contiguously.  This keeps the number of DMA descriptors low for small and
 *     medium row widths.
 *   - large path: the flat output space is split across the vector cores and
 *     each row span is processed with tiles whose length is capped by the
 *     available UB.
 * All arithmetic is done in FP32 and rounded back to the storage type.
 */

#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"
#include "swi_glu_launch.h"

using namespace AscendC;

namespace {
constexpr uint32_t SWI_GLU_MAX_BLOCK_COUNT = 4095;
}

template <typename T>
__global__ __aicore__ void swi_glu_kernel(
    GM_ADDR input, GM_ADDR output,
    int64_t totalOut, int64_t blockLen, int64_t totalRows,
    int64_t numBlocks, uint32_t tileElems, uint32_t batchRows)
{
    constexpr uint32_t dtSize = static_cast<uint32_t>(sizeof(T));
    if (totalOut <= 0 || blockLen <= 0 || numBlocks <= 0 || totalRows <= 0) {
        return;
    }
    int64_t bid = static_cast<int64_t>(GetBlockIdx());
    if (bid >= numBlocks) {
        return;
    }

    GlobalTensor<T> inGm;
    GlobalTensor<T> outGm;
    inGm.SetGlobalBuffer((__gm__ T *)input);
    outGm.SetGlobalBuffer((__gm__ T *)output);

    const int64_t blockLenBytes = blockLen * static_cast<int64_t>(dtSize);

    if (blockLenBytes <= SWI_GLU_BATCH_MAX_BLOCK_BYTES && batchRows > 0) {
        /* ---------- batched strided access over whole rows ---------- */
        int64_t rowsPerCore = (totalRows + numBlocks - 1) / numBlocks;
        int64_t rowStart = bid * rowsPerCore;
        int64_t rowEnd = rowStart + rowsPerCore;
        if (rowEnd > totalRows) {
            rowEnd = totalRows;
        }
        if (rowStart >= rowEnd) {
            return;
        }

        const int64_t perBlockBytes = ((blockLenBytes + 31) / 32) * 32;
        const uint32_t perBlockElems = static_cast<uint32_t>(perBlockBytes / static_cast<int64_t>(dtSize));

        uint32_t maxBatch = batchRows;
        if (maxBatch > SWI_GLU_MAX_BLOCK_COUNT) {
            maxBatch = SWI_GLU_MAX_BLOCK_COUNT;
        }
        if (maxBatch < 1) {
            maxBatch = 1;
        }

        const uint32_t bufElems = maxBatch * perBlockElems;
        const uint32_t bufBytes = bufElems * dtSize;

        TPipe pipe;
        TQue<QuePosition::VECIN, 1> inQue0;
        TQue<QuePosition::VECIN, 1> inQue1;
        TQue<QuePosition::VECOUT, 1> outQue;
        TBuf<TPosition::VECCALC> s0Buf;
        TBuf<TPosition::VECCALC> s1Buf;
        TBuf<TPosition::VECCALC> s2Buf;
        pipe.InitBuffer(inQue0, 1, bufBytes);
        pipe.InitBuffer(inQue1, 1, bufBytes);
        pipe.InitBuffer(outQue, 1, bufBytes);
        if constexpr (std::is_same_v<T, float>) {
            pipe.InitBuffer(s0Buf, bufBytes);
        } else {
            pipe.InitBuffer(s0Buf, static_cast<uint32_t>(bufElems * sizeof(float)));
            pipe.InitBuffer(s1Buf, static_cast<uint32_t>(bufElems * sizeof(float)));
            pipe.InitBuffer(s2Buf, static_cast<uint32_t>(bufElems * sizeof(float)));
        }

        DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        const uint32_t blockBytes = static_cast<uint32_t>(blockLenBytes);
        const uint32_t srcStrideBytes = static_cast<uint32_t>(blockLenBytes);

        int64_t row = rowStart;
        while (row < rowEnd) {
            int64_t remain = rowEnd - row;
            uint32_t n = static_cast<uint32_t>(
                remain < static_cast<int64_t>(maxBatch) ? remain : static_cast<int64_t>(maxBatch));
            int64_t inBase = row * (2 * blockLen);
            int64_t outBase = row * blockLen;

            DataCopyExtParams cpIn{static_cast<uint16_t>(n), blockBytes, srcStrideBytes, 0, 0};
            LocalTensor<T> x0 = inQue0.AllocTensor<T>();
            LocalTensor<T> x1 = inQue1.AllocTensor<T>();
            DataCopyPad(x0, inGm[inBase], cpIn, padParams);
            DataCopyPad(x1, inGm[inBase + blockLen], cpIn, padParams);
            inQue0.EnQue(x0);
            inQue1.EnQue(x1);
            x0 = inQue0.DeQue<T>();
            x1 = inQue1.DeQue<T>();

            LocalTensor<T> y = outQue.AllocTensor<T>();
            uint32_t total = n * perBlockElems;
            if constexpr (std::is_same_v<T, float>) {
                LocalTensor<float> sg = s0Buf.Get<float>();
                Sigmoid(sg, x0, total);
                Mul(y, x0, sg, total);
                Mul(y, y, x1, total);
            } else {
                LocalTensor<float> f0 = s0Buf.Get<float>();
                LocalTensor<float> f1 = s1Buf.Get<float>();
                LocalTensor<float> sg = s2Buf.Get<float>();
                Cast(f0, x0, RoundMode::CAST_NONE, total);
                Cast(f1, x1, RoundMode::CAST_NONE, total);
                Sigmoid(sg, f0, total);
                Mul(f0, f0, sg, total);
                Mul(f0, f0, f1, total);
                Cast(y, f0, RoundMode::CAST_RINT, total);
            }
            outQue.EnQue(y);
            inQue0.FreeTensor(x0);
            inQue1.FreeTensor(x1);

            y = outQue.DeQue<T>();
            DataCopyExtParams cpOut{static_cast<uint16_t>(n), blockBytes, 0, 0, 0};
            DataCopyPad(outGm[outBase], y, cpOut);
            outQue.FreeTensor(y);
            row += static_cast<int64_t>(n);
        }
        return;
    }

    /* ---------- large path: flat split of the output space ---------- */
    int64_t segStart = bid * totalOut / numBlocks;
    int64_t segEnd = (bid + 1) * totalOut / numBlocks;
    if (segStart >= segEnd) {
        return;
    }

    uint32_t tile = tileElems;
    if (tile == 0) {
        tile = 1024;
    }
    const uint32_t tileBytes = tile * dtSize;

    TPipe pipe;
    TQue<QuePosition::VECIN, 2> inQue0;
    TQue<QuePosition::VECIN, 2> inQue1;
    TQue<QuePosition::VECOUT, 2> outQue;
    TBuf<TPosition::VECCALC> s0Buf;
    TBuf<TPosition::VECCALC> s1Buf;
    TBuf<TPosition::VECCALC> s2Buf;
    pipe.InitBuffer(inQue0, 2, tileBytes);
    pipe.InitBuffer(inQue1, 2, tileBytes);
    pipe.InitBuffer(outQue, 2, tileBytes);
    pipe.InitBuffer(s0Buf, static_cast<uint32_t>(tile * sizeof(float)));
    if constexpr (!std::is_same_v<T, float>) {
        pipe.InitBuffer(s1Buf, static_cast<uint32_t>(tile * sizeof(float)));
        pipe.InitBuffer(s2Buf, static_cast<uint32_t>(tile * sizeof(float)));
    }

    DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
    int64_t oFirst = segStart / blockLen;
    int64_t oLast = (segEnd - 1) / blockLen;

    LocalTensor<float> s0 = s0Buf.Get<float>();

    for (int64_t o = oFirst; o <= oLast; ++o) {
        int64_t frameLo = o * blockLen;
        int64_t frameHi = frameLo + blockLen;
        int64_t s = segStart > frameLo ? segStart : frameLo;
        int64_t e = segEnd < frameHi ? segEnd : frameHi;
        if (s >= e) {
            continue;
        }
        int64_t cnt = e - s;
        int64_t inBase = frameLo * 2 + (s - frameLo);
        int64_t outBase = s;

        for (int64_t k = 0; k < cnt; k += static_cast<int64_t>(tile)) {
            int64_t c = cnt - k;
            if (c > static_cast<int64_t>(tile)) {
                c = static_cast<int64_t>(tile);
            }
            uint32_t n = static_cast<uint32_t>(c);
            DataCopyExtParams cp{static_cast<uint16_t>(1),
                static_cast<uint32_t>(n * dtSize), 0, 0, 0};

            LocalTensor<T> x0 = inQue0.AllocTensor<T>();
            LocalTensor<T> x1 = inQue1.AllocTensor<T>();
            DataCopyPad(x0, inGm[inBase + k], cp, padParams);
            DataCopyPad(x1, inGm[inBase + k + blockLen], cp, padParams);
            inQue0.EnQue(x0);
            inQue1.EnQue(x1);
            x0 = inQue0.DeQue<T>();
            x1 = inQue1.DeQue<T>();

            LocalTensor<T> y = outQue.AllocTensor<T>();
            if constexpr (std::is_same_v<T, float>) {
                Sigmoid(s0, x0, n);
                Mul(y, x0, s0, n);
                Mul(y, y, x1, n);
            } else {
                LocalTensor<float> f0 = s0Buf.Get<float>();
                LocalTensor<float> f1 = s1Buf.Get<float>();
                LocalTensor<float> sg = s2Buf.Get<float>();
                Cast(f0, x0, RoundMode::CAST_NONE, n);
                Cast(f1, x1, RoundMode::CAST_NONE, n);
                Sigmoid(sg, f0, n);
                Mul(f0, f0, sg, n);
                Mul(f0, f0, f1, n);
                Cast(y, f0, RoundMode::CAST_RINT, n);
            }
            outQue.EnQue(y);
            inQue0.FreeTensor(x0);
            inQue1.FreeTensor(x1);

            y = outQue.DeQue<T>();
            DataCopyPad(outGm[outBase + k], y, cp);
            outQue.FreeTensor(y);
        }
    }
}

SwiGluTiling calc_swi_glu_tiling_params(int64_t totalOut, int64_t blockLen, int64_t elemBytes)
{
    SwiGluTiling tiling;
    tiling.numBlocks = 1;
    tiling.tileElems = 1024;
    tiling.batchRows = 0;
    if (totalOut <= 0 || blockLen <= 0 || elemBytes <= 0) {
        return tiling;
    }

    uint64_t ubSize = 0;
    int64_t coreNum = 1;
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    if (platform != nullptr) {
        platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
        int64_t c = static_cast<int64_t>(platform->GetCoreNumAiv());
        if (c > 0) {
            coreNum = c;
        }
    }
    if (ubSize == 0) {
        ubSize = 192 * 1024;
    }

    int64_t totalRows = totalOut / blockLen;
    if (totalRows < 1) {
        totalRows = 1;
    }
    int64_t blockLenBytes = blockLen * elemBytes;
    int64_t budget = static_cast<int64_t>(ubSize) * 3 / 4;
    if (budget < 4096) {
        budget = 4096;
    }

    if (blockLenBytes <= SWI_GLU_BATCH_MAX_BLOCK_BYTES) {
        int64_t perBlockBytes = ((blockLenBytes + 31) / 32) * 32;
        int64_t perRowBytes = (elemBytes == 4) ? (4 * perBlockBytes) : (9 * perBlockBytes);
        if (perRowBytes < 1) {
            perRowBytes = 1;
        }
        int64_t rows = budget / perRowBytes;
        if (rows < 1) {
            rows = 1;
        }
        if (rows > static_cast<int64_t>(SWI_GLU_MAX_BLOCK_COUNT)) {
            rows = static_cast<int64_t>(SWI_GLU_MAX_BLOCK_COUNT);
        }
        if (rows > totalRows) {
            rows = totalRows;
        }
        tiling.batchRows = static_cast<uint32_t>(rows);
        int64_t nb = totalRows < coreNum ? totalRows : coreNum;
        if (nb < 1) {
            nb = 1;
        }
        tiling.numBlocks = nb;
        return tiling;
    }

    int64_t perElem = (elemBytes == 4) ? 28 : 24;
    int64_t elems = budget / perElem;
    if (elems > 16384) {
        elems = 16384;
    }
    elems = (elems / 256) * 256;
    if (elems < 512) {
        elems = 512;
    }
    tiling.tileElems = static_cast<uint32_t>(elems);

    const int64_t minPerCore = 4096;
    int64_t nb = (totalOut + minPerCore - 1) / minPerCore;
    if (nb > coreNum) {
        nb = coreNum;
    }
    if (nb < 1) {
        nb = 1;
    }
    tiling.numBlocks = nb;
    tiling.batchRows = 0;
    return tiling;
}

extern "C" {

void launch_swi_glu_kernel_float(
    GM_ADDR input, GM_ADDR output, int64_t totalOut, int64_t blockLen,
    int64_t totalRows, int64_t numBlocks, uint32_t tileElems, uint32_t batchRows, void *stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, blockLen, totalRows, numBlocks, tileElems, batchRows);
}

void launch_swi_glu_kernel_half(
    GM_ADDR input, GM_ADDR output, int64_t totalOut, int64_t blockLen,
    int64_t totalRows, int64_t numBlocks, uint32_t tileElems, uint32_t batchRows, void *stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, blockLen, totalRows, numBlocks, tileElems, batchRows);
}

void launch_swi_glu_kernel_bfloat16(
    GM_ADDR input, GM_ADDR output, int64_t totalOut, int64_t blockLen,
    int64_t totalRows, int64_t numBlocks, uint32_t tileElems, uint32_t batchRows, void *stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, blockLen, totalRows, numBlocks, tileElems, batchRows);
}

}
