/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_launch.h
 * \brief Launch function declarations for g++.
 */

#ifndef SWI_GLU_LAUNCH_H
#define SWI_GLU_LAUNCH_H

#include <cstdint>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

/* Rows whose byte width does not exceed this value are handled by the batched
 * (multi row per DMA descriptor) path. */
constexpr int64_t SWI_GLU_BATCH_MAX_BLOCK_BYTES = 8192;

struct SwiGluTiling {
    int64_t numBlocks;
    uint32_t tileElems;
    uint32_t batchRows;
};

SwiGluTiling calc_swi_glu_tiling_params(int64_t totalOut, int64_t blockLen, int64_t elemBytes);

extern "C" {
void launch_swi_glu_kernel_float(GM_ADDR input, GM_ADDR output,
    int64_t totalOut, int64_t blockLen, int64_t totalRows, int64_t numBlocks,
    uint32_t tileElems, uint32_t batchRows, void *stream);
void launch_swi_glu_kernel_half(GM_ADDR input, GM_ADDR output,
    int64_t totalOut, int64_t blockLen, int64_t totalRows, int64_t numBlocks,
    uint32_t tileElems, uint32_t batchRows, void *stream);
void launch_swi_glu_kernel_bfloat16(GM_ADDR input, GM_ADDR output,
    int64_t totalOut, int64_t blockLen, int64_t totalRows, int64_t numBlocks,
    uint32_t tileElems, uint32_t batchRows, void *stream);
}

#endif // SWI_GLU_LAUNCH_H
