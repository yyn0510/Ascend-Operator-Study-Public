/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_kernel.cpp
 * \brief ForeachNorm kernel, host tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <cstdint>
#include <limits>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

static constexpr int32_t NORM_MODE_SUM = 0; // y = (sum |x|^p)^(1/p)
static constexpr int32_t NORM_MODE_MAX = 1; // p = +inf, y = max |x|
static constexpr int32_t NORM_MODE_MIN = 2; // p = -inf, y = min |x|

// Compute |x|^p elementwise into dst (fp32). scratch is a temp buffer; for the
// generic path it must be pre-filled with the value p.
static __aicore__ inline void NormPowTerm(
    const AscendC::LocalTensor<float> &dst,
    const AscendC::LocalTensor<float> &xs,
    const AscendC::LocalTensor<float> &scratch,
    int32_t count, float p)
{
    if (p == 1.0f) {
        AscendC::Abs(dst, xs, count);
    } else if (p == 2.0f) {
        AscendC::Mul(dst, xs, xs, count);
    } else if (p == 3.0f) {
        AscendC::Abs(dst, xs, count);
        AscendC::Mul(scratch, dst, dst, count);
        AscendC::Mul(dst, scratch, dst, count);
    } else if (p == 4.0f) {
        AscendC::Mul(scratch, xs, xs, count);
        AscendC::Mul(dst, scratch, scratch, count);
    } else if (p == 5.0f) {
        AscendC::Abs(dst, xs, count);
        AscendC::Mul(scratch, dst, dst, count);
        AscendC::Mul(dst, scratch, dst, count);
        AscendC::Mul(dst, dst, scratch, count);
    } else if (p == 1.5f) {
        AscendC::Abs(dst, xs, count);
        AscendC::Sqrt(scratch, dst, count);
        AscendC::Mul(dst, dst, scratch, count);
    } else if (p == 2.5f) {
        AscendC::Abs(dst, xs, count);
        AscendC::Sqrt(scratch, dst, count);
        AscendC::Mul(dst, dst, dst, count);
        AscendC::Mul(dst, dst, scratch, count);
    } else {
        // generic: |x|^p = exp(p * log|x|)
        AscendC::Abs(dst, xs, count);
        AscendC::Log(dst, dst, count);
        AscendC::Mul(dst, dst, scratch, count);
        AscendC::Exp(dst, dst, count);
    }
}

template <typename T>
static __aicore__ inline void NormComputeTile(
    const AscendC::LocalTensor<T> &xLocal,
    const AscendC::LocalTensor<float> &fLocal,
    const AscendC::LocalTensor<float> &accLocal,
    const AscendC::LocalTensor<float> &expLocal,
    int32_t count, float p, int32_t mode)
{
    if (mode == NORM_MODE_MAX || mode == NORM_MODE_MIN) {
        if constexpr (std::is_same<T, float>::value) {
            AscendC::Abs(fLocal, xLocal, count);
        } else {
            AscendC::Cast(fLocal, xLocal, AscendC::RoundMode::CAST_NONE, count);
            AscendC::Abs(fLocal, fLocal, count);
        }
        if (mode == NORM_MODE_MAX) {
            AscendC::Max(accLocal, accLocal, fLocal, count);
        } else {
            AscendC::Min(accLocal, accLocal, fLocal, count);
        }
        return;
    }
    if constexpr (std::is_same<T, float>::value) {
        NormPowTerm(fLocal, xLocal, expLocal, count, p);
    } else {
        AscendC::Cast(fLocal, xLocal, AscendC::RoundMode::CAST_NONE, count);
        NormPowTerm(fLocal, fLocal, expLocal, count, p);
    }
    AscendC::Add(accLocal, accLocal, fLocal, count);
}

// Stage 1: each block reduces its contiguous chunk of x into an 8-float slot of
// the fp32 workspace (all 8 lanes hold the same partial result).
template <typename T>
__global__ __aicore__ void norm_partial_kernel(
    GM_ADDR x, GM_ADDR workspace, int64_t totalLength, int64_t blockLength,
    int32_t tileElems, float p, int32_t mode, float initVal)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 2> inQue;
    pipe.InitBuffer(inQue, 2, tileElems * sizeof(T));
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> accQue;
    pipe.InitBuffer(accQue, 1, tileElems * sizeof(float));
    AscendC::TBuf<AscendC::TPosition::VECCALC> fBuf;
    pipe.InitBuffer(fBuf, tileElems * sizeof(float));
    AscendC::TBuf<AscendC::TPosition::VECCALC> expBuf;
    pipe.InitBuffer(expBuf, tileElems * sizeof(float));
    AscendC::TQue<AscendC::QuePosition::VECOUT, 2> outQue;
    pipe.InitBuffer(outQue, 2, 32);

    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<float> wsGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * static_cast<int64_t>(AscendC::GetBlockIdx()));
    wsGm.SetGlobalBuffer((__gm__ float *)workspace + 8 * static_cast<int64_t>(AscendC::GetBlockIdx()));

    auto fLocal = fBuf.Get<float>();
    auto expLocal = expBuf.Get<float>();
    auto accLocal = accQue.AllocTensor<float>();

    AscendC::Duplicate(accLocal, initVal, tileElems);

    const bool fastPath = (p == 1.0f || p == 1.5f || p == 2.0f || p == 2.5f ||
                           p == 3.0f || p == 4.0f || p == 5.0f);
    if (mode == NORM_MODE_SUM && !fastPath) {
        AscendC::Duplicate(expLocal, p, tileElems);
    }

    int64_t curLen = totalLength - blockLength * static_cast<int64_t>(AscendC::GetBlockIdx());
    if (curLen > blockLength) {
        curLen = blockLength;
    }
    if (curLen < 0) {
        curLen = 0;
    }
    const int64_t tileNum = curLen / tileElems;
    const int64_t tailNum = curLen - tileNum * tileElems;

    for (int64_t i = 0; i < tileNum; ++i) {
        const int64_t offset = i * tileElems;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tileElems * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQue.EnQue(xLocal);
        xLocal = inQue.DeQue<T>();
        NormComputeTile<T>(xLocal, fLocal, accLocal, expLocal, tileElems, p, mode);
        inQue.FreeTensor(xLocal);
    }
    if (tailNum > 0) {
        const int64_t offset = tileNum * tileElems;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQue.EnQue(xLocal);
        xLocal = inQue.DeQue<T>();
        NormComputeTile<T>(xLocal, fLocal, accLocal, expLocal, static_cast<int32_t>(tailNum), p, mode);
        inQue.FreeTensor(xLocal);
    }

    // EnQue/DeQue pair guarantees the vector results are visible before the
    // scalar reads below.
    accQue.EnQue(accLocal);
    accLocal = accQue.DeQue<float>();

    float result = 0.0f;
    if (mode == NORM_MODE_MAX) {
        float m0 = initVal, m1 = initVal, m2 = initVal, m3 = initVal;
        int32_t i = 0;
        for (; i + 4 <= tileElems; i += 4) {
            float v0 = accLocal.GetValue(static_cast<uint32_t>(i));
            float v1 = accLocal.GetValue(static_cast<uint32_t>(i + 1));
            float v2 = accLocal.GetValue(static_cast<uint32_t>(i + 2));
            float v3 = accLocal.GetValue(static_cast<uint32_t>(i + 3));
            if (v0 > m0) { m0 = v0; }
            if (v1 > m1) { m1 = v1; }
            if (v2 > m2) { m2 = v2; }
            if (v3 > m3) { m3 = v3; }
        }
        for (; i < tileElems; ++i) {
            float v = accLocal.GetValue(static_cast<uint32_t>(i));
            if (v > m0) { m0 = v; }
        }
        float m = (m0 > m1) ? m0 : m1;
        if (m2 > m) { m = m2; }
        if (m3 > m) { m = m3; }
        result = m;
    } else if (mode == NORM_MODE_MIN) {
        float m0 = initVal, m1 = initVal, m2 = initVal, m3 = initVal;
        int32_t i = 0;
        for (; i + 4 <= tileElems; i += 4) {
            float v0 = accLocal.GetValue(static_cast<uint32_t>(i));
            float v1 = accLocal.GetValue(static_cast<uint32_t>(i + 1));
            float v2 = accLocal.GetValue(static_cast<uint32_t>(i + 2));
            float v3 = accLocal.GetValue(static_cast<uint32_t>(i + 3));
            if (v0 < m0) { m0 = v0; }
            if (v1 < m1) { m1 = v1; }
            if (v2 < m2) { m2 = v2; }
            if (v3 < m3) { m3 = v3; }
        }
        for (; i < tileElems; ++i) {
            float v = accLocal.GetValue(static_cast<uint32_t>(i));
            if (v < m0) { m0 = v; }
        }
        float m = (m0 < m1) ? m0 : m1;
        if (m2 < m) { m = m2; }
        if (m3 < m) { m = m3; }
        result = m;
    } else {
        float s0 = 0.0f, s1 = 0.0f, s2 = 0.0f, s3 = 0.0f;
        int32_t i = 0;
        for (; i + 4 <= tileElems; i += 4) {
            s0 += accLocal.GetValue(static_cast<uint32_t>(i));
            s1 += accLocal.GetValue(static_cast<uint32_t>(i + 1));
            s2 += accLocal.GetValue(static_cast<uint32_t>(i + 2));
            s3 += accLocal.GetValue(static_cast<uint32_t>(i + 3));
        }
        for (; i < tileElems; ++i) {
            s0 += accLocal.GetValue(static_cast<uint32_t>(i));
        }
        result = (s0 + s1) + (s2 + s3);
    }
    accQue.FreeTensor(accLocal);

    auto outLocal = outQue.AllocTensor<float>();
    AscendC::Duplicate(outLocal, result, 8);
    outQue.EnQue(outLocal);
    outLocal = outQue.DeQue<float>();
    AscendC::DataCopy(wsGm, outLocal, 8);
    outQue.FreeTensor(outLocal);
}

// Stage 2: one block folds the per-block partials (lane 0 of each 8-float slot)
// and writes the scalar norm result as a 16-element aligned block.
template <typename T>
__global__ __aicore__ void norm_final_kernel(
    GM_ADDR workspace, GM_ADDR y, int32_t wsElems, float p, int32_t mode, float initVal)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQue;
    pipe.InitBuffer(inQue, 1, wsElems * sizeof(float));
    AscendC::TBuf<AscendC::TPosition::VECCALC> dstBuf;
    pipe.InitBuffer(dstBuf, 64);
    AscendC::TBuf<AscendC::TPosition::VECCALC> expBuf;
    pipe.InitBuffer(expBuf, 64);
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQue;
    pipe.InitBuffer(outQue, 1, 16 * sizeof(T));

    AscendC::GlobalTensor<float> wsGm;
    AscendC::GlobalTensor<T> yGm;
    wsGm.SetGlobalBuffer((__gm__ float *)workspace);
    yGm.SetGlobalBuffer((__gm__ T *)y);

    auto wsLocal = inQue.AllocTensor<float>();
    AscendC::DataCopy(wsLocal, wsGm, static_cast<uint32_t>(wsElems));
    inQue.EnQue(wsLocal);
    wsLocal = inQue.DeQue<float>();

    const int32_t numBlocks = wsElems / 8;
    float result = 0.0f;
    if (mode == NORM_MODE_MAX) {
        float m = initVal;
        for (int32_t b = 0; b < numBlocks; ++b) {
            float v = wsLocal.GetValue(static_cast<uint32_t>(b * 8));
            if (v > m) {
                m = v;
            }
        }
        result = m;
    } else if (mode == NORM_MODE_MIN) {
        float m = initVal;
        for (int32_t b = 0; b < numBlocks; ++b) {
            float v = wsLocal.GetValue(static_cast<uint32_t>(b * 8));
            if (v < m) {
                m = v;
            }
        }
        result = m;
    } else {
        float s = 0.0f;
        for (int32_t b = 0; b < numBlocks; ++b) {
            s += wsLocal.GetValue(static_cast<uint32_t>(b * 8));
        }
        result = s;
    }
    inQue.FreeTensor(wsLocal);

    auto expLocal = expBuf.Get<float>();
    if constexpr (std::is_same<T, float>::value) {
        auto outLocal = outQue.AllocTensor<float>();
        AscendC::Duplicate(outLocal, result, 16);
        if (mode == NORM_MODE_SUM && p != 1.0f && p != 0.0f) {
            if (p == 2.0f) {
                AscendC::Sqrt(outLocal, outLocal, 16);
            } else {
                AscendC::Duplicate(expLocal, 1.0f / p, 16);
                AscendC::Log(outLocal, outLocal, 16);
                AscendC::Mul(outLocal, outLocal, expLocal, 16);
                AscendC::Exp(outLocal, outLocal, 16);
            }
        }
        outQue.EnQue(outLocal);
        outLocal = outQue.DeQue<float>();
        AscendC::DataCopy(yGm, outLocal, 16);
        outQue.FreeTensor(outLocal);
    } else {
        auto dstLocal = dstBuf.Get<float>();
        AscendC::Duplicate(dstLocal, result, 16);
        if (mode == NORM_MODE_SUM && p != 1.0f && p != 0.0f) {
            if (p == 2.0f) {
                AscendC::Sqrt(dstLocal, dstLocal, 16);
            } else {
                AscendC::Duplicate(expLocal, 1.0f / p, 16);
                AscendC::Log(dstLocal, dstLocal, 16);
                AscendC::Mul(dstLocal, dstLocal, expLocal, 16);
                AscendC::Exp(dstLocal, dstLocal, 16);
            }
        }
        auto outLocal = outQue.AllocTensor<T>();
        if constexpr (std::is_same<T, bfloat16_t>::value) {
            // float -> bfloat16 requires an explicit rounding mode; CAST_NONE is
            // not a supported round mode for this conversion on this target.
            AscendC::Cast(outLocal, dstLocal, AscendC::RoundMode::CAST_RINT, 16);
        } else {
            AscendC::Cast(outLocal, dstLocal, AscendC::RoundMode::CAST_NONE, 16);
        }
        outQue.EnQue(outLocal);
        outLocal = outQue.DeQue<T>();
        AscendC::DataCopy(yGm, outLocal, 16);
        outQue.FreeTensor(outLocal);
    }
}

// Host tiling: (numBlocks, blockLength, tileElems)
std::tuple<int64_t, int64_t, uint32_t> calc_foreach_norm_tiling(int64_t totalLength, int32_t dtypeSize)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    constexpr int64_t MIN_ELEMS_PER_CORE = 8192;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks > totalLength) {
        numBlocks = totalLength;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    if (blockLength < 1) {
        blockLength = 1;
    }

    // UB per element: 2 input tiles of dtypeSize + 3 float buffers + margin
    int64_t bytesPerElem = 2 * static_cast<int64_t>(dtypeSize) + 16;
    int64_t ubTotal = static_cast<int64_t>(ubSize);
    if (ubTotal <= 0) {
        ubTotal = 262144;
    }
    int64_t usable = ubTotal - 16384;
    if (usable < 16384) {
        usable = ubTotal / 2;
    }
    if (usable < 4096) {
        usable = 4096;
    }
    int64_t maxTile = usable / bytesPerElem;
    if (maxTile < 8) {
        maxTile = 8;
    }
    int64_t tileElems = (maxTile / 1024) * 1024;
    if (tileElems < 8) {
        tileElems = (maxTile / 8) * 8;
    }
    if (tileElems < 8) {
        tileElems = 8;
    }
    // Cap the tile size: the per-block scalar lane-fold at the end of the
    // partial kernel is O(tileElems), so a moderate tile keeps that tail short.
    if (tileElems > 4096) {
        tileElems = 4096;
    }
    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileElems));
}

static float NormInitValue(int32_t mode)
{
    if (mode == NORM_MODE_MAX) {
        return -std::numeric_limits<float>::infinity();
    }
    if (mode == NORM_MODE_MIN) {
        return std::numeric_limits<float>::infinity();
    }
    return 0.0f;
}

extern "C" {

void launch_fnorm_partial_float(GM_ADDR x, GM_ADDR ws, int64_t totalLength, int64_t numBlocks,
                                int64_t blockLength, uint32_t tileElems, float p, int32_t mode, void *stream)
{
    norm_partial_kernel<float><<<numBlocks, nullptr, stream>>>(
        x, ws, totalLength, blockLength, static_cast<int32_t>(tileElems), p, mode, NormInitValue(mode));
}

void launch_fnorm_partial_half(GM_ADDR x, GM_ADDR ws, int64_t totalLength, int64_t numBlocks,
                               int64_t blockLength, uint32_t tileElems, float p, int32_t mode, void *stream)
{
    norm_partial_kernel<half><<<numBlocks, nullptr, stream>>>(
        x, ws, totalLength, blockLength, static_cast<int32_t>(tileElems), p, mode, NormInitValue(mode));
}

void launch_fnorm_partial_bfloat16(GM_ADDR x, GM_ADDR ws, int64_t totalLength, int64_t numBlocks,
                                   int64_t blockLength, uint32_t tileElems, float p, int32_t mode, void *stream)
{
    norm_partial_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, ws, totalLength, blockLength, static_cast<int32_t>(tileElems), p, mode, NormInitValue(mode));
}

void launch_fnorm_final_float(GM_ADDR ws, GM_ADDR y, int32_t wsElems, float p, int32_t mode, float initVal, void *stream)
{
    norm_final_kernel<float><<<1, nullptr, stream>>>(ws, y, wsElems, p, mode, initVal);
}

void launch_fnorm_final_half(GM_ADDR ws, GM_ADDR y, int32_t wsElems, float p, int32_t mode, float initVal, void *stream)
{
    norm_final_kernel<half><<<1, nullptr, stream>>>(ws, y, wsElems, p, mode, initVal);
}

void launch_fnorm_final_bfloat16(GM_ADDR ws, GM_ADDR y, int32_t wsElems, float p, int32_t mode, float initVal, void *stream)
{
    norm_final_kernel<bfloat16_t><<<1, nullptr, stream>>>(ws, y, wsElems, p, mode, initVal);
}

}
