/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_plugin.cpp
 * \brief ForeachNorm API layer - torch bindings (compiled with g++)
 */

#include <cmath>
#include <limits>
#include <vector>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[] y");
}

static std::vector<torch::Tensor> foreach_norm_impl_meta(const torch::List<torch::Tensor> &x, double scalar)
{
    (void)scalar;
    std::vector<torch::Tensor> y;
    y.reserve(x.size());
    for (size_t i = 0; i < x.size(); ++i) {
        y.emplace_back(torch::empty({}, x[i].options()));
    }
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_impl_meta);
}

static std::vector<torch::Tensor> foreach_norm_impl_npu(const torch::List<torch::Tensor> &x, double scalar)
{
    std::vector<torch::Tensor> y;
    const int64_t n = static_cast<int64_t>(x.size());
    if (n == 0) {
        return y;
    }

    torch::Tensor first = x[0];
    const c10::OptionalDeviceGuard guard(first.device());
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    const auto dtype = first.scalar_type();
    TORCH_CHECK(dtype == torch::kFloat32 || dtype == torch::kFloat16 || dtype == torch::kBFloat16,
                "foreach_norm: unsupported dtype");

    const float p = static_cast<float>(scalar);
    int32_t mode = 0; // 0: sum-pow, 1: max (p=+inf), 2: min (p=-inf)
    if (std::isinf(p)) {
        mode = (p > 0.0f) ? 1 : 2;
    }
    float initVal = 0.0f;
    if (mode == 1) {
        initVal = -std::numeric_limits<float>::infinity();
    } else if (mode == 2) {
        initVal = std::numeric_limits<float>::infinity();
    }

    struct NormTask {
        GM_ADDR xPtr;
        GM_ADDR wsPtr;
        GM_ADDR yPtr;
        int64_t total;
        int64_t numBlocks;
        int64_t blockLength;
        uint32_t tileElems;
        int32_t wsElems;
    };

    std::vector<NormTask> tasks;
    std::vector<torch::Tensor> keepAlive;
    tasks.reserve(static_cast<size_t>(n));
    keepAlive.reserve(static_cast<size_t>(n) * 3);
    y.reserve(static_cast<size_t>(n));

    for (int64_t i = 0; i < n; ++i) {
        torch::Tensor t = x[i];
        TORCH_CHECK(t.scalar_type() == dtype,
                    "foreach_norm: all tensors in the list must share the same dtype");
        torch::Tensor tc = t.contiguous();
        const int64_t total = tc.numel();

        // 16-element storage so the kernel can write a 32B-aligned block; the
        // returned output is the scalar view of element 0.
        torch::Tensor outFull = torch::empty({16}, tc.options());
        torch::Tensor out = outFull.select(0, 0);

        int64_t numBlocks = 1;
        int64_t blockLength = 1;
        uint32_t tileElems = 1024;
        std::tie(numBlocks, blockLength, tileElems) =
            calc_foreach_norm_tiling(total, static_cast<int32_t>(tc.element_size()));

        const int64_t wsLen = numBlocks * 8;
        torch::Tensor ws = torch::empty(
            {wsLen}, torch::TensorOptions().dtype(torch::kFloat32).device(tc.device()));

        NormTask task;
        task.xPtr = (GM_ADDR)tc.data_ptr();
        task.wsPtr = (GM_ADDR)ws.data_ptr();
        task.yPtr = (GM_ADDR)outFull.data_ptr();
        task.total = total;
        task.numBlocks = numBlocks;
        task.blockLength = blockLength;
        task.tileElems = tileElems;
        task.wsElems = static_cast<int32_t>(wsLen);
        tasks.push_back(task);
        keepAlive.push_back(tc);
        keepAlive.push_back(ws);
        keepAlive.push_back(outFull);
        y.push_back(out);
    }

    const float pp = p;
    const int32_t mmode = mode;
    const float iinit = initVal;

    auto acl_call = [=]() -> int {
        for (const auto &tk : tasks) {
            if (dtype == torch::kFloat32) {
                launch_fnorm_partial_float(tk.xPtr, tk.wsPtr, tk.total, tk.numBlocks, tk.blockLength,
                                           tk.tileElems, pp, mmode, stream);
                launch_fnorm_final_float(tk.wsPtr, tk.yPtr, tk.wsElems, pp, mmode, iinit, stream);
            } else if (dtype == torch::kFloat16) {
                launch_fnorm_partial_half(tk.xPtr, tk.wsPtr, tk.total, tk.numBlocks, tk.blockLength,
                                          tk.tileElems, pp, mmode, stream);
                launch_fnorm_final_half(tk.wsPtr, tk.yPtr, tk.wsElems, pp, mmode, iinit, stream);
            } else {
                launch_fnorm_partial_bfloat16(tk.xPtr, tk.wsPtr, tk.total, tk.numBlocks, tk.blockLength,
                                              tk.tileElems, pp, mmode, stream);
                launch_fnorm_final_bfloat16(tk.wsPtr, tk.yPtr, tk.wsElems, pp, mmode, iinit, stream);
            }
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_impl_npu);
}

} // namespace cann_bench
