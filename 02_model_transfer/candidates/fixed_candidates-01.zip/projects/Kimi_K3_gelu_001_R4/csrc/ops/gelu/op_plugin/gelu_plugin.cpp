/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include <string>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/gelu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("gelu(Tensor x, str approximate=\"none\") -> Tensor");
}

torch::Tensor gelu_meta(const torch::Tensor &x, const std::string &approximate)
{
    TORCH_CHECK(x.dim() <= 8, "Gelu input dimension must be in [0, 8].");
    TORCH_CHECK(approximate == "none" || approximate == "tanh", "approximate must be 'none' or 'tanh'.");
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("gelu", gelu_meta);
}

torch::Tensor gelu_npu(const torch::Tensor &x, const std::string &approximate)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto xContig = x.contiguous();
    auto z = gelu_meta(xContig, approximate);
    if (xContig.numel() == 0) {
        return z;
    }
    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t totalLength = xContig.numel();
    int64_t numBlocks, blockLength, tileSize;
    std::tie(numBlocks, blockLength, tileSize) = calc_gelu_tiling_params(totalLength);
    int64_t approximateMode = (approximate == "tanh") ? 1 : 0;

    auto x_ptr = (GM_ADDR)xContig.data_ptr();
    auto z_ptr = (GM_ADDR)z.data_ptr();

    auto acl_call = [=]() -> int {
        if (xContig.scalar_type() == torch::kFloat32) {
            GELU_KERNEL_LAUNCH_FLOAT(x_ptr, z_ptr, totalLength, numBlocks, blockLength, tileSize, approximateMode, stream);
        } else if (xContig.scalar_type() == torch::kFloat16) {
            GELU_KERNEL_LAUNCH_HALF(x_ptr, z_ptr, totalLength, numBlocks, blockLength, tileSize, approximateMode, stream);
        } else if (xContig.scalar_type() == torch::kBFloat16) {
            GELU_KERNEL_LAUNCH_BFLOAT16(x_ptr, z_ptr, totalLength, numBlocks, blockLength, tileSize, approximateMode, stream);
        } else {
            TORCH_CHECK(false, "Gelu only supports float32, float16 and bfloat16.");
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Gelu", acl_call);
    return z;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("gelu", gelu_npu);
}

} // namespace cann_bench
