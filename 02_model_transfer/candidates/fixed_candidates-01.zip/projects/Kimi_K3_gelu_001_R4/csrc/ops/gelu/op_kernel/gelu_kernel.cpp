/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t GELU_APPROX_NONE = 0;
constexpr static int64_t GELU_APPROX_TANH = 1;
constexpr static float INV_SQRT2 = 0.70710678118654752440f;
constexpr static float SQRT_2_OVER_PI = 0.79788456080286535588f;
constexpr static float GELU_TANH_COEF = 0.044715f;
// |z| beyond 44 makes tanh saturate to exactly +-1 in fp32
constexpr static float TANH_Z_CLAMP = 44.0f;

// tanh approximate mode: y = (0.5*x) * (1 + tanh(z)), z clamped into tanh saturation region
template <typename T>
__aicore__ __inline__ void GeluTanhTile(AscendC::LocalTensor<float> X, AscendC::LocalTensor<T> yLocal,
                                        AscendC::LocalTensor<float> sA, AscendC::LocalTensor<float> sB,
                                        int64_t n)
{
    AscendC::Mul(sA, X, X, n);
    AscendC::Mul(sA, sA, X, n);
    AscendC::Muls(sA, sA, GELU_TANH_COEF, n);
    AscendC::Add(sA, sA, X, n);
    AscendC::Muls(sA, sA, SQRT_2_OVER_PI, n);
    AscendC::Maxs(sA, sA, -TANH_Z_CLAMP, n);
    AscendC::Mins(sA, sA, TANH_Z_CLAMP, n);
    AscendC::Tanh(sB, sA, n);
    AscendC::Adds(sB, sB, 1.0f, n);
    AscendC::Muls(sA, X, 0.5f, n);
    if constexpr (std::is_same<T, float>::value) {
        AscendC::Mul(yLocal, sA, sB, n);
    } else {
        AscendC::Mul(sA, sA, sB, n);
        AscendC::Cast(yLocal, sA, AscendC::RoundMode::CAST_RINT, n);
    }
}

// exact mode: y = (0.5*x) * u, u = erfc(-x/sqrt(2)) evaluated without cancellation.
// erfc(z) for z >= 0 via the classic rational form (fractional error < 1.2e-7):
//   t = 1/(1+0.5z); erfc(z) = t * exp(-z*z - 1.26551223 + t*P(t))
// then u = erfc(z) for v < 0 and u = 2 - erfc(z) for v >= 0, blended arithmetically.
template <typename T>
__aicore__ __inline__ void GeluErfTile(AscendC::LocalTensor<float> X, AscendC::LocalTensor<T> yLocal,
                                       AscendC::LocalTensor<float> sA, AscendC::LocalTensor<float> sB,
                                       AscendC::LocalTensor<float> sC, AscendC::LocalTensor<float> sD,
                                       AscendC::LocalTensor<float> sE, AscendC::LocalTensor<float> sF,
                                       int64_t n)
{
    // sA = v = x / sqrt(2)
    AscendC::Muls(sA, X, INV_SQRT2, n);
    // sB = z = |v|
    AscendC::Abs(sB, sA, n);
    // sC = z*z
    AscendC::Mul(sC, sB, sB, n);
    // sD = r = min(1 + 0.5*z, 1e30) to keep reciprocal finite for z = inf
    AscendC::Muls(sD, sB, 0.5f, n);
    AscendC::Adds(sD, sD, 1.0f, n);
    AscendC::Mins(sD, sD, 1.0e30f, n);
    // sE = t = 1/r, one Newton refinement for near-correct rounding
    AscendC::Reciprocal(sE, sD, n);
    AscendC::Mul(sF, sD, sE, n);
    AscendC::Muls(sF, sF, -1.0f, n);
    AscendC::Adds(sF, sF, 2.0f, n);
    AscendC::Mul(sE, sE, sF, n);
    // sF = P(t), Horner from the highest coefficient
    AscendC::Duplicate(sF, 0.17087277f, n);
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Adds(sF, sF, -0.82215223f, n);
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Adds(sF, sF, 1.48851587f, n);
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Adds(sF, sF, -1.13520398f, n);
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Adds(sF, sF, 0.27886807f, n);
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Adds(sF, sF, -0.18628806f, n);
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Adds(sF, sF, 0.09678418f, n);
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Adds(sF, sF, 0.37409196f, n);
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Adds(sF, sF, 1.00002368f, n);
    // sF = earg = t*P - z*z - 1.26551223
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Sub(sF, sF, sC, n);
    AscendC::Adds(sF, sF, -1.26551223f, n);
    // sC = er = t * exp(earg) = erfc(z)   (z*z no longer needed, reuse sC)
    AscendC::Exp(sC, sF, n);
    AscendC::Mul(sC, sC, sE, n);
    // sF = 2 - 2*er
    AscendC::Muls(sF, sC, -2.0f, n);
    AscendC::Adds(sF, sF, 2.0f, n);
    // sE = step = clamp(v * 1e38, 0, 1): 1 for v >= 0, 0 for v < 0 (NaN keeps er NaN anyway)
    AscendC::Muls(sE, sA, 1.0e38f, n);
    AscendC::Maxs(sE, sE, 0.0f, n);
    AscendC::Mins(sE, sE, 1.0f, n);
    // sC = u = er + step * (2 - 2*er)
    AscendC::Mul(sF, sF, sE, n);
    AscendC::Add(sC, sC, sF, n);
    // y = (0.5 * x) * u
    AscendC::Muls(sA, X, 0.5f, n);
    if constexpr (std::is_same<T, float>::value) {
        AscendC::Mul(yLocal, sA, sC, n);
    } else {
        AscendC::Mul(sA, sA, sC, n);
        AscendC::Cast(yLocal, sA, AscendC::RoundMode::CAST_RINT, n);
    }
}

template <typename T>
__global__ __aicore__ void gelu_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength,
                                       uint32_t tileSize, int64_t approximateMode)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> xFloatBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufA;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufB;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufC;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufD;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufE;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufF;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(xFloatBuf, tileSize);
    pipe.InitBuffer(bufA, tileSize);
    pipe.InitBuffer(bufB, tileSize);
    pipe.InitBuffer(bufC, tileSize);
    pipe.InitBuffer(bufD, tileSize);
    pipe.InitBuffer(bufE, tileSize);
    pipe.InitBuffer(bufF, tileSize);

    AscendC::LocalTensor<float> xf = xFloatBuf.Get<float>();
    AscendC::LocalTensor<float> sA = bufA.Get<float>();
    AscendC::LocalTensor<float> sB = bufB.Get<float>();
    AscendC::LocalTensor<float> sC = bufC.Get<float>();
    AscendC::LocalTensor<float> sD = bufD.Get<float>();
    AscendC::LocalTensor<float> sE = bufE.Get<float>();
    AscendC::LocalTensor<float> sF = bufF.Get<float>();

    int64_t blockIdx = AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * blockIdx);

    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t elementNumPerTile = tileSize / sizeof(float);
    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;
    int64_t loopCount = tileNum + (tailTileElementNum > 0 ? 1 : 0);

    for (int64_t i = 0; i < loopCount; ++i) {
        int64_t elemNum = (i < tileNum) ? elementNumPerTile : tailTileElementNum;
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elemNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();
        AscendC::LocalTensor<float> X;
        if constexpr (std::is_same<T, float>::value) {
            X = xLocal;
        } else {
            AscendC::Cast(xf, xLocal, AscendC::RoundMode::CAST_NONE, elemNum);
            X = xf;
        }
        if (approximateMode == GELU_APPROX_TANH) {
            GeluTanhTile<T>(X, yLocal, sA, sB, elemNum);
        } else {
            GeluErfTile<T>(X, yLocal, sA, sB, sC, sD, sE, sF, elemNum);
        }

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_gelu_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 2048;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (totalLength <= 0) {
        return std::make_tuple(1, 0, 1024);
    }
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    // 4 queue buffers (depth 2 x 2) + 7 fp32 scratch buffers share UB, keep margin
    int64_t tileSize = static_cast<int64_t>(ubSize) / 12;
    tileSize = tileSize / 256 * 256;
    if (tileSize < 1024) {
        tileSize = 1024;
    }
    if (tileSize > 32768) {
        tileSize = 32768;
    }
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_gelu_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                              int64_t blockLength, uint32_t tileSize, int64_t approximateMode, void *stream)
{
    gelu_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, approximateMode);
}

void launch_gelu_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                             int64_t blockLength, uint32_t tileSize, int64_t approximateMode, void *stream)
{
    gelu_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, approximateMode);
}

void launch_gelu_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                 int64_t blockLength, uint32_t tileSize, int64_t approximateMode, void *stream)
{
    gelu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, approximateMode);
}

}
