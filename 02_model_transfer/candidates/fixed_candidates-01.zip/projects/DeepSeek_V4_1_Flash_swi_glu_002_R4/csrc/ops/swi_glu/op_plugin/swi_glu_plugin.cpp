/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_plugin.cpp
 * \brief SwiGLU torch plugin.
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include <tuple>
#include <vector>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"
#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    int64_t rank = input.dim();
    int64_t d = dim < 0 ? dim + rank : dim;
    TORCH_CHECK(rank >= 1, "swi_glu requires at least 1 dimension");
    TORCH_CHECK(d >= 0 && d < rank, "dim out of range for swi_glu");
    int64_t dimSize = input.size(d);
    TORCH_CHECK(dimSize % 2 == 0, "The split dim size must be even for swi_glu");
    std::vector<int64_t> out_shape(input.sizes().begin(), input.sizes().end());
    out_shape[d] = dimSize / 2;
    return torch::empty(out_shape, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto output = swi_glu_meta(input, dim);
    auto x = input.contiguous();
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t rank = x.dim();
    int64_t d = dim < 0 ? dim + rank : dim;
    int64_t half = x.size(d) / 2;
    int64_t inner = 1;
    for (int64_t i = d + 1; i < rank; ++i) {
        inner *= x.size(i);
    }
    int64_t outStride = half * inner;
    int64_t totalOut = x.numel() / 2;
    if (totalOut <= 0) {
        return output;
    }

    int64_t numBlocks = 1;
    int64_t blockLength = totalOut;
    uint32_t tileElems = 0;
    std::tie(numBlocks, blockLength, tileElems) = calc_swi_glu_tiling_params(totalOut);

    auto input_ptr = (GM_ADDR)x.data_ptr();
    auto output_ptr = (GM_ADDR)output.data_ptr();

    auto acl_call = [=]() -> int {
        if (x.scalar_type() == torch::kFloat32) {
            launch_swi_glu_kernel_float(input_ptr, output_ptr, totalOut,
                                        numBlocks, blockLength, outStride, tileElems, stream);
        } else if (x.scalar_type() == torch::kFloat16) {
            launch_swi_glu_kernel_half(input_ptr, output_ptr, totalOut,
                                       numBlocks, blockLength, outStride, tileElems, stream);
        } else if (x.scalar_type() == torch::kBFloat16) {
            launch_swi_glu_kernel_bfloat16(input_ptr, output_ptr, totalOut,
                                           numBlocks, blockLength, outStride, tileElems, stream);
        } else {
            TORCH_CHECK(false, "Unsupported dtype for swi_glu");
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return output;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
