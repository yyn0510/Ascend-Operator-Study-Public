/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGLU kernel, host tiling and launch wrappers.
 *
 * Layout: input is split on `dim` into x0 / x1.  Each "row" of the output is
 * contiguous with `outStride = half * inner` elements; the matching x0 data of
 * a row is a contiguous `outStride` block of the input, and x1 is the next
 * `outStride` block.  Small `outStride` (e.g. split on the last dim) can use a
 * batched multi-block DataCopyPad path when the byte stride is 32B aligned.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr int32_t SWI_GLU_PIPELINE_DEPTH = 2;
constexpr int64_t SWI_GLU_MAX_BLOCK_COUNT = 65535;

template <typename T>
__aicore__ inline void SwiGluCompute(const AscendC::LocalTensor<T> &outLocal,
                                     const AscendC::LocalTensor<T> &in0,
                                     const AscendC::LocalTensor<T> &in1,
                                     AscendC::TBuf<AscendC::TPosition::VECCALC> &f0Buf,
                                     AscendC::TBuf<AscendC::TPosition::VECCALC> &f1Buf,
                                     AscendC::TBuf<AscendC::TPosition::VECCALC> &tmpBuf,
                                     uint32_t len)
{
    if constexpr (std::is_same_v<T, float>) {
        AscendC::Muls(outLocal, in0, -1.0f, len);
        AscendC::Exp(outLocal, outLocal, len);
        AscendC::Adds(outLocal, outLocal, 1.0f, len);
        AscendC::Div(outLocal, in0, outLocal, len);
        AscendC::Mul(outLocal, outLocal, in1, len);
    } else {
        AscendC::LocalTensor<float> f0 = f0Buf.Get<float>();
        AscendC::LocalTensor<float> f1 = f1Buf.Get<float>();
        AscendC::LocalTensor<float> tmp = tmpBuf.Get<float>();
        AscendC::Cast(f0, in0, AscendC::RoundMode::CAST_NONE, len);
        AscendC::Cast(f1, in1, AscendC::RoundMode::CAST_NONE, len);
        AscendC::Muls(tmp, f0, -1.0f, len);
        AscendC::Exp(tmp, tmp, len);
        AscendC::Adds(tmp, tmp, 1.0f, len);
        AscendC::Div(f0, f0, tmp, len);
        AscendC::Mul(f0, f0, f1, len);
        if constexpr (std::is_same_v<T, bfloat16_t>) {
            AscendC::Cast(outLocal, f0, AscendC::RoundMode::CAST_RINT, len);
        } else {
            AscendC::Cast(outLocal, f0, AscendC::RoundMode::CAST_NONE, len);
        }
    }
}

template <typename T>
__global__ __aicore__ void swi_glu_kernel(GM_ADDR input, GM_ADDR output,
                                          int64_t totalOut, int64_t blockLength,
                                          int64_t outStride, uint32_t tileElems)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, SWI_GLU_PIPELINE_DEPTH> inQueue0;
    AscendC::TQue<AscendC::QuePosition::VECIN, SWI_GLU_PIPELINE_DEPTH> inQueue1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, SWI_GLU_PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> f0Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> f1Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf;

    pipe.InitBuffer(inQueue0, SWI_GLU_PIPELINE_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(inQueue1, SWI_GLU_PIPELINE_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(outQueue, SWI_GLU_PIPELINE_DEPTH, tileElems * sizeof(T));
    if constexpr (!std::is_same_v<T, float>) {
        pipe.InitBuffer(f0Buf, tileElems * sizeof(float));
        pipe.InitBuffer(f1Buf, tileElems * sizeof(float));
        pipe.InitBuffer(tmpBuf, tileElems * sizeof(float));
    }

    AscendC::GlobalTensor<T> inGm;
    AscendC::GlobalTensor<T> outGm;
    inGm.SetGlobalBuffer((__gm__ T *)input);
    outGm.SetGlobalBuffer((__gm__ T *)output);

    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t start = blockIdx * blockLength;
    if (start >= totalOut) {
        return;
    }
    int64_t curBlockLen = totalOut - start;
    if (curBlockLen > blockLength) {
        curBlockLen = blockLength;
    }

    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    int64_t processed = 0;
    while (processed < curBlockLen) {
        int64_t n = start + processed;
        int64_t o = n / outStride;
        int64_t s = n - o * outStride;
        int64_t remainRow = outStride - s;
        int64_t remainTotal = curBlockLen - processed;

        if (s == 0 && outStride > 0 && outStride <= static_cast<int64_t>(tileElems) &&
            (outStride * static_cast<int64_t>(sizeof(T))) % 32 == 0) {
            int64_t rowsAvail = remainTotal / outStride;
            int64_t rowsFit = static_cast<int64_t>(tileElems) / outStride;
            int64_t rows = rowsAvail < rowsFit ? rowsAvail : rowsFit;
            if (rows > SWI_GLU_MAX_BLOCK_COUNT) {
                rows = SWI_GLU_MAX_BLOCK_COUNT;
            }
            if (rows >= 1) {
                uint32_t blkLenBytes = static_cast<uint32_t>(outStride * static_cast<int64_t>(sizeof(T)));
                AscendC::DataCopyExtParams cparams{static_cast<uint16_t>(rows), blkLenBytes,
                                                   blkLenBytes, 0, 0};
                int64_t base = o * 2 * outStride;

                auto in0 = inQueue0.AllocTensor<T>();
                auto in1 = inQueue1.AllocTensor<T>();
                AscendC::DataCopyPad(in0, inGm[base], cparams, padParams);
                AscendC::DataCopyPad(in1, inGm[base + outStride], cparams, padParams);
                inQueue0.EnQue(in0);
                inQueue1.EnQue(in1);
                in0 = inQueue0.DeQue<T>();
                in1 = inQueue1.DeQue<T>();

                auto outLocal = outQueue.AllocTensor<T>();
                uint32_t len = static_cast<uint32_t>(rows * outStride);
                SwiGluCompute<T>(outLocal, in0, in1, f0Buf, f1Buf, tmpBuf, len);

                outQueue.EnQue(outLocal);
                inQueue0.FreeTensor(in0);
                inQueue1.FreeTensor(in1);
                outLocal = outQueue.DeQue<T>();

                AscendC::DataCopyExtParams sp{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
                AscendC::DataCopyPad(outGm[o * outStride], outLocal, sp);
                outQueue.FreeTensor(outLocal);

                processed += rows * outStride;
                continue;
            }
        }

        int64_t chunk = remainTotal < remainRow ? remainTotal : remainRow;
        if (chunk > static_cast<int64_t>(tileElems)) {
            chunk = static_cast<int64_t>(tileElems);
        }
        uint32_t len = static_cast<uint32_t>(chunk);
        int64_t src0 = o * 2 * outStride + s;
        int64_t src1 = src0 + outStride;
        int64_t dst = n;

        AscendC::DataCopyExtParams cparams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};

        auto in0 = inQueue0.AllocTensor<T>();
        auto in1 = inQueue1.AllocTensor<T>();
        AscendC::DataCopyPad(in0, inGm[src0], cparams, padParams);
        AscendC::DataCopyPad(in1, inGm[src1], cparams, padParams);
        inQueue0.EnQue(in0);
        inQueue1.EnQue(in1);
        in0 = inQueue0.DeQue<T>();
        in1 = inQueue1.DeQue<T>();

        auto outLocal = outQueue.AllocTensor<T>();
        SwiGluCompute<T>(outLocal, in0, in1, f0Buf, f1Buf, tmpBuf, len);
        outQueue.EnQue(outLocal);
        inQueue0.FreeTensor(in0);
        inQueue1.FreeTensor(in1);
        outLocal = outQueue.DeQue<T>();

        AscendC::DataCopyPad(outGm[dst], outLocal, cparams);
        outQueue.FreeTensor(outLocal);

        processed += chunk;
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_tiling_params(int64_t totalOut)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (ubSize == 0) {
        ubSize = 192 * 1024;
    }

    int64_t tile = static_cast<int64_t>(ubSize) / 32;
    tile = (tile / 64) * 64;
    if (tile < 256) {
        tile = 256;
    }
    if (tile > 32768) {
        tile = 32768;
    }

    int64_t numBlocks = coreNum;
    if (totalOut < numBlocks) {
        numBlocks = totalOut;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalOut + numBlocks - 1) / numBlocks;

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tile));
}

extern "C" {
void launch_swi_glu_kernel_float(GM_ADDR input, GM_ADDR output, int64_t totalOut,
                                 int64_t numBlocks, int64_t blockLength,
                                 int64_t outStride, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, blockLength, outStride, tileElems);
}

void launch_swi_glu_kernel_half(GM_ADDR input, GM_ADDR output, int64_t totalOut,
                                int64_t numBlocks, int64_t blockLength,
                                int64_t outStride, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, blockLength, outStride, tileElems);
}

void launch_swi_glu_kernel_bfloat16(GM_ADDR input, GM_ADDR output, int64_t totalOut,
                                    int64_t numBlocks, int64_t blockLength,
                                    int64_t outStride, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, blockLength, outStride, tileElems);
}
}
