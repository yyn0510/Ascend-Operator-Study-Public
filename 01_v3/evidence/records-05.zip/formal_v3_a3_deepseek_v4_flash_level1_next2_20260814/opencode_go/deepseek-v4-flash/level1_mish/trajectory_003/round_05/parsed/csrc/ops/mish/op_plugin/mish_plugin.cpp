#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/mish_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("mish(Tensor x) -> Tensor");
}

torch::Tensor mish_meta(const torch::Tensor &x)
{
    TORCH_CHECK(x.scalar_type() == at::kHalf ||
                x.scalar_type() == at::kFloat ||
                x.scalar_type() == at::kBFloat16,
                "mish: unsupported dtype");
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("mish", mish_meta);
}

torch::Tensor mish_npu(const torch::Tensor &x)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto z = mish_meta(x);
    int64_t totalLength = x.numel();
    if (totalLength == 0) {
        return z;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    int64_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_mish_tiling_params(totalLength);

    auto x_ptr = (GM_ADDR)x.data_ptr();
    auto z_ptr = (GM_ADDR)z.data_ptr();

    auto acl_call = [=]() -> int {
        if (x.scalar_type() == at::kHalf) {
            launch_mish_kernel_half(x_ptr, z_ptr, totalLength, numBlocks,
                                    blockLength, static_cast<uint32_t>(tileSize), stream);
        } else if (x.scalar_type() == at::kFloat) {
            launch_mish_kernel_float(x_ptr, z_ptr, totalLength, numBlocks,
                                     blockLength, static_cast<uint32_t>(tileSize), stream);
        } else if (x.scalar_type() == at::kBFloat16) {
            launch_mish_kernel_bfloat16(x_ptr, z_ptr, totalLength, numBlocks,
                                        blockLength, static_cast<uint32_t>(tileSize), stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Mish", acl_call);
    return z;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("mish", mish_npu);
}

} // namespace cann_bench
