#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;
constexpr static float RECIP_CLAMP_MAX = 3.402823466e+38f;

template <typename T>
__aicore__ inline void ConvertInputToFloat(AscendC::LocalTensor<float> dst,
                                           AscendC::LocalTensor<T> src,
                                           int32_t count)
{
    if constexpr (std::is_same<T, float>::value) {
        AscendC::Muls(dst, src, 1.0f, count);
    } else {
        AscendC::Cast(dst, src, AscendC::RoundMode::CAST_NONE, count);
    }
}

template <typename T>
__aicore__ inline void ConvertFloatToOutput(AscendC::LocalTensor<T> dst,
                                            AscendC::LocalTensor<float> src,
                                            int32_t count)
{
    if constexpr (std::is_same<T, float>::value) {
        AscendC::Muls(dst, src, 1.0f, count);
    } else {
        AscendC::Cast(dst, src, AscendC::RoundMode::CAST_RINT, count);
    }
}

__aicore__ inline void RefineReciprocal(AscendC::LocalTensor<float> out,
                                        AscendC::LocalTensor<float> in,
                                        AscendC::LocalTensor<float> tmp,
                                        int32_t count)
{
    AscendC::Reciprocal(out, in, count);

    AscendC::Mins(tmp, in, RECIP_CLAMP_MAX, count);
    AscendC::Mul(tmp, tmp, out, count);
    AscendC::Muls(tmp, tmp, -1.0f, count);
    AscendC::Adds(tmp, tmp, 2.0f, count);
    AscendC::Mul(out, out, tmp, count);

    AscendC::Mins(tmp, in, RECIP_CLAMP_MAX, count);
    AscendC::Mul(tmp, tmp, out, count);
    AscendC::Muls(tmp, tmp, -1.0f, count);
    AscendC::Adds(tmp, tmp, 2.0f, count);
    AscendC::Mul(out, out, tmp, count);
}

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength,
                                       int64_t blockLength,
                                       uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) /
                                static_cast<int64_t>(sizeof(T));
    if (elementNumPerTile <= 0) {
        return;
    }

    uint32_t floatBufBytes = static_cast<uint32_t>(
        elementNumPerTile * static_cast<int64_t>(sizeof(float)));

    AscendC::TBuf<AscendC::TPosition::VECCALC> xFloatBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> aFloatBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tFloatBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpFloatBuf;
    pipe.InitBuffer(xFloatBuf, floatBufBytes);
    pipe.InitBuffer(aFloatBuf, floatBufBytes);
    pipe.InitBuffer(tFloatBuf, floatBufBytes);
    pipe.InitBuffer(tmpFloatBuf, floatBufBytes);

    auto xF = xFloatBuf.Get<float>();
    auto aF = aFloatBuf.Get<float>();
    auto tF = tFloatBuf.Get<float>();
    auto tmpF = tmpFloatBuf.Get<float>();

    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - AscendC::GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailElements = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        uint32_t blockLen = static_cast<uint32_t>(
            elementNumPerTile * static_cast<int64_t>(sizeof(T)));
        AscendC::DataCopyExtParams copyParams{1, blockLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xInT = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xInT, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xInT);
        xInT = inQueue.DeQue<T>();

        int32_t count = static_cast<int32_t>(elementNumPerTile);

        ConvertInputToFloat(xF, xInT, count);

        AscendC::Muls(tF, xF, -1.0f, count);
        AscendC::Exp(aF, tF, count);
        AscendC::Muls(aF, aF, 2.0f, count);
        AscendC::Adds(aF, aF, 1.0f, count);

        RefineReciprocal(tF, aF, tmpF, count);
        AscendC::Add(aF, aF, tF, count);
        RefineReciprocal(tF, aF, tmpF, count);
        AscendC::Muls(tF, tF, 2.0f, count);
        AscendC::Mul(aF, tF, xF, count);

        auto zLocal = outQueue.AllocTensor<T>();
        ConvertFloatToOutput(zLocal, aF, count);
        outQueue.EnQue(zLocal);
        inQueue.FreeTensor(xInT);

        zLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], zLocal, copyParams);
        outQueue.FreeTensor(zLocal);
    }

    if (tailElements > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        uint32_t blockLen = static_cast<uint32_t>(
            tailElements * static_cast<int64_t>(sizeof(T)));
        AscendC::DataCopyExtParams copyParams{1, blockLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xInT = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xInT, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xInT);
        xInT = inQueue.DeQue<T>();

        int32_t count = static_cast<int32_t>(tailElements);

        ConvertInputToFloat(xF, xInT, count);

        AscendC::Muls(tF, xF, -1.0f, count);
        AscendC::Exp(aF, tF, count);
        AscendC::Muls(aF, aF, 2.0f, count);
        AscendC::Adds(aF, aF, 1.0f, count);

        RefineReciprocal(tF, aF, tmpF, count);
        AscendC::Add(aF, aF, tF, count);
        RefineReciprocal(tF, aF, tmpF, count);
        AscendC::Muls(tF, tF, 2.0f, count);
        AscendC::Mul(aF, tF, xF, count);

        auto zLocal = outQueue.AllocTensor<T>();
        ConvertFloatToOutput(zLocal, aF, count);
        outQueue.EnQue(zLocal);
        inQueue.FreeTensor(xInT);

        zLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], zLocal, copyParams);
        outQueue.FreeTensor(zLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;

    if (totalLength <= 0) {
        return std::make_tuple(1, 0, static_cast<int64_t>(32));
    }

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 192 * 1024;
    }

    int64_t coreNum = static_cast<int64_t>(ascendcPlatform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t minBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    int64_t numBlocks = std::min(coreNum, minBlocks);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    uint64_t rawTileSize = ubSize / (static_cast<uint64_t>(PIPELINE_DEPTH) * 8);
    uint64_t alignedTileSize = (rawTileSize / 32) * 32;
    if (alignedTileSize < 32) {
        alignedTileSize = 32;
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<int64_t>(alignedTileSize));
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y,
                              int64_t totalLength,
                              int64_t numBlocks,
                              int64_t blockLength,
                              uint32_t tileSize,
                              void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y,
                             int64_t totalLength,
                             int64_t numBlocks,
                             int64_t blockLength,
                             uint32_t tileSize,
                             void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y,
                                 int64_t totalLength,
                                 int64_t numBlocks,
                                 int64_t blockLength,
                                 uint32_t tileSize,
                                 void *stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
