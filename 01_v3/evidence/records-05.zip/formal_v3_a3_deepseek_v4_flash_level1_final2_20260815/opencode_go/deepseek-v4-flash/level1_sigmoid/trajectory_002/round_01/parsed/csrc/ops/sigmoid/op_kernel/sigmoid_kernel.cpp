#include <algorithm>
#include <cstdint>
#include <tuple>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

using namespace AscendC;

constexpr static uint32_t PIPELINE_DEPTH = 2;
constexpr static uint32_t TILING_BUFFER_DIVISOR = 6;

template <typename T>
__global__ __aicore__ void sigmoid_kernel(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize)
{
    TPipe pipe;
    GlobalTensor<T> xGm;
    GlobalTensor<T> yGm;
    TQue<QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    TQue<QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);

    int64_t blockIdx = GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * blockIdx);

    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t elementNumPerTile = tileSize / sizeof(T);
    if (elementNumPerTile <= 0) {
        elementNumPerTile = 1;
    }

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        uint32_t copyBytes = static_cast<uint32_t>(elementNumPerTile * sizeof(T));
        DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
        DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);

        xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();
        Sigmoid(yLocal, xLocal, static_cast<uint32_t>(elementNumPerTile));
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        DataCopyPad(yGm[offset], yLocal, copyParams, padParams);
        outQueueY.FreeTensor(yLocal);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        uint32_t copyBytes = static_cast<uint32_t>(tailTileElementNum * sizeof(T));
        DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
        DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);

        xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();
        Sigmoid(yLocal, xLocal, static_cast<uint32_t>(tailTileElementNum));
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        DataCopyPad(yGm[offset], yLocal, copyParams, padParams);
        outQueueY.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;

    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 192 * 1024;
    }

    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = std::min<int64_t>(
        coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks < 1) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    uint64_t tileSize = ubSize / TILING_BUFFER_DIVISOR;
    tileSize = (tileSize / 32) * 32;
    if (tileSize < 32) {
        tileSize = 32;
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<int64_t>(tileSize));
}

extern "C" {

void launch_sigmoid_kernel_float(
    GM_ADDR x, GM_ADDR y, int64_t totalLength,
    int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void *stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(
    GM_ADDR x, GM_ADDR y, int64_t totalLength,
    int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void *stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(
    GM_ADDR x, GM_ADDR y, int64_t totalLength,
    int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void *stream)
{
    sigmoid_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

}
