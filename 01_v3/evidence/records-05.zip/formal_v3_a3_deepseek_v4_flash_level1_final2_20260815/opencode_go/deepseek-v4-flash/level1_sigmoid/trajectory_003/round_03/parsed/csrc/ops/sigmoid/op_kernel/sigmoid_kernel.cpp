#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

using namespace AscendC;

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t BUFFER_NUM = 2;
constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;

template <typename T>
__aicore__ inline void SigmoidCompute(LocalTensor<T>& xLocal, LocalTensor<T>& yLocal, int32_t count)
{
    AscendC::Muls(yLocal, xLocal, static_cast<T>(-1.0f), count);
    AscendC::Exp(yLocal, yLocal, count);
    AscendC::Adds(yLocal, yLocal, static_cast<T>(1.0f), count);
    AscendC::Reciprocal(yLocal, yLocal, count);
}

template <typename T>
__global__ __aicore__ void sigmoid_kernel(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    TPipe pipe;
    GlobalTensor<T> xGm, yGm;
    TQue<QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    TQue<QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    xGm.SetGlobalBuffer((__gm__ T *)x + GetBlockIdx() * blockLength);
    yGm.SetGlobalBuffer((__gm__ T *)y + GetBlockIdx() * blockLength);

    int64_t currentBlockLength = totalLength - GetBlockIdx() * blockLength;
    if (currentBlockLength <= 0) {
        return;
    }
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    int64_t elementNumPerTile = tileSize / sizeof(T);
    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        auto yLocal = outQueue.AllocTensor<T>();

        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        SigmoidCompute(xLocal, yLocal, static_cast<int32_t>(elementNumPerTile));

        inQueue.FreeTensor(xLocal);
        outQueue.EnQue(yLocal);
        yLocal = outQueue.DeQue<T>();

        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailTileElementNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        auto yLocal = outQueue.AllocTensor<T>();

        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        SigmoidCompute(xLocal, yLocal, static_cast<int32_t>(tailTileElementNum));

        inQueue.FreeTensor(xLocal);
        outQueue.EnQue(yLocal);
        yLocal = outQueue.DeQue<T>();

        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength)
{
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t tileSize = static_cast<int64_t>(ubSize / (PIPELINE_DEPTH * BUFFER_NUM));
    tileSize = (tileSize / 32) * 32;
    if (tileSize <= 0) {
        tileSize = 32 * 1024;
    }

    if (totalLength <= 0) {
        return std::make_tuple(1, int64_t(0), tileSize);
    }

    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    if (numBlocks > totalLength) {
        numBlocks = totalLength;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
