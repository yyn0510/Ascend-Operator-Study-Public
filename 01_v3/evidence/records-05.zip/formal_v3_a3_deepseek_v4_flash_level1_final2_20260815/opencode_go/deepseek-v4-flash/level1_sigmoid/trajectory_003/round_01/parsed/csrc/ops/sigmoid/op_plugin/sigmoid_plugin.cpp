#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/sigmoid_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("sigmoid(Tensor x) -> Tensor");
}

torch::Tensor sigmoid_meta(const torch::Tensor &x)
{
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 ||
                x.scalar_type() == torch::kHalf ||
                x.scalar_type() == torch::kBFloat16,
                "sigmoid: unsupported dtype");
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("sigmoid", sigmoid_meta);
}

torch::Tensor sigmoid_npu(const torch::Tensor &x)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto y = sigmoid_meta(x);

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t totalLength = x.numel();
    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    int64_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_sigmoid_tiling_params(totalLength);

    auto x_ptr = (GM_ADDR)x.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();

    auto acl_call = [=]() -> int {
        uint32_t tileSizeU32 = static_cast<uint32_t>(tileSize);
        if (x.scalar_type() == torch::kFloat32) {
            launch_sigmoid_kernel_float(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSizeU32, stream);
        } else if (x.scalar_type() == torch::kHalf) {
            launch_sigmoid_kernel_half(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSizeU32, stream);
        } else if (x.scalar_type() == torch::kBFloat16) {
            launch_sigmoid_kernel_bfloat16(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSizeU32, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Sigmoid", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("sigmoid", sigmoid_npu);
}

} // namespace cann_bench
