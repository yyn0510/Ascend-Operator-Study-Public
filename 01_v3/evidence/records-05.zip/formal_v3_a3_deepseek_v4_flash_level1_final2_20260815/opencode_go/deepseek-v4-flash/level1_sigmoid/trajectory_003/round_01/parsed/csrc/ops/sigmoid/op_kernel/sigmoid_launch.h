#ifndef SIGMOID_LAUNCH_H
#define SIGMOID_LAUNCH_H

#include <cstdint>
#include <tuple>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength);

extern "C" {

void launch_sigmoid_kernel_float(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize, void* stream);

void launch_sigmoid_kernel_half(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize, void* stream);

void launch_sigmoid_kernel_bfloat16(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize, void* stream);

}

#define SIGMOID_KERNEL_LAUNCH_FLOAT(x, y, len, blocks, blkLen, tileSz, stream) \
    launch_sigmoid_kernel_float(x, y, len, blocks, blkLen, tileSz, stream)

#define SIGMOID_KERNEL_LAUNCH_HALF(x, y, len, blocks, blkLen, tileSz, stream) \
    launch_sigmoid_kernel_half(x, y, len, blocks, blkLen, tileSz, stream)

#define SIGMOID_KERNEL_LAUNCH_BFLOAT16(x, y, len, blocks, blkLen, tileSz, stream) \
    launch_sigmoid_kernel_bfloat16(x, y, len, blocks, blkLen, tileSz, stream)

#endif // SIGMOID_LAUNCH_H
