#include <cstdint>
#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;
constexpr static int32_t TOTAL_BUFFER_NUM = 6;

template <typename T>
__global__ __aicore__ void sigmoid_kernel(
    GM_ADDR x, GM_ADDR z,
    int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t startOffset = blockIdx * blockLength;
    int64_t currentBlockLength = totalLength - startOffset;
    if (currentBlockLength <= 0) {
        return;
    }
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, zGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueZ;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> tmpQueue;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueZ, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpQueue, PIPELINE_DEPTH, tileSize);

    xGm.SetGlobalBuffer((__gm__ T *)x + startOffset);
    zGm.SetGlobalBuffer((__gm__ T *)z + startOffset);

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elementNumPerTile <= 0) {
        elementNumPerTile = 1;
    }

    T negOne = static_cast<T>(-1.0f);
    T one = static_cast<T>(1.0f);

    int64_t offset = 0;
    while (offset < currentBlockLength) {
        int64_t tileLen = currentBlockLength - offset;
        if (tileLen > elementNumPerTile) {
            tileLen = elementNumPerTile;
        }

        uint32_t copyBytes = static_cast<uint32_t>(tileLen * static_cast<int64_t>(sizeof(T)));
        AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto tmp1 = tmpQueue.AllocTensor<T>();
        auto tmp2 = tmpQueue.AllocTensor<T>();
        auto yLocal = outQueueZ.AllocTensor<T>();

        AscendC::Muls(tmp1, xLocal, negOne, static_cast<int32_t>(tileLen));
        AscendC::Exp(tmp2, tmp1, static_cast<int32_t>(tileLen));
        AscendC::Adds(tmp1, tmp2, one, static_cast<int32_t>(tileLen));
        AscendC::Duplicate(tmp2, one, static_cast<int32_t>(tileLen));
        AscendC::Div(yLocal, tmp2, tmp1, static_cast<int32_t>(tileLen));

        outQueueZ.EnQue(yLocal);
        tmpQueue.FreeTensor(tmp1);
        tmpQueue.FreeTensor(tmp2);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueZ.DeQue<T>();
        AscendC::DataCopyPad(zGm[offset], yLocal, copyParams);
        outQueueZ.FreeTensor(yLocal);

        offset += tileLen;
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);

    int64_t coreNum = static_cast<int64_t>(ascendcPlatform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = std::min<int64_t>(coreNum, totalLength);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = totalLength / numBlocks;
    if (totalLength % numBlocks != 0) {
        blockLength += 1;
    }

    int64_t ubBytes = static_cast<int64_t>(ubSize);
    if (ubBytes < 32) {
        ubBytes = 32;
    }
    int64_t tileSize = (ubBytes / TOTAL_BUFFER_NUM / 32) * 32;
    if (tileSize < 32) {
        tileSize = 32;
    }

    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(
    GM_ADDR x, GM_ADDR z,
    int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, z, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(
    GM_ADDR x, GM_ADDR z,
    int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, z, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(
    GM_ADDR x, GM_ADDR z,
    int64_t totalLength, int64_t numBlocks,
    int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, z, totalLength, blockLength, tileSize);
}

}
