#include <cstdint>
#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static uint32_t PIPELINE_DEPTH = 2;
constexpr static uint32_t TEMP_BUFFER_NUM = 2;
constexpr static int64_t BUFFER_NUM = static_cast<int64_t>(PIPELINE_DEPTH) * 2 + TEMP_BUFFER_NUM;

template <typename T>
__global__ __aicore__ void sigmoid_kernel(GM_ADDR x, GM_ADDR z, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t startOffset = blockIdx * blockLength;
    int64_t currentBlockLength = totalLength - startOffset;
    if (currentBlockLength <= 0) {
        return;
    }
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, zGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueZ;
    AscendC::TBuf<AscendC::TPipe> tempBuf1;
    AscendC::TBuf<AscendC::TPipe> tempBuf2;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueZ, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tempBuf1, tileSize);
    pipe.InitBuffer(tempBuf2, tileSize);

    xGm.SetGlobalBuffer((__gm__ T *)x + startOffset);
    zGm.SetGlobalBuffer((__gm__ T *)z + startOffset);

    int64_t elementNumPerTile = tileSize / static_cast<int64_t>(sizeof(T));
    if (elementNumPerTile <= 0) {
        elementNumPerTile = 1;
    }

    auto temp1 = tempBuf1.Get<T>();
    auto temp2 = tempBuf2.Get<T>();
    const T negOne = static_cast<T>(-1.0f);
    const T one = static_cast<T>(1.0f);

    int64_t offset = 0;
    while (offset < currentBlockLength) {
        int64_t tileLen = currentBlockLength - offset;
        if (tileLen > elementNumPerTile) {
            tileLen = elementNumPerTile;
        }

        int32_t calCount = static_cast<int32_t>(tileLen);
        uint32_t copyBytes = static_cast<uint32_t>(tileLen * static_cast<int64_t>(sizeof(T)));
        AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueZ.AllocTensor<T>();
        AscendC::Muls(temp1, xLocal, negOne, calCount);
        AscendC::Exp(temp2, temp1, calCount);
        AscendC::Adds(temp1, temp2, one, calCount);
        AscendC::Reciprocal(yLocal, temp1, calCount);

        outQueueZ.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueZ.DeQue<T>();
        AscendC::DataCopyPad(zGm[offset], yLocal, copyParams);
        outQueueZ.FreeTensor(yLocal);

        offset += tileLen;
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);

    int64_t coreNum = static_cast<int64_t>(ascendcPlatform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = std::min<int64_t>(coreNum, totalLength);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = totalLength / numBlocks + ((totalLength % numBlocks != 0) ? 1 : 0);

    int64_t ubBytes = static_cast<int64_t>(ubSize);
    if (ubBytes < 32) {
        ubBytes = 32;
    }
    int64_t tileSize = (ubBytes / BUFFER_NUM / 32) * 32;
    if (tileSize < 32) {
        tileSize = 32;
    }

    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR z, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, z, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR z, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, z, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(GM_ADDR x, GM_ADDR z, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, z, totalLength, blockLength, tileSize);
}

}
