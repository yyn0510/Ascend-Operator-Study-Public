#include <algorithm>
#include <cstdint>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"
#include "swi_glu_launch.h"

using namespace AscendC;

template <typename T>
__global__ __aicore__ void swi_glu_kernel(
    GM_ADDR input, GM_ADDR output,
    int64_t blockOut, int64_t outer, int64_t chunkSize, int64_t chunksPerRow,
    int64_t rowsPerTile, int64_t rowGroupsPerChunk, int64_t totalTiles,
    int64_t tilesPerBlock, int64_t tileElems)
{
    int64_t tileStart = AscendC::GetBlockIdx() * tilesPerBlock;
    if (tileStart >= totalTiles) {
        return;
    }
    int64_t tileEnd = tileStart + tilesPerBlock;
    if (tileEnd > totalTiles) {
        tileEnd = totalTiles;
    }

    AscendC::GlobalTensor<T> inGm, outGm;
    inGm.SetGlobalBuffer((__gm__ T *)input);
    outGm.SetGlobalBuffer((__gm__ T *)output);

    AscendC::TPipe pipe;
    constexpr int32_t BUF_DEPTH = 1;
    AscendC::TQue<AscendC::QuePosition::VECIN, BUF_DEPTH> inQueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, BUF_DEPTH> inQueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, BUF_DEPTH> outQueZ;
    AscendC::TBuf<AscendC::TPosition::VECCALC> f0Buf, f1Buf, tmp0Buf, tmp1Buf;

    uint32_t tileBytes = static_cast<uint32_t>(tileElems * sizeof(T));
    uint32_t floatBytes = static_cast<uint32_t>(tileElems * sizeof(float));

    pipe.InitBuffer(inQueX0, BUF_DEPTH, tileBytes);
    pipe.InitBuffer(inQueX1, BUF_DEPTH, tileBytes);
    pipe.InitBuffer(outQueZ, BUF_DEPTH, tileBytes);
    pipe.InitBuffer(f0Buf, floatBytes);
    pipe.InitBuffer(f1Buf, floatBytes);
    pipe.InitBuffer(tmp0Buf, floatBytes);
    pipe.InitBuffer(tmp1Buf, floatBytes);

    auto x0F = f0Buf.Get<float>();
    auto x1F = f1Buf.Get<float>();
    auto tmp0 = tmp0Buf.Get<float>();
    auto tmp1 = tmp1Buf.Get<float>();

    for (int64_t t = tileStart; t < tileEnd; ++t) {
        int64_t chunk = t / rowGroupsPerChunk;
        int64_t group = t % rowGroupsPerChunk;
        int64_t rowStart = group * rowsPerTile;
        int64_t rowCount = outer - rowStart;
        if (rowCount > rowsPerTile) {
            rowCount = rowsPerTile;
        }

        int64_t offset = chunk * chunkSize;
        int64_t count = blockOut - offset;
        if (count > chunkSize) {
            count = chunkSize;
        }

        int64_t total = rowCount * count;
        uint32_t rows = static_cast<uint32_t>(rowCount);
        uint32_t cnt = static_cast<uint32_t>(count);
        uint32_t elemTotal = static_cast<uint32_t>(total);
        uint32_t blockBytes = static_cast<uint32_t>(count * sizeof(T));
        uint32_t srcGap = 0;
        uint32_t dstGap = 0;
        if (rows > 1) {
            srcGap = static_cast<uint32_t>((2 * blockOut - count) * sizeof(T));
            dstGap = static_cast<uint32_t>((blockOut - count) * sizeof(T));
        }

        AscendC::DataCopyExtParams inParams{rows, blockBytes, srcGap, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        int64_t srcBase = rowStart * 2 * blockOut + offset;
        auto x0Local = inQueX0.AllocTensor<T>();
        AscendC::DataCopyPad(x0Local, inGm[srcBase], inParams, padParams);
        inQueX0.EnQue(x0Local);

        auto x1Local = inQueX1.AllocTensor<T>();
        AscendC::DataCopyPad(x1Local, inGm[srcBase + blockOut], inParams, padParams);
        inQueX1.EnQue(x1Local);

        x0Local = inQueX0.DeQue<T>();
        x1Local = inQueX1.DeQue<T>();

        auto zLocal = outQueZ.AllocTensor<T>();

        if constexpr (std::is_same_v<T, float>) {
            AscendC::Muls(tmp0, x0Local, -1.0f, elemTotal);
            AscendC::Exp(tmp1, tmp0, elemTotal);
            AscendC::Adds(tmp0, tmp1, 1.0f, elemTotal);
            AscendC::Div(tmp1, x0Local, tmp0, elemTotal);
            AscendC::Mul(zLocal, tmp1, x1Local, elemTotal);
        } else {
            AscendC::Cast<float, T>(x0F, x0Local, AscendC::RoundMode::CAST_NONE, elemTotal);
            AscendC::Cast<float, T>(x1F, x1Local, AscendC::RoundMode::CAST_NONE, elemTotal);

            AscendC::Muls(tmp0, x0F, -1.0f, elemTotal);
            AscendC::Exp(tmp1, tmp0, elemTotal);
            AscendC::Adds(tmp0, tmp1, 1.0f, elemTotal);
            AscendC::Div(tmp1, x0F, tmp0, elemTotal);
            AscendC::Mul(tmp0, tmp1, x1F, elemTotal);
            AscendC::Cast<T, float>(zLocal, tmp0, AscendC::RoundMode::CAST_RINT, elemTotal);
        }

        outQueZ.EnQue(zLocal);
        inQueX0.FreeTensor(x0Local);
        inQueX1.FreeTensor(x1Local);

        zLocal = outQueZ.DeQue<T>();
        AscendC::DataCopyExtParams outParams{rows, blockBytes, 0, dstGap, 0};
        int64_t outBase = rowStart * blockOut + offset;
        AscendC::DataCopyPad(outGm[outBase], zLocal, outParams);
        outQueZ.FreeTensor(zLocal);
    }
}

SwiGluTiling calc_swi_glu_tiling_params(int64_t outer, int64_t half, int64_t inner)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);

    int64_t coreNum = static_cast<int64_t>(ascendcPlatform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t blockOut = half * inner;
    if (blockOut < 1) {
        blockOut = 1;
    }

    int64_t tileElems = static_cast<int64_t>(ubSize) / 40;
    tileElems = (tileElems / 64) * 64;
    if (tileElems < 64) {
        tileElems = 64;
    }

    int64_t maxL = std::min(blockOut, tileElems);
    if (maxL < 1) {
        maxL = 1;
    }

    int64_t bestL = maxL;
    int64_t bestRowsPerTile = std::max<int64_t>(1, tileElems / bestL);
    int64_t bestRowGroups = (outer + bestRowsPerTile - 1) / bestRowsPerTile;
    int64_t bestChunks = (blockOut + bestL - 1) / bestL;
    int64_t bestTiles = bestChunks * bestRowGroups;

    for (int64_t l = 1; l <= maxL; ++l) {
        int64_t chunks = (blockOut + l - 1) / l;
        int64_t rowsPer = std::max<int64_t>(1, tileElems / l);
        int64_t rowGroups = (outer + rowsPer - 1) / rowsPer;
        int64_t tiles = chunks * rowGroups;
        if (tiles < bestTiles || (tiles == bestTiles && l > bestL)) {
            bestTiles = tiles;
            bestL = l;
            bestRowsPerTile = rowsPer;
            bestRowGroups = rowGroups;
            bestChunks = chunks;
        }
    }

    int64_t chunksPerRow = bestChunks;
    int64_t rowsPerTile = bestRowsPerTile;
    int64_t rowGroupsPerChunk = bestRowGroups;
    int64_t totalTiles = bestTiles;
    int64_t numBlocks = std::min(coreNum, totalTiles);
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    int64_t tilesPerBlock = (totalTiles + numBlocks - 1) / numBlocks;

    SwiGluTiling tiling;
    tiling.blockOut = blockOut;
    tiling.outer = outer;
    tiling.chunkSize = bestL;
    tiling.chunksPerRow = chunksPerRow;
    tiling.rowsPerTile = rowsPerTile;
    tiling.rowGroupsPerChunk = rowGroupsPerChunk;
    tiling.totalTiles = totalTiles;
    tiling.numBlocks = numBlocks;
    tiling.tilesPerBlock = tilesPerBlock;
    tiling.tileElems = tileElems;
    return tiling;
}

extern "C" {

void launch_swi_glu_kernel_float(GM_ADDR input, GM_ADDR output, SwiGluTiling tiling, void *stream)
{
    swi_glu_kernel<float><<<tiling.numBlocks, nullptr, stream>>>(
        input, output, tiling.blockOut, tiling.outer, tiling.chunkSize,
        tiling.chunksPerRow, tiling.rowsPerTile, tiling.rowGroupsPerChunk,
        tiling.totalTiles, tiling.tilesPerBlock, tiling.tileElems);
}

void launch_swi_glu_kernel_half(GM_ADDR input, GM_ADDR output, SwiGluTiling tiling, void *stream)
{
    swi_glu_kernel<half><<<tiling.numBlocks, nullptr, stream>>>(
        input, output, tiling.blockOut, tiling.outer, tiling.chunkSize,
        tiling.chunksPerRow, tiling.rowsPerTile, tiling.rowGroupsPerChunk,
        tiling.totalTiles, tiling.tilesPerBlock, tiling.tileElems);
}

void launch_swi_glu_kernel_bfloat16(GM_ADDR input, GM_ADDR output, SwiGluTiling tiling, void *stream)
{
    swi_glu_kernel<bfloat16_t><<<tiling.numBlocks, nullptr, stream>>>(
        input, output, tiling.blockOut, tiling.outer, tiling.chunkSize,
        tiling.chunksPerRow, tiling.rowsPerTile, tiling.rowGroupsPerChunk,
        tiling.totalTiles, tiling.tilesPerBlock, tiling.tileElems);
}

}
