#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    TORCH_CHECK(input.dim() > 0, "input must be non-scalar");
    TORCH_CHECK(input.scalar_type() == at::kFloat ||
                    input.scalar_type() == at::kHalf ||
                    input.scalar_type() == at::kBFloat16,
                "SwiGlu only supports float16, float32 and bfloat16");

    int64_t ndim = input.dim();
    int64_t realDim = dim < 0 ? dim + ndim : dim;
    TORCH_CHECK(realDim >= 0 && realDim < ndim, "dim out of range");

    auto sizes = input.sizes().vec();
    TORCH_CHECK(sizes[realDim] % 2 == 0, "SwiGlu split dimension must be even");
    sizes[realDim] /= 2;
    return torch::empty(sizes, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto output = swi_glu_meta(input, dim);
    auto input_contig = input.contiguous();
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t ndim = input.dim();
    int64_t realDim = dim < 0 ? dim + ndim : dim;

    int64_t outer = 1;
    for (int64_t i = 0; i < realDim; ++i) {
        outer *= input.size(i);
    }

    int64_t split = input.size(realDim);
    int64_t inner = 1;
    for (int64_t i = realDim + 1; i < ndim; ++i) {
        inner *= input.size(i);
    }

    int64_t half = split / 2;
    SwiGluTiling tiling = calc_swi_glu_tiling_params(outer, half, inner);

    auto input_ptr = (GM_ADDR)input_contig.data_ptr();

    auto acl_call = [=]() -> int {
        if (input_contig.scalar_type() == at::kFloat) {
            launch_swi_glu_kernel_float(input_ptr, (GM_ADDR)output.data_ptr(), tiling, stream);
        } else if (input_contig.scalar_type() == at::kHalf) {
            launch_swi_glu_kernel_half(input_ptr, (GM_ADDR)output.data_ptr(), tiling, stream);
        } else if (input_contig.scalar_type() == at::kBFloat16) {
            launch_swi_glu_kernel_bfloat16(input_ptr, (GM_ADDR)output.data_ptr(), tiling, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return output;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
