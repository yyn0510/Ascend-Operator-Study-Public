/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel, host tiling and launch wrappers (bisheng -xasc)
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

using namespace AscendC;

constexpr int64_t MISH_PIPELINE_DEPTH = 2;
constexpr float MISH_EXP_CLAMP = 1.0e19f;

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength,
                                       int64_t blockLength,
                                       uint32_t tileElems)
{
    constexpr bool isF32 = std::is_same<T, float>::value;

    TPipe pipe;
    TQue<QuePosition::VECIN, MISH_PIPELINE_DEPTH> inQueue;
    TQue<QuePosition::VECOUT, MISH_PIPELINE_DEPTH> outQueue;
    TBuf<QuePosition::VECCALC> bufA;
    TBuf<QuePosition::VECCALC> bufB;

    pipe.InitBuffer(inQueue, MISH_PIPELINE_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(outQueue, MISH_PIPELINE_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(bufA, tileElems * sizeof(float));
    if constexpr (!isF32) {
        pipe.InitBuffer(bufB, tileElems * sizeof(float));
    }

    int64_t blockStart = blockLength * (int64_t)GetBlockIdx();
    GlobalTensor<T> xGm;
    GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T*)x + blockStart);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockStart);

    int64_t currentBlockLength = totalLength - blockStart;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    if (currentBlockLength <= 0) return;

    int64_t offset = 0;
    while (offset < currentBlockLength) {
        int64_t n = currentBlockLength - offset;
        if (n > (int64_t)tileElems) n = (int64_t)tileElems;
        uint32_t count = (uint32_t)n;

        DataCopyExtParams copyParams{1, (uint32_t)(n * (int64_t)sizeof(T)), 0, 0, 0};
        DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        LocalTensor<T> xLocal = inQueue.AllocTensor<T>();
        DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        LocalTensor<float> a = bufA.Get<float>();
        LocalTensor<T> yLocal = outQueue.AllocTensor<T>();

        if constexpr (isF32) {
            LocalTensor<float> xf = xLocal;
            LocalTensor<float> yf = yLocal;
            Exp(yf, xf, count);                       // e = exp(x)
            Mins(yf, yf, MISH_EXP_CLAMP, count);      // clamp e
            Adds(a, yf, 2.0f, count);                 // a = e + 2
            Mul(yf, yf, a, count);                    // yf = n = e * (e + 2)
            Adds(a, yf, 2.0f, count);                 // a = n + 2
            Div(a, yf, a, count);                     // a = r = n / (n + 2)
            Mul(yf, xf, a, count);                    // y = x * r
        } else {
            LocalTensor<float> b = bufB.Get<float>();
            Cast(a, xLocal, RoundMode::CAST_NONE, count); // a = x_fp32
            Exp(b, a, count);                              // b = e
            Mins(b, b, MISH_EXP_CLAMP, count);             // clamp e
            Adds(a, b, 2.0f, count);                       // a = e + 2
            Mul(b, b, a, count);                           // b = n = e * (e + 2)
            Adds(a, b, 2.0f, count);                       // a = n + 2
            Div(b, b, a, count);                           // b = r = n / (n + 2)
            Cast(a, xLocal, RoundMode::CAST_NONE, count);  // a = x_fp32 (reload)
            Mul(a, a, b, count);                           // a = y_fp32
            Cast(yLocal, a, RoundMode::CAST_RINT, count);  // y = T
        }

        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);

        yLocal = outQueue.DeQue<T>();
        DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);

        offset += n;
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength, int64_t typeSize)
{
    if (totalLength <= 0) {
        return std::make_tuple(1, 0, 64);
    }

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    constexpr int64_t MIN_ELEMS_PER_CORE = 2048;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) numBlocks = coreNum;
    if (numBlocks <= 0) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    // UB bytes per element:
    // fp32: inQueue 2*4=8, outQueue 2*4=8, bufA 4 => 20
    // fp16/bf16: inQueue 2*2=4, outQueue 2*2=4, bufA 4, bufB 4 => 16
    int64_t bytesPerElem = (typeSize == 4) ? 20 : 16;

    uint64_t usableUb = ubSize * 9 / 10;  // 90% utilization
    int64_t maxTileElems = (int64_t)(usableUb / (uint64_t)bytesPerElem);
    int64_t tileElems = (maxTileElems / 64) * 64;
    if (tileElems < 64) tileElems = 64;
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

extern "C" {
void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElems);
}
void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElems);
}
void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElems);
}
}
