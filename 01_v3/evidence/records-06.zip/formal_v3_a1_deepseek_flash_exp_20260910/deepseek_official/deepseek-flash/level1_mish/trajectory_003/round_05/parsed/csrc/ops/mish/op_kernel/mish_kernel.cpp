/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel, host tiling and launch wrappers (bisheng -xasc)
 *
 * mish(x) = x * tanh(softplus(x))
 *         = x * (e^2 + 2e) / (e^2 + 2e + 2),  e = exp(x)
 * The e^2 term is evaluated as e * (e + 2) which keeps the exact same
 * mathematical value while removing one multiply from the critical path.
 * The exponential result is clamped before squaring so that large positive
 * inputs saturate to tanh == 1 instead of producing inf/inf.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

using namespace AscendC;

constexpr int64_t MISH_IN_DEPTH = 3;
constexpr int64_t MISH_OUT_DEPTH = 2;
constexpr int64_t MISH_PRELOAD = 2;
constexpr float MISH_EXP_CLAMP = 1.0e19f;

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength,
                                       int64_t blockLength,
                                       uint32_t tileElems)
{
    constexpr bool isF32 = std::is_same<T, float>::value;

    if (totalLength <= 0 || blockLength <= 0 || tileElems == 0) {
        return;
    }

    int64_t blockStart = blockLength * (int64_t)GetBlockIdx();
    if (blockStart >= totalLength) {
        return;
    }
    int64_t currentBlockLength = totalLength - blockStart;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    TPipe pipe;
    TQue<QuePosition::VECIN, MISH_IN_DEPTH> inQueue;
    TQue<QuePosition::VECOUT, MISH_OUT_DEPTH> outQueue;
    TBuf<QuePosition::VECCALC> bufA;
    TBuf<QuePosition::VECCALC> bufB;

    pipe.InitBuffer(inQueue, MISH_IN_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(outQueue, MISH_OUT_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(bufA, tileElems * sizeof(float));
    if constexpr (!isF32) {
        pipe.InitBuffer(bufB, tileElems * sizeof(float));
    }

    GlobalTensor<T> xGm;
    GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T*)x + blockStart);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockStart);

    DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
    const int64_t tileElemsI = (int64_t)tileElems;

    int64_t curOff = 0;
    int64_t preOff = 0;

    // Prologue: issue the first prefetch batch so that the very first compute
    // can already run while a subsequent DMA is in flight.
    for (int64_t k = 0; k < MISH_PRELOAD; ++k) {
        if (preOff < currentBlockLength) {
            int64_t pn = currentBlockLength - preOff;
            if (pn > tileElemsI) {
                pn = tileElemsI;
            }
            DataCopyExtParams cp{1, (uint32_t)(pn * (int64_t)sizeof(T)), 0, 0, 0};
            LocalTensor<T> xt = inQueue.AllocTensor<T>();
            DataCopyPad(xt, xGm[preOff], cp, padParams);
            inQueue.EnQue(xt);
            preOff += pn;
        }
    }

    while (curOff < currentBlockLength) {
        int64_t n = currentBlockLength - curOff;
        if (n > tileElemsI) {
            n = tileElemsI;
        }
        const uint32_t count = (uint32_t)n;

        // Keep the memory pipe busy: prefetch the tile that will be consumed
        // two iterations later, then consume the head of the in queue.
        if (preOff < currentBlockLength) {
            int64_t nn = currentBlockLength - preOff;
            if (nn > tileElemsI) {
                nn = tileElemsI;
            }
            DataCopyExtParams cpn{1, (uint32_t)(nn * (int64_t)sizeof(T)), 0, 0, 0};
            LocalTensor<T> xt = inQueue.AllocTensor<T>();
            DataCopyPad(xt, xGm[preOff], cpn, padParams);
            inQueue.EnQue(xt);
            preOff += nn;
        }

        LocalTensor<T> xLocal = inQueue.DeQue<T>();
        LocalTensor<T> yLocal = outQueue.AllocTensor<T>();

        if constexpr (isF32) {
            LocalTensor<float> a = bufA.Get<float>();
            LocalTensor<float> xf = xLocal;
            LocalTensor<float> yf = yLocal;
            Exp(yf, xf, count);                       // e = exp(x)
            Mins(yf, yf, MISH_EXP_CLAMP, count);      // clamp e
            Adds(a, yf, 2.0f, count);                 // a = e + 2
            Mul(yf, yf, a, count);                    // yf = n = e * (e + 2)
            Adds(a, yf, 2.0f, count);                 // a = n + 2
            Div(a, yf, a, count);                     // a = r = n / (n + 2)
            Mul(yf, xf, a, count);                    // y = x * r
        } else {
            LocalTensor<float> a = bufA.Get<float>();
            LocalTensor<float> b = bufB.Get<float>();
            Cast(a, xLocal, RoundMode::CAST_NONE, count); // a = x_fp32
            Exp(b, a, count);                              // b = e
            Mins(b, b, MISH_EXP_CLAMP, count);             // clamp e
            Adds(a, b, 2.0f, count);                       // a = e + 2
            Mul(b, b, a, count);                           // b = n = e * (e + 2)
            Adds(a, b, 2.0f, count);                       // a = n + 2
            Div(b, b, a, count);                           // b = r = n / (n + 2)
            Cast(a, xLocal, RoundMode::CAST_NONE, count);  // a = x_fp32 (reload)
            Mul(a, a, b, count);                           // a = y_fp32
            Cast(yLocal, a, RoundMode::CAST_RINT, count);  // y = T
        }

        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);

        yLocal = outQueue.DeQue<T>();
        DataCopyExtParams cpo{1, (uint32_t)(n * (int64_t)sizeof(T)), 0, 0, 0};
        DataCopyPad(yGm[curOff], yLocal, cpo);
        outQueue.FreeTensor(yLocal);

        curOff += n;
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength, int64_t typeSize)
{
    // Cache device platform facts once; avoids repeated platform queries on every launch.
    static int64_t sCoreNum = -1;
    static int64_t sUbBytes = 0;
    if (sCoreNum < 0) {
        auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
        uint64_t ubSize = 0;
        ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
        sUbBytes = (int64_t)ubSize;
        sCoreNum = ascendcPlatform->GetCoreNumAiv();
        if (sCoreNum <= 0) {
            sCoreNum = 1;
        }
        if (sUbBytes <= 0) {
            sUbBytes = 192 * 1024;
        }
    }

    if (totalLength <= 0) {
        return std::make_tuple(1, 0, 256);
    }

    constexpr int64_t MIN_ELEMS_PER_CORE = 2048;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > sCoreNum) {
        numBlocks = sCoreNum;
    }
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    // Align the per-core span so every core base address (and every tile inside
    // it) is 32B aligned, which keeps the DMA on the fast descriptor path.
    blockLength = ((blockLength + 255) / 256) * 256;

    // UB bytes per element (tile size tracked in elements):
    // fp32:      inQueue 3*4 + outQueue 2*4 + bufA 4                     = 24
    // fp16/bf16: inQueue 3*2 + outQueue 2*2 + bufA 4 + bufB 4            = 18
    int64_t bytesPerElem = (typeSize == 4) ? 24 : 18;

    int64_t usableUb = sUbBytes * 92 / 100;
    int64_t maxTileElems = usableUb / bytesPerElem;
    int64_t tileElems = (maxTileElems / 256) * 256;
    if (tileElems < 256) {
        tileElems = 256;
    }
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

extern "C" {
void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElems);
}
void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElems);
}
void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElems);
}
}
