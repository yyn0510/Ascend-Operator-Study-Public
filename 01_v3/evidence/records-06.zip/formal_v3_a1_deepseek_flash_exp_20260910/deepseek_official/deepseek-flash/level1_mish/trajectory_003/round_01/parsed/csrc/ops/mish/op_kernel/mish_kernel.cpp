/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish host code - kernel launch and tiling (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

using namespace AscendC;

constexpr int64_t PIPELINE_DEPTH = 2;
constexpr float MAX_EXP_VALUE = 1e19f;

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileElems)
{
    TPipe pipe;
    TQue<QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    TQue<QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    TBuf<QuePosition::VECCALC> calcBuf0, calcBuf1, calcBuf2;
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileElems * sizeof(T));
    pipe.InitBuffer(calcBuf0, tileElems * sizeof(float));
    pipe.InitBuffer(calcBuf1, tileElems * sizeof(float));
    pipe.InitBuffer(calcBuf2, tileElems * sizeof(float));

    GlobalTensor<T> xGm, yGm;
    xGm.SetGlobalBuffer((__gm__ T*)x + blockLength * GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T*)y + blockLength * GetBlockIdx());

    int64_t currentBlockLength = totalLength - GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    if (currentBlockLength <= 0) return;

    int64_t offset = 0;
    while (offset < currentBlockLength) {
        int64_t n = currentBlockLength - offset;
        if (n > tileElems) n = tileElems;
        uint32_t count = static_cast<uint32_t>(n);

        DataCopyExtParams copyParams{1, static_cast<uint32_t>(n * sizeof(T)), 0, 0, 0};
        DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        LocalTensor<float> calc0 = calcBuf0.Get<float>();
        LocalTensor<float> calc1 = calcBuf1.Get<float>();
        LocalTensor<float> calc2 = calcBuf2.Get<float>();

        if constexpr (std::is_same_v<T, float>) {
            calc0 = xLocal;
        } else {
            Cast(calc0, xLocal, RoundMode::CAST_NONE, count);
        }

        Exp(calc1, calc0, count);
        Mins(calc1, calc1, MAX_EXP_VALUE, count);
        Muls(calc2, calc1, 2.0f, count);
        Mul(calc1, calc1, calc1, count);
        Add(calc2, calc2, calc1, count);
        Adds(calc1, calc2, 2.0f, count);
        Div(calc2, calc2, calc1, count);

        auto yLocal = outQueue.AllocTensor<T>();
        if constexpr (std::is_same_v<T, float>) {
            Mul(yLocal, calc0, calc2, count);
        } else {
            Mul(calc1, calc0, calc2, count);
            Cast(yLocal, calc1, RoundMode::CAST_RINT, count);
        }

        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);

        yLocal = outQueue.DeQue<T>();
        DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);

        offset += n;
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength, int64_t typeSize)
{
    if (totalLength <= 0) {
        return std::make_tuple(1, 0, 8);
    }

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    uint64_t usableUb = ubSize * 8 / 10;
    int64_t bytesPerElem = 4 * typeSize + 12;
    int64_t maxTileElems = usableUb / bytesPerElem;
    int64_t tileElems = (maxTileElems / 8) * 8;
    if (tileElems < 8) tileElems = 8;
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

extern "C" {
void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElems);
}
void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElems);
}
void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElems);
}
}
