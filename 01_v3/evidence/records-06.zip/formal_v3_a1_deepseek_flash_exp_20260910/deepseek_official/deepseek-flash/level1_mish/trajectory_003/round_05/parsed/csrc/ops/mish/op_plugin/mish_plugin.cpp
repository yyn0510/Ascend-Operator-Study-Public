/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_plugin.cpp
 * \brief Mish API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"
#include "../op_kernel/mish_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("mish(Tensor x) -> Tensor");
}

torch::Tensor mish_meta(const torch::Tensor &x)
{
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("mish", mish_meta);
}

torch::Tensor mish_npu(const torch::Tensor &x)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto y = torch::empty_like(x);

    int64_t totalLength = x.numel();
    if (totalLength == 0) {
        return y;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t typeSize = x.element_size();

    int64_t numBlocks = 1;
    int64_t blockLength = 0;
    int64_t tileElems = 256;
    std::tie(numBlocks, blockLength, tileElems) = calc_mish_tiling_params(totalLength, typeSize);

    auto x_ptr = (GM_ADDR)x.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();
    uint32_t tile = static_cast<uint32_t>(tileElems);
    c10::ScalarType scalarType = x.scalar_type();

    auto acl_call = [=]() -> int {
        if (scalarType == torch::kFloat32) {
            launch_mish_kernel_float(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tile, stream);
        } else if (scalarType == torch::kFloat16) {
            launch_mish_kernel_half(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tile, stream);
        } else if (scalarType == torch::kBFloat16) {
            launch_mish_kernel_bfloat16(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tile, stream);
        } else {
            TORCH_CHECK(false, "mish: unsupported input dtype");
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Mish", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("mish", m.impl("mish", mish_npu));
}

} // namespace cann_bench
