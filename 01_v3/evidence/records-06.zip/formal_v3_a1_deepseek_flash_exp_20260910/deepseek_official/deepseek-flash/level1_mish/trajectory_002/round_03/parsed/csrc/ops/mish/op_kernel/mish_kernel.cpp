/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel + host tiling + launch wrappers (bisheng -xasc)
 *
 * y = x * tanh(softplus(x)) = x * e * (e + 2) / (e * (e + 2) + 2),  e = exp(min(x, 20))
 * The product/quotient ordering avoids the catastrophic cancellation of the
 * "x - 2x/d" form for strongly negative inputs, keeps every intermediate in
 * range, and reproduces the golden NaN/inf behaviour.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t MISH_BUFFER_NUM = 2;
constexpr static float MISH_EXP_CLAMP = 20.0f;
constexpr static int64_t MISH_DMA_ALIGN_BYTES = 32;

struct MishPlatformCaps {
    uint64_t ubSize;
    int64_t coreNum;
};

static const MishPlatformCaps &GetMishPlatformCaps()
{
    static const MishPlatformCaps caps = []() -> MishPlatformCaps {
        MishPlatformCaps c;
        c.ubSize = 192ULL * 1024ULL;
        c.coreNum = 40;
        auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
        if (platform != nullptr) {
            uint64_t u = 0;
            platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, u);
            if (u > 0) {
                c.ubSize = u;
            }
            int64_t n = platform->GetCoreNumAiv();
            if (n > 0) {
                c.coreNum = n;
            }
        }
        return c;
    }();
    return caps;
}

template <typename T>
__global__ __aicore__ void mish_kernel(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    using ComputeT = float;
    constexpr bool kNeedCast = !std::is_same<T, ComputeT>::value;

    if (tileSize < static_cast<uint32_t>(MISH_DMA_ALIGN_BYTES)) {
        return;
    }
    int64_t elemNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elemNumPerTile <= 0) {
        return;
    }

    int64_t startOffset = blockLength * static_cast<int64_t>(AscendC::GetBlockIdx());
    if (startOffset >= totalLength) {
        return;
    }
    int64_t currentBlockLength = totalLength - startOffset;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, MISH_BUFFER_NUM> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, MISH_BUFFER_NUM> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBufA;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBufB;
    AscendC::TBuf<AscendC::TPosition::VECCALC> workBufC;

    uint32_t workBytes = static_cast<uint32_t>(elemNumPerTile * static_cast<int64_t>(sizeof(ComputeT)));
    pipe.InitBuffer(inQueueX, MISH_BUFFER_NUM, tileSize);
    pipe.InitBuffer(outQueueY, MISH_BUFFER_NUM, tileSize);
    pipe.InitBuffer(workBufA, workBytes);
    pipe.InitBuffer(workBufB, workBytes);
    if constexpr (kNeedCast) {
        pipe.InitBuffer(workBufC, workBytes);
    }

    xGm.SetGlobalBuffer(reinterpret_cast<__gm__ T *>(x) + startOffset);
    yGm.SetGlobalBuffer(reinterpret_cast<__gm__ T *>(y) + startOffset);

    int64_t tileNum = (currentBlockLength + elemNumPerTile - 1) / elemNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elemNumPerTile;
        int64_t remaining = currentBlockLength - offset;
        bool isFullTile = (remaining >= elemNumPerTile);
        int64_t elemNum = isFullTile ? elemNumPerTile : remaining;
        uint32_t n = static_cast<uint32_t>(elemNum);

        AscendC::LocalTensor<T> xLocal = inQueueX.AllocTensor<T>();
        if (isFullTile) {
            AscendC::DataCopy(xLocal, xGm[offset], n);
        } else {
            AscendC::DataCopyExtParams copyParams{
                1, static_cast<uint32_t>(elemNum * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
            AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
            AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        }
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        AscendC::LocalTensor<T> yLocal = outQueueY.AllocTensor<T>();
        AscendC::LocalTensor<ComputeT> fa = workBufA.Get<ComputeT>();
        AscendC::LocalTensor<ComputeT> fb = workBufB.Get<ComputeT>();

        if constexpr (kNeedCast) {
            AscendC::LocalTensor<ComputeT> fc = workBufC.Get<ComputeT>();
            AscendC::Cast(fa, xLocal, AscendC::RoundMode::CAST_NONE, n);
            AscendC::Mins(fb, fa, MISH_EXP_CLAMP, n);
            AscendC::Exp(fc, fb, n);
            AscendC::Adds(fb, fc, 2.0f, n);
            AscendC::Mul(fc, fc, fb, n);
            AscendC::Adds(fb, fc, 2.0f, n);
            AscendC::Div(fc, fc, fb, n);
            AscendC::Mul(fb, fa, fc, n);
            AscendC::Cast(yLocal, fb, AscendC::RoundMode::CAST_RINT, n);
        } else {
            AscendC::Mins(fa, xLocal, MISH_EXP_CLAMP, n);
            AscendC::Exp(fa, fa, n);
            AscendC::Adds(fb, fa, 2.0f, n);
            AscendC::Mul(fa, fa, fb, n);
            AscendC::Adds(fb, fa, 2.0f, n);
            AscendC::Div(fa, fa, fb, n);
            AscendC::Mul(yLocal, xLocal, fa, n);
        }

        inQueueX.FreeTensor(xLocal);
        outQueueY.EnQue(yLocal);
        yLocal = outQueueY.DeQue<T>();
        if (isFullTile) {
            AscendC::DataCopy(yGm[offset], yLocal, n);
        } else {
            AscendC::DataCopyExtParams copyParams{
                1, static_cast<uint32_t>(elemNum * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
            AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        }
        outQueueY.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength, int64_t elementSize)
{
    const MishPlatformCaps &caps = GetMishPlatformCaps();
    int64_t coreNum = caps.coreNum > 0 ? caps.coreNum : 1;
    uint64_t ubSize = caps.ubSize;
    if (elementSize <= 0) {
        elementSize = 4;
    }

    constexpr int64_t MIN_ELEMS_PER_CORE = 4096;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t alignElem = MISH_DMA_ALIGN_BYTES / elementSize;
    if (alignElem <= 0) {
        alignElem = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    blockLength = (blockLength + alignElem - 1) / alignElem * alignElem;

    // UB budget for one in-flight tile:
    //   in queue  : MISH_BUFFER_NUM * tileSize
    //   out queue : MISH_BUFFER_NUM * tileSize
    //   work      : (2 for float32 / 3 for 2-byte types) * tileSize / sizeof(T) * sizeof(float)
    uint64_t avail = ubSize / 8 * 7;
    int64_t k = (elementSize == 4) ? 6 : 10;
    int64_t tileSize = static_cast<int64_t>(avail / static_cast<uint64_t>(k));
    tileSize = tileSize / MISH_DMA_ALIGN_BYTES * MISH_DMA_ALIGN_BYTES;
    if (tileSize < MISH_DMA_ALIGN_BYTES) {
        tileSize = MISH_DMA_ALIGN_BYTES;
    }

    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
