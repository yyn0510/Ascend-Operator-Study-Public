/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file sigmoid_kernel.cpp
 * \brief Sigmoid elementwise kernel, host tiling calculation and direct-launch wrappers.
 *
 *        y = 1 / (1 + exp(-x))
 */

#include <algorithm>
#include <tuple>

#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

namespace {
constexpr int32_t SIGMOID_BUFFER_NUM = 2;
constexpr int64_t SIGMOID_MIN_ELEMS_PER_CORE = 2048;
constexpr int64_t SIGMOID_ALIGN_BYTES = 32;
constexpr int64_t SIGMOID_FALLBACK_UB_BYTES = 192 * 1024;
}  // namespace

template <typename T>
__global__ __aicore__ void sigmoid_kernel(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T *)x);
    yGm.SetGlobalBuffer((__gm__ T *)y);

    const int64_t startOffset = static_cast<int64_t>(AscendC::GetBlockIdx()) * blockLength;
    int64_t curLen = totalLength - startOffset;
    if (curLen > blockLength) {
        curLen = blockLength;
    }
    if (curLen <= 0) {
        return;
    }

    int64_t elemsPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elemsPerTile < 1) {
        elemsPerTile = 1;
    }

    const int64_t fullTiles = curLen / elemsPerTile;
    const int64_t tailElems = curLen - fullTiles * elemsPerTile;
    const int64_t loopNum = fullTiles + ((tailElems > 0) ? 1 : 0);

    if constexpr (AscendC::IsSameType<T, bfloat16_t>::value) {
        // bfloat16: Cast to float for computation
        AscendC::TQue<AscendC::QuePosition::VECIN, SIGMOID_BUFFER_NUM> inQueue;
        AscendC::TQue<AscendC::QuePosition::VECCALC, SIGMOID_BUFFER_NUM> calcQueue;
        pipe.InitBuffer(inQueue, SIGMOID_BUFFER_NUM, tileSize);
        pipe.InitBuffer(calcQueue, SIGMOID_BUFFER_NUM, tileSize * 2);

        for (int64_t i = 0; i < loopNum; ++i) {
            const int64_t count = (i < fullTiles) ? elemsPerTile : tailElems;
            const int64_t offset = startOffset + i * elemsPerTile;

            AscendC::LocalTensor<T> xLocal = inQueue.AllocTensor<T>();
            if ((offset * sizeof(T)) % SIGMOID_ALIGN_BYTES == 0 &&
                (count * sizeof(T)) % SIGMOID_ALIGN_BYTES == 0) {
                AscendC::DataCopy(xLocal, xGm[offset], count);
            } else {
                AscendC::DataCopyExtParams copyParams{
                    1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
                AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
                AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
            }
            inQueue.EnQue(xLocal);
            xLocal = inQueue.DeQue<T>();

            AscendC::LocalTensor<float> calcLocal = calcQueue.AllocTensor<float>();
            AscendC::Cast(calcLocal, xLocal, AscendC::RoundMode::CAST_NONE, static_cast<int32_t>(count));
            AscendC::Sigmoid(calcLocal, calcLocal, static_cast<int32_t>(count));
            AscendC::Cast(xLocal, calcLocal, AscendC::RoundMode::CAST_RINT, static_cast<int32_t>(count));
            calcQueue.FreeTensor(calcLocal);

            if ((offset * sizeof(T)) % SIGMOID_ALIGN_BYTES == 0 &&
                (count * sizeof(T)) % SIGMOID_ALIGN_BYTES == 0) {
                AscendC::DataCopy(yGm[offset], xLocal, count);
            } else {
                AscendC::DataCopyExtParams copyParams{
                    1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
                AscendC::DataCopyPad(yGm[offset], xLocal, copyParams);
            }
            inQueue.FreeTensor(xLocal);
        }
    } else {
        // float or half: in-place Sigmoid
        AscendC::TQue<AscendC::QuePosition::VECIN, SIGMOID_BUFFER_NUM> inQueue;
        pipe.InitBuffer(inQueue, SIGMOID_BUFFER_NUM, tileSize);

        for (int64_t i = 0; i < loopNum; ++i) {
            const int64_t count = (i < fullTiles) ? elemsPerTile : tailElems;
            const int64_t offset = startOffset + i * elemsPerTile;

            AscendC::LocalTensor<T> xLocal = inQueue.AllocTensor<T>();
            if ((offset * sizeof(T)) % SIGMOID_ALIGN_BYTES == 0 &&
                (count * sizeof(T)) % SIGMOID_ALIGN_BYTES == 0) {
                AscendC::DataCopy(xLocal, xGm[offset], count);
            } else {
                AscendC::DataCopyExtParams copyParams{
                    1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
                AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
                AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
            }
            inQueue.EnQue(xLocal);
            xLocal = inQueue.DeQue<T>();

            AscendC::Sigmoid(xLocal, xLocal, static_cast<int32_t>(count));

            if ((offset * sizeof(T)) % SIGMOID_ALIGN_BYTES == 0 &&
                (count * sizeof(T)) % SIGMOID_ALIGN_BYTES == 0) {
                AscendC::DataCopy(yGm[offset], xLocal, count);
            } else {
                AscendC::DataCopyExtParams copyParams{
                    1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
                AscendC::DataCopyPad(yGm[offset], xLocal, copyParams);
            }
            inQueue.FreeTensor(xLocal);
        }
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(
    int64_t totalLength, int64_t dtypeSize, bool needCalc)
{
    int64_t coreNum = 1;
    uint64_t ubSize = 0;
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    if (platform != nullptr) {
        platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
        coreNum = static_cast<int64_t>(platform->GetCoreNumAiv());
    }
    if (coreNum <= 0) {
        coreNum = 1;
    }
    int64_t ubTotal = static_cast<int64_t>(ubSize);
    if (ubTotal <= 0) {
        ubTotal = SIGMOID_FALLBACK_UB_BYTES;
    }

    if (totalLength <= 0) {
        return std::make_tuple(static_cast<int64_t>(1), static_cast<int64_t>(0), SIGMOID_ALIGN_BYTES);
    }

    int64_t numBlocks = (totalLength + SIGMOID_MIN_ELEMS_PER_CORE - 1) / SIGMOID_MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    int64_t align = SIGMOID_ALIGN_BYTES / dtypeSize;
    if (align < 1) {
        align = 1;
    }
    blockLength = (blockLength + align - 1) / align * align;

    int64_t tileSize;
    if (needCalc) {
        // inQueue(2) + calcQueue(2 * 2) = 6 * tileSize
        tileSize = ubTotal / 6;
    } else {
        // inQueue(2) = 2 * tileSize
        tileSize = ubTotal / 2;
    }
    tileSize = tileSize / SIGMOID_ALIGN_BYTES * SIGMOID_ALIGN_BYTES;
    if (tileSize < SIGMOID_ALIGN_BYTES) {
        tileSize = SIGMOID_ALIGN_BYTES;
    }

    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                 int64_t blockLength, uint32_t tileSize, void *stream)
{
    sigmoid_kernel<float><<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                int64_t blockLength, uint32_t tileSize, void *stream)
{
    sigmoid_kernel<half><<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                    int64_t blockLength, uint32_t tileSize, void *stream)
{
    sigmoid_kernel<bfloat16_t><<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

}  // extern "C"
