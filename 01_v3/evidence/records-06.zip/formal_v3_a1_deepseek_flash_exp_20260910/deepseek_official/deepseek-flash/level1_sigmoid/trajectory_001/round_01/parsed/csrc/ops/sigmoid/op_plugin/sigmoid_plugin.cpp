/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file sigmoid_plugin.cpp
 * \brief Sigmoid API layer - torch bindings (compiled with g++).
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include <tuple>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/sigmoid_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("sigmoid(Tensor x) -> Tensor");
}

torch::Tensor sigmoid_meta(const torch::Tensor &x)
{
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 || x.scalar_type() == torch::kFloat16 || x.scalar_type() == torch::kBFloat16,
                "Sigmoid only supports float32, float16, and bfloat16.");
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("sigmoid", sigmoid_meta);
}

torch::Tensor sigmoid_npu(const torch::Tensor &x)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto y = sigmoid_meta(x);
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t totalLength = x.numel();
    int64_t numBlocks, blockLength, tileSize;
    std::tie(numBlocks, blockLength, tileSize) = calc_sigmoid_tiling_params(totalLength);

    auto x_ptr = (GM_ADDR)x.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();

    auto acl_call = [=]() -> int {
        if (x.scalar_type() == torch::kFloat32) {
            launch_sigmoid_kernel_float(x_ptr, y_ptr, totalLength, numBlocks, blockLength, static_cast<uint32_t>(tileSize), stream);
        } else if (x.scalar_type() == torch::kFloat16) {
            launch_sigmoid_kernel_half(x_ptr, y_ptr, totalLength, numBlocks, blockLength, static_cast<uint32_t>(tileSize), stream);
        } else if (x.scalar_type() == torch::kBFloat16) {
            launch_sigmoid_kernel_bfloat16(x_ptr, y_ptr, totalLength, numBlocks, blockLength, static_cast<uint32_t>(tileSize), stream);
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Sigmoid", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("sigmoid", sigmoid_npu);
}

} // namespace cann_bench
