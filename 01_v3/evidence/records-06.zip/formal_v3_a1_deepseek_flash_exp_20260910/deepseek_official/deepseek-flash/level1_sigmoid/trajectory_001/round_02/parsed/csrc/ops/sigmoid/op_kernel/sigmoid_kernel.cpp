/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file sigmoid_kernel.cpp
 * \brief Sigmoid kernel, host tiling and launch wrappers for Direct Launch.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static float MAX_EXP_ARG = 87.0f;

template <typename T>
__aicore__ inline void ComputeSigmoid(const AscendC::LocalTensor<T>& yLocal,
                                      const AscendC::LocalTensor<T>& xLocal,
                                      const AscendC::LocalTensor<float>& f0,
                                      const AscendC::LocalTensor<float>& f1,
                                      int32_t count)
{
    if constexpr (std::is_same_v<T, float>) {
        AscendC::Muls(f0, xLocal, -1.0f, count);
        AscendC::Mins(f0, f0, MAX_EXP_ARG, count);
        AscendC::Exp(f0, f0, count);
        AscendC::Adds(f0, f0, 1.0f, count);
        AscendC::Reciprocal(f1, f0, count);
        AscendC::Mul(f0, f0, f1, count);
        AscendC::Muls(f0, f0, -1.0f, count);
        AscendC::Adds(f0, f0, 2.0f, count);
        AscendC::Mul(yLocal, f1, f0, count);
    } else {
        AscendC::Cast(f0, xLocal, AscendC::RoundMode::CAST_NONE, count);
        AscendC::Muls(f0, f0, -1.0f, count);
        AscendC::Mins(f0, f0, MAX_EXP_ARG, count);
        AscendC::Exp(f0, f0, count);
        AscendC::Adds(f0, f0, 1.0f, count);
        AscendC::Reciprocal(f1, f0, count);
        AscendC::Mul(f0, f0, f1, count);
        AscendC::Muls(f0, f0, -1.0f, count);
        AscendC::Adds(f0, f0, 2.0f, count);
        AscendC::Mul(f1, f1, f0, count);
        AscendC::Cast(yLocal, f1, AscendC::RoundMode::CAST_RINT, count);
    }
}

template <typename T>
__global__ __aicore__ void sigmoid_kernel(GM_ADDR x, GM_ADDR y,
                                          int64_t totalLength,
                                          int64_t blockLength,
                                          uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    int64_t elementNumPerTile = tileSize / sizeof(T);
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf0;
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf1;
    pipe.InitBuffer(calcBuf0, elementNumPerTile * sizeof(float));
    pipe.InitBuffer(calcBuf1, elementNumPerTile * sizeof(float));

    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + blockIdx * blockLength);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockIdx * blockLength);

    auto f0 = calcBuf0.Get<float>();
    auto f1 = calcBuf1.Get<float>();

    int64_t tileNum = (currentBlockLength + elementNumPerTile - 1) / elementNumPerTile;
    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        int64_t remaining = currentBlockLength - offset;
        int32_t count = static_cast<int32_t>(remaining < elementNumPerTile ? remaining : elementNumPerTile);

        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        ComputeSigmoid<T>(yLocal, xLocal, f0, f1, count);
        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);

        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 2048;
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    if (dtypeSize <= 0) {
        dtypeSize = 4;
    }
    int64_t unitCost = 4 + 8 / dtypeSize;
    if (unitCost <= 0) {
        unitCost = 6;
    }
    int64_t tileSize = static_cast<int64_t>(ubSize) * 9 / 10 / unitCost;
    tileSize = tileSize / 32 * 32;
    if (tileSize < 32) {
        tileSize = 32;
    }
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
