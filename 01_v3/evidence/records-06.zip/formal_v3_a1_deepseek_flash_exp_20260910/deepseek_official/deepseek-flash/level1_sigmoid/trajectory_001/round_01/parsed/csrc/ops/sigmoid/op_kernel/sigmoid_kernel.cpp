/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file sigmoid_kernel.cpp
 * \brief Sigmoid kernel, host tiling and launch wrappers for Direct Launch.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

template <typename T>
__aicore__ inline void ComputeSigmoid(const AscendC::LocalTensor<T>& yLocal,
                                      const AscendC::LocalTensor<T>& xLocal,
                                      const AscendC::LocalTensor<float>& tmpLocal,
                                      int32_t count)
{
    if constexpr (std::is_same_v<T, float>) {
        AscendC::Muls(tmpLocal, xLocal, -1.0f, count);
        AscendC::Exp(tmpLocal, tmpLocal, count);
        AscendC::Adds(tmpLocal, tmpLocal, 1.0f, count);
        AscendC::Reciprocal(yLocal, tmpLocal, count);
    } else {
        AscendC::Cast(tmpLocal, xLocal, AscendC::RoundMode::CAST_NONE, count);
        AscendC::Muls(tmpLocal, tmpLocal, -1.0f, count);
        AscendC::Exp(tmpLocal, tmpLocal, count);
        AscendC::Adds(tmpLocal, tmpLocal, 1.0f, count);
        AscendC::Reciprocal(tmpLocal, tmpLocal, count);
        AscendC::Cast(yLocal, tmpLocal, AscendC::RoundMode::CAST_RINT, count);
    }
}

template <typename T>
__global__ __aicore__ void sigmoid_kernel(GM_ADDR x, GM_ADDR y,
                                          int64_t totalLength,
                                          int64_t blockLength,
                                          uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    int64_t elementNumPerTile = tileSize / sizeof(T);
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf;
    pipe.InitBuffer(calcBuf, elementNumPerTile * sizeof(float));

    int64_t blockIdx = AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)x + blockIdx * blockLength);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockIdx * blockLength);

    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t tileNum = (currentBlockLength + elementNumPerTile - 1) / elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        int64_t remaining = currentBlockLength - offset;
        int32_t count = static_cast<int32_t>(remaining < elementNumPerTile ? remaining : elementNumPerTile);

        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        auto tmpLocal = calcBuf.Get<float>();
        ComputeSigmoid<T>(yLocal, xLocal, tmpLocal, count);

        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);
        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 2048;
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    int64_t tileSize = static_cast<int64_t>(ubSize / 6);
    tileSize = tileSize / 32 * 32;
    if (tileSize < 32) {
        tileSize = 32;
    }
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
