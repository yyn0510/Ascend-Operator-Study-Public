/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file sigmoid_kernel.cpp
 * \brief Sigmoid kernel, host tiling and launch wrappers for Direct Launch.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static float SIGMOID_CLAMP_F32 = 87.0f;
constexpr static half SIGMOID_CLAMP_F16 = (half)10.0f;

template <typename T>
__aicore__ inline void SigmoidCopyIn(AscendC::LocalTensor<T> dst, AscendC::GlobalTensor<T> src, int32_t count)
{
    if ((count * static_cast<int32_t>(sizeof(T))) % 32 == 0) {
        AscendC::DataCopy(dst, src, count);
        return;
    }
    AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
    AscendC::DataCopyPad(dst, src, copyParams, padParams);
}

template <typename T>
__aicore__ inline void SigmoidCopyOut(AscendC::GlobalTensor<T> dst, AscendC::LocalTensor<T> src, int32_t count)
{
    if ((count * static_cast<int32_t>(sizeof(T))) % 32 == 0) {
        AscendC::DataCopy(dst, src, count);
        return;
    }
    AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
    AscendC::DataCopyPad(dst, src, copyParams);
}

template <typename T>
__global__ __aicore__ void sigmoid_kernel(GM_ADDR x, GM_ADDR y,
                                          int64_t totalLength,
                                          int64_t blockLength,
                                          uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    int64_t elemsPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));

    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf0;
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf1;
    if constexpr (std::is_same_v<T, half>) {
        pipe.InitBuffer(calcBuf0, static_cast<int32_t>(elemsPerTile * sizeof(float)));
        pipe.InitBuffer(calcBuf1, static_cast<int32_t>(elemsPerTile * sizeof(float)));
    }

    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t curLen = totalLength - blockIdx * blockLength;
    if (curLen > blockLength) {
        curLen = blockLength;
    }
    if (curLen <= 0) {
        return;
    }

    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + blockIdx * blockLength);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockIdx * blockLength);

    int64_t tileNum = (curLen + elemsPerTile - 1) / elemsPerTile;
    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elemsPerTile;
        int64_t remain = curLen - offset;
        int32_t count = static_cast<int32_t>(remain < elemsPerTile ? remain : elemsPerTile);

        AscendC::LocalTensor<T> xLocal = inQueue.AllocTensor<T>();
        SigmoidCopyIn<T>(xLocal, xGm[offset], count);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        AscendC::LocalTensor<T> yLocal = outQueue.AllocTensor<T>();

        if constexpr (std::is_same_v<T, float>) {
            AscendC::Mins(yLocal, xLocal, SIGMOID_CLAMP_F32, count);
            AscendC::Exp(yLocal, yLocal, count);
            AscendC::Adds(xLocal, yLocal, 1.0f, count);
            AscendC::Div(yLocal, yLocal, xLocal, count);
        } else if constexpr (std::is_same_v<T, half>) {
            AscendC::LocalTensor<float> f0 = calcBuf0.Get<float>();
            AscendC::LocalTensor<float> f1 = calcBuf1.Get<float>();
            AscendC::Cast(f0, xLocal, AscendC::RoundMode::CAST_NONE, count);
            AscendC::Mins(f0, f0, SIGMOID_CLAMP_F32, count);
            AscendC::Exp(f0, f0, count);
            AscendC::Adds(f1, f0, 1.0f, count);
            AscendC::Div(f0, f0, f1, count);
            AscendC::Cast(yLocal, f0, AscendC::RoundMode::CAST_RINT, count);
        } else if constexpr (std::is_same_v<T, bfloat16_t>) {
            AscendC::LocalTensor<half> hX = xLocal.template ReinterpretCast<half>();
            AscendC::LocalTensor<half> hY = yLocal.template ReinterpretCast<half>();
            AscendC::Cast(hX, xLocal, AscendC::RoundMode::CAST_NONE, count);
            AscendC::Mins(hX, hX, SIGMOID_CLAMP_F16, count);
            AscendC::Exp(hX, hX, count);
            AscendC::Adds(hY, hX, (half)1.0f, count);
            AscendC::Div(hX, hX, hY, count);
            AscendC::Cast(yLocal, hX, AscendC::RoundMode::CAST_RINT, count);
        }

        inQueue.FreeTensor(xLocal);
        outQueue.EnQue(yLocal);
        yLocal = outQueue.DeQue<T>();
        SigmoidCopyOut<T>(yGm[offset], yLocal, count);
        outQueue.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(int64_t totalLength, int64_t dtypeSize, int64_t bufferMultiplier)
{
    if (dtypeSize <= 0) {
        dtypeSize = 4;
    }
    int64_t alignElems = 32 / dtypeSize;
    if (alignElems < 1) {
        alignElems = 1;
    }

    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = static_cast<int64_t>(platform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }

    constexpr int64_t MIN_ELEMS_PER_CORE = 2048;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    blockLength = ((blockLength + alignElems - 1) / alignElems) * alignElems;
    if (blockLength < alignElems) {
        blockLength = alignElems;
    }

    uint64_t budget = ubSize * 9 / 10;
    if (bufferMultiplier < 1) {
        bufferMultiplier = 1;
    }
    int64_t tileSize = static_cast<int64_t>(budget / static_cast<uint64_t>(bufferMultiplier));
    tileSize = tileSize / 32 * 32;
    if (tileSize < 32) {
        tileSize = 32;
    }
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
