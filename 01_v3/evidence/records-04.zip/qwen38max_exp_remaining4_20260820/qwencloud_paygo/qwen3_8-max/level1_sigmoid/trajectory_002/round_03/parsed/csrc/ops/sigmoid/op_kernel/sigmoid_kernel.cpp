#include <cstdint>
#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
constexpr static uint32_t MAX_TILE_BYTES = 65535;

static uint32_t align_tile_bytes(uint64_t bytes)
{
    if (bytes > MAX_TILE_BYTES) {
        bytes = MAX_TILE_BYTES;
    }
    bytes = (bytes / 32) * 32;
    if (bytes < 32) {
        bytes = 32;
    }
    return static_cast<uint32_t>(bytes);
}

template <typename T>
__global__ __aicore__ void sigmoid_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - blockLength * AscendC::GetBlockIdx();
    if (currentBlockLength <= 0) {
        return;
    }
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    int64_t elementNumPerTile = tileSize / sizeof(T);
    if (elementNumPerTile <= 0) {
        return;
    }

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        AscendC::Sigmoid(yLocal, xLocal, static_cast<int32_t>(elementNumPerTile));
        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);

        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailTileElementNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();

        int64_t alignElems = 32 / sizeof(T);
        if (alignElems < 1) {
            alignElems = 1;
        }
        int64_t computeElems = ((tailTileElementNum + alignElems - 1) / alignElems) * alignElems;
        if (computeElems > elementNumPerTile) {
            computeElems = elementNumPerTile;
        }

        AscendC::Sigmoid(yLocal, xLocal, static_cast<int32_t>(computeElems));
        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);

        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_sigmoid_tiling_params(int64_t totalLength)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 256 * 1024;
    }

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    uint32_t tileBytes = align_tile_bytes(ubSize / (PIPELINE_DEPTH * 2));

    if (totalLength <= 0) {
        return std::make_tuple(1, 0, tileBytes);
    }

    int64_t blocksByMin = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    int64_t numBlocks = std::min(coreNum, blocksByMin);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    return std::make_tuple(numBlocks, blockLength, tileBytes);
}

extern "C" {

void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
