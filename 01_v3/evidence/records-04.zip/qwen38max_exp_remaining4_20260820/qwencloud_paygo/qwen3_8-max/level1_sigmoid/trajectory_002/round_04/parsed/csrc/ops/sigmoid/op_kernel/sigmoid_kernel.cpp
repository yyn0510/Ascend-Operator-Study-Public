#include <cstdint>
#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;
constexpr static int32_t BF16_PIPELINE_DEPTH = 1;
constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
constexpr static uint32_t MAX_TILE_BYTES = 65535;

static uint32_t align_tile_bytes(uint64_t bytes)
{
    if (bytes > MAX_TILE_BYTES) {
        bytes = MAX_TILE_BYTES;
    }
    bytes = (bytes / 32) * 32;
    if (bytes < 32) {
        bytes = 32;
    }
    return static_cast<uint32_t>(bytes);
}

__aicore__ inline float bf16_bits_to_float_sat(uint16_t v)
{
    if ((v & 0x7F80u) == 0x7F80u) {
        if ((v & 0x007Fu) != 0u) {
            union {
                uint32_t u;
                float f;
            } bits;
            bits.u = (static_cast<uint32_t>(v) << 16) | 0x00400000u;
            return bits.f;
        }
        return (v & 0x8000u) ? -88.0f : 88.0f;
    }

    union {
        uint32_t u;
        float f;
    } bits;
    bits.u = static_cast<uint32_t>(v) << 16;
    float value = bits.f;

    if (value > 88.0f) {
        return 88.0f;
    }
    if (value < -88.0f) {
        return -88.0f;
    }
    return value;
}

__aicore__ inline uint16_t float_to_bf16_bits(float value)
{
    union {
        uint32_t u;
        float f;
    } bits;
    bits.f = value;
    uint32_t u = bits.u;

    if ((u & 0x7F800000u) == 0x7F800000u && (u & 0x007FFFFFu) != 0u) {
        return static_cast<uint16_t>((u >> 16) | 0x0040u);
    }

    uint32_t lsb = (u >> 16) & 1u;
    uint32_t rounded = u + 0x00007FFFu + lsb;
    return static_cast<uint16_t>(rounded >> 16);
}

template <typename T>
__global__ __aicore__ void sigmoid_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - blockLength * AscendC::GetBlockIdx();
    if (currentBlockLength <= 0) {
        return;
    }
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    int64_t elementNumPerTile = tileSize / sizeof(T);
    if (elementNumPerTile <= 0) {
        return;
    }

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        AscendC::Sigmoid(yLocal, xLocal, static_cast<int32_t>(elementNumPerTile));
        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);

        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailTileElementNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();

        int64_t alignElems = 32 / sizeof(T);
        if (alignElems < 1) {
            alignElems = 1;
        }
        int64_t computeElems = ((tailTileElementNum + alignElems - 1) / alignElems) * alignElems;
        if (computeElems > elementNumPerTile) {
            computeElems = elementNumPerTile;
        }

        AscendC::Sigmoid(yLocal, xLocal, static_cast<int32_t>(computeElems));
        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);

        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }
}

__global__ __aicore__ void sigmoid_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<int16_t> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, BF16_PIPELINE_DEPTH> inQueueU16;
    AscendC::TQue<AscendC::QuePosition::VECOUT, BF16_PIPELINE_DEPTH> outQueueU16;
    AscendC::TQue<AscendC::QuePosition::VECIN, BF16_PIPELINE_DEPTH> inQueueF;
    AscendC::TQue<AscendC::QuePosition::VECOUT, BF16_PIPELINE_DEPTH> outQueueF;

    int64_t elementNumPerTile = tileSize / sizeof(int16_t);
    if (elementNumPerTile <= 0) {
        return;
    }

    uint32_t floatBufSize = static_cast<uint32_t>(elementNumPerTile * sizeof(float));

    pipe.InitBuffer(inQueueU16, BF16_PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueU16, BF16_PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(inQueueF, BF16_PIPELINE_DEPTH, floatBufSize);
    pipe.InitBuffer(outQueueF, BF16_PIPELINE_DEPTH, floatBufSize);

    xGm.SetGlobalBuffer((__gm__ int16_t *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ int16_t *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - blockLength * AscendC::GetBlockIdx();
    if (currentBlockLength <= 0) {
        return;
    }
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        int32_t computeCount = static_cast<int32_t>(elementNumPerTile);

        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(computeCount * sizeof(int16_t)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<int16_t> padParams{false, 0, 0, 0};

        auto xU16 = inQueueU16.AllocTensor<int16_t>();
        AscendC::DataCopyPad(xU16, xGm[offset], copyParams, padParams);
        inQueueU16.EnQue(xU16);
        xU16 = inQueueU16.DeQue<int16_t>();

        auto xF = inQueueF.AllocTensor<float>();
        for (int32_t j = 0; j < computeCount; ++j) {
            xF[j] = bf16_bits_to_float_sat(static_cast<uint16_t>(xU16[j]));
        }
        inQueueF.EnQue(xF);
        xF = inQueueF.DeQue<float>();

        auto yF = outQueueF.AllocTensor<float>();
        AscendC::Sigmoid(yF, xF, computeCount);
        outQueueF.EnQue(yF);
        yF = outQueueF.DeQue<float>();

        auto yU16 = outQueueU16.AllocTensor<int16_t>();
        for (int32_t j = 0; j < computeCount; ++j) {
            yU16[j] = static_cast<int16_t>(float_to_bf16_bits(yF[j]));
        }
        outQueueU16.EnQue(yU16);

        inQueueU16.FreeTensor(xU16);
        inQueueF.FreeTensor(xF);
        outQueueF.FreeTensor(yF);

        yU16 = outQueueU16.DeQue<int16_t>();
        AscendC::DataCopyPad(yGm[offset], yU16, copyParams);
        outQueueU16.FreeTensor(yU16);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        int32_t tailCount = static_cast<int32_t>(tailTileElementNum);

        int64_t alignElems = 8;
        int64_t computeElems = ((tailTileElementNum + alignElems - 1) / alignElems) * alignElems;
        if (computeElems > elementNumPerTile) {
            computeElems = elementNumPerTile;
        }
        int32_t computeCount = static_cast<int32_t>(computeElems);

        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailCount * sizeof(int16_t)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<int16_t> padParams{false, 0, 0, 0};

        auto xU16 = inQueueU16.AllocTensor<int16_t>();
        AscendC::DataCopyPad(xU16, xGm[offset], copyParams, padParams);
        inQueueU16.EnQue(xU16);
        xU16 = inQueueU16.DeQue<int16_t>();

        auto xF = inQueueF.AllocTensor<float>();
        for (int32_t j = 0; j < computeCount; ++j) {
            if (j < tailCount) {
                xF[j] = bf16_bits_to_float_sat(static_cast<uint16_t>(xU16[j]));
            } else {
                xF[j] = 0.0f;
            }
        }
        inQueueF.EnQue(xF);
        xF = inQueueF.DeQue<float>();

        auto yF = outQueueF.AllocTensor<float>();
        AscendC::Sigmoid(yF, xF, computeCount);
        outQueueF.EnQue(yF);
        yF = outQueueF.DeQue<float>();

        auto yU16 = outQueueU16.AllocTensor<int16_t>();
        for (int32_t j = 0; j < tailCount; ++j) {
            yU16[j] = static_cast<int16_t>(float_to_bf16_bits(yF[j]));
        }
        outQueueU16.EnQue(yU16);

        inQueueU16.FreeTensor(xU16);
        inQueueF.FreeTensor(xF);
        outQueueF.FreeTensor(yF);

        yU16 = outQueueU16.DeQue<int16_t>();
        AscendC::DataCopyPad(yGm[offset], yU16, copyParams);
        outQueueU16.FreeTensor(yU16);
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_sigmoid_tiling_params(int64_t totalLength)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 256 * 1024;
    }

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    uint32_t tileBytes = align_tile_bytes(ubSize / (PIPELINE_DEPTH * 2));

    if (totalLength <= 0) {
        return std::make_tuple(1, 0, tileBytes);
    }

    int64_t blocksByMin = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    int64_t numBlocks = std::min(coreNum, blocksByMin);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    return std::make_tuple(numBlocks, blockLength, tileBytes);
}

std::tuple<int64_t, int64_t, uint32_t> calc_sigmoid_tiling_params_bf16(int64_t totalLength)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 256 * 1024;
    }

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    uint32_t tileBytes = align_tile_bytes(ubSize / 8);

    if (totalLength <= 0) {
        return std::make_tuple(1, 0, tileBytes);
    }

    int64_t blocksByMin = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    int64_t numBlocks = std::min(coreNum, blocksByMin);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    return std::make_tuple(numBlocks, blockLength, tileBytes);
}

extern "C" {

void launch_sigmoid_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    sigmoid_kernel_bf16<<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
