#include <tuple>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/sigmoid_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("sigmoid(Tensor x) -> Tensor");
}

namespace {

void check_sigmoid_dtype(const torch::Tensor& x)
{
    auto dtype = x.scalar_type();
    TORCH_CHECK(
        dtype == at::ScalarType::Float ||
        dtype == at::ScalarType::Half ||
        dtype == at::ScalarType::BFloat16,
        "Sigmoid only supports float32, float16 and bfloat16.");
}

torch::Tensor sigmoid_float_contiguous(const torch::Tensor& xf)
{
    TORCH_CHECK(xf.scalar_type() == at::ScalarType::Float, "Internal error: expected float32 tensor.");
    auto xfc = xf.contiguous();
    auto yf = torch::empty_like(xfc);

    int64_t totalLength = xfc.numel();
    if (totalLength == 0) {
        return yf;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t numBlocks = 1;
    int64_t blockLength = 0;
    uint32_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_sigmoid_tiling_params(totalLength);

    auto x_ptr = (GM_ADDR)xfc.data_ptr();
    auto y_ptr = (GM_ADDR)yf.data_ptr();

    auto acl_call = [=]() -> int {
        SIGMOID_KERNEL_LAUNCH_FLOAT(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Sigmoid", acl_call);
    return yf;
}

} // namespace

torch::Tensor sigmoid_meta(const torch::Tensor &x)
{
    check_sigmoid_dtype(x);
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("sigmoid", sigmoid_meta);
}

torch::Tensor sigmoid_npu(const torch::Tensor &x)
{
    const c10::OptionalDeviceGuard guard(x.device());
    check_sigmoid_dtype(x);

    auto xc = x.contiguous();
    int64_t totalLength = xc.numel();
    if (totalLength == 0) {
        return torch::empty_like(xc);
    }

    if (xc.scalar_type() == at::ScalarType::BFloat16) {
        auto xf = xc.to(xc.options().dtype(at::ScalarType::Float));
        auto yf = sigmoid_float_contiguous(xf);
        return yf.to(xc.options().dtype(at::ScalarType::BFloat16));
    }

    auto y = torch::empty_like(xc);
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t numBlocks = 1;
    int64_t blockLength = 0;
    uint32_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_sigmoid_tiling_params(totalLength);

    auto x_ptr = (GM_ADDR)xc.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();
    auto dtype = xc.scalar_type();

    auto acl_call = [=]() -> int {
        if (dtype == at::ScalarType::Float) {
            SIGMOID_KERNEL_LAUNCH_FLOAT(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        } else if (dtype == at::ScalarType::Half) {
            SIGMOID_KERNEL_LAUNCH_HALF(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Sigmoid", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("sigmoid", sigmoid_npu);
}

} // namespace cann_bench
