#include <tuple>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/sigmoid_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("sigmoid(Tensor x) -> Tensor");
}

namespace {

void check_sigmoid_dtype(const torch::Tensor& x)
{
    auto dtype = x.scalar_type();
    TORCH_CHECK(
        dtype == at::ScalarType::Float ||
        dtype == at::ScalarType::Half ||
        dtype == at::ScalarType::BFloat16,
        "Sigmoid only supports float32, float16 and bfloat16.");
}

} // namespace

torch::Tensor sigmoid_meta(const torch::Tensor &x)
{
    check_sigmoid_dtype(x);
    return torch::empty(x.sizes(), x.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("sigmoid", sigmoid_meta);
}

torch::Tensor sigmoid_npu(const torch::Tensor &x)
{
    const c10::OptionalDeviceGuard guard(x.device());
    check_sigmoid_dtype(x);

    torch::Tensor input = x;
    if (!input.is_contiguous()) {
        input = input.contiguous();
    }

    int64_t totalLength = input.numel();
    auto y = torch::empty(input.sizes(), input.options());
    if (totalLength == 0) {
        return y;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    auto dtype = input.scalar_type();

    int64_t numBlocks = 1;
    int64_t blockLength = 0;
    uint32_t tileSize = 0;

    if (dtype == at::ScalarType::BFloat16) {
        std::tie(numBlocks, blockLength, tileSize) = calc_sigmoid_tiling_params_bf16(totalLength);
    } else {
        std::tie(numBlocks, blockLength, tileSize) = calc_sigmoid_tiling_params(totalLength);
    }

    auto x_ptr = (GM_ADDR)input.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();

    auto acl_call = [=]() -> int {
        if (dtype == at::ScalarType::Float) {
            SIGMOID_KERNEL_LAUNCH_FLOAT(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        } else if (dtype == at::ScalarType::Half) {
            SIGMOID_KERNEL_LAUNCH_HALF(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        } else if (dtype == at::ScalarType::BFloat16) {
            SIGMOID_KERNEL_LAUNCH_BF16(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Sigmoid", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("sigmoid", sigmoid_npu);
}

} // namespace cann_bench
