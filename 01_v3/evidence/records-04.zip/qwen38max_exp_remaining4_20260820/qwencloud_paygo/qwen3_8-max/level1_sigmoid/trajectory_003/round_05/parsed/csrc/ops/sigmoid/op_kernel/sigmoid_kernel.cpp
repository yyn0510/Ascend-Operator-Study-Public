#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;
constexpr static int32_t FLOAT_BUFFER_NUM = 3;
constexpr static int64_t ALIGN_BYTES = 32;

__global__ __aicore__ void sigmoid_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t alignElems = ALIGN_BYTES / static_cast<int64_t>(sizeof(float));
    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(float));
    elementNumPerTile = (elementNumPerTile / alignElems) * alignElems;
    if (elementNumPerTile <= 0) {
        return;
    }

    uint32_t tileBytes = static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float)));

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<float> xGm;
    AscendC::GlobalTensor<float> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> tmpQueue;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(tmpQueue, PIPELINE_DEPTH, tileBytes);

    xGm.SetGlobalBuffer((__gm__ float *)x + blockIdx * blockLength);
    yGm.SetGlobalBuffer((__gm__ float *)y + blockIdx * blockLength);

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;
    int64_t totalTiles = tileNum + (tailTileElementNum > 0 ? 1 : 0);
    if (totalTiles <= 0) {
        return;
    }

    AscendC::DataCopyPadExtParams<float> padIn{true, 0.0f, 0, 0};

    int64_t firstCount = (tileNum > 0) ? elementNumPerTile : tailTileElementNum;
    AscendC::DataCopyExtParams firstCopyParams{
        1, static_cast<uint32_t>(firstCount * static_cast<int64_t>(sizeof(float))), 0, 0, 0};

    auto xFirst = inQueueX.AllocTensor<float>();
    AscendC::DataCopyPad(xFirst, xGm[0], firstCopyParams, padIn);
    inQueueX.EnQue(xFirst);

    for (int64_t i = 0; i < totalTiles; ++i) {
        if (i > 0) {
            int64_t prevIndex = i - 1;
            int64_t prevCount = (prevIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
            int64_t prevOffset = prevIndex * elementNumPerTile;
            AscendC::DataCopyExtParams prevCopyParams{
                1, static_cast<uint32_t>(prevCount * static_cast<int64_t>(sizeof(float))), 0, 0, 0};

            auto yPrev = outQueueY.DeQue<float>();
            AscendC::DataCopyPad(yGm[prevOffset], yPrev, prevCopyParams);
            outQueueY.FreeTensor(yPrev);
        }

        if (i + 1 < totalTiles) {
            int64_t nextIndex = i + 1;
            int64_t nextCount = (nextIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
            int64_t nextOffset = nextIndex * elementNumPerTile;
            AscendC::DataCopyExtParams nextCopyParams{
                1, static_cast<uint32_t>(nextCount * static_cast<int64_t>(sizeof(float))), 0, 0, 0};

            auto xNext = inQueueX.AllocTensor<float>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopyParams, padIn);
            inQueueX.EnQue(xNext);
        }

        int64_t count = (i < tileNum) ? elementNumPerTile : tailTileElementNum;
        int64_t processCount64 = ((count + alignElems - 1) / alignElems) * alignElems;
        int32_t processCount = static_cast<int32_t>(processCount64);

        auto xLocal = inQueueX.DeQue<float>();
        auto yLocal = outQueueY.AllocTensor<float>();
        auto tmpLocal = tmpQueue.AllocTensor<float>();

        AscendC::Muls(xLocal, xLocal, -1.0f, processCount);
        AscendC::Exp(xLocal, xLocal, processCount);
        AscendC::Adds(xLocal, xLocal, 1.0f, processCount);
        AscendC::Duplicate(tmpLocal, 1.0f, processCount);
        AscendC::Div(yLocal, tmpLocal, xLocal, processCount);

        tmpQueue.FreeTensor(tmpLocal);
        inQueueX.FreeTensor(xLocal);
        outQueueY.EnQue(yLocal);
    }

    int64_t lastIndex = totalTiles - 1;
    int64_t lastCount = (lastIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
    int64_t lastOffset = lastIndex * elementNumPerTile;
    AscendC::DataCopyExtParams lastCopyParams{
        1, static_cast<uint32_t>(lastCount * static_cast<int64_t>(sizeof(float))), 0, 0, 0};

    auto yLast = outQueueY.DeQue<float>();
    AscendC::DataCopyPad(yGm[lastOffset], yLast, lastCopyParams);
    outQueueY.FreeTensor(yLast);
}

template <typename T>
__global__ __aicore__ void sigmoid_kernel_convert(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t alignElems = ALIGN_BYTES / static_cast<int64_t>(sizeof(T));
    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    elementNumPerTile = (elementNumPerTile / alignElems) * alignElems;
    if (elementNumPerTile <= 0) {
        return;
    }

    uint32_t tileBytes = static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(T)));
    uint32_t floatWorkBytes = static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float)));

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TQue<AscendC::QuePosition::VECIN, FLOAT_BUFFER_NUM> floatQueue;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(floatQueue, FLOAT_BUFFER_NUM, floatWorkBytes);

    xGm.SetGlobalBuffer((__gm__ T *)x + blockIdx * blockLength);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockIdx * blockLength);

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;
    int64_t totalTiles = tileNum + (tailTileElementNum > 0 ? 1 : 0);
    if (totalTiles <= 0) {
        return;
    }

    AscendC::DataCopyPadExtParams<T> padIn{true, static_cast<T>(0), 0, 0};

    int64_t firstCount = (tileNum > 0) ? elementNumPerTile : tailTileElementNum;
    AscendC::DataCopyExtParams firstCopyParams{
        1, static_cast<uint32_t>(firstCount * static_cast<int64_t>(sizeof(T))), 0, 0, 0};

    auto xFirst = inQueueX.AllocTensor<T>();
    AscendC::DataCopyPad(xFirst, xGm[0], firstCopyParams, padIn);
    inQueueX.EnQue(xFirst);

    for (int64_t i = 0; i < totalTiles; ++i) {
        if (i > 0) {
            int64_t prevIndex = i - 1;
            int64_t prevCount = (prevIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
            int64_t prevOffset = prevIndex * elementNumPerTile;
            AscendC::DataCopyExtParams prevCopyParams{
                1, static_cast<uint32_t>(prevCount * static_cast<int64_t>(sizeof(T))), 0, 0, 0};

            auto yPrev = outQueueY.DeQue<T>();
            AscendC::DataCopyPad(yGm[prevOffset], yPrev, prevCopyParams);
            outQueueY.FreeTensor(yPrev);
        }

        if (i + 1 < totalTiles) {
            int64_t nextIndex = i + 1;
            int64_t nextCount = (nextIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
            int64_t nextOffset = nextIndex * elementNumPerTile;
            AscendC::DataCopyExtParams nextCopyParams{
                1, static_cast<uint32_t>(nextCount * static_cast<int64_t>(sizeof(T))), 0, 0, 0};

            auto xNext = inQueueX.AllocTensor<T>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopyParams, padIn);
            inQueueX.EnQue(xNext);
        }

        int64_t count = (i < tileNum) ? elementNumPerTile : tailTileElementNum;
        int64_t processCount64 = ((count + alignElems - 1) / alignElems) * alignElems;
        int32_t processCount = static_cast<int32_t>(processCount64);

        auto xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();

        auto aLocal = floatQueue.AllocTensor<float>();
        auto bLocal = floatQueue.AllocTensor<float>();
        auto cLocal = floatQueue.AllocTensor<float>();

        AscendC::Cast(aLocal, xLocal, AscendC::RoundMode::CAST_NONE, processCount);
        inQueueX.FreeTensor(xLocal);

        AscendC::Muls(bLocal, aLocal, -1.0f, processCount);
        AscendC::Exp(bLocal, bLocal, processCount);
        AscendC::Adds(bLocal, bLocal, 1.0f, processCount);
        AscendC::Duplicate(cLocal, 1.0f, processCount);
        AscendC::Div(aLocal, cLocal, bLocal, processCount);

        AscendC::Cast(yLocal, aLocal, AscendC::RoundMode::CAST_RINT, processCount);

        floatQueue.FreeTensor(aLocal);
        floatQueue.FreeTensor(bLocal);
        floatQueue.FreeTensor(cLocal);

        outQueueY.EnQue(yLocal);
    }

    int64_t lastIndex = totalTiles - 1;
    int64_t lastCount = (lastIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
    int64_t lastOffset = lastIndex * elementNumPerTile;
    AscendC::DataCopyExtParams lastCopyParams{
        1, static_cast<uint32_t>(lastCount * static_cast<int64_t>(sizeof(T))), 0, 0, 0};

    auto yLast = outQueueY.DeQue<T>();
    AscendC::DataCopyPad(yGm[lastOffset], yLast, lastCopyParams);
    outQueueY.FreeTensor(yLast);
}

std::tuple<int64_t, int64_t, uint32_t> calc_sigmoid_tiling_params(
    int64_t totalLength,
    int64_t dtypeSize)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();

    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 256ULL * 1024ULL;
    }

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = 1;
    if (totalLength > 0) {
        numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
        if (numBlocks <= 0) {
            numBlocks = 1;
        }
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    uint64_t bufferFactor = (dtypeSize <= 2) ? 14ULL : 8ULL;
    uint64_t tileSize64 = ubSize / bufferFactor;
    tileSize64 = (tileSize64 / 32ULL) * 32ULL;
    if (tileSize64 < 32ULL) {
        tileSize64 = 32ULL;
    }

    uint32_t tileSize = static_cast<uint32_t>(tileSize64);
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void *stream)
{
    sigmoid_kernel_float<<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void *stream)
{
    sigmoid_kernel_convert<half><<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void *stream)
{
    sigmoid_kernel_convert<bfloat16_t><<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

}
