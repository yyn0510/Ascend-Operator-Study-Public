#include <cstdint>
#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t BUFFER_COUNT = PIPELINE_DEPTH * 2 + 4;

template <typename T>
__global__ __aicore__ void sigmoid_kernel(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::QuePosition::VECOUT> tmpNumBuf;
    AscendC::TBuf<AscendC::QuePosition::VECOUT> tmpDenBuf;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpNumBuf, tileSize);
    pipe.InitBuffer(tmpDenBuf, tileSize);

    xGm.SetGlobalBuffer((__gm__ T *)x + blockIdx * blockLength);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockIdx * blockLength);

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize / sizeof(T));
    if (elementNumPerTile <= 0) {
        elementNumPerTile = 1;
    }

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;
    int64_t totalTiles = tileNum + (tailTileElementNum > 0 ? 1 : 0);
    if (totalTiles <= 0) {
        return;
    }

    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    const T zero = static_cast<T>(0.0f);
    const T one = static_cast<T>(1.0f);
    const T minusOne = static_cast<T>(-1.0f);

    auto numLocal = tmpNumBuf.Get<T>();
    auto denLocal = tmpDenBuf.Get<T>();

    int64_t firstCount = (0 < tileNum) ? elementNumPerTile : tailTileElementNum;
    AscendC::DataCopyExtParams firstCopyParams{
        1, static_cast<uint32_t>(firstCount * sizeof(T)), 0, 0, 0};

    auto xFirst = inQueueX.AllocTensor<T>();
    AscendC::DataCopyPad(xFirst, xGm[0], firstCopyParams, padParams);
    inQueueX.EnQue(xFirst);

    for (int64_t i = 0; i < totalTiles; ++i) {
        if (i > 0) {
            int64_t prevIndex = i - 1;
            int64_t prevCount = (prevIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
            int64_t prevOffset = prevIndex * elementNumPerTile;
            AscendC::DataCopyExtParams prevCopyParams{
                1, static_cast<uint32_t>(prevCount * sizeof(T)), 0, 0, 0};

            auto yPrev = outQueueY.DeQue<T>();
            AscendC::DataCopyPad(yGm[prevOffset], yPrev, prevCopyParams);
            outQueueY.FreeTensor(yPrev);
        }

        if (i + 1 < totalTiles) {
            int64_t nextIndex = i + 1;
            int64_t nextCount = (nextIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
            int64_t nextOffset = nextIndex * elementNumPerTile;
            AscendC::DataCopyExtParams nextCopyParams{
                1, static_cast<uint32_t>(nextCount * sizeof(T)), 0, 0, 0};

            auto xNext = inQueueX.AllocTensor<T>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopyParams, padParams);
            inQueueX.EnQue(xNext);
        }

        int64_t curCount = (i < tileNum) ? elementNumPerTile : tailTileElementNum;

        auto xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();

        // Stable branchless sigmoid:
        // numerator   = exp(min(x, 0))
        // denominator = 1 + exp(-abs(x))
        // y = numerator / denominator
        AscendC::Mins(numLocal, xLocal, zero, curCount);
        AscendC::Abs(denLocal, xLocal, curCount);
        AscendC::Muls(denLocal, denLocal, minusOne, curCount);

        AscendC::Exp(numLocal, numLocal, curCount);
        AscendC::Exp(denLocal, denLocal, curCount);
        AscendC::Adds(denLocal, denLocal, one, curCount);

        AscendC::Div(yLocal, numLocal, denLocal, curCount);

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
    }

    int64_t lastIndex = totalTiles - 1;
    int64_t lastCount = (lastIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
    int64_t lastOffset = lastIndex * elementNumPerTile;
    AscendC::DataCopyExtParams lastCopyParams{
        1, static_cast<uint32_t>(lastCount * sizeof(T)), 0, 0, 0};

    auto yLast = outQueueY.DeQue<T>();
    AscendC::DataCopyPad(yGm[lastOffset], yLast, lastCopyParams);
    outQueueY.FreeTensor(yLast);
}

std::tuple<int64_t, int64_t, uint32_t> calc_sigmoid_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();

    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 256ULL * 1024ULL;
    }

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = 1;
    if (totalLength > 0) {
        numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
        if (numBlocks <= 0) {
            numBlocks = 1;
        }
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    uint64_t perBuffer = ubSize / BUFFER_COUNT;
    perBuffer = (perBuffer / 32ULL) * 32ULL;
    if (perBuffer < 32ULL) {
        perBuffer = 32ULL;
    }

    uint32_t tileSize = static_cast<uint32_t>(perBuffer);
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void *stream)
{
    sigmoid_kernel<float><<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void *stream)
{
    sigmoid_kernel<half><<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void *stream)
{
    sigmoid_kernel<bfloat16_t><<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

}
