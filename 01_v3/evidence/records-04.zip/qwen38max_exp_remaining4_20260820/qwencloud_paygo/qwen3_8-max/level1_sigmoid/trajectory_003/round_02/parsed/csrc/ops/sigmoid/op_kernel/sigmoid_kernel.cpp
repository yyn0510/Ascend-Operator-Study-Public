#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

__global__ __aicore__ void sigmoid_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize)
{
    AscendC::TPipe pipe;

    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    AscendC::GlobalTensor<float> xGm;
    AscendC::GlobalTensor<float> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);

    xGm.SetGlobalBuffer((__gm__ float *)x + blockIdx * blockLength);
    yGm.SetGlobalBuffer((__gm__ float *)y + blockIdx * blockLength);

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize / sizeof(float));
    if (elementNumPerTile <= 0) {
        return;
    }

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;
    int64_t totalTiles = tileNum + (tailTileElementNum > 0 ? 1 : 0);
    if (totalTiles <= 0) {
        return;
    }

    AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};

    int64_t firstCount = (tileNum > 0) ? elementNumPerTile : tailTileElementNum;
    AscendC::DataCopyExtParams firstCopyParams{
        1, static_cast<uint32_t>(firstCount * sizeof(float)), 0, 0, 0};

    auto xFirst = inQueueX.AllocTensor<float>();
    AscendC::DataCopyPad(xFirst, xGm[0], firstCopyParams, padParams);
    inQueueX.EnQue(xFirst);

    for (int64_t i = 0; i < totalTiles; ++i) {
        if (i > 0) {
            int64_t prevIndex = i - 1;
            int64_t prevCount = (prevIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
            int64_t prevOffset = prevIndex * elementNumPerTile;
            AscendC::DataCopyExtParams prevCopyParams{
                1, static_cast<uint32_t>(prevCount * sizeof(float)), 0, 0, 0};

            auto yPrev = outQueueY.DeQue<float>();
            AscendC::DataCopyPad(yGm[prevOffset], yPrev, prevCopyParams);
            outQueueY.FreeTensor(yPrev);
        }

        if (i + 1 < totalTiles) {
            int64_t nextIndex = i + 1;
            int64_t nextCount = (nextIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
            int64_t nextOffset = nextIndex * elementNumPerTile;
            AscendC::DataCopyExtParams nextCopyParams{
                1, static_cast<uint32_t>(nextCount * sizeof(float)), 0, 0, 0};

            auto xNext = inQueueX.AllocTensor<float>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopyParams, padParams);
            inQueueX.EnQue(xNext);
        }

        int64_t curCount = (i < tileNum) ? elementNumPerTile : tailTileElementNum;

        auto xLocal = inQueueX.DeQue<float>();
        auto yLocal = outQueueY.AllocTensor<float>();

        AscendC::Muls(yLocal, xLocal, -1.0f, curCount);
        AscendC::Exp(yLocal, yLocal, curCount);
        AscendC::Adds(yLocal, yLocal, 1.0f, curCount);
        AscendC::Reciprocal(yLocal, yLocal, curCount);

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
    }

    int64_t lastIndex = totalTiles - 1;
    int64_t lastCount = (lastIndex < tileNum) ? elementNumPerTile : tailTileElementNum;
    int64_t lastOffset = lastIndex * elementNumPerTile;
    AscendC::DataCopyExtParams lastCopyParams{
        1, static_cast<uint32_t>(lastCount * sizeof(float)), 0, 0, 0};

    auto yLast = outQueueY.DeQue<float>();
    AscendC::DataCopyPad(yGm[lastOffset], yLast, lastCopyParams);
    outQueueY.FreeTensor(yLast);
}

std::tuple<int64_t, int64_t, uint32_t> calc_sigmoid_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();

    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 256ULL * 1024ULL;
    }

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = 1;
    if (totalLength > 0) {
        numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
        if (numBlocks <= 0) {
            numBlocks = 1;
        }
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    uint64_t tileSize64 = ubSize / 6ULL;
    tileSize64 = (tileSize64 / 32ULL) * 32ULL;
    if (tileSize64 < 32ULL) {
        tileSize64 = 32ULL;
    }

    uint32_t tileSize = static_cast<uint32_t>(tileSize64);
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_sigmoid_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void *stream)
{
    sigmoid_kernel_float<<<static_cast<uint32_t>(numBlocks), nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

}
