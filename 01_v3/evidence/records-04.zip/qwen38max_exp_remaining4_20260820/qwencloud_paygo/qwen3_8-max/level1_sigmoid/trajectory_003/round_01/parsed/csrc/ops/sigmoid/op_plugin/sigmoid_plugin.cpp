#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/sigmoid_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("sigmoid(Tensor x) -> Tensor y");
}

torch::Tensor sigmoid_meta(const torch::Tensor &x)
{
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("sigmoid", sigmoid_meta);
}

torch::Tensor sigmoid_npu(const torch::Tensor &x)
{
    const c10::OptionalDeviceGuard guard(x.device());

    auto x_contig = x.contiguous();
    auto y = torch::empty_like(x_contig);

    int64_t totalLength = x_contig.numel();
    if (totalLength == 0) {
        return y;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t numBlocks = 1;
    int64_t blockLength = totalLength;
    uint32_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_sigmoid_tiling_params(totalLength);

    GM_ADDR x_ptr = reinterpret_cast<GM_ADDR>(x_contig.data_ptr());
    GM_ADDR y_ptr = reinterpret_cast<GM_ADDR>(y.data_ptr());

    auto dtype = x_contig.scalar_type();
    TORCH_CHECK(
        dtype == torch::kFloat32 || dtype == torch::kFloat16 || dtype == torch::kBFloat16,
        "Sigmoid only supports float32, float16 and bfloat16");

    auto acl_call = [=]() -> int {
        if (dtype == torch::kFloat32) {
            launch_sigmoid_kernel_float(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        } else if (dtype == torch::kFloat16) {
            launch_sigmoid_kernel_half(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        } else {
            launch_sigmoid_kernel_bfloat16(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Sigmoid", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("sigmoid", sigmoid_npu);
}

} // namespace cann_bench
