/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file sigmoid_kernel.cpp
 * \brief Sigmoid kernel, host tiling and launch wrappers for Ascend C Direct Launch.
 */

#include <tuple>
#include <algorithm>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void sigmoid_kernel_impl(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize)
{
    constexpr int32_t ALIGN_ELEMS = (sizeof(T) == 4) ? 8 : 16;

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;

    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t blockOffset = blockIdx * blockLength;
    int64_t currentBlockLength = totalLength - blockOffset;
    if (currentBlockLength <= 0) {
        return;
    }
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    elementNumPerTile = (elementNumPerTile / ALIGN_ELEMS) * ALIGN_ELEMS;
    if (elementNumPerTile < ALIGN_ELEMS) {
        elementNumPerTile = ALIGN_ELEMS;
    }

    uint32_t bufBytes = static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(T)));

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, bufBytes);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, bufBytes);

    xGm.SetGlobalBuffer((__gm__ T*)x + blockOffset);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockOffset);

    int64_t fullTiles = currentBlockLength / elementNumPerTile;
    int64_t tail = currentBlockLength - fullTiles * elementNumPerTile;
    int64_t tileCount = fullTiles + (tail > 0 ? 1 : 0);
    if (tileCount == 0) {
        return;
    }

    AscendC::DataCopyExtParams fullCopyParams{
        1, static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
    AscendC::DataCopyExtParams tailCopyParams{
        1, static_cast<uint32_t>(tail * static_cast<int64_t>(sizeof(T))), 0, 0, 0};

    AscendC::DataCopyPadExtParams<T> padFalse{false, 0, 0, 0};
    AscendC::DataCopyPadExtParams<T> padTrue{true, 0, 0, 0};

    int64_t tailCompute = 0;
    if (tail > 0) {
        tailCompute = ((tail + ALIGN_ELEMS - 1) / ALIGN_ELEMS) * ALIGN_ELEMS;
        if (tailCompute > elementNumPerTile) {
            tailCompute = elementNumPerTile;
        }
    }

    {
        auto xLocal = inQueue.AllocTensor<T>();
        if (fullTiles > 0) {
            AscendC::DataCopyPad(xLocal, xGm[0], fullCopyParams, padFalse);
        } else {
            AscendC::DataCopyPad(xLocal, xGm[0], tailCopyParams, padTrue);
        }
        inQueue.EnQue(xLocal);
    }

    bool hasPending = false;
    int64_t pendingOffset = 0;
    int64_t pendingCount = 0;

    for (int64_t tileIdx = 0; tileIdx < tileCount; ++tileIdx) {
        int64_t curOffset = tileIdx * elementNumPerTile;
        int64_t curCount = (tileIdx < fullTiles) ? elementNumPerTile : tail;
        int64_t curCompute = (tileIdx < fullTiles) ? elementNumPerTile : tailCompute;

        auto xLocal = inQueue.DeQue<T>();

        if (tileIdx + 1 < tileCount) {
            int64_t nextOffset = (tileIdx + 1) * elementNumPerTile;
            bool nextFull = ((tileIdx + 1) < fullTiles);
            auto nextLocal = inQueue.AllocTensor<T>();
            if (nextFull) {
                AscendC::DataCopyPad(nextLocal, xGm[nextOffset], fullCopyParams, padFalse);
            } else {
                AscendC::DataCopyPad(nextLocal, xGm[nextOffset], tailCopyParams, padTrue);
            }
            inQueue.EnQue(nextLocal);
        }

        if (hasPending) {
            auto prevOut = outQueue.DeQue<T>();
            AscendC::DataCopyExtParams prevCopyParams{
                1, static_cast<uint32_t>(pendingCount * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
            AscendC::DataCopyPad(yGm[pendingOffset], prevOut, prevCopyParams);
            outQueue.FreeTensor(prevOut);
        }

        auto yLocal = outQueue.AllocTensor<T>();
        AscendC::Sigmoid(yLocal, xLocal, static_cast<int32_t>(curCompute));
        outQueue.EnQue(yLocal);

        inQueue.FreeTensor(xLocal);

        hasPending = true;
        pendingOffset = curOffset;
        pendingCount = curCount;
    }

    if (hasPending) {
        auto lastOut = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams lastCopyParams{
            1, static_cast<uint32_t>(pendingCount * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
        AscendC::DataCopyPad(yGm[pendingOffset], lastOut, lastCopyParams);
        outQueue.FreeTensor(lastOut);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_sigmoid_tiling_params(
    int64_t totalLength,
    int64_t mode)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr static uint64_t UB_RESERVE = 64 * 1024;
    constexpr static uint64_t BUFFER_NUM = 4;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 256 * 1024;
    }

    int64_t coreNum = static_cast<int64_t>(ascendcPlatform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }

    if (totalLength <= 0) {
        return std::make_tuple(1, 0, 64);
    }

    int64_t blocksByWork = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    int64_t numBlocks = std::min(coreNum, blocksByWork);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t alignElem = (mode == 0) ? 8 : 16;
    int64_t rawBlockLength = (totalLength + numBlocks - 1) / numBlocks;
    int64_t blockLength = ((rawBlockLength + alignElem - 1) / alignElem) * alignElem;

    uint64_t usableUbSize = (ubSize > UB_RESERVE) ? (ubSize - UB_RESERVE) : ubSize;
    uint64_t tileBytes = usableUbSize / BUFFER_NUM;
    tileBytes = (tileBytes / 64) * 64;
    if (tileBytes < 1024) {
        tileBytes = 1024;
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<int64_t>(tileBytes));
}

extern "C" {

void launch_sigmoid_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void* stream)
{
    sigmoid_kernel_impl<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_half(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void* stream)
{
    sigmoid_kernel_impl<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_sigmoid_kernel_bfloat16(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    void* stream)
{
    sigmoid_kernel_impl<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
