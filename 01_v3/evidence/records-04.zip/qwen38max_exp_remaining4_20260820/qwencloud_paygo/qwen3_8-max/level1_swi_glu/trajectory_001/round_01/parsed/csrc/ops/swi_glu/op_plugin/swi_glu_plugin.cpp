/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

torch::Tensor swi_glu_meta(const torch::Tensor& input, int64_t dim)
{
    int64_t rank = input.dim();
    TORCH_CHECK(rank > 0, "SwiGlu input must have at least one dimension.");

    int64_t dim_ = dim;
    if (dim_ < 0) {
        dim_ += rank;
    }
    TORCH_CHECK(dim_ >= 0 && dim_ < rank, "SwiGlu dim out of range.");

    auto outSizes = input.sizes().vec();
    TORCH_CHECK(outSizes[dim_] % 2 == 0, "SwiGlu split dimension size must be even.");
    outSizes[dim_] /= 2;

    return torch::empty(outSizes, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor& input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto output = swi_glu_meta(input, dim);

    if (output.numel() == 0) {
        return output;
    }

    TORCH_CHECK(
        input.scalar_type() == torch::kFloat32 ||
        input.scalar_type() == torch::kFloat16 ||
        input.scalar_type() == torch::kBFloat16,
        "SwiGlu only supports float32, float16 and bfloat16.");

    auto x = input.is_contiguous() ? input : input.contiguous();
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t rank = x.dim();
    int64_t dim_ = dim;
    if (dim_ < 0) {
        dim_ += rank;
    }

    auto sizes = x.sizes();
    int64_t halfDim = sizes[dim_] / 2;

    int64_t inner = 1;
    for (int64_t i = dim_ + 1; i < rank; ++i) {
        inner *= sizes[i];
    }

    int64_t outer = 1;
    for (int64_t i = 0; i < dim_; ++i) {
        outer *= sizes[i];
    }

    int64_t chunkSize = halfDim * inner;
    int64_t totalOutput = output.numel();
    int64_t dtypeSize = x.element_size();

    int64_t numBlocks = 1;
    int64_t blockLength = 0;
    uint32_t tileElems = 0;
    std::tie(numBlocks, blockLength, tileElems) =
        calc_swi_glu_tiling_params(totalOutput, dtypeSize, outer, chunkSize);

    auto inputPtr = (GM_ADDR)x.data_ptr();
    auto outputPtr = (GM_ADDR)output.data_ptr();

    auto acl_call = [=]() -> int {
        if (x.scalar_type() == torch::kFloat32) {
            launch_swi_glu_kernel_float(
                inputPtr, outputPtr, totalOutput, outer, chunkSize,
                numBlocks, blockLength, tileElems, stream);
        } else if (x.scalar_type() == torch::kFloat16) {
            launch_swi_glu_kernel_half(
                inputPtr, outputPtr, totalOutput, outer, chunkSize,
                numBlocks, blockLength, tileElems, stream);
        } else if (x.scalar_type() == torch::kBFloat16) {
            launch_swi_glu_kernel_bfloat16(
                inputPtr, outputPtr, totalOutput, outer, chunkSize,
                numBlocks, blockLength, tileElems, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return output;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
