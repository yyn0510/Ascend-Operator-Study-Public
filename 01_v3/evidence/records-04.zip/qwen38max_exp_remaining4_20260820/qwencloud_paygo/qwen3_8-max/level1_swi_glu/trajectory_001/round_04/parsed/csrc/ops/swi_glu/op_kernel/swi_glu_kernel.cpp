/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t MAX_DMA_BLOCKS = 255;
constexpr static int64_t TILE_SLACK_ELEMS = 128;

template <typename T>
__global__ __aicore__ void swi_glu_kernel(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize,
    int64_t blockLength,
    uint32_t tileElems)
{
    constexpr bool kIsFloat = std::is_same<T, float>::value;

    if (totalOutput <= 0 || outerNum <= 0 || chunkSize <= 0 ||
        blockLength <= 0 || tileElems == 0) {
        return;
    }

    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t startOut = blockIdx * blockLength;
    if (startOut >= totalOutput) {
        return;
    }

    int64_t endOut = startOut + blockLength;
    if (endOut > totalOutput) {
        endOut = totalOutput;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> inputGm;
    AscendC::GlobalTensor<T> outputGm;

    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpA;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpB;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpC;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpD;

    uint32_t tileBytes = static_cast<uint32_t>(static_cast<uint64_t>(tileElems) * sizeof(T));
    pipe.InitBuffer(inQueueX0, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(inQueueX1, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileBytes);

    if constexpr (kIsFloat) {
        pipe.InitBuffer(tmpA, 1, tileBytes);
        pipe.InitBuffer(tmpB, 1, tileBytes);
    } else {
        uint32_t floatTileBytes = static_cast<uint32_t>(static_cast<uint64_t>(tileElems) * sizeof(float));
        pipe.InitBuffer(tmpA, 1, floatTileBytes);
        pipe.InitBuffer(tmpB, 1, floatTileBytes);
        pipe.InitBuffer(tmpC, 1, floatTileBytes);
        pipe.InitBuffer(tmpD, 1, floatTileBytes);
    }

    inputGm.SetGlobalBuffer((__gm__ T*)input);
    outputGm.SetGlobalBuffer((__gm__ T*)output);

    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    int64_t tileLimit = tileElems;
    if (tileLimit > TILE_SLACK_ELEMS) {
        tileLimit -= TILE_SLACK_ELEMS;
    }
    if (tileLimit <= 0) {
        return;
    }

    int64_t pos = startOut;
    while (pos < endOut) {
        int64_t outerIdx = pos / chunkSize;
        int64_t offsetInSeg = pos - outerIdx * chunkSize;
        int64_t remainInSeg = chunkSize - offsetInSeg;
        int64_t remaining = endOut - pos;

        int64_t len = 0;
        int64_t group = 1;
        bool multiBlock = false;

        uint64_t chunkBytes64 = static_cast<uint64_t>(chunkSize) * sizeof(T);
        uint64_t srcStride64 = 2ULL * chunkBytes64;

        if (offsetInSeg == 0 &&
            remaining >= chunkSize &&
            chunkSize <= tileLimit &&
            chunkBytes64 <= 0xFFFFFFFFULL &&
            srcStride64 <= 0xFFFFFFFFULL) {

            group = tileLimit / chunkSize;
            if (group < 1) {
                group = 1;
            }

            int64_t byRemaining = remaining / chunkSize;
            if (byRemaining < group) {
                group = byRemaining;
            }

            int64_t byOuter = outerNum - outerIdx;
            if (byOuter < group) {
                group = byOuter;
            }

            if (group > MAX_DMA_BLOCKS) {
                group = MAX_DMA_BLOCKS;
            }
            if (group < 1) {
                group = 1;
            }

            len = group * chunkSize;
            multiBlock = (group > 1);
        } else {
            len = remaining;
            if (len > remainInSeg) {
                len = remainInSeg;
            }
            if (len > tileLimit) {
                len = tileLimit;
            }
        }

        if (len <= 0) {
            break;
        }

        int64_t in0 = outerIdx * 2 * chunkSize + offsetInSeg;
        int64_t in1 = in0 + chunkSize;

        auto x0Local = inQueueX0.AllocTensor<T>();
        auto x1Local = inQueueX1.AllocTensor<T>();

        if (multiBlock) {
            uint32_t chunkBytes = static_cast<uint32_t>(chunkBytes64);
            AscendC::DataCopyExtParams copyParams{
                static_cast<uint8_t>(group),
                chunkBytes,
                static_cast<uint32_t>(srcStride64),
                chunkBytes,
                0};

            AscendC::DataCopyPad(x0Local, inputGm[in0], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, inputGm[in1], copyParams, padParams);
        } else {
            uint32_t bytes = static_cast<uint32_t>(static_cast<uint64_t>(len) * sizeof(T));
            AscendC::DataCopyExtParams copyParams{1, bytes, 0, 0, 0};

            AscendC::DataCopyPad(x0Local, inputGm[in0], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, inputGm[in1], copyParams, padParams);
        }

        inQueueX0.EnQue(x0Local);
        inQueueX1.EnQue(x1Local);

        x0Local = inQueueX0.DeQue<T>();
        x1Local = inQueueX1.DeQue<T>();

        auto zLocal = outQueue.AllocTensor<T>();
        int32_t n = static_cast<int32_t>(len);

        if constexpr (kIsFloat) {
            auto c = tmpA.AllocTensor<float>();
            auto d = tmpB.AllocTensor<float>();

            // ratio = exp(min(x, 0)) / (1 + exp(-abs(x)))
            AscendC::Muls(c, x0Local, 1.0f, n);
            AscendC::Mins(c, c, 0.0f, n);

            AscendC::Abs(d, x0Local, n);
            AscendC::Muls(d, d, -1.0f, n);

            AscendC::Exp(c, c, n);
            AscendC::Exp(d, d, n);
            AscendC::Adds(d, d, 1.0f, n);

            AscendC::Div(zLocal, c, d, n);
            AscendC::Mul(zLocal, zLocal, x0Local, n);
            AscendC::Mul(zLocal, zLocal, x1Local, n);

            tmpA.FreeTensor(c);
            tmpB.FreeTensor(d);
        } else {
            auto a = tmpA.AllocTensor<float>();
            auto b = tmpB.AllocTensor<float>();
            auto c = tmpC.AllocTensor<float>();
            auto d = tmpD.AllocTensor<float>();

            AscendC::Cast(a, x0Local, AscendC::RoundMode::CAST_NONE, n);
            AscendC::Cast(b, x1Local, AscendC::RoundMode::CAST_NONE, n);

            // ratio = exp(min(x, 0)) / (1 + exp(-abs(x)))
            AscendC::Muls(c, a, 1.0f, n);
            AscendC::Mins(c, c, 0.0f, n);

            AscendC::Abs(d, a, n);
            AscendC::Muls(d, d, -1.0f, n);

            AscendC::Mul(b, b, a, n);

            AscendC::Exp(c, c, n);
            AscendC::Exp(d, d, n);
            AscendC::Adds(d, d, 1.0f, n);

            AscendC::Div(a, c, d, n);
            AscendC::Mul(b, b, a, n);

            AscendC::Cast(zLocal, b, AscendC::RoundMode::CAST_NONE, n);

            tmpA.FreeTensor(a);
            tmpB.FreeTensor(b);
            tmpC.FreeTensor(c);
            tmpD.FreeTensor(d);
        }

        outQueue.EnQue(zLocal);

        inQueueX0.FreeTensor(x0Local);
        inQueueX1.FreeTensor(x1Local);

        zLocal = outQueue.DeQue<T>();
        uint32_t outBytes = static_cast<uint32_t>(static_cast<uint64_t>(len) * sizeof(T));
        AscendC::DataCopyExtParams copyOut{1, outBytes, 0, 0, 0};
        AscendC::DataCopyPad(outputGm[pos], zLocal, copyOut);
        outQueue.FreeTensor(zLocal);

        pos += len;
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_tiling_params(
    int64_t totalOutput,
    int64_t dtypeSize,
    int64_t outerNum,
    int64_t chunkSize)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr static int64_t MAX_TILE_ELEMS = 8192;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();

    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (ubSize == 0) {
        ubSize = 245760;
    }
    if (dtypeSize <= 0) {
        dtypeSize = 4;
    }

    int64_t numBlocks = 1;
    int64_t blockLength = 0;

    if (totalOutput <= 0) {
        numBlocks = 1;
        blockLength = 0;
    } else {
        int64_t maxBlocksByWork = (totalOutput + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
        if (maxBlocksByWork < 1) {
            maxBlocksByWork = 1;
        }

        numBlocks = std::min(coreNum, maxBlocksByWork);
        if (numBlocks < 1) {
            numBlocks = 1;
        }

        if (chunkSize > 0 && (outerNum >= numBlocks || chunkSize < 64)) {
            int64_t segPerBlock = (outerNum + numBlocks - 1) / numBlocks;
            if (segPerBlock < 1) {
                segPerBlock = 1;
            }
            blockLength = segPerBlock * chunkSize;
        } else {
            blockLength = (totalOutput + numBlocks - 1) / numBlocks;
        }

        if (blockLength < 1) {
            blockLength = 1;
        }
    }

    int64_t align = 32 / dtypeSize;
    if (align < 1) {
        align = 1;
    }

    int64_t ub = static_cast<int64_t>(ubSize);
    int64_t usable = ub * 3 / 4;
    if (ub >= 131072) {
        int64_t usableReserved = ub - 65536;
        if (usableReserved < usable) {
            usable = usableReserved;
        }
    }
    if (usable < 16384) {
        usable = ub / 2;
    }
    if (usable < 4096) {
        usable = 4096;
    }

    int64_t bytesPerElem = 40;
    int64_t tile = usable / bytesPerElem;
    tile = (tile / align) * align;
    if (tile < align) {
        tile = align;
    }
    if (tile > MAX_TILE_ELEMS) {
        tile = (MAX_TILE_ELEMS / align) * align;
        if (tile < align) {
            tile = align;
        }
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tile));
}

extern "C" {

void launch_swi_glu_kernel_float(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream)
{
    if (numBlocks <= 0 || totalOutput <= 0) {
        return;
    }
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(
        input, output, totalOutput, outerNum, chunkSize, blockLength, tileElems);
}

void launch_swi_glu_kernel_half(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream)
{
    if (numBlocks <= 0 || totalOutput <= 0) {
        return;
    }
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(
        input, output, totalOutput, outerNum, chunkSize, blockLength, tileElems);
}

void launch_swi_glu_kernel_bfloat16(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream)
{
    if (numBlocks <= 0 || totalOutput <= 0) {
        return;
    }
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        input, output, totalOutput, outerNum, chunkSize, blockLength, tileElems);
}

}
