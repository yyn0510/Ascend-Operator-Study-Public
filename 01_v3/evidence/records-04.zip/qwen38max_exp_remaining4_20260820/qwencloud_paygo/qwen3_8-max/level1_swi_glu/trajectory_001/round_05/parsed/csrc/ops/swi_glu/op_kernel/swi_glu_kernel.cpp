/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t TILE_SLACK_ELEMS = 32;

template <typename T>
__global__ __aicore__ void swi_glu_kernel(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize,
    int64_t blockLength,
    uint32_t tileElems)
{
    (void)outerNum;

    constexpr bool kIsFloat = std::is_same<T, float>::value;

    if (totalOutput <= 0 || outerNum <= 0 || chunkSize <= 0 ||
        blockLength <= 0 || tileElems == 0) {
        return;
    }

    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t startOut = blockIdx * blockLength;
    if (startOut >= totalOutput) {
        return;
    }

    int64_t endOut = startOut + blockLength;
    if (endOut > totalOutput) {
        endOut = totalOutput;
    }

    AscendC::TPipe pipe;

    AscendC::GlobalTensor<T> inputGm;
    AscendC::GlobalTensor<T> outputGm;

    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpA;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpB;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpC;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpD;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpE;

    uint32_t tileBytes = static_cast<uint32_t>(static_cast<uint64_t>(tileElems) * sizeof(T));
    uint32_t floatTileBytes = static_cast<uint32_t>(static_cast<uint64_t>(tileElems) * sizeof(float));

    pipe.InitBuffer(inQueueX0, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(inQueueX1, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileBytes);

    pipe.InitBuffer(tmpA, 1, floatTileBytes);
    pipe.InitBuffer(tmpB, 1, floatTileBytes);
    pipe.InitBuffer(tmpC, 1, floatTileBytes);
    pipe.InitBuffer(tmpD, 1, floatTileBytes);
    pipe.InitBuffer(tmpE, 1, floatTileBytes);

    inputGm.SetGlobalBuffer((__gm__ T*)input);
    outputGm.SetGlobalBuffer((__gm__ T*)output);

    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    int64_t tileLimit = static_cast<int64_t>(tileElems);
    if (tileLimit > TILE_SLACK_ELEMS) {
        tileLimit -= TILE_SLACK_ELEMS;
    }
    if (tileLimit <= 0) {
        return;
    }

    int64_t pos = startOut;
    while (pos < endOut) {
        int64_t outerIdx = pos / chunkSize;
        int64_t offsetInSeg = pos - outerIdx * chunkSize;
        int64_t remainInSeg = chunkSize - offsetInSeg;
        int64_t remaining = endOut - pos;

        int64_t len = remaining;
        if (len > remainInSeg) {
            len = remainInSeg;
        }
        if (len > tileLimit) {
            len = tileLimit;
        }
        if (len <= 0) {
            break;
        }

        int64_t in0 = outerIdx * 2 * chunkSize + offsetInSeg;
        int64_t in1 = in0 + chunkSize;

        auto x0Local = inQueueX0.AllocTensor<T>();
        auto x1Local = inQueueX1.AllocTensor<T>();

        uint32_t bytes = static_cast<uint32_t>(static_cast<uint64_t>(len) * sizeof(T));
        AscendC::DataCopyExtParams copyParams{1, bytes, 0, 0, 0};

        AscendC::DataCopyPad(x0Local, inputGm[in0], copyParams, padParams);
        AscendC::DataCopyPad(x1Local, inputGm[in1], copyParams, padParams);

        inQueueX0.EnQue(x0Local);
        inQueueX1.EnQue(x1Local);

        x0Local = inQueueX0.DeQue<T>();
        x1Local = inQueueX1.DeQue<T>();

        auto zLocal = outQueue.AllocTensor<T>();
        int32_t n = static_cast<int32_t>(len);

        if constexpr (kIsFloat) {
            auto a = tmpA.AllocTensor<float>();
            auto b = tmpB.AllocTensor<float>();
            auto c = tmpC.AllocTensor<float>();

            AscendC::Mins(a, x0Local, 0.0f, n);
            AscendC::Abs(b, x0Local, n);
            AscendC::Muls(b, b, -1.0f, n);

            AscendC::Exp(a, a, n);
            AscendC::Exp(b, b, n);
            AscendC::Adds(b, b, 1.0f, n);

            AscendC::Div(c, a, b, n);
            AscendC::Mul(a, x0Local, x1Local, n);
            AscendC::Mul(zLocal, c, a, n);

            outQueue.EnQue(zLocal);

            tmpA.FreeTensor(a);
            tmpB.FreeTensor(b);
            tmpC.FreeTensor(c);
        } else {
            auto a = tmpA.AllocTensor<float>();
            auto b = tmpB.AllocTensor<float>();
            auto c = tmpC.AllocTensor<float>();
            auto d = tmpD.AllocTensor<float>();
            auto e = tmpE.AllocTensor<float>();

            AscendC::Cast(a, x0Local, AscendC::RoundMode::CAST_NONE, n);
            AscendC::Cast(b, x1Local, AscendC::RoundMode::CAST_NONE, n);

            AscendC::Mins(c, a, 0.0f, n);
            AscendC::Abs(d, a, n);
            AscendC::Muls(d, d, -1.0f, n);

            AscendC::Exp(c, c, n);
            AscendC::Exp(d, d, n);
            AscendC::Adds(d, d, 1.0f, n);

            AscendC::Div(e, c, d, n);
            AscendC::Mul(c, a, b, n);
            AscendC::Mul(a, e, c, n);

            AscendC::Cast(zLocal, a, AscendC::RoundMode::CAST_NONE, n);

            outQueue.EnQue(zLocal);

            tmpA.FreeTensor(a);
            tmpB.FreeTensor(b);
            tmpC.FreeTensor(c);
            tmpD.FreeTensor(d);
            tmpE.FreeTensor(e);
        }

        inQueueX0.FreeTensor(x0Local);
        inQueueX1.FreeTensor(x1Local);

        zLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(outputGm[pos], zLocal, copyParams);
        outQueue.FreeTensor(zLocal);

        pos += len;
    }
}

__global__ __aicore__ void swi_glu_interleaved_kernel(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize,
    int64_t blockLength,
    uint32_t tileElems)
{
    (void)outerNum;

    if (totalOutput <= 0 || outerNum <= 0 || chunkSize <= 0 ||
        blockLength <= 0 || tileElems == 0) {
        return;
    }

    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t startOut = blockIdx * blockLength;
    if (startOut >= totalOutput) {
        return;
    }

    int64_t endOut = startOut + blockLength;
    if (endOut > totalOutput) {
        endOut = totalOutput;
    }

    AscendC::TPipe pipe;

    AscendC::GlobalTensor<float> inputGm;
    AscendC::GlobalTensor<float> outputGm;

    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> x0Queue;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> x1Queue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;

    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpA;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpB;
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> tmpC;

    uint32_t tileBytes = static_cast<uint32_t>(static_cast<uint64_t>(tileElems) * sizeof(float));
    uint32_t interleavedTileBytes = static_cast<uint32_t>(static_cast<uint64_t>(tileElems) * 2 * sizeof(float));

    pipe.InitBuffer(inQueue, 1, interleavedTileBytes);
    pipe.InitBuffer(x0Queue, 1, tileBytes);
    pipe.InitBuffer(x1Queue, 1, tileBytes);
    pipe.InitBuffer(outQueue, 1, tileBytes);

    pipe.InitBuffer(tmpA, 1, tileBytes);
    pipe.InitBuffer(tmpB, 1, tileBytes);
    pipe.InitBuffer(tmpC, 1, tileBytes);

    inputGm.SetGlobalBuffer((__gm__ float*)input);
    outputGm.SetGlobalBuffer((__gm__ float*)output);

    AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};

    int64_t tileLimit = static_cast<int64_t>(tileElems);
    if (tileLimit > TILE_SLACK_ELEMS) {
        tileLimit -= TILE_SLACK_ELEMS;
    }
    if (tileLimit <= 0) {
        return;
    }

    int64_t pos = startOut;
    while (pos < endOut) {
        int64_t remaining = endOut - pos;
        int64_t group = remaining / chunkSize;
        if (group <= 0) {
            break;
        }

        int64_t maxGroup = tileLimit / chunkSize;
        if (maxGroup <= 0) {
            maxGroup = 1;
        }
        if (group > maxGroup) {
            group = maxGroup;
        }

        int64_t len = group * chunkSize;
        if (len <= 0) {
            break;
        }

        int64_t outerIdx = pos / chunkSize;
        int64_t inBase = outerIdx * 2 * chunkSize;

        auto inLocal = inQueue.AllocTensor<float>();

        uint32_t inBytes = static_cast<uint32_t>(static_cast<uint64_t>(len) * 2 * sizeof(float));
        AscendC::DataCopyExtParams copyInParams{1, inBytes, 0, 0, 0};
        AscendC::DataCopyPad(inLocal, inputGm[inBase], copyInParams, padParams);

        inQueue.EnQue(inLocal);
        inLocal = inQueue.DeQue<float>();

        auto x0Local = x0Queue.AllocTensor<float>();
        auto x1Local = x1Queue.AllocTensor<float>();

        if (chunkSize == 1) {
            for (int64_t i = 0; i < len; ++i) {
                int32_t dst = static_cast<int32_t>(i);
                int32_t src0 = static_cast<int32_t>(2 * i);
                int32_t src1 = static_cast<int32_t>(2 * i + 1);
                x0Local.SetValue(dst, inLocal.GetValue(src0));
                x1Local.SetValue(dst, inLocal.GetValue(src1));
            }
        } else {
            int64_t idx = 0;
            for (int64_t g = 0; g < group; ++g) {
                int64_t base = g * 2 * chunkSize;
                for (int64_t j = 0; j < chunkSize; ++j) {
                    int32_t dst = static_cast<int32_t>(idx);
                    int32_t src0 = static_cast<int32_t>(base + j);
                    int32_t src1 = static_cast<int32_t>(base + chunkSize + j);
                    x0Local.SetValue(dst, inLocal.GetValue(src0));
                    x1Local.SetValue(dst, inLocal.GetValue(src1));
                    ++idx;
                }
            }
        }

        x0Queue.EnQue(x0Local);
        x1Queue.EnQue(x1Local);
        inQueue.FreeTensor(inLocal);

        x0Local = x0Queue.DeQue<float>();
        x1Local = x1Queue.DeQue<float>();

        auto zLocal = outQueue.AllocTensor<float>();
        int32_t n = static_cast<int32_t>(len);

        auto a = tmpA.AllocTensor<float>();
        auto b = tmpB.AllocTensor<float>();
        auto c = tmpC.AllocTensor<float>();

        AscendC::Mins(a, x0Local, 0.0f, n);
        AscendC::Abs(b, x0Local, n);
        AscendC::Muls(b, b, -1.0f, n);

        AscendC::Exp(a, a, n);
        AscendC::Exp(b, b, n);
        AscendC::Adds(b, b, 1.0f, n);

        AscendC::Div(c, a, b, n);
        AscendC::Mul(a, x0Local, x1Local, n);
        AscendC::Mul(zLocal, c, a, n);

        outQueue.EnQue(zLocal);

        tmpA.FreeTensor(a);
        tmpB.FreeTensor(b);
        tmpC.FreeTensor(c);

        x0Queue.FreeTensor(x0Local);
        x1Queue.FreeTensor(x1Local);

        zLocal = outQueue.DeQue<float>();

        uint32_t outBytes = static_cast<uint32_t>(static_cast<uint64_t>(len) * sizeof(float));
        AscendC::DataCopyExtParams copyOutParams{1, outBytes, 0, 0, 0};
        AscendC::DataCopyPad(outputGm[pos], zLocal, copyOutParams);
        outQueue.FreeTensor(zLocal);

        pos += len;
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_tiling_params(
    int64_t totalOutput,
    int64_t dtypeSize,
    int64_t outerNum,
    int64_t chunkSize)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr static int64_t MAX_TILE_ELEMS = 8192;
    constexpr static int64_t BYTES_PER_ELEM = 48;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();

    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (ubSize == 0) {
        ubSize = 245760;
    }
    if (dtypeSize <= 0) {
        dtypeSize = 4;
    }

    int64_t numBlocks = 1;
    int64_t blockLength = 0;

    if (totalOutput <= 0) {
        numBlocks = 1;
        blockLength = 0;
    } else {
        int64_t maxBlocksByWork = (totalOutput + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
        if (maxBlocksByWork < 1) {
            maxBlocksByWork = 1;
        }

        numBlocks = std::min(coreNum, maxBlocksByWork);
        if (numBlocks < 1) {
            numBlocks = 1;
        }

        if (chunkSize > 0 && (outerNum >= numBlocks || chunkSize < 64)) {
            int64_t segPerBlock = (outerNum + numBlocks - 1) / numBlocks;
            if (segPerBlock < 1) {
                segPerBlock = 1;
            }
            blockLength = segPerBlock * chunkSize;
        } else {
            blockLength = (totalOutput + numBlocks - 1) / numBlocks;
        }

        if (blockLength < 1) {
            blockLength = 1;
        }
    }

    int64_t align = 32 / dtypeSize;
    if (align < 1) {
        align = 1;
    }

    int64_t ub = static_cast<int64_t>(ubSize);
    int64_t usable = ub * 3 / 4;
    if (ub >= 131072) {
        int64_t usableReserved = ub - 98304;
        if (usableReserved < usable) {
            usable = usableReserved;
        }
    }
    if (usable < 16384) {
        usable = ub / 2;
    }
    if (usable < 4096) {
        usable = 4096;
    }

    int64_t tile = usable / BYTES_PER_ELEM;
    tile = (tile / align) * align;
    if (tile < align) {
        tile = align;
    }
    if (tile > MAX_TILE_ELEMS) {
        tile = (MAX_TILE_ELEMS / align) * align;
        if (tile < align) {
            tile = align;
        }
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tile));
}

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_interleaved_tiling_params(
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr static int64_t MAX_TILE_ELEMS = 4096;
    constexpr static int64_t BYTES_PER_ELEM = 40;
    constexpr static int64_t ALIGN_ELEMS = 8;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();

    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (ubSize == 0) {
        ubSize = 245760;
    }

    int64_t numBlocks = 1;
    int64_t blockLength = 0;

    if (totalOutput <= 0 || chunkSize <= 0) {
        numBlocks = 1;
        blockLength = 0;
    } else {
        int64_t maxBlocksByWork = (totalOutput + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
        if (maxBlocksByWork < 1) {
            maxBlocksByWork = 1;
        }

        numBlocks = std::min(coreNum, maxBlocksByWork);
        if (numBlocks < 1) {
            numBlocks = 1;
        }

        int64_t segPerBlock = (outerNum + numBlocks - 1) / numBlocks;
        if (segPerBlock < 1) {
            segPerBlock = 1;
        }
        blockLength = segPerBlock * chunkSize;
        if (blockLength < 1) {
            blockLength = 1;
        }
    }

    int64_t ub = static_cast<int64_t>(ubSize);
    int64_t usable = ub * 3 / 4;
    if (ub >= 131072) {
        int64_t usableReserved = ub - 98304;
        if (usableReserved < usable) {
            usable = usableReserved;
        }
    }
    if (usable < 16384) {
        usable = ub / 2;
    }
    if (usable < 4096) {
        usable = 4096;
    }

    int64_t tile = usable / BYTES_PER_ELEM;
    tile = (tile / ALIGN_ELEMS) * ALIGN_ELEMS;
    if (tile < ALIGN_ELEMS) {
        tile = ALIGN_ELEMS;
    }
    if (tile > MAX_TILE_ELEMS) {
        tile = (MAX_TILE_ELEMS / ALIGN_ELEMS) * ALIGN_ELEMS;
        if (tile < ALIGN_ELEMS) {
            tile = ALIGN_ELEMS;
        }
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tile));
}

extern "C" {

void launch_swi_glu_kernel_float(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream)
{
    if (numBlocks <= 0 || totalOutput <= 0) {
        return;
    }
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(
        input, output, totalOutput, outerNum, chunkSize, blockLength, tileElems);
}

void launch_swi_glu_kernel_half(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream)
{
    if (numBlocks <= 0 || totalOutput <= 0) {
        return;
    }
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(
        input, output, totalOutput, outerNum, chunkSize, blockLength, tileElems);
}

void launch_swi_glu_interleaved_float(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOutput,
    int64_t outerNum,
    int64_t chunkSize,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream)
{
    if (numBlocks <= 0 || totalOutput <= 0) {
        return;
    }
    swi_glu_interleaved_kernel<<<numBlocks, nullptr, stream>>>(
        input, output, totalOutput, outerNum, chunkSize, blockLength, tileElems);
}

}
