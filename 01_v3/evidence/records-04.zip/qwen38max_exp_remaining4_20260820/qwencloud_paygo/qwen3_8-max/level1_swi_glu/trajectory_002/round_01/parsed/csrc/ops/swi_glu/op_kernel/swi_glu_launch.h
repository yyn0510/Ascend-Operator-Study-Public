/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef SWI_GLU_LAUNCH_H
#define SWI_GLU_LAUNCH_H

#include <cstdint>
#include <tuple>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_tiling_params(
    int64_t totalOut,
    int64_t segLen,
    int64_t elemSize,
    int64_t lowPrec);

extern "C" {

void launch_swi_glu_kernel_float(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOut,
    int64_t segLen,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream);

void launch_swi_glu_kernel_half(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOut,
    int64_t segLen,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream);

void launch_swi_glu_kernel_bfloat16(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOut,
    int64_t segLen,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream);

}

#endif // SWI_GLU_LAUNCH_H
