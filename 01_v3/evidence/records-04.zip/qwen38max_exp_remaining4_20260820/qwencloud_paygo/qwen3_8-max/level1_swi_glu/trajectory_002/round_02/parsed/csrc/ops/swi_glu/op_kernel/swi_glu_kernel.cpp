/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include <cstdint>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr int SWIGLU_PIPELINE_DEPTH = 2;
constexpr int64_t SWIGLU_MAX_BLOCKS_PER_COPY = 4096;

__global__ __aicore__ void swi_glu_kernel_float(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOut,
    int64_t segLen,
    int64_t blockLength,
    uint32_t tileElems)
{
    if (totalOut <= 0 || segLen <= 0 || blockLength <= 0 || tileElems == 0) {
        return;
    }

    int64_t start = static_cast<int64_t>(AscendC::GetBlockIdx()) * blockLength;
    if (start >= totalOut) {
        return;
    }
    int64_t end = start + blockLength;
    if (end > totalOut) {
        end = totalOut;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<float> inGm;
    AscendC::GlobalTensor<float> outGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, SWIGLU_PIPELINE_DEPTH> qX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, SWIGLU_PIPELINE_DEPTH> qX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> qTemp;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> qWork;

    uint32_t tileBytes = static_cast<uint32_t>(tileElems * sizeof(float));
    pipe.InitBuffer(qX0, SWIGLU_PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(qX1, SWIGLU_PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(qTemp, 1, tileBytes);
    pipe.InitBuffer(qWork, 1, tileBytes);

    inGm.SetGlobalBuffer((__gm__ float*)input);
    outGm.SetGlobalBuffer((__gm__ float*)output);

    int64_t tileElemsInt = static_cast<int64_t>(tileElems);
    int64_t pos = start;

    while (pos < end) {
        bool grouped = false;
        int64_t len = 0;
        int64_t group = 1;
        int64_t segIdx = pos / segLen;
        int64_t off = pos - segIdx * segLen;

        if (segLen <= tileElemsInt) {
            if (off != 0) {
                len = segLen - off;
                if (len > end - pos) {
                    len = end - pos;
                }
            } else {
                int64_t full = (end - pos) / segLen;
                if (full > 0) {
                    int64_t maxGroup = tileElemsInt / segLen;
                    if (maxGroup > SWIGLU_MAX_BLOCKS_PER_COPY) {
                        maxGroup = SWIGLU_MAX_BLOCKS_PER_COPY;
                    }
                    if (maxGroup < 1) {
                        maxGroup = 1;
                    }
                    group = full < maxGroup ? full : maxGroup;
                    len = group * segLen;
                    if (group > 1) {
                        grouped = true;
                    }
                } else {
                    len = end - pos;
                }
            }
        } else {
            len = segLen - off;
            if (len > end - pos) {
                len = end - pos;
            }
            if (len > tileElemsInt) {
                len = tileElemsInt;
            }
        }

        if (len <= 0) {
            break;
        }

        int32_t n = static_cast<int32_t>(len);
        AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};
        auto x0Local = qX0.AllocTensor<float>();
        auto x1Local = qX1.AllocTensor<float>();

        if (grouped) {
            uint32_t blockBytesSeg = static_cast<uint32_t>(segLen * sizeof(float));
            uint32_t srcStride = static_cast<uint32_t>(2 * segLen * sizeof(float));
            uint32_t dstStride = blockBytesSeg;
            AscendC::DataCopyExtParams copyX0{
                static_cast<uint16_t>(group),
                blockBytesSeg,
                srcStride,
                dstStride,
                0};
            AscendC::DataCopyExtParams copyX1 = copyX0;
            int64_t x0Base = segIdx * 2 * segLen;
            int64_t x1Base = x0Base + segLen;
            AscendC::DataCopyPad(x0Local, inGm[x0Base], copyX0, padParams);
            AscendC::DataCopyPad(x1Local, inGm[x1Base], copyX1, padParams);
        } else {
            int64_t x0Off = segIdx * 2 * segLen + off;
            int64_t x1Off = x0Off + segLen;
            AscendC::DataCopyExtParams copyParams{
                static_cast<uint16_t>(1),
                static_cast<uint32_t>(len * sizeof(float)),
                0,
                0,
                0};
            AscendC::DataCopyPad(x0Local, inGm[x0Off], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, inGm[x1Off], copyParams, padParams);
        }

        qX0.EnQue(x0Local);
        qX1.EnQue(x1Local);
        x0Local = qX0.DeQue<float>();
        x1Local = qX1.DeQue<float>();

        auto temp = qTemp.AllocTensor<float>();
        auto work = qWork.AllocTensor<float>();

        AscendC::Sigmoid(temp, x0Local, n);
        AscendC::Mul(work, x0Local, temp, n);
        AscendC::Mul(temp, work, x1Local, n);

        qTemp.EnQue(temp);
        qX0.FreeTensor(x0Local);
        qX1.FreeTensor(x1Local);
        qWork.FreeTensor(work);

        temp = qTemp.DeQue<float>();
        AscendC::DataCopyExtParams outCopy{
            static_cast<uint16_t>(1),
            static_cast<uint32_t>(len * sizeof(float)),
            0,
            0,
            0};
        AscendC::DataCopyPad(outGm[pos], temp, outCopy);
        qTemp.FreeTensor(temp);

        pos += len;
    }
}

template <typename T>
__global__ __aicore__ void swi_glu_kernel_low(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOut,
    int64_t segLen,
    int64_t blockLength,
    uint32_t tileElems)
{
    if (totalOut <= 0 || segLen <= 0 || blockLength <= 0 || tileElems == 0) {
        return;
    }

    int64_t start = static_cast<int64_t>(AscendC::GetBlockIdx()) * blockLength;
    if (start >= totalOut) {
        return;
    }
    int64_t end = start + blockLength;
    if (end > totalOut) {
        end = totalOut;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> inGm;
    AscendC::GlobalTensor<T> outGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, SWIGLU_PIPELINE_DEPTH> qX0T;
    AscendC::TQue<AscendC::QuePosition::VECIN, SWIGLU_PIPELINE_DEPTH> qX1T;
    AscendC::TQue<AscendC::QuePosition::VECOUT, SWIGLU_PIPELINE_DEPTH> qZT;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> qF0;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> qF1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> qFTemp;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> qFRes;

    uint32_t tileBytesT = static_cast<uint32_t>(tileElems * sizeof(T));
    uint32_t tileBytesF = static_cast<uint32_t>(tileElems * sizeof(float));
    pipe.InitBuffer(qX0T, SWIGLU_PIPELINE_DEPTH, tileBytesT);
    pipe.InitBuffer(qX1T, SWIGLU_PIPELINE_DEPTH, tileBytesT);
    pipe.InitBuffer(qZT, SWIGLU_PIPELINE_DEPTH, tileBytesT);
    pipe.InitBuffer(qF0, 1, tileBytesF);
    pipe.InitBuffer(qF1, 1, tileBytesF);
    pipe.InitBuffer(qFTemp, 1, tileBytesF);
    pipe.InitBuffer(qFRes, 1, tileBytesF);

    inGm.SetGlobalBuffer((__gm__ T*)input);
    outGm.SetGlobalBuffer((__gm__ T*)output);

    int64_t tileElemsInt = static_cast<int64_t>(tileElems);
    int64_t pos = start;

    while (pos < end) {
        bool grouped = false;
        int64_t len = 0;
        int64_t group = 1;
        int64_t segIdx = pos / segLen;
        int64_t off = pos - segIdx * segLen;

        if (segLen <= tileElemsInt) {
            if (off != 0) {
                len = segLen - off;
                if (len > end - pos) {
                    len = end - pos;
                }
            } else {
                int64_t full = (end - pos) / segLen;
                if (full > 0) {
                    int64_t maxGroup = tileElemsInt / segLen;
                    if (maxGroup > SWIGLU_MAX_BLOCKS_PER_COPY) {
                        maxGroup = SWIGLU_MAX_BLOCKS_PER_COPY;
                    }
                    if (maxGroup < 1) {
                        maxGroup = 1;
                    }
                    group = full < maxGroup ? full : maxGroup;
                    len = group * segLen;
                    if (group > 1) {
                        grouped = true;
                    }
                } else {
                    len = end - pos;
                }
            }
        } else {
            len = segLen - off;
            if (len > end - pos) {
                len = end - pos;
            }
            if (len > tileElemsInt) {
                len = tileElemsInt;
            }
        }

        if (len <= 0) {
            break;
        }

        int32_t n = static_cast<int32_t>(len);
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto x0Local = qX0T.AllocTensor<T>();
        auto x1Local = qX1T.AllocTensor<T>();

        if (grouped) {
            uint32_t blockBytesSeg = static_cast<uint32_t>(segLen * sizeof(T));
            uint32_t srcStride = static_cast<uint32_t>(2 * segLen * sizeof(T));
            uint32_t dstStride = blockBytesSeg;
            AscendC::DataCopyExtParams copyX0{
                static_cast<uint16_t>(group),
                blockBytesSeg,
                srcStride,
                dstStride,
                0};
            AscendC::DataCopyExtParams copyX1 = copyX0;
            int64_t x0Base = segIdx * 2 * segLen;
            int64_t x1Base = x0Base + segLen;
            AscendC::DataCopyPad(x0Local, inGm[x0Base], copyX0, padParams);
            AscendC::DataCopyPad(x1Local, inGm[x1Base], copyX1, padParams);
        } else {
            int64_t x0Off = segIdx * 2 * segLen + off;
            int64_t x1Off = x0Off + segLen;
            AscendC::DataCopyExtParams copyParams{
                static_cast<uint16_t>(1),
                static_cast<uint32_t>(len * sizeof(T)),
                0,
                0,
                0};
            AscendC::DataCopyPad(x0Local, inGm[x0Off], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, inGm[x1Off], copyParams, padParams);
        }

        qX0T.EnQue(x0Local);
        qX1T.EnQue(x1Local);
        x0Local = qX0T.DeQue<T>();
        x1Local = qX1T.DeQue<T>();

        auto f0 = qF0.AllocTensor<float>();
        auto f1 = qF1.AllocTensor<float>();
        auto temp = qFTemp.AllocTensor<float>();
        auto res = qFRes.AllocTensor<float>();

        AscendC::Cast(f0, x0Local, AscendC::RoundMode::CAST_NONE, n);
        AscendC::Cast(f1, x1Local, AscendC::RoundMode::CAST_NONE, n);
        AscendC::Sigmoid(temp, f0, n);
        AscendC::Mul(res, f0, temp, n);
        AscendC::Mul(temp, res, f1, n);

        auto zLocal = qZT.AllocTensor<T>();
        AscendC::Cast(zLocal, temp, AscendC::RoundMode::CAST_RINT, n);
        qZT.EnQue(zLocal);

        qX0T.FreeTensor(x0Local);
        qX1T.FreeTensor(x1Local);
        qF0.FreeTensor(f0);
        qF1.FreeTensor(f1);
        qFTemp.FreeTensor(temp);
        qFRes.FreeTensor(res);

        zLocal = qZT.DeQue<T>();
        AscendC::DataCopyExtParams outCopy{
            static_cast<uint16_t>(1),
            static_cast<uint32_t>(len * sizeof(T)),
            0,
            0,
            0};
        AscendC::DataCopyPad(outGm[pos], zLocal, outCopy);
        qZT.FreeTensor(zLocal);

        pos += len;
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_swi_glu_tiling_params(
    int64_t totalOut,
    int64_t segLen,
    int64_t elemSize,
    int64_t lowPrec)
{
    constexpr int64_t MIN_OUT_PER_CORE = 1024;
    constexpr uint32_t DEFAULT_TILE_ELEMS = 4096;

    uint64_t ubSize = 256 * 1024;
    int64_t coreNum = 1;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    if (ascendcPlatform != nullptr) {
        uint64_t tmpUbSize = 0;
        ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, tmpUbSize);
        if (tmpUbSize != 0) {
            ubSize = tmpUbSize;
        }
        int64_t tmpCoreNum = ascendcPlatform->GetCoreNumAiv();
        if (tmpCoreNum > 0) {
            coreNum = tmpCoreNum;
        }
    }

    if (totalOut <= 0 || segLen <= 0 || elemSize <= 0) {
        return std::make_tuple(1, 1, 256);
    }

    int64_t blocksByWork = (totalOut + MIN_OUT_PER_CORE - 1) / MIN_OUT_PER_CORE;
    if (blocksByWork < 1) {
        blocksByWork = 1;
    }
    int64_t numBlocks = coreNum < blocksByWork ? coreNum : blocksByWork;
    int64_t blockLength = (totalOut + numBlocks - 1) / numBlocks;

    int64_t bytesPerElem;
    if (lowPrec != 0) {
        bytesPerElem = 6 * elemSize + 16;
    } else {
        bytesPerElem = 6 * elemSize;
    }
    if (bytesPerElem <= 0) {
        bytesPerElem = 32;
    }

    int64_t maxTile = static_cast<int64_t>(ubSize / static_cast<uint64_t>(bytesPerElem));
    int64_t tile = static_cast<int64_t>(DEFAULT_TILE_ELEMS);
    if (maxTile < tile) {
        tile = maxTile;
    }
    if (tile < 32) {
        tile = 32;
    }
    tile = (tile / 32) * 32;
    if (tile < 32) {
        tile = 32;
    }
    uint32_t tileElems = static_cast<uint32_t>(tile);

    if (segLen > 0 && segLen <= static_cast<int64_t>(tileElems)) {
        int64_t blocks = (blockLength + segLen - 1) / segLen;
        if (blocks < 1) {
            blocks = 1;
        }
        blockLength = blocks * segLen;
        int64_t needed = (totalOut + blockLength - 1) / blockLength;
        if (needed < 1) {
            needed = 1;
        }
        numBlocks = needed < coreNum ? needed : coreNum;
    }

    if (blockLength < 1) {
        blockLength = 1;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }

    return std::make_tuple(numBlocks, blockLength, tileElems);
}

extern "C" {

void launch_swi_glu_kernel_float(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOut,
    int64_t segLen,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream)
{
    swi_glu_kernel_float<<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, segLen, blockLength, tileElems);
}

void launch_swi_glu_kernel_half(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOut,
    int64_t segLen,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream)
{
    swi_glu_kernel_low<half><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, segLen, blockLength, tileElems);
}

void launch_swi_glu_kernel_bfloat16(
    GM_ADDR input,
    GM_ADDR output,
    int64_t totalOut,
    int64_t segLen,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElems,
    void* stream)
{
    swi_glu_kernel_low<__bf16><<<numBlocks, nullptr, stream>>>(
        input, output, totalOut, segLen, blockLength, tileElems);
}

}
