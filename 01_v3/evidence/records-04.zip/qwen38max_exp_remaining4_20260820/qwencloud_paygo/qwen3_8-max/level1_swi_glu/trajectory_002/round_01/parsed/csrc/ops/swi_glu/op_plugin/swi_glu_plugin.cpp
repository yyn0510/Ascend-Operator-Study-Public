/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    int64_t ndim = input.dim();
    TORCH_CHECK(ndim > 0, "input must have at least one dimension");

    int64_t d = dim < 0 ? dim + ndim : dim;
    TORCH_CHECK(d >= 0 && d < ndim, "dim is out of range");
    TORCH_CHECK(input.size(d) % 2 == 0, "input size on split dim must be even");

    auto sizes = input.sizes().vec();
    sizes[d] /= 2;
    return at::empty(sizes, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto out = swi_glu_meta(input, dim);

    auto src = input.contiguous();
    auto scalarType = src.scalar_type();
    TORCH_CHECK(
        scalarType == torch::kFloat32 || scalarType == torch::kFloat16 || scalarType == torch::kBFloat16,
        "swi_glu only supports float16, float32 and bfloat16");

    int64_t ndim = src.dim();
    int64_t d = dim < 0 ? dim + ndim : dim;
    auto sizes = src.sizes();

    int64_t pre = 1;
    int64_t post = 1;
    for (int64_t i = 0; i < d; ++i) {
        pre *= sizes[i];
    }
    for (int64_t i = d + 1; i < ndim; ++i) {
        post *= sizes[i];
    }

    int64_t half = sizes[d] / 2;
    int64_t segLen = half * post;
    int64_t totalOut = pre * segLen;
    if (totalOut == 0) {
        return out;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t lowPrec = (scalarType == torch::kFloat32) ? 0 : 1;

    int64_t numBlocks = 1;
    int64_t blockLength = 1;
    uint32_t tileElems = 256;
    std::tie(numBlocks, blockLength, tileElems) =
        calc_swi_glu_tiling_params(totalOut, segLen, src.element_size(), lowPrec);

    GM_ADDR in_ptr = (GM_ADDR)src.data_ptr();
    GM_ADDR out_ptr = (GM_ADDR)out.data_ptr();

    auto acl_call = [=]() -> int {
        if (scalarType == torch::kFloat32) {
            launch_swi_glu_kernel_float(
                in_ptr, out_ptr, totalOut, segLen,
                numBlocks, blockLength, tileElems, stream);
        } else if (scalarType == torch::kFloat16) {
            launch_swi_glu_kernel_half(
                in_ptr, out_ptr, totalOut, segLen,
                numBlocks, blockLength, tileElems, stream);
        } else if (scalarType == torch::kBFloat16) {
            launch_swi_glu_kernel_bfloat16(
                in_ptr, out_ptr, totalOut, segLen,
                numBlocks, blockLength, tileElems, stream);
        } else {
            TORCH_CHECK(false, "unsupported dtype for swi_glu");
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return out;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
