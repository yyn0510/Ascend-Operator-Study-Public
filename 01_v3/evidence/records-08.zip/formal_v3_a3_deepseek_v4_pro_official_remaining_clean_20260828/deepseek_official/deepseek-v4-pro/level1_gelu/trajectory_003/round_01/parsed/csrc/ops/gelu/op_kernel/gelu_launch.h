/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef GELU_LAUNCH_H
#define GELU_LAUNCH_H

#include <cstdint>
#include <tuple>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

std::tuple<int64_t, int64_t, int64_t> calc_gelu_tiling_params(int64_t totalLength, int64_t dataSize);

extern "C" {
void launch_gelu_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                              int64_t blockLength, uint32_t tileSize, int32_t approximateMode,
                              void *stream);
void launch_gelu_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                             int64_t blockLength, uint32_t tileSize, int32_t approximateMode,
                             void *stream);
void launch_gelu_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                 int64_t blockLength, uint32_t tileSize, int32_t approximateMode,
                                 void *stream);
}

#define GELU_KERNEL_LAUNCH_FLOAT(x, y, totalLength, numBlocks, blockLength, tileSize, approximateMode, stream) \
    launch_gelu_kernel_float(x, y, totalLength, numBlocks, blockLength, tileSize, approximateMode, stream)

#define GELU_KERNEL_LAUNCH_HALF(x, y, totalLength, numBlocks, blockLength, tileSize, approximateMode, stream) \
    launch_gelu_kernel_half(x, y, totalLength, numBlocks, blockLength, tileSize, approximateMode, stream)

#define GELU_KERNEL_LAUNCH_BFLOAT16(x, y, totalLength, numBlocks, blockLength, tileSize, approximateMode, stream) \
    launch_gelu_kernel_bfloat16(x, y, totalLength, numBlocks, blockLength, tileSize, approximateMode, stream)

#endif // GELU_LAUNCH_H
