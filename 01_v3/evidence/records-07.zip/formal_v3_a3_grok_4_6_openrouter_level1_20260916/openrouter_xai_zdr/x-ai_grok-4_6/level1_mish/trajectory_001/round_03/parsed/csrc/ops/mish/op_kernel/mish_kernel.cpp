/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel, tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t MIN_ELEMS_PER_CORE = 512;
constexpr static int64_t UB_RESERVED = 16384;
constexpr static int64_t TILE_ALIGN = 256;
constexpr static int64_t ELEM_ALIGN = 64;
constexpr static int64_t UB_SIZE_DEFAULT = 192 * 1024;
constexpr static int64_t CORE_NUM_DEFAULT = 48;
constexpr static int64_t MIN_TILE_BYTES = 4096;

template <typename T>
class KernelMish {
public:
    __aicore__ inline KernelMish() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR y, int64_t gmOffset, int64_t currentBlockLength, uint32_t tileSize)
    {
        currentBlockLength_ = currentBlockLength;
        elementNumPerTile_ = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
        elementNumPerTile_ = elementNumPerTile_ / ELEM_ALIGN * ELEM_ALIGN;
        if (elementNumPerTile_ < ELEM_ALIGN) {
            elementNumPerTile_ = ELEM_ALIGN;
        }
        xGm.SetGlobalBuffer((__gm__ T *)x + gmOffset, currentBlockLength);
        yGm.SetGlobalBuffer((__gm__ T *)y + gmOffset, currentBlockLength);
        pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
        pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);
        uint32_t tmpBytes = static_cast<uint32_t>(elementNumPerTile_ * static_cast<int64_t>(sizeof(float)));
        pipe.InitBuffer(tmpBufU, tmpBytes);
        pipe.InitBuffer(tmpBufW, tmpBytes);
        if constexpr (sizeof(T) != sizeof(float)) {
            pipe.InitBuffer(tmpBufX, tmpBytes);
            pipe.InitBuffer(tmpBufY, tmpBytes);
        }
    }

    __aicore__ inline void Process()
    {
        if (currentBlockLength_ <= 0 || elementNumPerTile_ <= 0) {
            return;
        }
        int64_t tileNum = (currentBlockLength_ + elementNumPerTile_ - 1) / elementNumPerTile_;
        for (int64_t i = 0; i < tileNum; ++i) {
            int64_t offset = i * elementNumPerTile_;
            int64_t n = elementNumPerTile_;
            if (offset + n > currentBlockLength_) {
                n = currentBlockLength_ - offset;
            }
            CopyIn(offset, n);
            Compute(n);
            CopyOut(offset, n);
        }
    }

private:
    __aicore__ inline uint32_t AlignedCount(int64_t n)
    {
        int64_t aligned = (n + ELEM_ALIGN - 1) / ELEM_ALIGN * ELEM_ALIGN;
        if (aligned > elementNumPerTile_) {
            aligned = elementNumPerTile_;
        }
        if (aligned < n) {
            aligned = n;
        }
        return static_cast<uint32_t>(aligned);
    }

    __aicore__ inline void CopyIn(int64_t offset, int64_t n)
    {
        AscendC::LocalTensor<T> xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(n * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
    }

    __aicore__ inline void ComputeMishFloat(const AscendC::LocalTensor<float> &dst,
                                            const AscendC::LocalTensor<float> &srcX,
                                            const AscendC::LocalTensor<float> &tmpU,
                                            const AscendC::LocalTensor<float> &tmpW, uint32_t count)
    {
        // u = exp(-abs(x)), always in (0, 1], no overflow
        // pos_ratio = (1 + 2u) / (1 + 2u + 2u^2)   for x >= 0
        // neg_ratio = (2u + u^2) / (2 + 2u + u^2)  for x < 0
        // y = relu(x) * pos_ratio + (x - relu(x)) * neg_ratio
        AscendC::Abs(tmpU, srcX, count);
        AscendC::Muls(tmpU, tmpU, -1.0f, count);
        AscendC::Exp(tmpU, tmpU, count);
        AscendC::Mul(tmpW, tmpU, tmpU, count);
        AscendC::Muls(dst, tmpU, 2.0f, count);
        AscendC::Adds(tmpU, dst, 1.0f, count);
        AscendC::Add(dst, dst, tmpW, count);
        AscendC::Muls(tmpW, tmpW, 2.0f, count);
        AscendC::Add(tmpW, tmpU, tmpW, count);
        AscendC::Div(tmpU, tmpU, tmpW, count);
        AscendC::Adds(tmpW, dst, 2.0f, count);
        AscendC::Div(dst, dst, tmpW, count);
        AscendC::Relu(tmpW, srcX, count);
        AscendC::Sub(tmpU, tmpU, dst, count);
        AscendC::Mul(tmpW, tmpW, tmpU, count);
        AscendC::Mul(dst, srcX, dst, count);
        AscendC::Add(dst, dst, tmpW, count);
    }

    __aicore__ inline void Compute(int64_t n)
    {
        uint32_t count = AlignedCount(n);
        AscendC::LocalTensor<T> xLocal = inQueue.DeQue<T>();
        AscendC::LocalTensor<T> yLocal = outQueue.AllocTensor<T>();
        AscendC::LocalTensor<float> tmpU = tmpBufU.Get<float>();
        AscendC::LocalTensor<float> tmpW = tmpBufW.Get<float>();
        if constexpr (sizeof(T) == sizeof(float)) {
            ComputeMishFloat(yLocal, xLocal, tmpU, tmpW, count);
        } else {
            AscendC::LocalTensor<float> tmpX = tmpBufX.Get<float>();
            AscendC::LocalTensor<float> tmpY = tmpBufY.Get<float>();
            AscendC::Cast(tmpX, xLocal, AscendC::RoundMode::CAST_NONE, count);
            ComputeMishFloat(tmpY, tmpX, tmpU, tmpW, count);
            AscendC::Cast(yLocal, tmpY, AscendC::RoundMode::CAST_RINT, count);
        }
        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);
    }

    __aicore__ inline void CopyOut(int64_t offset, int64_t n)
    {
        AscendC::LocalTensor<T> yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(n * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBufU;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBufW;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBufX;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBufY;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    int64_t currentBlockLength_ = 0;
    int64_t elementNumPerTile_ = 0;
};

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t gmOffset = blockIdx * blockLength;
    if (gmOffset >= totalLength) {
        return;
    }
    int64_t currentBlockLength = totalLength - gmOffset;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    KernelMish<T> op;
    op.Init(x, y, gmOffset, currentBlockLength, tileSize);
    op.Process();
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    int64_t coreNum = 0;
    if (ascendcPlatform != nullptr) {
        ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
        coreNum = ascendcPlatform->GetCoreNumAiv();
    }
    if (ubSize < 64 * 1024) {
        ubSize = static_cast<uint64_t>(UB_SIZE_DEFAULT);
    }
    if (coreNum <= 0) {
        coreNum = CORE_NUM_DEFAULT;
    }
    if (dtypeSize <= 0) {
        dtypeSize = static_cast<int64_t>(sizeof(float));
    }
    if (totalLength <= 0) {
        return std::make_tuple(1, 0, TILE_ALIGN);
    }

    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    blockLength = (blockLength + ELEM_ALIGN - 1) / ELEM_ALIGN * ELEM_ALIGN;
    numBlocks = (totalLength + blockLength - 1) / blockLength;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
        blockLength = (totalLength + numBlocks - 1) / numBlocks;
        blockLength = (blockLength + ELEM_ALIGN - 1) / ELEM_ALIGN * ELEM_ALIGN;
        numBlocks = (totalLength + blockLength - 1) / blockLength;
        if (numBlocks > coreNum) {
            numBlocks = coreNum;
            blockLength = (totalLength + numBlocks - 1) / numBlocks;
        }
    }
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t usableUb = static_cast<int64_t>(ubSize);
    if (usableUb > UB_RESERVED) {
        usableUb -= UB_RESERVED;
    }
    usableUb = usableUb * 8 / 10;
    int64_t extraFloatBufs = (dtypeSize < static_cast<int64_t>(sizeof(float))) ? 4 : 2;
    int64_t extraFactor = extraFloatBufs * (static_cast<int64_t>(sizeof(float)) / dtypeSize);
    int64_t denom = PIPELINE_DEPTH * 2 + extraFactor;
    if (denom <= 0) {
        denom = 8;
    }
    int64_t tileSize = usableUb / denom;
    tileSize = tileSize / TILE_ALIGN * TILE_ALIGN;
    if (tileSize < MIN_TILE_BYTES) {
        tileSize = MIN_TILE_BYTES;
    }
    int64_t tileElems = tileSize / dtypeSize;
    tileElems = tileElems / ELEM_ALIGN * ELEM_ALIGN;
    if (tileElems < ELEM_ALIGN) {
        tileElems = ELEM_ALIGN;
    }
    tileSize = tileElems * dtypeSize;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                              uint32_t tileSize, void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
