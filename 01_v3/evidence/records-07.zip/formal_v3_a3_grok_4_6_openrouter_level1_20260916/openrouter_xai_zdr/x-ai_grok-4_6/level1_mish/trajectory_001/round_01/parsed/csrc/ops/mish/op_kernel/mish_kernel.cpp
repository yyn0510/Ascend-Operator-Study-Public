/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel, tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
constexpr static int64_t UB_RESERVED = 4096;
constexpr static int64_t TILE_ALIGN = 32;

template <typename T>
class KernelMish {
public:
    __aicore__ inline KernelMish() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR y, int64_t gmOffset, int64_t currentBlockLength, uint32_t tileSize)
    {
        currentBlockLength_ = currentBlockLength;
        elementNumPerTile_ = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
        if (elementNumPerTile_ < 1) {
            elementNumPerTile_ = 1;
        }
        xGm.SetGlobalBuffer((__gm__ T *)x + gmOffset, currentBlockLength);
        yGm.SetGlobalBuffer((__gm__ T *)y + gmOffset, currentBlockLength);
        pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
        pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);
        if constexpr (sizeof(T) != sizeof(float)) {
            uint32_t tmpBytes = static_cast<uint32_t>(static_cast<int64_t>(tileSize) * sizeof(float) / sizeof(T));
            pipe.InitBuffer(tmpBufX, tmpBytes);
            pipe.InitBuffer(tmpBufY, tmpBytes);
        }
    }

    __aicore__ inline void Process()
    {
        if (currentBlockLength_ <= 0 || elementNumPerTile_ <= 0) {
            return;
        }
        int64_t tileNum = currentBlockLength_ / elementNumPerTile_;
        int64_t tailNum = currentBlockLength_ - tileNum * elementNumPerTile_;
        for (int64_t i = 0; i < tileNum; ++i) {
            int64_t offset = i * elementNumPerTile_;
            CopyIn(offset, elementNumPerTile_);
            Compute(elementNumPerTile_);
            CopyOut(offset, elementNumPerTile_);
        }
        if (tailNum > 0) {
            int64_t offset = tileNum * elementNumPerTile_;
            CopyIn(offset, tailNum);
            Compute(tailNum);
            CopyOut(offset, tailNum);
        }
    }

private:
    __aicore__ inline void CopyIn(int64_t offset, int64_t n)
    {
        AscendC::LocalTensor<T> xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(n * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
    }

    __aicore__ inline void Compute(int64_t n)
    {
        uint32_t count = static_cast<uint32_t>(n);
        AscendC::LocalTensor<T> xLocal = inQueue.DeQue<T>();
        AscendC::LocalTensor<T> yLocal = outQueue.AllocTensor<T>();
        if constexpr (sizeof(T) == sizeof(float)) {
            AscendC::Exp(yLocal, xLocal, count);
            AscendC::Adds(yLocal, yLocal, 1.0f, count);
            AscendC::Ln(yLocal, yLocal, count);
            AscendC::Tanh(yLocal, yLocal, count);
            AscendC::Mul(yLocal, xLocal, yLocal, count);
        } else {
            AscendC::LocalTensor<float> tmpX = tmpBufX.Get<float>();
            AscendC::LocalTensor<float> tmpY = tmpBufY.Get<float>();
            AscendC::Cast(tmpX, xLocal, AscendC::RoundMode::CAST_NONE, count);
            AscendC::Exp(tmpY, tmpX, count);
            AscendC::Adds(tmpY, tmpY, 1.0f, count);
            AscendC::Ln(tmpY, tmpY, count);
            AscendC::Tanh(tmpY, tmpY, count);
            AscendC::Mul(tmpY, tmpX, tmpY, count);
            AscendC::Cast(yLocal, tmpY, AscendC::RoundMode::CAST_RINT, count);
        }
        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);
    }

    __aicore__ inline void CopyOut(int64_t offset, int64_t n)
    {
        AscendC::LocalTensor<T> yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(n * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBufX;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBufY;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    int64_t currentBlockLength_ = 0;
    int64_t elementNumPerTile_ = 0;
};

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t gmOffset = blockIdx * blockLength;
    if (gmOffset >= totalLength) {
        return;
    }
    int64_t currentBlockLength = totalLength - gmOffset;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    KernelMish<T> op;
    op.Init(x, y, gmOffset, currentBlockLength, tileSize);
    op.Process();
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (totalLength <= 0) {
        return std::make_tuple(1, 0, TILE_ALIGN);
    }
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    int64_t usableUb = static_cast<int64_t>(ubSize);
    if (usableUb > UB_RESERVED) {
        usableUb -= UB_RESERVED;
    }
    int64_t extraTmpFactor = 0;
    if (dtypeSize > 0 && dtypeSize < static_cast<int64_t>(sizeof(float))) {
        extraTmpFactor = 2 * (static_cast<int64_t>(sizeof(float)) / dtypeSize);
    }
    int64_t denom = PIPELINE_DEPTH * 2 + extraTmpFactor;
    if (denom <= 0) {
        denom = 4;
    }
    int64_t tileSize = usableUb / denom;
    tileSize = tileSize / TILE_ALIGN * TILE_ALIGN;
    if (tileSize < TILE_ALIGN) {
        tileSize = TILE_ALIGN;
    }
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                              uint32_t tileSize, void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
