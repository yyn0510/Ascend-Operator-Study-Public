/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file gelu_plugin.cpp
 * \brief Gelu API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/gelu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("gelu(Tensor x, str approximate=\"none\") -> Tensor");
}

torch::Tensor gelu_meta(const torch::Tensor &x, c10::string_view approximate)
{
    TORCH_CHECK(approximate == "none" || approximate == "tanh",
                "gelu approximate only supports 'none' and 'tanh'");
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 ||
                    x.scalar_type() == torch::kFloat16 ||
                    x.scalar_type() == torch::kBFloat16,
                "gelu only supports float32, float16 and bfloat16");
    return torch::empty(x.sizes(), x.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("gelu", gelu_meta);
}

torch::Tensor gelu_npu(const torch::Tensor &x, c10::string_view approximate)
{
    const c10::OptionalDeviceGuard guard(x.device());
    TORCH_CHECK(approximate == "none" || approximate == "tanh",
                "gelu approximate only supports 'none' and 'tanh'");
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 ||
                    x.scalar_type() == torch::kFloat16 ||
                    x.scalar_type() == torch::kBFloat16,
                "gelu only supports float32, float16 and bfloat16");

    auto xContig = x.contiguous();
    auto y = torch::empty(xContig.sizes(), xContig.options());
    int64_t totalLength = xContig.numel();
    if (totalLength == 0) {
        return y;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    int64_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) =
        calc_gelu_tiling_params(totalLength, static_cast<int64_t>(xContig.element_size()));
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    auto xPtr = (GM_ADDR)xContig.data_ptr();
    auto yPtr = (GM_ADDR)y.data_ptr();
    int32_t approxMode = (approximate == "tanh") ? 1 : 0;
    auto tileSizeU32 = static_cast<uint32_t>(tileSize);

    auto acl_call = [=]() -> int {
        if (xContig.scalar_type() == torch::kFloat32) {
            GELU_KERNEL_LAUNCH_FLOAT(xPtr, yPtr, totalLength, numBlocks, blockLength, tileSizeU32, approxMode, stream);
        } else if (xContig.scalar_type() == torch::kFloat16) {
            GELU_KERNEL_LAUNCH_HALF(xPtr, yPtr, totalLength, numBlocks, blockLength, tileSizeU32, approxMode, stream);
        } else if (xContig.scalar_type() == torch::kBFloat16) {
            GELU_KERNEL_LAUNCH_BF16(xPtr, yPtr, totalLength, numBlocks, blockLength, tileSizeU32, approxMode, stream);
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Gelu", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("gelu", gelu_npu);
}

} // namespace cann_bench
