/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file gelu_kernel.cpp
 * \brief Gelu kernel, tiling and launch wrappers (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int32_t GELU_APPROX_TANH = 1;
constexpr static float GELU_TANH_COEF = 0.044715f;
constexpr static float GELU_TANH_SQRT_2_OVER_PI = 0.7978845608028654f;
constexpr static float GELU_RSQRT2 = 0.7071067811865476f;
constexpr static float GELU_HALF = 0.5f;
constexpr static float GELU_ERF_P = 0.3275911f;
constexpr static float GELU_ERF_A1 = 0.254829592f;
constexpr static float GELU_ERF_A2 = -0.284496736f;
constexpr static float GELU_ERF_A3 = 1.421413741f;
constexpr static float GELU_ERF_A4 = -1.453152027f;
constexpr static float GELU_ERF_A5 = 1.061405429f;
constexpr static float GELU_EXP_MIN = -80.0f;
constexpr static float GELU_SIGN_TINY = 1.0e-30f;

template <typename T>
__aicore__ inline uint32_t AlignVecCount(uint32_t n)
{
    constexpr uint32_t alignNum = (sizeof(T) == sizeof(float)) ? 8u : 16u;
    return (n + alignNum - 1u) / alignNum * alignNum;
}

__aicore__ inline void ComputeGeluTanh(
    AscendC::LocalTensor<float> y,
    AscendC::LocalTensor<float> x,
    AscendC::LocalTensor<float> t,
    uint32_t count)
{
    AscendC::Mul(t, x, x, count);
    AscendC::Muls(t, t, GELU_TANH_COEF, count);
    AscendC::Adds(t, t, 1.0f, count);
    AscendC::Mul(t, t, x, count);
    AscendC::Muls(t, t, GELU_TANH_SQRT_2_OVER_PI, count);
    AscendC::Tanh(t, t, count);
    AscendC::Adds(t, t, 1.0f, count);
    AscendC::Muls(t, t, GELU_HALF, count);
    AscendC::Mul(y, t, x, count);
}

__aicore__ inline void ComputeGeluNone(
    AscendC::LocalTensor<float> y,
    AscendC::LocalTensor<float> x,
    AscendC::LocalTensor<float> w0,
    AscendC::LocalTensor<float> w1,
    uint32_t count)
{
    AscendC::Muls(w0, x, GELU_RSQRT2, count);
    AscendC::Mul(w1, w0, w0, count);
    AscendC::Muls(w1, w1, -1.0f, count);
    AscendC::Maxs(w1, w1, GELU_EXP_MIN, count);
    AscendC::Exp(w1, w1, count);

    AscendC::Abs(y, w0, count);
    AscendC::Muls(y, y, GELU_ERF_P, count);
    AscendC::Adds(y, y, 1.0f, count);
    AscendC::Reciprocal(y, y, count);

    AscendC::Muls(w0, y, GELU_ERF_A5, count);
    AscendC::Adds(w0, w0, GELU_ERF_A4, count);
    AscendC::Mul(w0, w0, y, count);
    AscendC::Adds(w0, w0, GELU_ERF_A3, count);
    AscendC::Mul(w0, w0, y, count);
    AscendC::Adds(w0, w0, GELU_ERF_A2, count);
    AscendC::Mul(w0, w0, y, count);
    AscendC::Adds(w0, w0, GELU_ERF_A1, count);
    AscendC::Mul(w0, w0, y, count);
    AscendC::Mul(w0, w0, w1, count);

    AscendC::Abs(y, x, count);
    AscendC::Maxs(y, y, GELU_SIGN_TINY, count);
    AscendC::Reciprocal(y, y, count);
    AscendC::Mul(w1, y, x, count);

    AscendC::Mul(y, w1, w0, count);
    AscendC::Muls(y, y, -1.0f, count);
    AscendC::Add(y, w1, y, count);
    AscendC::Adds(y, y, 1.0f, count);
    AscendC::Maxs(y, y, 0.0f, count);
    AscendC::Mins(y, y, 2.0f, count);
    AscendC::Muls(y, y, GELU_HALF, count);
    AscendC::Mul(y, y, x, count);
}

template <typename T>
__aicore__ inline void ProcessGeluTile(
    AscendC::GlobalTensor<T> &xGm,
    AscendC::GlobalTensor<T> &yGm,
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> &inQueueX,
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> &outQueueY,
    AscendC::LocalTensor<float> &w0,
    AscendC::LocalTensor<float> &w1,
    AscendC::LocalTensor<float> &w2,
    AscendC::LocalTensor<float> &xF,
    int64_t offset,
    uint32_t n,
    int32_t approximate)
{
    uint32_t nAlign = AlignVecCount<T>(n);
    uint8_t rightPad = static_cast<uint8_t>(nAlign - n);
    AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(n * sizeof(T)), 0, 0, 0};
    AscendC::DataCopyPadExtParams<T> padParams{rightPad > 0, 0, rightPad, 0};

    auto xLocal = inQueueX.AllocTensor<T>();
    AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
    inQueueX.EnQue(xLocal);
    xLocal = inQueueX.DeQue<T>();
    auto yLocal = outQueueY.AllocTensor<T>();

    if constexpr (sizeof(T) == sizeof(float)) {
        if (approximate == GELU_APPROX_TANH) {
            ComputeGeluTanh(yLocal, xLocal, w0, nAlign);
        } else {
            ComputeGeluNone(yLocal, xLocal, w0, w1, nAlign);
        }
    } else {
        AscendC::Cast(xF, xLocal, AscendC::RoundMode::CAST_NONE, nAlign);
        if (approximate == GELU_APPROX_TANH) {
            ComputeGeluTanh(w0, xF, w1, nAlign);
            AscendC::Cast(yLocal, w0, AscendC::RoundMode::CAST_RINT, nAlign);
        } else {
            ComputeGeluNone(w0, xF, w1, w2, nAlign);
            AscendC::Cast(yLocal, w0, AscendC::RoundMode::CAST_RINT, nAlign);
        }
    }

    outQueueY.EnQue(yLocal);
    inQueueX.FreeTensor(xLocal);
    yLocal = outQueueY.DeQue<T>();
    AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
    outQueueY.FreeTensor(yLocal);
}

template <typename T>
__global__ __aicore__ void gelu_kernel(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize,
    int32_t approximate)
{
    AscendC::TPipe pipe;
    int64_t currentBlockLength = totalLength - blockLength * static_cast<int64_t>(AscendC::GetBlockIdx());
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    constexpr int64_t alignNum = (sizeof(T) == sizeof(float)) ? 8 : 16;
    elementNumPerTile = elementNumPerTile / alignNum * alignNum;
    if (elementNumPerTile <= 0) {
        return;
    }

    constexpr int64_t workTiles = (sizeof(T) == sizeof(float)) ? 2 : 4;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuf;
    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(calcBuf, workTiles * elementNumPerTile * static_cast<int64_t>(sizeof(float)));

    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    auto w0 = calcBuf.Get<float>();
    auto w1 = w0[static_cast<uint32_t>(elementNumPerTile)];
    auto w2 = w1;
    auto xF = w1;
    if constexpr (sizeof(T) != sizeof(float)) {
        w2 = w0[static_cast<uint32_t>(2 * elementNumPerTile)];
        xF = w0[static_cast<uint32_t>(3 * elementNumPerTile)];
    }

    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        ProcessGeluTile<T>(
            xGm, yGm, inQueueX, outQueueY, w0, w1, w2, xF,
            i * elementNumPerTile, static_cast<uint32_t>(elementNumPerTile), approximate);
    }
    if (tailTileElementNum > 0) {
        ProcessGeluTile<T>(
            xGm, yGm, inQueueX, outQueueY, w0, w1, w2, xF,
            tileNum * elementNumPerTile, static_cast<uint32_t>(tailTileElementNum), approximate);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_gelu_tiling_params(int64_t totalLength, int64_t dsize, int32_t approximate)
{
    (void)approximate;
    constexpr static int64_t MIN_ELEMS_PER_CORE = 256;
    constexpr static int64_t ALIGN_ELEMS = 64;
    if (dsize <= 0) {
        dsize = static_cast<int64_t>(sizeof(float));
    }
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 192 * 1024;
    }
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 48;
    }

    int64_t numBlocks = 1;
    if (totalLength > 0) {
        numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
        if (numBlocks <= 0) {
            numBlocks = 1;
        }
    }
    int64_t blockLength = 0;
    if (numBlocks > 0) {
        blockLength = (totalLength + numBlocks - 1) / numBlocks;
        blockLength = (blockLength + ALIGN_ELEMS - 1) / ALIGN_ELEMS * ALIGN_ELEMS;
    }

    int64_t extraFloatTiles = (dsize == static_cast<int64_t>(sizeof(float))) ? 2 : 4;
    int64_t bytesPerElem = PIPELINE_DEPTH * 2 * dsize + extraFloatTiles * static_cast<int64_t>(sizeof(float));
    if (bytesPerElem < 8) {
        bytesPerElem = 8;
    }
    int64_t usableUb = static_cast<int64_t>(ubSize) / 2;
    if (usableUb < 16 * 1024) {
        usableUb = static_cast<int64_t>(ubSize) * 3 / 5;
    }
    int64_t e = usableUb / bytesPerElem;
    e = (e / ALIGN_ELEMS) * ALIGN_ELEMS;
    if (e < ALIGN_ELEMS) {
        e = ALIGN_ELEMS;
    }
    int64_t tileSize = e * dsize;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_gelu_kernel_float(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    uint32_t tileSize, int32_t approximate, void *stream)
{
    gelu_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, approximate);
}

void launch_gelu_kernel_half(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    uint32_t tileSize, int32_t approximate, void *stream)
{
    gelu_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, approximate);
}

void launch_gelu_kernel_bf16(
    GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    uint32_t tileSize, int32_t approximate, void *stream)
{
    gelu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize, approximate);
}

}
