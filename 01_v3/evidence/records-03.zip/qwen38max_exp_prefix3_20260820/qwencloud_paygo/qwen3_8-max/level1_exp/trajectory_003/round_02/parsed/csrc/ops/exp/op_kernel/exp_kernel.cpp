#include <tuple>
#include <algorithm>
#include <type_traits>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

constexpr static int64_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void exp_kernel(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileElements,
    float effScale,
    float effShift)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> tempQueue;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    if constexpr (!std::is_same<T, float>::value) {
        pipe.InitBuffer(tempQueue, 1, static_cast<uint32_t>(tileElements * sizeof(float)));
    }

    int64_t blockIdx = AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T*)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockLength * blockIdx);

    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t tileElems = static_cast<int64_t>(tileElements);
    if (tileElems <= 0) {
        return;
    }

    int64_t tileNum = currentBlockLength / tileElems;
    int64_t tailTileElementNum = currentBlockLength - tileNum * tileElems;
    int64_t iterNum = tileNum + (tailTileElementNum > 0 ? 1 : 0);

    for (int64_t i = 0; i < iterNum; ++i) {
        int64_t offset = i * tileElems;
        int64_t count = (i == tileNum) ? tailTileElementNum : tileElems;
        if (count <= 0) {
            continue;
        }

        int32_t calCount = static_cast<int32_t>(count);
        AscendC::DataCopyExtParams copyParams{
            1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();

        if constexpr (std::is_same<T, float>::value) {
            if (effScale != 1.0f) {
                AscendC::Muls(yLocal, xLocal, effScale, calCount);
                if (effShift != 0.0f) {
                    AscendC::Adds(yLocal, yLocal, effShift, calCount);
                }
                AscendC::Exp(yLocal, yLocal, calCount);
            } else {
                if (effShift != 0.0f) {
                    AscendC::Adds(yLocal, xLocal, effShift, calCount);
                    AscendC::Exp(yLocal, yLocal, calCount);
                } else {
                    AscendC::Exp(yLocal, xLocal, calCount);
                }
            }
        } else {
            auto tmp = tempQueue.AllocTensor<float>();
            AscendC::Cast(tmp, xLocal, AscendC::RoundMode::CAST_NONE, calCount);

            if (effScale != 1.0f) {
                AscendC::Muls(tmp, tmp, effScale, calCount);
                if (effShift != 0.0f) {
                    AscendC::Adds(tmp, tmp, effShift, calCount);
                }
            } else if (effShift != 0.0f) {
                AscendC::Adds(tmp, tmp, effShift, calCount);
            }

            AscendC::Exp(tmp, tmp, calCount);
            AscendC::Cast(yLocal, tmp, AscendC::RoundMode::CAST_NONE, calCount);
            tempQueue.FreeTensor(tmp);
        }

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_exp_tiling_params(
    int64_t totalLength,
    int64_t elementSize)
{
    if (totalLength <= 0) {
        return std::make_tuple(1, 0, 32);
    }

    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 256 * 1024;
    }

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = std::min(
        coreNum,
        (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    if (elementSize <= 0) {
        elementSize = 4;
    }

    int64_t bytesPerElem = 2 * PIPELINE_DEPTH * elementSize + 4 + 8;
    if (bytesPerElem <= 0) {
        bytesPerElem = 32;
    }

    uint64_t usableUb = ubSize / 8 * 7;
    if (usableUb == 0) {
        usableUb = ubSize;
    }

    int64_t tileElements = static_cast<int64_t>(usableUb / static_cast<uint64_t>(bytesPerElem));
    tileElements = (tileElements / 32) * 32;
    if (tileElements < 32) {
        tileElements = 32;
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileElements));
}

extern "C" {

void launch_exp_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElements,
    float effScale,
    float effShift,
    void* stream)
{
    if (numBlocks <= 0) {
        return;
    }
    exp_kernel<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, effScale, effShift);
}

void launch_exp_kernel_half(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElements,
    float effScale,
    float effShift,
    void* stream)
{
    if (numBlocks <= 0) {
        return;
    }
    exp_kernel<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, effScale, effShift);
}

void launch_exp_kernel_bfloat16(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElements,
    float effScale,
    float effShift,
    void* stream)
{
    if (numBlocks <= 0) {
        return;
    }
    exp_kernel<AscendC::bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, effScale, effShift);
}

}
