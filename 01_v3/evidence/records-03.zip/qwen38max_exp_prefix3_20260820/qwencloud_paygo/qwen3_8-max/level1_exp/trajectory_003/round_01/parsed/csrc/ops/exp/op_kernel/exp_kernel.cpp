#include <tuple>
#include <algorithm>
#include <type_traits>
#include <cstdint>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

constexpr static int64_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void exp_kernel(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileElements,
    float effScale,
    float effShift)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> temp1;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> temp2;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    pipe.InitBuffer(temp1, static_cast<uint32_t>(tileElements * sizeof(float)));
    pipe.InitBuffer(temp2, static_cast<uint32_t>(tileElements * sizeof(float)));

    int64_t blockIdx = AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T*)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockLength * blockIdx);

    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    int64_t tileElems = static_cast<int64_t>(tileElements);
    if (tileElems <= 0) {
        return;
    }

    int64_t tileNum = currentBlockLength / tileElems;
    int64_t tailTileElementNum = currentBlockLength - tileNum * tileElems;
    int64_t iterNum = tileNum + (tailTileElementNum > 0 ? 1 : 0);

    auto tmp1 = temp1.GetLocalTensor<float>();
    auto tmp2 = temp2.GetLocalTensor<float>();

    for (int64_t i = 0; i < iterNum; ++i) {
        int64_t offset = i * tileElems;
        int64_t count = (i == tileNum) ? tailTileElementNum : tileElems;
        if (count <= 0) {
            continue;
        }

        int32_t calCount = static_cast<int32_t>(count);
        AscendC::DataCopyExtParams copyParams{
            1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();

        if constexpr (std::is_same<T, float>::value) {
            AscendC::LocalTensor<float> src = xLocal;

            if (effScale != 1.0f) {
                AscendC::Muls(tmp1, xLocal, effScale, calCount);
                src = tmp1;
            }

            if (effShift != 0.0f) {
                if (effScale != 1.0f) {
                    AscendC::Adds(tmp2, tmp1, effShift, calCount);
                    src = tmp2;
                } else {
                    AscendC::Adds(tmp1, xLocal, effShift, calCount);
                    src = tmp1;
                }
            }

            AscendC::Exp(yLocal, src, calCount);
        } else {
            AscendC::Cast(tmp1, xLocal, AscendC::RoundMode::CAST_NONE, calCount);
            bool curIsTmp1 = true;

            if (effScale != 1.0f) {
                if (curIsTmp1) {
                    AscendC::Muls(tmp2, tmp1, effScale, calCount);
                    curIsTmp1 = false;
                } else {
                    AscendC::Muls(tmp1, tmp2, effScale, calCount);
                    curIsTmp1 = true;
                }
            }

            if (effShift != 0.0f) {
                if (curIsTmp1) {
                    AscendC::Adds(tmp2, tmp1, effShift, calCount);
                    curIsTmp1 = false;
                } else {
                    AscendC::Adds(tmp1, tmp2, effShift, calCount);
                    curIsTmp1 = true;
                }
            }

            if (curIsTmp1) {
                AscendC::Exp(tmp2, tmp1, calCount);
                AscendC::Cast(yLocal, tmp2, AscendC::RoundMode::CAST_NONE, calCount);
            } else {
                AscendC::Exp(tmp1, tmp2, calCount);
                AscendC::Cast(yLocal, tmp1, AscendC::RoundMode::CAST_NONE, calCount);
            }
        }

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_exp_tiling_params(
    int64_t totalLength,
    int64_t elementSize)
{
    if (totalLength <= 0) {
        return std::make_tuple(1, 0, 1);
    }

    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) {
        ubSize = 256 * 1024;
    }

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = std::min(
        coreNum,
        (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    if (elementSize <= 0) {
        elementSize = 4;
    }

    int64_t bytesPerElem = 4 * elementSize + 16;
    if (bytesPerElem <= 0) {
        bytesPerElem = 32;
    }

    uint64_t usableUb = ubSize / 8 * 7;
    if (usableUb == 0) {
        usableUb = ubSize;
    }

    int64_t tileElements = static_cast<int64_t>(usableUb / static_cast<uint64_t>(bytesPerElem));
    tileElements = (tileElements / 32) * 32;
    if (tileElements < 32) {
        tileElements = 32;
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileElements));
}

extern "C" {

void launch_exp_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElements,
    float effScale,
    float effShift,
    void* stream)
{
    if (numBlocks <= 0) {
        return;
    }
    exp_kernel<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, effScale, effShift);
}

void launch_exp_kernel_half(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElements,
    float effScale,
    float effShift,
    void* stream)
{
    if (numBlocks <= 0) {
        return;
    }
    exp_kernel<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, effScale, effShift);
}

void launch_exp_kernel_bfloat16(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileElements,
    float effScale,
    float effShift,
    void* stream)
{
    if (numBlocks <= 0) {
        return;
    }
    exp_kernel<AscendC::bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, effScale, effShift);
}

}
