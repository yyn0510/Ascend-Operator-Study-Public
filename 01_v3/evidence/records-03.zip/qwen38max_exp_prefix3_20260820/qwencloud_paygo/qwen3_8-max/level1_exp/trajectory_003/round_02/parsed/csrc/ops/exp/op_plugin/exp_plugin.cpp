#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include <cmath>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/exp_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("exp(Tensor x, float base=-1.0, float scale=1.0, float shift=0.0) -> Tensor");
}

torch::Tensor exp_meta(
    const torch::Tensor& x,
    double base,
    double scale,
    double shift)
{
    (void)base;
    (void)scale;
    (void)shift;
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("exp", exp_meta);
}

torch::Tensor exp_npu(
    const torch::Tensor& x,
    double base,
    double scale,
    double shift)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto x_contig = x.contiguous();
    auto y = torch::empty_like(x_contig);

    int64_t totalLength = x_contig.numel();
    if (totalLength == 0) {
        return y;
    }

    auto dtype = x_contig.scalar_type();
    TORCH_CHECK(
        dtype == torch::kFloat16 || dtype == torch::kFloat32 || dtype == torch::kBFloat16,
        "Exp only supports float16, float32 and bfloat16.");

    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t numBlocks = 0;
    int64_t blockLength = 0;
    uint32_t tileElements = 0;
    std::tie(numBlocks, blockLength, tileElements) =
        calc_exp_tiling_params(totalLength, x_contig.element_size());

    float effScale = static_cast<float>(scale);
    float effShift = static_cast<float>(shift);

    if (base > 0.0) {
        double lnBase = std::log(base);
        effScale = static_cast<float>(static_cast<double>(scale) * lnBase);
        effShift = static_cast<float>(static_cast<double>(shift) * lnBase);
    }

    auto x_ptr = (GM_ADDR)x_contig.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();

    auto acl_call = [=]() -> int {
        if (dtype == torch::kFloat32) {
            launch_exp_kernel_float(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength,
                tileElements, effScale, effShift, stream);
        } else if (dtype == torch::kFloat16) {
            launch_exp_kernel_half(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength,
                tileElements, effScale, effShift, stream);
        } else {
            launch_exp_kernel_bfloat16(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength,
                tileElements, effScale, effShift, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Exp", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("exp", exp_npu);
}

} // namespace cann_bench
