#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include <cmath>
#include <tuple>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/exp_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("exp(Tensor x, float base=-1.0, float scale=1.0, float shift=0.0) -> Tensor");
}

torch::Tensor exp_meta(const torch::Tensor &x, double base, double scale, double shift)
{
    TORCH_CHECK(
        x.scalar_type() == torch::kFloat16 ||
        x.scalar_type() == torch::kFloat32 ||
        x.scalar_type() == torch::kBFloat16,
        "Exp only supports float16, float32 and bfloat16.");
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("exp", exp_meta);
}

torch::Tensor exp_npu(const torch::Tensor &x, double base, double scale, double shift)
{
    const c10::OptionalDeviceGuard guard(x.device());

    torch::Tensor x_ = x.is_contiguous() ? x : x.contiguous();
    auto y = exp_meta(x_, base, scale, shift);

    int64_t totalLength = x_.numel();
    if (totalLength == 0) return y;

    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t numBlocks = 1;
    int64_t blockLength = 0;
    int64_t tileElements = 256;
    std::tie(numBlocks, blockLength, tileElements) =
        calc_exp_tiling_params(totalLength, static_cast<int64_t>(x_.element_size()));

    auto x_ptr = (GM_ADDR)x_.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();

    float scaleF = static_cast<float>(scale);
    float shiftF = static_cast<float>(shift);
    float logBase = 1.0f;
    if (base > 0.0) {
        logBase = static_cast<float>(std::log(base));
    }

    auto acl_call = [=]() -> int {
        if (x_.scalar_type() == torch::kFloat32) {
            launch_exp_kernel_float(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileElements,
                scaleF, shiftF, logBase, stream);
        } else if (x_.scalar_type() == torch::kFloat16) {
            launch_exp_kernel_half(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileElements,
                scaleF, shiftF, logBase, stream);
        } else if (x_.scalar_type() == torch::kBFloat16) {
            launch_exp_kernel_bfloat16(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileElements,
                scaleF, shiftF, logBase, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Exp", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("exp", exp_npu);
}

} // namespace cann_bench
