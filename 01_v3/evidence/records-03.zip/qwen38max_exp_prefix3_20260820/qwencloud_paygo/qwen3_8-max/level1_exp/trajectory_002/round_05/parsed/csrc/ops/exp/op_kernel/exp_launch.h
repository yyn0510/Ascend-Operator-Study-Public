#ifndef EXP_LAUNCH_H
#define EXP_LAUNCH_H

#include <cstdint>
#include <tuple>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(int64_t totalLength, int64_t bytesPerElem);

extern "C" {

void launch_exp_kernel_float(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB, void* stream);

void launch_exp_kernel_half_direct(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB, void* stream);

void launch_exp_kernel_half_fp32(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB, void* stream);

void launch_exp_kernel_bfloat16(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB, void* stream);

void launch_exp_const_kernel_float(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float constVal, void* stream);

void launch_exp_const_kernel_half(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float constVal, void* stream);

void launch_exp_const_kernel_bfloat16(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float constVal, void* stream);

}

#endif // EXP_LAUNCH_H
