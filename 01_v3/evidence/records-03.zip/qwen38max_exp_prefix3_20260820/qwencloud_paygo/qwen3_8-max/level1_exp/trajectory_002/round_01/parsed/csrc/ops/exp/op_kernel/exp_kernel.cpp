#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;

__global__ __aicore__ void exp_kernel_float(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t blockLength, int64_t tileElements,
    float scale, float shift, float logBase)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<float> xGm;
    AscendC::GlobalTensor<float> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(float)));
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(float)));

    xGm.SetGlobalBuffer((__gm__ float*)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ float*)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - blockLength * AscendC::GetBlockIdx();
    if (currentBlockLength <= 0) return;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;

    int64_t tileNum = currentBlockLength / tileElements;
    int64_t tail = currentBlockLength - tileNum * tileElements;
    int64_t totalTiles = tileNum + (tail > 0 ? 1 : 0);
    if (totalTiles == 0) return;

    AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};

    int64_t firstCount = (0 < tileNum) ? tileElements : tail;
    AscendC::DataCopyExtParams firstCopy{1, static_cast<uint32_t>(firstCount * sizeof(float)), 0, 0, 0};
    auto xPrefetch = inQueue.AllocTensor<float>();
    AscendC::DataCopyPad(xPrefetch, xGm[0], firstCopy, padParams);
    inQueue.EnQue(xPrefetch);

    bool hasPendingOut = false;
    int64_t pendingOffset = 0;
    int64_t pendingCount = 0;

    for (int64_t i = 0; i < totalTiles; ++i) {
        auto xLocal = inQueue.DeQue<float>();

        int64_t count = (i < tileNum) ? tileElements : tail;
        int64_t offset = (i < tileNum) ? i * tileElements : tileNum * tileElements;

        if (i + 1 < totalTiles) {
            int64_t nextCount = (i + 1 < tileNum) ? tileElements : tail;
            int64_t nextOffset = (i + 1 < tileNum) ? (i + 1) * tileElements : tileNum * tileElements;
            AscendC::DataCopyExtParams nextCopy{1, static_cast<uint32_t>(nextCount * sizeof(float)), 0, 0, 0};
            auto xNext = inQueue.AllocTensor<float>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopy, padParams);
            inQueue.EnQue(xNext);
        }

        auto yLocal = outQueue.AllocTensor<float>();
        int32_t count32 = static_cast<int32_t>(count);

        if (scale == 1.0f && shift == 0.0f && logBase == 1.0f) {
            AscendC::Exp(yLocal, xLocal, count32);
        } else {
            AscendC::Muls(yLocal, xLocal, scale, count32);
            AscendC::Adds(yLocal, yLocal, shift, count32);
            if (logBase != 1.0f) {
                AscendC::Muls(yLocal, yLocal, logBase, count32);
            }
            AscendC::Exp(yLocal, yLocal, count32);
        }

        inQueue.FreeTensor(xLocal);
        outQueue.EnQue(yLocal);

        if (hasPendingOut) {
            auto yOut = outQueue.DeQue<float>();
            AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(float)), 0, 0, 0};
            AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
            outQueue.FreeTensor(yOut);
        }

        hasPendingOut = true;
        pendingOffset = offset;
        pendingCount = count;
    }

    if (hasPendingOut) {
        auto yOut = outQueue.DeQue<float>();
        AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(float)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
        outQueue.FreeTensor(yOut);
    }
}

template <typename T>
__global__ __aicore__ void exp_kernel_16bit(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t blockLength, int64_t tileElements,
    float scale, float shift, float logBase)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::QuePosition::VECIN> workBuf1;
    AscendC::TBuf<AscendC::QuePosition::VECIN> workBuf2;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    pipe.InitBuffer(workBuf1, static_cast<uint32_t>(tileElements * sizeof(float)));
    pipe.InitBuffer(workBuf2, static_cast<uint32_t>(tileElements * sizeof(float)));

    xGm.SetGlobalBuffer((__gm__ T*)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T*)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - blockLength * AscendC::GetBlockIdx();
    if (currentBlockLength <= 0) return;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;

    int64_t tileNum = currentBlockLength / tileElements;
    int64_t tail = currentBlockLength - tileNum * tileElements;
    int64_t totalTiles = tileNum + (tail > 0 ? 1 : 0);
    if (totalTiles == 0) return;

    AscendC::LocalTensor<float> tmp1 = workBuf1.Get<float>();
    AscendC::LocalTensor<float> tmp2 = workBuf2.Get<float>();

    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    int64_t firstCount = (0 < tileNum) ? tileElements : tail;
    AscendC::DataCopyExtParams firstCopy{1, static_cast<uint32_t>(firstCount * sizeof(T)), 0, 0, 0};
    auto xPrefetch = inQueue.AllocTensor<T>();
    AscendC::DataCopyPad(xPrefetch, xGm[0], firstCopy, padParams);
    inQueue.EnQue(xPrefetch);

    bool hasPendingOut = false;
    int64_t pendingOffset = 0;
    int64_t pendingCount = 0;

    for (int64_t i = 0; i < totalTiles; ++i) {
        auto xLocal = inQueue.DeQue<T>();

        int64_t count = (i < tileNum) ? tileElements : tail;
        int64_t offset = (i < tileNum) ? i * tileElements : tileNum * tileElements;

        if (i + 1 < totalTiles) {
            int64_t nextCount = (i + 1 < tileNum) ? tileElements : tail;
            int64_t nextOffset = (i + 1 < tileNum) ? (i + 1) * tileElements : tileNum * tileElements;
            AscendC::DataCopyExtParams nextCopy{1, static_cast<uint32_t>(nextCount * sizeof(T)), 0, 0, 0};
            auto xNext = inQueue.AllocTensor<T>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopy, padParams);
            inQueue.EnQue(xNext);
        }

        auto yLocal = outQueue.AllocTensor<T>();
        int32_t count32 = static_cast<int32_t>(count);

        AscendC::Cast(tmp1, xLocal, AscendC::RoundMode::CAST_NONE, count32);
        inQueue.FreeTensor(xLocal);

        if (scale == 1.0f && shift == 0.0f && logBase == 1.0f) {
            AscendC::Exp(tmp2, tmp1, count32);
            AscendC::Cast(yLocal, tmp2, AscendC::RoundMode::CAST_NONE, count32);
        } else {
            AscendC::Muls(tmp2, tmp1, scale, count32);
            AscendC::Adds(tmp1, tmp2, shift, count32);

            if (logBase != 1.0f) {
                AscendC::Muls(tmp2, tmp1, logBase, count32);
                AscendC::Exp(tmp1, tmp2, count32);
                AscendC::Cast(yLocal, tmp1, AscendC::RoundMode::CAST_NONE, count32);
            } else {
                AscendC::Exp(tmp2, tmp1, count32);
                AscendC::Cast(yLocal, tmp2, AscendC::RoundMode::CAST_NONE, count32);
            }
        }

        outQueue.EnQue(yLocal);

        if (hasPendingOut) {
            auto yOut = outQueue.DeQue<T>();
            AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
            outQueue.FreeTensor(yOut);
        }

        hasPendingOut = true;
        pendingOffset = offset;
        pendingCount = count;
    }

    if (hasPendingOut) {
        auto yOut = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
        outQueue.FreeTensor(yOut);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(int64_t totalLength, int64_t elemSize)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) ubSize = 192ULL * 1024ULL;

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t numBlocks = 1;
    if (totalLength > 0) {
        int64_t blocksByLength = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
        numBlocks = std::min(coreNum, blocksByLength);
    }
    if (numBlocks <= 0) numBlocks = 1;

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    int64_t budget = static_cast<int64_t>(ubSize) * 3 / 4;
    int64_t perElem = (elemSize == 4) ? 16 : 16;
    int64_t tileElements = budget / perElem;

    if (tileElements < 32) tileElements = 32;
    tileElements = (tileElements / 32) * 32;
    if (tileElements <= 0) tileElements = 32;
    if (tileElements > 131072) tileElements = 131072;

    return std::make_tuple(numBlocks, blockLength, tileElements);
}

extern "C" {

void launch_exp_kernel_float(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float scale, float shift, float logBase, void* stream)
{
    exp_kernel_float<<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, scale, shift, logBase);
}

void launch_exp_kernel_half(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float scale, float shift, float logBase, void* stream)
{
    exp_kernel_16bit<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, scale, shift, logBase);
}

void launch_exp_kernel_bfloat16(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float scale, float shift, float logBase, void* stream)
{
    exp_kernel_16bit<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, scale, shift, logBase);
}

}
