#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void exp_kernel_direct(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    uint32_t tileBytes = static_cast<uint32_t>(tileElements * sizeof(T));
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileBytes);

    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t start = blockLength * blockIdx;
    if (start >= totalLength) return;

    xGm.SetGlobalBuffer((__gm__ T*)x + start);
    yGm.SetGlobalBuffer((__gm__ T*)y + start);

    int64_t currentBlockLength = totalLength - start;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;

    int64_t tileNum = currentBlockLength / tileElements;
    int64_t tail = currentBlockLength - tileNum * tileElements;
    int64_t totalTiles = tileNum + (tail > 0 ? 1 : 0);
    if (totalTiles <= 0) return;

    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    int64_t firstCount = (tileNum > 0) ? tileElements : tail;
    AscendC::DataCopyExtParams firstCopy{1, static_cast<uint32_t>(firstCount * sizeof(T)), 0, 0, 0};
    auto xPrefetch = inQueue.AllocTensor<T>();
    AscendC::DataCopyPad(xPrefetch, xGm[0], firstCopy, padParams);
    inQueue.EnQue(xPrefetch);

    T a = static_cast<T>(coefA);
    T b = static_cast<T>(coefB);

    bool hasPendingOut = false;
    int64_t pendingOffset = 0;
    int64_t pendingCount = 0;

    for (int64_t i = 0; i < totalTiles; ++i) {
        auto xLocal = inQueue.DeQue<T>();

        int64_t count = (i < tileNum) ? tileElements : tail;
        int64_t offset = (i < tileNum) ? i * tileElements : tileNum * tileElements;

        if (i + 1 < totalTiles) {
            int64_t nextCount = (i + 1 < tileNum) ? tileElements : tail;
            int64_t nextOffset = (i + 1 < tileNum) ? (i + 1) * tileElements : tileNum * tileElements;
            AscendC::DataCopyExtParams nextCopy{1, static_cast<uint32_t>(nextCount * sizeof(T)), 0, 0, 0};
            auto xNext = inQueue.AllocTensor<T>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopy, padParams);
            inQueue.EnQue(xNext);
        }

        if (hasPendingOut) {
            auto yOut = outQueue.DeQue<T>();
            AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
            outQueue.FreeTensor(yOut);
        }

        auto yLocal = outQueue.AllocTensor<T>();
        int32_t vecCount = static_cast<int32_t>((count + 31) & ~31LL);

        if (coefA == 1.0f && coefB == 0.0f) {
            AscendC::Exp(yLocal, xLocal, vecCount);
        } else if (coefB == 0.0f) {
            AscendC::Muls(yLocal, xLocal, a, vecCount);
            AscendC::Exp(yLocal, yLocal, vecCount);
        } else if (coefA == 1.0f) {
            AscendC::Adds(yLocal, xLocal, b, vecCount);
            AscendC::Exp(yLocal, yLocal, vecCount);
        } else {
            AscendC::Muls(yLocal, xLocal, a, vecCount);
            AscendC::Adds(yLocal, yLocal, b, vecCount);
            AscendC::Exp(yLocal, yLocal, vecCount);
        }

        inQueue.FreeTensor(xLocal);
        outQueue.EnQue(yLocal);

        hasPendingOut = true;
        pendingOffset = offset;
        pendingCount = count;
    }

    if (hasPendingOut) {
        auto yOut = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
        outQueue.FreeTensor(yOut);
    }
}

template <typename T>
__global__ __aicore__ void exp_kernel_16bit_fp32(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::QuePosition::VECIN> workBuf;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    pipe.InitBuffer(workBuf, static_cast<uint32_t>(tileElements * sizeof(float)));

    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t start = blockLength * blockIdx;
    if (start >= totalLength) return;

    xGm.SetGlobalBuffer((__gm__ T*)x + start);
    yGm.SetGlobalBuffer((__gm__ T*)y + start);

    int64_t currentBlockLength = totalLength - start;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;

    int64_t tileNum = currentBlockLength / tileElements;
    int64_t tail = currentBlockLength - tileNum * tileElements;
    int64_t totalTiles = tileNum + (tail > 0 ? 1 : 0);
    if (totalTiles <= 0) return;

    AscendC::LocalTensor<float> tmp = workBuf.Get<float>();
    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    int64_t firstCount = (tileNum > 0) ? tileElements : tail;
    AscendC::DataCopyExtParams firstCopy{1, static_cast<uint32_t>(firstCount * sizeof(T)), 0, 0, 0};
    auto xPrefetch = inQueue.AllocTensor<T>();
    AscendC::DataCopyPad(xPrefetch, xGm[0], firstCopy, padParams);
    inQueue.EnQue(xPrefetch);

    bool hasPendingOut = false;
    int64_t pendingOffset = 0;
    int64_t pendingCount = 0;

    for (int64_t i = 0; i < totalTiles; ++i) {
        auto xLocal = inQueue.DeQue<T>();

        int64_t count = (i < tileNum) ? tileElements : tail;
        int64_t offset = (i < tileNum) ? i * tileElements : tileNum * tileElements;

        if (i + 1 < totalTiles) {
            int64_t nextCount = (i + 1 < tileNum) ? tileElements : tail;
            int64_t nextOffset = (i + 1 < tileNum) ? (i + 1) * tileElements : tileNum * tileElements;
            AscendC::DataCopyExtParams nextCopy{1, static_cast<uint32_t>(nextCount * sizeof(T)), 0, 0, 0};
            auto xNext = inQueue.AllocTensor<T>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopy, padParams);
            inQueue.EnQue(xNext);
        }

        if (hasPendingOut) {
            auto yOut = outQueue.DeQue<T>();
            AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
            outQueue.FreeTensor(yOut);
        }

        auto yLocal = outQueue.AllocTensor<T>();
        int32_t vecCount = static_cast<int32_t>((count + 31) & ~31LL);

        AscendC::Cast(tmp, xLocal, AscendC::RoundMode::CAST_NONE, vecCount);

        if (coefA == 1.0f && coefB == 0.0f) {
            AscendC::Exp(tmp, tmp, vecCount);
        } else if (coefB == 0.0f) {
            AscendC::Muls(tmp, tmp, coefA, vecCount);
            AscendC::Exp(tmp, tmp, vecCount);
        } else if (coefA == 1.0f) {
            AscendC::Adds(tmp, tmp, coefB, vecCount);
            AscendC::Exp(tmp, tmp, vecCount);
        } else {
            AscendC::Muls(tmp, tmp, coefA, vecCount);
            AscendC::Adds(tmp, tmp, coefB, vecCount);
            AscendC::Exp(tmp, tmp, vecCount);
        }

        AscendC::Cast(yLocal, tmp, AscendC::RoundMode::CAST_RINT, vecCount);

        inQueue.FreeTensor(xLocal);
        outQueue.EnQue(yLocal);

        hasPendingOut = true;
        pendingOffset = offset;
        pendingCount = count;
    }

    if (hasPendingOut) {
        auto yOut = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
        outQueue.FreeTensor(yOut);
    }
}

template <typename T>
__global__ __aicore__ void exp_const_kernel_direct(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t blockLength, int64_t tileElements,
    float constVal)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    uint32_t tileBytes = static_cast<uint32_t>(tileElements * sizeof(T));
    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileBytes);

    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t start = blockLength * blockIdx;
    if (start >= totalLength) return;

    xGm.SetGlobalBuffer((__gm__ T*)x + start);
    yGm.SetGlobalBuffer((__gm__ T*)y + start);

    int64_t currentBlockLength = totalLength - start;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;

    int64_t tileNum = currentBlockLength / tileElements;
    int64_t tail = currentBlockLength - tileNum * tileElements;
    int64_t totalTiles = tileNum + (tail > 0 ? 1 : 0);
    if (totalTiles <= 0) return;

    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    int64_t firstCount = (tileNum > 0) ? tileElements : tail;
    AscendC::DataCopyExtParams firstCopy{1, static_cast<uint32_t>(firstCount * sizeof(T)), 0, 0, 0};
    auto xPrefetch = inQueue.AllocTensor<T>();
    AscendC::DataCopyPad(xPrefetch, xGm[0], firstCopy, padParams);
    inQueue.EnQue(xPrefetch);

    T zero = static_cast<T>(0.0f);
    T val = static_cast<T>(constVal);

    bool hasPendingOut = false;
    int64_t pendingOffset = 0;
    int64_t pendingCount = 0;

    for (int64_t i = 0; i < totalTiles; ++i) {
        auto xLocal = inQueue.DeQue<T>();

        int64_t count = (i < tileNum) ? tileElements : tail;
        int64_t offset = (i < tileNum) ? i * tileElements : tileNum * tileElements;

        if (i + 1 < totalTiles) {
            int64_t nextCount = (i + 1 < tileNum) ? tileElements : tail;
            int64_t nextOffset = (i + 1 < tileNum) ? (i + 1) * tileElements : tileNum * tileElements;
            AscendC::DataCopyExtParams nextCopy{1, static_cast<uint32_t>(nextCount * sizeof(T)), 0, 0, 0};
            auto xNext = inQueue.AllocTensor<T>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopy, padParams);
            inQueue.EnQue(xNext);
        }

        if (hasPendingOut) {
            auto yOut = outQueue.DeQue<T>();
            AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
            outQueue.FreeTensor(yOut);
        }

        auto yLocal = outQueue.AllocTensor<T>();
        int32_t vecCount = static_cast<int32_t>((count + 31) & ~31LL);

        AscendC::Muls(yLocal, xLocal, zero, vecCount);
        AscendC::Adds(yLocal, yLocal, val, vecCount);

        inQueue.FreeTensor(xLocal);
        outQueue.EnQue(yLocal);

        hasPendingOut = true;
        pendingOffset = offset;
        pendingCount = count;
    }

    if (hasPendingOut) {
        auto yOut = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
        outQueue.FreeTensor(yOut);
    }
}

template <typename T>
__global__ __aicore__ void exp_const_kernel_16bit_fp32(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t blockLength, int64_t tileElements,
    float constVal)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::QuePosition::VECIN> workBuf;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElements * sizeof(T)));
    pipe.InitBuffer(workBuf, static_cast<uint32_t>(tileElements * sizeof(float)));

    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t start = blockLength * blockIdx;
    if (start >= totalLength) return;

    xGm.SetGlobalBuffer((__gm__ T*)x + start);
    yGm.SetGlobalBuffer((__gm__ T*)y + start);

    int64_t currentBlockLength = totalLength - start;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;

    int64_t tileNum = currentBlockLength / tileElements;
    int64_t tail = currentBlockLength - tileNum * tileElements;
    int64_t totalTiles = tileNum + (tail > 0 ? 1 : 0);
    if (totalTiles <= 0) return;

    AscendC::LocalTensor<float> tmp = workBuf.Get<float>();
    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    int64_t firstCount = (tileNum > 0) ? tileElements : tail;
    AscendC::DataCopyExtParams firstCopy{1, static_cast<uint32_t>(firstCount * sizeof(T)), 0, 0, 0};
    auto xPrefetch = inQueue.AllocTensor<T>();
    AscendC::DataCopyPad(xPrefetch, xGm[0], firstCopy, padParams);
    inQueue.EnQue(xPrefetch);

    bool hasPendingOut = false;
    int64_t pendingOffset = 0;
    int64_t pendingCount = 0;

    for (int64_t i = 0; i < totalTiles; ++i) {
        auto xLocal = inQueue.DeQue<T>();

        int64_t count = (i < tileNum) ? tileElements : tail;
        int64_t offset = (i < tileNum) ? i * tileElements : tileNum * tileElements;

        if (i + 1 < totalTiles) {
            int64_t nextCount = (i + 1 < tileNum) ? tileElements : tail;
            int64_t nextOffset = (i + 1 < tileNum) ? (i + 1) * tileElements : tileNum * tileElements;
            AscendC::DataCopyExtParams nextCopy{1, static_cast<uint32_t>(nextCount * sizeof(T)), 0, 0, 0};
            auto xNext = inQueue.AllocTensor<T>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], nextCopy, padParams);
            inQueue.EnQue(xNext);
        }

        if (hasPendingOut) {
            auto yOut = outQueue.DeQue<T>();
            AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
            outQueue.FreeTensor(yOut);
        }

        auto yLocal = outQueue.AllocTensor<T>();
        int32_t vecCount = static_cast<int32_t>((count + 31) & ~31LL);

        AscendC::Cast(tmp, xLocal, AscendC::RoundMode::CAST_NONE, vecCount);
        AscendC::Muls(tmp, tmp, 0.0f, vecCount);
        AscendC::Adds(tmp, tmp, constVal, vecCount);
        AscendC::Cast(yLocal, tmp, AscendC::RoundMode::CAST_RINT, vecCount);

        inQueue.FreeTensor(xLocal);
        outQueue.EnQue(yLocal);

        hasPendingOut = true;
        pendingOffset = offset;
        pendingCount = count;
    }

    if (hasPendingOut) {
        auto yOut = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams outCopy{1, static_cast<uint32_t>(pendingCount * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[pendingOffset], yOut, outCopy);
        outQueue.FreeTensor(yOut);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(int64_t totalLength, int64_t bytesPerElem)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 4096;
    constexpr int64_t ALIGN_ELEMS = 256;
    constexpr int64_t MAX_TILE_ELEMS = 65536;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    if (ubSize == 0) ubSize = 256ULL * 1024ULL;

    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t numBlocks = coreNum;
    if (totalLength > 0) {
        int64_t blocksByLength = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
        numBlocks = std::min(coreNum, blocksByLength);
    }
    if (numBlocks <= 0) numBlocks = 1;

    if (bytesPerElem <= 0) bytesPerElem = 16;
    uint64_t usable = (ubSize > 4096ULL) ? (ubSize - 4096ULL) : ubSize;

    int64_t tileElements = static_cast<int64_t>(usable / static_cast<uint64_t>(bytesPerElem));
    tileElements = (tileElements / ALIGN_ELEMS) * ALIGN_ELEMS;
    if (tileElements < ALIGN_ELEMS) tileElements = ALIGN_ELEMS;
    if (tileElements > MAX_TILE_ELEMS) tileElements = MAX_TILE_ELEMS;

    int64_t blockLength = ALIGN_ELEMS;
    if (totalLength > 0) {
        blockLength = (totalLength + numBlocks - 1) / numBlocks;
        blockLength = ((blockLength + ALIGN_ELEMS - 1) / ALIGN_ELEMS) * ALIGN_ELEMS;
        if (blockLength < ALIGN_ELEMS) blockLength = ALIGN_ELEMS;

        int64_t neededBlocks = (totalLength + blockLength - 1) / blockLength;
        if (neededBlocks > 0 && neededBlocks < numBlocks) numBlocks = neededBlocks;
    } else {
        numBlocks = 1;
    }

    return std::make_tuple(numBlocks, blockLength, tileElements);
}

extern "C" {

void launch_exp_kernel_float(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB, void* stream)
{
    exp_kernel_direct<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, coefA, coefB);
}

void launch_exp_kernel_half_direct(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB, void* stream)
{
    exp_kernel_direct<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, coefA, coefB);
}

void launch_exp_kernel_half_fp32(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB, void* stream)
{
    exp_kernel_16bit_fp32<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, coefA, coefB);
}

void launch_exp_kernel_bfloat16(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float coefA, float coefB, void* stream)
{
    exp_kernel_16bit_fp32<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, coefA, coefB);
}

void launch_exp_const_kernel_float(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float constVal, void* stream)
{
    exp_const_kernel_direct<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, constVal);
}

void launch_exp_const_kernel_half(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float constVal, void* stream)
{
    exp_const_kernel_direct<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, constVal);
}

void launch_exp_const_kernel_bfloat16(
    GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileElements,
    float constVal, void* stream)
{
    exp_const_kernel_16bit_fp32<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileElements, constVal);
}

}
