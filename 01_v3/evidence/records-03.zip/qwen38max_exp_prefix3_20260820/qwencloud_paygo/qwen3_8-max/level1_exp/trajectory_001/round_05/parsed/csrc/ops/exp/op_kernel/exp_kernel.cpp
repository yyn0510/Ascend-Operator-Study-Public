#include <cstdint>
#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"
#include "exp_launch.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void exp_kernel_direct(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift)
{
    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t blockStart = blockLength * blockIdx;
    if (blockStart >= totalLength) {
        return;
    }

    int64_t currentBlockLength = totalLength - blockStart;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    int64_t alignElems = 32 / static_cast<int64_t>(sizeof(T));
    if (alignElems < 8) {
        alignElems = 8;
    }
    elementNumPerTile = (elementNumPerTile / alignElems) * alignElems;
    if (elementNumPerTile < alignElems) {
        elementNumPerTile = alignElems;
    }

    int64_t fullTileNum = currentBlockLength / elementNumPerTile;
    int64_t tail = currentBlockLength - fullTileNum * elementNumPerTile;
    int64_t totalTiles = fullTileNum + (tail > 0 ? 1 : 0);
    if (totalTiles <= 0) {
        return;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);

    xGm.SetGlobalBuffer((__gm__ T*)x + blockStart);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockStart);

    T scaleT = static_cast<T>(scale);
    T shiftT = static_cast<T>(shift);
    bool doScale = (scale != 1.0f);
    bool doShift = (shift != 0.0f);

    AscendC::DataCopyPadExtParams<T> padIn{false, 0, 0, 0};

    int64_t n0 = (fullTileNum > 0) ? elementNumPerTile : tail;
    AscendC::DataCopyExtParams cp0{
        1, static_cast<uint32_t>(n0 * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
    auto xPrefetch = inQueueX.AllocTensor<T>();
    AscendC::DataCopyPad(xPrefetch, xGm[0], cp0, padIn);
    inQueueX.EnQue(xPrefetch);

    for (int64_t i = 0; i < totalTiles; ++i) {
        if (i + 1 < totalTiles) {
            int64_t nextIdx = i + 1;
            int64_t nextOffset = nextIdx * elementNumPerTile;
            int64_t nextN = (nextIdx < fullTileNum) ? elementNumPerTile : tail;
            AscendC::DataCopyExtParams cpNext{
                1, static_cast<uint32_t>(nextN * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
            auto xNext = inQueueX.AllocTensor<T>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], cpNext, padIn);
            inQueueX.EnQue(xNext);
        }

        int64_t n = (i < fullTileNum) ? elementNumPerTile : tail;
        int64_t countAligned = ((n + alignElems - 1) / alignElems) * alignElems;
        if (countAligned > elementNumPerTile) {
            countAligned = elementNumPerTile;
        }
        int32_t count = static_cast<int32_t>(countAligned);

        auto xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();

        if (doScale) {
            AscendC::Muls(xLocal, xLocal, scaleT, count);
        }
        if (doShift) {
            AscendC::Adds(xLocal, xLocal, shiftT, count);
        }
        AscendC::Exp(yLocal, xLocal, count);

        inQueueX.FreeTensor(xLocal);
        outQueueY.EnQue(yLocal);

        if (i > 0) {
            int64_t wIdx = i - 1;
            int64_t wOffset = wIdx * elementNumPerTile;
            int64_t wN = (wIdx < fullTileNum) ? elementNumPerTile : tail;
            AscendC::DataCopyExtParams cpW{
                1, static_cast<uint32_t>(wN * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
            auto yPrev = outQueueY.DeQue<T>();
            AscendC::DataCopyPad(yGm[wOffset], yPrev, cpW);
            outQueueY.FreeTensor(yPrev);
        }
    }

    int64_t lastIdx = totalTiles - 1;
    int64_t lastOffset = lastIdx * elementNumPerTile;
    int64_t lastN = (lastIdx < fullTileNum) ? elementNumPerTile : tail;
    AscendC::DataCopyExtParams cpLast{
        1, static_cast<uint32_t>(lastN * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
    auto yLast = outQueueY.DeQue<T>();
    AscendC::DataCopyPad(yGm[lastOffset], yLast, cpLast);
    outQueueY.FreeTensor(yLast);
}

template <typename T>
__global__ __aicore__ void exp_kernel_lowprec_fp32compute(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift)
{
    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t blockStart = blockLength * blockIdx;
    if (blockStart >= totalLength) {
        return;
    }

    int64_t currentBlockLength = totalLength - blockStart;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    int64_t alignElems = 32 / static_cast<int64_t>(sizeof(T));
    if (alignElems < 8) {
        alignElems = 8;
    }
    elementNumPerTile = (elementNumPerTile / alignElems) * alignElems;
    if (elementNumPerTile < alignElems) {
        elementNumPerTile = alignElems;
    }

    int64_t fullTileNum = currentBlockLength / elementNumPerTile;
    int64_t tail = currentBlockLength - fullTileNum * elementNumPerTile;
    int64_t totalTiles = fullTileNum + (tail > 0 ? 1 : 0);
    if (totalTiles <= 0) {
        return;
    }

    uint32_t tmpSize = static_cast<uint32_t>(
        ((elementNumPerTile * static_cast<int64_t>(sizeof(float)) + 31) / 32) * 32);
    if (tmpSize < 32) {
        tmpSize = 32;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::QuePosition::VECOUT> tmpBuf;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpBuf, tmpSize);

    AscendC::LocalTensor<float> tmpLocal = tmpBuf.Get<float>();

    xGm.SetGlobalBuffer((__gm__ T*)x + blockStart);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockStart);

    bool doScale = (scale != 1.0f);
    bool doShift = (shift != 0.0f);

    AscendC::DataCopyPadExtParams<T> padIn{false, 0, 0, 0};

    int64_t n0 = (fullTileNum > 0) ? elementNumPerTile : tail;
    AscendC::DataCopyExtParams cp0{
        1, static_cast<uint32_t>(n0 * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
    auto xPrefetch = inQueueX.AllocTensor<T>();
    AscendC::DataCopyPad(xPrefetch, xGm[0], cp0, padIn);
    inQueueX.EnQue(xPrefetch);

    for (int64_t i = 0; i < totalTiles; ++i) {
        if (i + 1 < totalTiles) {
            int64_t nextIdx = i + 1;
            int64_t nextOffset = nextIdx * elementNumPerTile;
            int64_t nextN = (nextIdx < fullTileNum) ? elementNumPerTile : tail;
            AscendC::DataCopyExtParams cpNext{
                1, static_cast<uint32_t>(nextN * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
            auto xNext = inQueueX.AllocTensor<T>();
            AscendC::DataCopyPad(xNext, xGm[nextOffset], cpNext, padIn);
            inQueueX.EnQue(xNext);
        }

        int64_t n = (i < fullTileNum) ? elementNumPerTile : tail;
        int64_t countAligned = ((n + alignElems - 1) / alignElems) * alignElems;
        if (countAligned > elementNumPerTile) {
            countAligned = elementNumPerTile;
        }
        int32_t count = static_cast<int32_t>(countAligned);

        auto xLocal = inQueueX.DeQue<T>();
        AscendC::Cast(tmpLocal, xLocal, AscendC::RoundMode::CAST_NONE, count);
        inQueueX.FreeTensor(xLocal);

        auto yLocal = outQueueY.AllocTensor<T>();

        if (doScale) {
            AscendC::Muls(tmpLocal, tmpLocal, scale, count);
        }
        if (doShift) {
            AscendC::Adds(tmpLocal, tmpLocal, shift, count);
        }
        AscendC::Exp(tmpLocal, tmpLocal, count);
        AscendC::Cast(yLocal, tmpLocal, AscendC::RoundMode::CAST_RINT, count);

        outQueueY.EnQue(yLocal);

        if (i > 0) {
            int64_t wIdx = i - 1;
            int64_t wOffset = wIdx * elementNumPerTile;
            int64_t wN = (wIdx < fullTileNum) ? elementNumPerTile : tail;
            AscendC::DataCopyExtParams cpW{
                1, static_cast<uint32_t>(wN * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
            auto yPrev = outQueueY.DeQue<T>();
            AscendC::DataCopyPad(yGm[wOffset], yPrev, cpW);
            outQueueY.FreeTensor(yPrev);
        }
    }

    int64_t lastIdx = totalTiles - 1;
    int64_t lastOffset = lastIdx * elementNumPerTile;
    int64_t lastN = (lastIdx < fullTileNum) ? elementNumPerTile : tail;
    AscendC::DataCopyExtParams cpLast{
        1, static_cast<uint32_t>(lastN * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
    auto yLast = outQueueY.DeQue<T>();
    AscendC::DataCopyPad(yGm[lastOffset], yLast, cpLast);
    outQueueY.FreeTensor(yLast);
}

std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(
    int64_t totalLength,
    int64_t dtypeSize,
    int64_t mode)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();

    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);

    int64_t coreNum = static_cast<int64_t>(ascendcPlatform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }

    if (totalLength <= 0) {
        return std::make_tuple(int64_t(1), int64_t(0), int64_t(512));
    }

    if (dtypeSize <= 0) {
        dtypeSize = 4;
    }
    if (ubSize == 0) {
        ubSize = 192 * 1024;
    }

    int64_t bufferNum = (mode == 0) ? 4 : 6;
    uint64_t reserveBytes = 16 * 1024;
    uint64_t tileBytes = 0;

    if (ubSize > reserveBytes + static_cast<uint64_t>(bufferNum) * 512ULL) {
        tileBytes = (ubSize - reserveBytes) / static_cast<uint64_t>(bufferNum);
    } else {
        tileBytes = ubSize / static_cast<uint64_t>(bufferNum + 1);
    }

    tileBytes = (tileBytes / 512) * 512;
    if (tileBytes < 512) {
        tileBytes = 512;
    }

    int64_t alignElems = 32 / dtypeSize;
    if (alignElems < 8) {
        alignElems = 8;
    }

    int64_t elemTile = static_cast<int64_t>(tileBytes) / dtypeSize;
    elemTile = (elemTile / alignElems) * alignElems;
    if (elemTile < alignElems) {
        elemTile = alignElems;
    }

    int64_t tileSizeOut = elemTile * dtypeSize;

    int64_t totalTiles = (totalLength + elemTile - 1) / elemTile;
    if (totalTiles <= 0) {
        totalTiles = 1;
    }

    int64_t numBlocks = coreNum < totalTiles ? coreNum : totalTiles;
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t tilesPerBlock = (totalTiles + numBlocks - 1) / numBlocks;
    int64_t blockLength = tilesPerBlock * elemTile;

    return std::make_tuple(numBlocks, blockLength, tileSizeOut);
}

extern "C" {

void launch_exp_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift,
    void* stream)
{
    if (numBlocks <= 0 || totalLength <= 0) {
        return;
    }
    exp_kernel_direct<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, scale, shift);
}

void launch_exp_kernel_half(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift,
    void* stream)
{
    if (numBlocks <= 0 || totalLength <= 0) {
        return;
    }
    exp_kernel_direct<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, scale, shift);
}

void launch_exp_kernel_bfloat16(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift,
    void* stream)
{
    if (numBlocks <= 0 || totalLength <= 0) {
        return;
    }
    exp_kernel_lowprec_fp32compute<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, scale, shift);
}

}
