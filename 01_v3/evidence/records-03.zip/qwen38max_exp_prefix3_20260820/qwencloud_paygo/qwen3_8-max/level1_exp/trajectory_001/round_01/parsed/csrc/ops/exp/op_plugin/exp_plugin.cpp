#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include <cmath>
#include <tuple>

#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/exp_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("exp(Tensor x, float base=-1.0, float scale=1.0, float shift=0.0) -> Tensor");
}

torch::Tensor exp_meta(
    const torch::Tensor& x,
    double base,
    double scale,
    double shift)
{
    (void)base;
    (void)scale;
    (void)shift;
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("exp", exp_meta);
}

torch::Tensor exp_npu(
    const torch::Tensor& x,
    double base,
    double scale,
    double shift)
{
    const c10::OptionalDeviceGuard guard(x.device());

    TORCH_CHECK(
        x.scalar_type() == torch::kFloat32 ||
        x.scalar_type() == torch::kHalf ||
        x.scalar_type() == torch::kBFloat16,
        "Exp only supports float16, float32 and bfloat16.");

    auto x_contig = x.contiguous();
    auto y = torch::empty_like(x_contig);

    int64_t totalLength = x_contig.numel();
    if (totalLength == 0) {
        return y;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    int64_t dtypeSize = static_cast<int64_t>(x_contig.element_size());
    int64_t needFloatTemp = (x_contig.scalar_type() == torch::kFloat32) ? 0 : 1;

    int64_t numBlocks = 1;
    int64_t blockLength = totalLength;
    int64_t tileSize = 512;
    std::tie(numBlocks, blockLength, tileSize) =
        calc_exp_tiling_params(totalLength, dtypeSize, needFloatTemp);

    float scaleF = static_cast<float>(scale);
    float shiftF = static_cast<float>(shift);
    float logBaseF = 0.0f;
    int64_t useBase = 0;

    if (base > 0.0) {
        useBase = 1;
        logBaseF = static_cast<float>(std::log(base));
    }

    GM_ADDR x_ptr = reinterpret_cast<GM_ADDR>(x_contig.data_ptr());
    GM_ADDR y_ptr = reinterpret_cast<GM_ADDR>(y.data_ptr());
    uint32_t tileSz = static_cast<uint32_t>(tileSize);

    auto acl_call = [=]() -> int {
        if (x_contig.scalar_type() == torch::kFloat32) {
            launch_exp_kernel_float(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSz,
                scaleF, shiftF, logBaseF, useBase, stream);
        } else if (x_contig.scalar_type() == torch::kHalf) {
            launch_exp_kernel_half(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSz,
                scaleF, shiftF, logBaseF, useBase, stream);
        } else {
            launch_exp_kernel_bfloat16(
                x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSz,
                scaleF, shiftF, logBaseF, useBase, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Exp", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("exp", exp_npu);
}

}
