#include <cstdint>
#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

constexpr static int64_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void exp_kernel_fp32(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift,
    float logBase,
    int64_t useBase)
{
    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    int64_t alignElems = 32 / static_cast<int64_t>(sizeof(T));
    if (alignElems < 1) {
        alignElems = 1;
    }
    if (elementNumPerTile >= alignElems) {
        elementNumPerTile = (elementNumPerTile / alignElems) * alignElems;
    }
    if (elementNumPerTile <= 0) {
        elementNumPerTile = alignElems;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);

    xGm.SetGlobalBuffer((__gm__ T*)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockLength * blockIdx);

    int64_t remaining = currentBlockLength;
    int64_t offset = 0;

    while (remaining > 0) {
        int64_t n = remaining < elementNumPerTile ? remaining : elementNumPerTile;
        int32_t count = static_cast<int32_t>(n);

        AscendC::DataCopyExtParams copyParams{
            1, static_cast<uint32_t>(n * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();

        AscendC::Muls(xLocal, xLocal, scale, count);
        AscendC::Adds(xLocal, xLocal, shift, count);
        if (useBase != 0) {
            AscendC::Muls(xLocal, xLocal, logBase, count);
        }
        AscendC::Exp(yLocal, xLocal, count);

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);

        offset += n;
        remaining -= n;
    }
}

template <typename T>
__global__ __aicore__ void exp_kernel_lowprec(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift,
    float logBase,
    int64_t useBase)
{
    int64_t blockIdx = AscendC::GetBlockIdx();
    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    int64_t alignElems = 32 / static_cast<int64_t>(sizeof(T));
    if (alignElems < 1) {
        alignElems = 1;
    }
    if (elementNumPerTile >= alignElems) {
        elementNumPerTile = (elementNumPerTile / alignElems) * alignElems;
    }
    if (elementNumPerTile <= 0) {
        elementNumPerTile = alignElems;
    }

    uint32_t tmpSize = static_cast<uint32_t>(
        ((elementNumPerTile * static_cast<int64_t>(sizeof(float)) + 31) / 32) * 32);
    if (tmpSize < 32) {
        tmpSize = 32;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::QuePosition::VECOUT> tmpBuf;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpBuf, tmpSize);

    AscendC::LocalTensor<float> tmpLocal = tmpBuf.Get<float>();

    xGm.SetGlobalBuffer((__gm__ T*)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockLength * blockIdx);

    int64_t remaining = currentBlockLength;
    int64_t offset = 0;

    while (remaining > 0) {
        int64_t n = remaining < elementNumPerTile ? remaining : elementNumPerTile;
        int32_t count = static_cast<int32_t>(n);

        AscendC::DataCopyExtParams copyParams{
            1, static_cast<uint32_t>(n * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        AscendC::Cast(tmpLocal, xLocal, AscendC::RoundMode::CAST_NONE, count);
        AscendC::Muls(tmpLocal, tmpLocal, scale, count);
        AscendC::Adds(tmpLocal, tmpLocal, shift, count);
        if (useBase != 0) {
            AscendC::Muls(tmpLocal, tmpLocal, logBase, count);
        }
        AscendC::Exp(tmpLocal, tmpLocal, count);

        auto yLocal = outQueueY.AllocTensor<T>();
        AscendC::Cast(yLocal, tmpLocal, AscendC::RoundMode::CAST_NONE, count);

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);

        offset += n;
        remaining -= n;
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(
    int64_t totalLength,
    int64_t dtypeSize,
    int64_t needFloatTemp)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);

    int64_t coreNum = static_cast<int64_t>(ascendcPlatform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }

    if (totalLength <= 0) {
        return std::make_tuple(int64_t(1), int64_t(0), int64_t(512));
    }

    int64_t blocksByLen = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    int64_t numBlocks = coreNum < blocksByLen ? coreNum : blocksByLen;
    if (numBlocks <= 0) {
        numBlocks = 1;
    }

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    if (dtypeSize <= 0) {
        dtypeSize = 4;
    }

    uint64_t budget = ubSize;
    if (budget == 0) {
        budget = 192 * 1024;
    }

    uint64_t tileBytes;
    if (needFloatTemp != 0 && dtypeSize < 4) {
        tileBytes = budget / 8;
    } else {
        tileBytes = budget / 6;
    }

    tileBytes = (tileBytes / 512) * 512;
    if (tileBytes < 512) {
        tileBytes = 512;
    }
    if (tileBytes > 0xffffffffULL) {
        tileBytes = 0xffffffffULL;
    }

    return std::make_tuple(numBlocks, blockLength, static_cast<int64_t>(tileBytes));
}

extern "C" {

void launch_exp_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift,
    float logBase,
    int64_t useBase,
    void* stream)
{
    if (numBlocks <= 0 || totalLength <= 0) {
        return;
    }
    exp_kernel_fp32<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, scale, shift, logBase, useBase);
}

void launch_exp_kernel_half(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift,
    float logBase,
    int64_t useBase,
    void* stream)
{
    if (numBlocks <= 0 || totalLength <= 0) {
        return;
    }
    exp_kernel_lowprec<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, scale, shift, logBase, useBase);
}

void launch_exp_kernel_bfloat16(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    float scale,
    float shift,
    float logBase,
    int64_t useBase,
    void* stream)
{
    if (numBlocks <= 0 || totalLength <= 0) {
        return;
    }
    exp_kernel_lowprec<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, scale, shift, logBase, useBase);
}

}
