/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGlu host code - kernel launch and tiling (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;

/*
 * SwiGlu: input is split into x0 / x1 along one dim.
 * Flattened view: outer rows, each output row has rowLen elements.
 *   x0 of row r: input[r * 2 * rowLen + i]
 *   x1 of row r: input[r * 2 * rowLen + rowLen + i]
 *   out of row r: output[r * rowLen + i]
 * Two data paths:
 *  - rowLen >= tileElems: 1D tiled copies inside a row.
 *  - rowLen <  tileElems: batch many rows into one 2D strided DataCopyPad
 *    (blockCount rows, blockLen = rowLen elems, srcStride skips the x1 half),
 *    avoiding per-row tiny copies for small split dims.
 */
template <typename T>
__global__ __aicore__ void swiglu_kernel(GM_ADDR input, GM_ADDR output,
                                         int64_t outTotal, int64_t rowLen,
                                         int64_t blockLen, uint32_t tileElems)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t start = blockIdx * blockLen;
    if (start >= outTotal) { return; }
    int64_t end = start + blockLen;
    if (end > outTotal) { end = outTotal; }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> inGm;
    AscendC::GlobalTensor<T> outGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    uint32_t tileBytes = tileElems * static_cast<uint32_t>(sizeof(T));
    pipe.InitBuffer(inQueueX0, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(inQueueX1, PIPELINE_DEPTH, tileBytes);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileBytes);
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufF0;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufF1;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufF2;
    pipe.InitBuffer(bufF0, tileElems * static_cast<uint32_t>(sizeof(float)));
    pipe.InitBuffer(bufF1, tileElems * static_cast<uint32_t>(sizeof(float)));
    pipe.InitBuffer(bufF2, tileElems * static_cast<uint32_t>(sizeof(float)));

    inGm.SetGlobalBuffer((__gm__ T *)input);
    outGm.SetGlobalBuffer((__gm__ T *)output);

    bool grouped = (rowLen > 0) && (rowLen < static_cast<int64_t>(tileElems)) &&
                   (start % rowLen == 0) && ((end - start) % rowLen == 0);

    if (grouped) {
        int64_t g = static_cast<int64_t>(tileElems) / rowLen;
        if (g > 4095) { g = 4095; }
        if (g < 1) { g = 1; }
        int64_t rowsTotal = (end - start) / rowLen;
        int64_t row0 = start / rowLen;
        for (int64_t rr = 0; rr < rowsTotal; rr += g) {
            int64_t cntRows = rowsTotal - rr;
            if (cntRows > g) { cntRows = g; }
            uint32_t n = static_cast<uint32_t>(cntRows * rowLen);
            uint32_t blockBytes = static_cast<uint32_t>(rowLen) * static_cast<uint32_t>(sizeof(T));
            AscendC::DataCopyExtParams cpIn{static_cast<uint16_t>(cntRows), blockBytes, blockBytes, 0, 0};
            AscendC::DataCopyExtParams cpOut{static_cast<uint16_t>(cntRows), blockBytes, 0, 0, 0};
            AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
            int64_t x0Base = (row0 + rr) * 2 * rowLen;

            auto x0Local = inQueueX0.AllocTensor<T>();
            auto x1Local = inQueueX1.AllocTensor<T>();
            AscendC::DataCopyPad(x0Local, inGm[x0Base], cpIn, padParams);
            AscendC::DataCopyPad(x1Local, inGm[x0Base + rowLen], cpIn, padParams);
            inQueueX0.EnQue(x0Local);
            inQueueX1.EnQue(x1Local);
            x0Local = inQueueX0.DeQue<T>();
            x1Local = inQueueX1.DeQue<T>();

            auto outLocal = outQueue.AllocTensor<T>();
            if constexpr (std::is_same<T, float>::value) {
                auto f2 = bufF2.Get<float>();
                AscendC::Sigmoid(f2, x0Local, n);
                AscendC::Mul(outLocal, x0Local, f2, n);
                AscendC::Mul(outLocal, outLocal, x1Local, n);
            } else {
                auto f0 = bufF0.Get<float>();
                auto f1 = bufF1.Get<float>();
                auto f2 = bufF2.Get<float>();
                AscendC::Cast(f0, x0Local, AscendC::RoundMode::CAST_NONE, n);
                AscendC::Cast(f1, x1Local, AscendC::RoundMode::CAST_NONE, n);
                AscendC::Sigmoid(f2, f0, n);
                AscendC::Mul(f0, f0, f2, n);
                AscendC::Mul(f0, f0, f1, n);
                if constexpr (std::is_same<T, half>::value) {
                    AscendC::Cast(outLocal, f0, AscendC::RoundMode::CAST_NONE, n);
                } else {
                    AscendC::Cast(outLocal, f0, AscendC::RoundMode::CAST_RINT, n);
                }
            }
            outQueue.EnQue(outLocal);
            inQueueX0.FreeTensor(x0Local);
            inQueueX1.FreeTensor(x1Local);
            outLocal = outQueue.DeQue<T>();
            AscendC::DataCopyPad(outGm[start + rr * rowLen], outLocal, cpOut, padParams);
            outQueue.FreeTensor(outLocal);
        }
        return;
    }

    // 1D path: rowLen >= tileElems (or unaligned fallback)
    int64_t n = start;
    while (n < end) {
        int64_t row = n / rowLen;
        int64_t i0 = n - row * rowLen;
        int64_t seg = rowLen - i0;
        if (seg > end - n) { seg = end - n; }
        int64_t x0Base = row * 2 * rowLen + i0;
        int64_t x1Base = x0Base + rowLen;
        int64_t outBase = n;

        for (int64_t t = 0; t < seg; t += static_cast<int64_t>(tileElems)) {
            int64_t cnt = seg - t;
            if (cnt > static_cast<int64_t>(tileElems)) { cnt = static_cast<int64_t>(tileElems); }
            uint32_t cntU = static_cast<uint32_t>(cnt);
            uint32_t copyBytes = cntU * static_cast<uint32_t>(sizeof(T));
            AscendC::DataCopyExtParams copyParams{1, copyBytes, 0, 0, 0};
            AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

            auto x0Local = inQueueX0.AllocTensor<T>();
            auto x1Local = inQueueX1.AllocTensor<T>();
            AscendC::DataCopyPad(x0Local, inGm[x0Base + t], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, inGm[x1Base + t], copyParams, padParams);
            inQueueX0.EnQue(x0Local);
            inQueueX1.EnQue(x1Local);
            x0Local = inQueueX0.DeQue<T>();
            x1Local = inQueueX1.DeQue<T>();

            auto outLocal = outQueue.AllocTensor<T>();
            if constexpr (std::is_same<T, float>::value) {
                auto f2 = bufF2.Get<float>();
                AscendC::Sigmoid(f2, x0Local, cntU);
                AscendC::Mul(outLocal, x0Local, f2, cntU);
                AscendC::Mul(outLocal, outLocal, x1Local, cntU);
            } else {
                auto f0 = bufF0.Get<float>();
                auto f1 = bufF1.Get<float>();
                auto f2 = bufF2.Get<float>();
                AscendC::Cast(f0, x0Local, AscendC::RoundMode::CAST_NONE, cntU);
                AscendC::Cast(f1, x1Local, AscendC::RoundMode::CAST_NONE, cntU);
                AscendC::Sigmoid(f2, f0, cntU);
                AscendC::Mul(f0, f0, f2, cntU);
                AscendC::Mul(f0, f0, f1, cntU);
                if constexpr (std::is_same<T, half>::value) {
                    AscendC::Cast(outLocal, f0, AscendC::RoundMode::CAST_NONE, cntU);
                } else {
                    AscendC::Cast(outLocal, f0, AscendC::RoundMode::CAST_RINT, cntU);
                }
            }
            outQueue.EnQue(outLocal);
            inQueueX0.FreeTensor(x0Local);
            inQueueX1.FreeTensor(x1Local);
            outLocal = outQueue.DeQue<T>();
            AscendC::DataCopyPad(outGm[outBase + t], outLocal, copyParams);
            outQueue.FreeTensor(outLocal);
        }
        n += seg;
    }
}

// Tiling function
std::tuple<int64_t, int64_t, uint32_t> calc_swiglu_tiling_params(int64_t outTotal, int64_t rowLen, int64_t dtypeSize)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr static int64_t MAX_TILE_ELEMS = 32768;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) { coreNum = 1; }

    int64_t numBlocks = (outTotal + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks < 1) { numBlocks = 1; }
    if (numBlocks > coreNum) { numBlocks = coreNum; }
    int64_t blockLen = (outTotal + numBlocks - 1) / numBlocks;
    if (blockLen < 1) { blockLen = 1; }

    // Align blockLen to whole rows so the grouped (small rowLen) path starts on a row boundary.
    if (rowLen > 1 && rowLen < MAX_TILE_ELEMS) {
        blockLen = ((blockLen + rowLen - 1) / rowLen) * rowLen;
        numBlocks = (outTotal + blockLen - 1) / blockLen;
        if (numBlocks < 1) { numBlocks = 1; }
    }

    // storage per tile element: 3 queues * depth 2 * dtypeSize + 3 float buffers * 4B
    int64_t bytesPerElem = 6 * dtypeSize + 3 * static_cast<int64_t>(sizeof(float));
    int64_t budget = (static_cast<int64_t>(ubSize) / 10) * 8;
    if (budget < 8192) { budget = 8192; }
    int64_t tile = budget / bytesPerElem;
    if (tile > MAX_TILE_ELEMS) { tile = MAX_TILE_ELEMS; }
    tile = (tile / 128) * 128;
    if (tile < 128) { tile = 128; }
    return std::make_tuple(numBlocks, blockLen, static_cast<uint32_t>(tile));
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_swiglu_kernel_float(GM_ADDR input, GM_ADDR output, int64_t outTotal, int64_t rowLen,
                                int64_t numBlocks, int64_t blockLen, uint32_t tileElems, void *stream)
{
    swiglu_kernel<float><<<numBlocks, nullptr, stream>>>(input, output, outTotal, rowLen, blockLen, tileElems);
}

void launch_swiglu_kernel_half(GM_ADDR input, GM_ADDR output, int64_t outTotal, int64_t rowLen,
                               int64_t numBlocks, int64_t blockLen, uint32_t tileElems, void *stream)
{
    swiglu_kernel<half><<<numBlocks, nullptr, stream>>>(input, output, outTotal, rowLen, blockLen, tileElems);
}

void launch_swiglu_kernel_bfloat16(GM_ADDR input, GM_ADDR output, int64_t outTotal, int64_t rowLen,
                                   int64_t numBlocks, int64_t blockLen, uint32_t tileElems, void *stream)
{
    swiglu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(input, output, outTotal, rowLen, blockLen, tileElems);
}

}
