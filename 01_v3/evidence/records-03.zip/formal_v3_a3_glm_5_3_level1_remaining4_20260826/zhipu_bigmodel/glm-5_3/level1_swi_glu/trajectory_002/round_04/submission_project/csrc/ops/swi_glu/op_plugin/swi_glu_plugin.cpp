/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_plugin.cpp
 * \brief SwiGlu API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

static int64_t swiglu_normalize_dim(int64_t dim, int64_t rank)
{
    if (dim < 0) { dim += rank; }
    return dim;
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    int64_t rank = input.dim();
    TORCH_CHECK(rank >= 1, "input must have at least 1 dimension");
    int64_t d = swiglu_normalize_dim(dim, rank);
    TORCH_CHECK(d >= 0 && d < rank, "dim is out of range for swi_glu");
    TORCH_CHECK(input.size(d) % 2 == 0, "swi_glu requires the size of the split dim to be even");
    auto outShape = input.sizes().vec();
    outShape[d] /= 2;
    return torch::empty(outShape, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto x = input.contiguous();
    auto output = swi_glu_meta(x, dim);

    int64_t rank = x.dim();
    int64_t d = swiglu_normalize_dim(dim, rank);
    int64_t outer = 1;
    for (int64_t i = 0; i < d; ++i) { outer *= x.size(i); }
    int64_t inner = 1;
    for (int64_t i = d + 1; i < rank; ++i) { inner *= x.size(i); }
    int64_t rowLen = (x.size(d) / 2) * inner;
    int64_t outTotal = outer * rowLen;
    if (outTotal == 0) { return output; }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t dtypeSize = static_cast<int64_t>(x.element_size());
    int64_t numBlocks = 1;
    int64_t blockLen = 1;
    uint32_t tileElems = 128;
    std::tie(numBlocks, blockLen, tileElems) = calc_swiglu_tiling_params(outTotal, dtypeSize);

    auto inPtr = (GM_ADDR)x.data_ptr();
    auto outPtr = (GM_ADDR)output.data_ptr();

    auto acl_call = [=]() -> int {
        if (x.scalar_type() == torch::kFloat32) {
            launch_swiglu_kernel_float(inPtr, outPtr, outTotal, rowLen, numBlocks, blockLen, tileElems, stream);
        } else if (x.scalar_type() == torch::kFloat16) {
            launch_swiglu_kernel_half(inPtr, outPtr, outTotal, rowLen, numBlocks, blockLen, tileElems, stream);
        } else if (x.scalar_type() == torch::kBFloat16) {
            launch_swiglu_kernel_bfloat16(inPtr, outPtr, outTotal, rowLen, numBlocks, blockLen, tileElems, stream);
        } else {
            TORCH_CHECK(false, "swi_glu: unsupported dtype");
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return output;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
