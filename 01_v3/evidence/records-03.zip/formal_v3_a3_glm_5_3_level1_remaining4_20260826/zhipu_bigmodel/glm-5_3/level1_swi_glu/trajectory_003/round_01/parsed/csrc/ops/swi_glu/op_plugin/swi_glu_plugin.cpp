/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_plugin.cpp
 * \brief SwiGlu API layer - torch bindings (compiled with g++)
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/swi_glu_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("swi_glu(Tensor input, int dim=-1) -> Tensor");
}

torch::Tensor swi_glu_meta(const torch::Tensor &input, int64_t dim)
{
    const auto sizes = input.sizes();
    const int64_t rank = static_cast<int64_t>(sizes.size());
    TORCH_CHECK(rank >= 1, "input must have at least one dimension");
    int64_t d = dim;
    if (d < 0) {
        d += rank;
    }
    TORCH_CHECK(d >= 0 && d < rank, "dim is out of range");
    TORCH_CHECK(sizes[d] % 2 == 0, "size along the split dim must be even");
    TORCH_CHECK(input.scalar_type() == torch::kFloat32 ||
                input.scalar_type() == torch::kFloat16 ||
                input.scalar_type() == torch::kBFloat16,
                "swi_glu supports float32, float16 and bfloat16");
    auto outSizes = sizes.vec();
    outSizes[d] /= 2;
    return torch::empty(outSizes, input.options());
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("swi_glu", swi_glu_meta);
}

torch::Tensor swi_glu_npu(const torch::Tensor &input, int64_t dim)
{
    const c10::OptionalDeviceGuard guard(input.device());
    auto x = input.contiguous();
    auto out = swi_glu_meta(x, dim);

    const auto sizes = x.sizes();
    const int64_t rank = static_cast<int64_t>(sizes.size());
    int64_t d = dim;
    if (d < 0) {
        d += rank;
    }
    int64_t outer = 1;
    for (int64_t i = 0; i < d; ++i) {
        outer *= sizes[i];
    }
    int64_t inner = 1;
    for (int64_t i = d + 1; i < rank; ++i) {
        inner *= sizes[i];
    }
    const int64_t segLen = (sizes[d] / 2) * inner;
    const int64_t totalOut = outer * segLen;
    if (totalOut == 0) {
        return out;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t numBlocks = 1;
    int64_t blockLength = 1;
    int64_t tileElems = 1;
    std::tie(numBlocks, blockLength, tileElems) =
        calc_swiglu_tiling_params(totalOut, static_cast<int64_t>(x.element_size()));

    auto x_ptr = (GM_ADDR)x.data_ptr();
    auto y_ptr = (GM_ADDR)out.data_ptr();
    const auto dtype = x.scalar_type();

    auto acl_call = [=]() -> int {
        if (dtype == torch::kFloat32) {
            launch_swiglu_kernel_float(x_ptr, y_ptr, totalOut, segLen, numBlocks, blockLength,
                                       static_cast<uint32_t>(tileElems), stream);
        } else if (dtype == torch::kFloat16) {
            launch_swiglu_kernel_half(x_ptr, y_ptr, totalOut, segLen, numBlocks, blockLength,
                                      static_cast<uint32_t>(tileElems), stream);
        } else if (dtype == torch::kBFloat16) {
            launch_swiglu_kernel_bfloat16(x_ptr, y_ptr, totalOut, segLen, numBlocks, blockLength,
                                          static_cast<uint32_t>(tileElems), stream);
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("SwiGlu", acl_call);
    return out;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("swi_glu", swi_glu_npu);
}

} // namespace cann_bench
