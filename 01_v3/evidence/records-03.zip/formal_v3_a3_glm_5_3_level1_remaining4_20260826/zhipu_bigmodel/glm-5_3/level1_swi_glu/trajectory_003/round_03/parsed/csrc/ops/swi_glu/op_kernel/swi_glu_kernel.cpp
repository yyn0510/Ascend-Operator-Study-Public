/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGlu host + kernel code (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;
constexpr static int64_t MAX_TILE_BYTES = 65536;
constexpr static int64_t MAX_COPY_BLOCK_COUNT = 4095;
constexpr static int64_t COPY_ALIGN_BYTES = 32;

/*
 * Layout: input is viewed as [outer, 2*h, inner] where h = size(dim)/2.
 * x0 = input[:, 0:h, :], x1 = input[:, h:2h, :].
 * Output is [outer, h, inner] contiguous.
 * For output flat index g: seg = g / (h*inner), off = g % (h*inner);
 *   x0 element at (seg*2 + 0)*segLen + off, x1 at (seg*2 + 1)*segLen + off.
 * Within one segment all three streams are contiguous. When segLen*dtypeSize
 * is 32-byte aligned, multiple consecutive segments are gathered with one
 * strided multi-block DataCopyPad (hardware requires 32B-aligned blockLen for
 * blockCount > 1). Otherwise the kernel falls back to single-block copies
 * that never cross a segment boundary.
 */
template <typename T>
__global__ __aicore__ void swi_glu_kernel(GM_ADDR x, GM_ADDR y,
                                           int64_t totalOut, int64_t segLen,
                                           int64_t blockLength, uint32_t tileElems)
{
    if (totalOut <= 0 || segLen <= 0 || tileElems == 0 || blockLength <= 0) {
        return;
    }
    int64_t start = static_cast<int64_t>(AscendC::GetBlockIdx()) * blockLength;
    if (start >= totalOut) {
        return;
    }
    int64_t end = start + blockLength;
    if (end > totalOut) {
        end = totalOut;
    }

    const int64_t esize = static_cast<int64_t>(sizeof(T));
    const int64_t tile = static_cast<int64_t>(tileElems);
    const bool segAligned = ((segLen * esize) % COPY_ALIGN_BYTES) == 0;

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQue;
    pipe.InitBuffer(inQueX0, PIPELINE_DEPTH, static_cast<uint32_t>(tileElems * sizeof(T)));
    pipe.InitBuffer(inQueX1, PIPELINE_DEPTH, static_cast<uint32_t>(tileElems * sizeof(T)));
    pipe.InitBuffer(outQue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElems * sizeof(T)));

    AscendC::TBuf<AscendC::TPosition::VECCALC> f0Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> f1Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> sigBuf;
    if constexpr (std::is_same<T, float>::value) {
        pipe.InitBuffer(sigBuf, static_cast<uint32_t>(tileElems * sizeof(float)));
    } else {
        pipe.InitBuffer(f0Buf, static_cast<uint32_t>(tileElems * sizeof(float)));
        pipe.InitBuffer(f1Buf, static_cast<uint32_t>(tileElems * sizeof(float)));
        pipe.InitBuffer(sigBuf, static_cast<uint32_t>(tileElems * sizeof(float)));
    }

    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T *)x);
    yGm.SetGlobalBuffer((__gm__ T *)y);

    int64_t s = start;
    while (s < end) {
        const int64_t segIdx = s / segLen;
        const int64_t segOff = s - segIdx * segLen;
        int64_t len = 0;
        int64_t blockCount = 1;
        if (segAligned && segOff == 0 && segLen <= tile) {
            int64_t fullSegs = (end - s) / segLen;
            int64_t maxSegs = tile / segLen;
            if (maxSegs > MAX_COPY_BLOCK_COUNT) {
                maxSegs = MAX_COPY_BLOCK_COUNT;
            }
            if (fullSegs > maxSegs) {
                fullSegs = maxSegs;
            }
            if (fullSegs >= 1) {
                len = fullSegs * segLen;
                blockCount = fullSegs;
            }
        }
        if (len <= 0) {
            len = end - s;
            if (len > segLen - segOff) {
                len = segLen - segOff;
            }
            if (len > tile) {
                len = tile;
            }
            blockCount = 1;
        }

        auto x0Local = inQueX0.AllocTensor<T>();
        auto x1Local = inQueX1.AllocTensor<T>();
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        if (blockCount > 1) {
            AscendC::DataCopyExtParams copyParams{
                static_cast<uint16_t>(blockCount),
                static_cast<uint32_t>(segLen * esize),
                static_cast<uint32_t>(segLen * esize), 0, 0};
            AscendC::DataCopyPad(x0Local, xGm[segIdx * 2 * segLen], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, xGm[segIdx * 2 * segLen + segLen], copyParams, padParams);
        } else {
            AscendC::DataCopyExtParams copyParams{
                1, static_cast<uint32_t>(len * esize), 0, 0, 0};
            AscendC::DataCopyPad(x0Local, xGm[segIdx * 2 * segLen + segOff], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, xGm[segIdx * 2 * segLen + segLen + segOff], copyParams, padParams);
        }
        inQueX0.EnQue(x0Local);
        inQueX1.EnQue(x1Local);
        x0Local = inQueX0.DeQue<T>();
        x1Local = inQueX1.DeQue<T>();

        auto outLocal = outQue.AllocTensor<T>();
        const uint32_t n = static_cast<uint32_t>(len);
        auto sigLocal = sigBuf.Get<float>();
        if constexpr (std::is_same<T, float>::value) {
            AscendC::Sigmoid(sigLocal, x0Local, n);
            AscendC::Mul(outLocal, x0Local, sigLocal, n);
            AscendC::Mul(outLocal, outLocal, x1Local, n);
        } else {
            auto f0Local = f0Buf.Get<float>();
            auto f1Local = f1Buf.Get<float>();
            AscendC::Cast(f0Local, x0Local, AscendC::RoundMode::CAST_NONE, n);
            AscendC::Cast(f1Local, x1Local, AscendC::RoundMode::CAST_NONE, n);
            AscendC::Sigmoid(sigLocal, f0Local, n);
            AscendC::Mul(f0Local, f0Local, sigLocal, n);
            AscendC::Mul(f0Local, f0Local, f1Local, n);
            AscendC::Cast(outLocal, f0Local, AscendC::RoundMode::CAST_ROUND, n);
        }
        outQue.EnQue(outLocal);
        inQueX0.FreeTensor(x0Local);
        inQueX1.FreeTensor(x1Local);
        outLocal = outQue.DeQue<T>();
        AscendC::DataCopyExtParams outParams{1, static_cast<uint32_t>(len * esize), 0, 0, 0};
        AscendC::DataCopyPad(yGm[s], outLocal, outParams);
        outQue.FreeTensor(outLocal);
        s += len;
    }
}

// Tiling: returns (numBlocks, blockLength, tileElems)
std::tuple<int64_t, int64_t, int64_t> calc_swiglu_tiling_params(int64_t totalOut, int64_t elemBytes)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = (totalOut + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    int64_t blockLength = (totalOut + numBlocks - 1) / numBlocks;

    // UB cost per tile element:
    //   queues: 3 queues x depth 2 x elemBytes
    //   fp32 scratch: 3 x 4 bytes for 16-bit dtypes, 1 x 4 bytes for fp32
    int64_t bytesPerElem;
    if (elemBytes >= 4) {
        bytesPerElem = 6 * 4 + 4;
    } else {
        bytesPerElem = 6 * elemBytes + 12;
    }
    int64_t budget = static_cast<int64_t>(ubSize) * 9 / 10;
    if (budget < 8192) {
        budget = 8192;
    }
    int64_t tileElems = budget / bytesPerElem;
    const int64_t maxElems = MAX_TILE_BYTES / elemBytes;
    if (tileElems > maxElems) {
        tileElems = maxElems;
    }
    if (tileElems < 64) {
        tileElems = 64;
    }
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

extern "C" {

void launch_swiglu_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalOut, int64_t segLen,
                                int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalOut, segLen, blockLength, tileElems);
}

void launch_swiglu_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalOut, int64_t segLen,
                               int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalOut, segLen, blockLength, tileElems);
}

void launch_swiglu_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalOut, int64_t segLen,
                                   int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalOut, segLen, blockLength, tileElems);
}

}
