/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file swi_glu_kernel.cpp
 * \brief SwiGlu host + kernel code (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;
constexpr static int64_t MAX_TILE_BYTES = 65536;
constexpr static int64_t MAX_COPY_BLOCK_COUNT = 4095;
constexpr static int64_t COPY_ALIGN_BYTES = 32;

/*
 * Layout: input is viewed as [outer, 2*h, inner] where h = size(dim)/2.
 * x0 = input[:, 0:h, :], x1 = input[:, h:2h, :]; output is [outer, h, inner].
 * For output flat index g: seg = g / (h*inner), off = g % (h*inner);
 * x0 element at seg*2*segLen + off, x1 at seg*2*segLen + segLen + off.
 * When segLen*esize is 32B aligned, consecutive segments are gathered with one
 * strided multi-block DataCopyPad; otherwise single-block copies that never
 * cross a segment boundary are used.
 */
template <typename T>
__global__ __aicore__ void swi_glu_kernel(GM_ADDR x, GM_ADDR y,
                                           int64_t totalOut, int64_t segLen,
                                           int64_t blockLength, uint32_t tileElems)
{
    if (totalOut <= 0 || segLen <= 0 || tileElems == 0 || blockLength <= 0) {
        return;
    }
    int64_t start = static_cast<int64_t>(AscendC::GetBlockIdx()) * blockLength;
    if (start >= totalOut) {
        return;
    }
    int64_t end = start + blockLength;
    if (end > totalOut) {
        end = totalOut;
    }

    const int64_t esize = static_cast<int64_t>(sizeof(T));
    const int64_t tile = static_cast<int64_t>(tileElems);
    const bool segAligned = ((segLen * esize) % COPY_ALIGN_BYTES) == 0;

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueX0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueX1;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQue;
    pipe.InitBuffer(inQueX0, PIPELINE_DEPTH, static_cast<uint32_t>(tileElems * sizeof(T)));
    pipe.InitBuffer(inQueX1, PIPELINE_DEPTH, static_cast<uint32_t>(tileElems * sizeof(T)));
    pipe.InitBuffer(outQue, PIPELINE_DEPTH, static_cast<uint32_t>(tileElems * sizeof(T)));

    AscendC::TBuf<AscendC::TPosition::VECCALC> f0Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> f1Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> sigBuf;
    if constexpr (!std::is_same<T, float>::value) {
        pipe.InitBuffer(f0Buf, static_cast<uint32_t>(tileElems * sizeof(float)));
        pipe.InitBuffer(f1Buf, static_cast<uint32_t>(tileElems * sizeof(float)));
        pipe.InitBuffer(sigBuf, static_cast<uint32_t>(tileElems * sizeof(float)));
    }

    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T *)x);
    yGm.SetGlobalBuffer((__gm__ T *)y);

    int64_t s = start;
    while (s < end) {
        const int64_t segIdx = s / segLen;
        const int64_t segOff = s - segIdx * segLen;
        int64_t len = 0;
        int64_t blockCount = 1;
        if (segAligned && segOff == 0 && segLen <= tile) {
            int64_t fullSegs = (end - s) / segLen;
            int64_t maxSegs = tile / segLen;
            if (maxSegs > MAX_COPY_BLOCK_COUNT) {
                maxSegs = MAX_COPY_BLOCK_COUNT;
            }
            if (fullSegs > maxSegs) {
                fullSegs = maxSegs;
            }
            if (fullSegs >= 1) {
                len = fullSegs * segLen;
                blockCount = fullSegs;
            }
        }
        if (len <= 0) {
            len = end - s;
            if (len > segLen - segOff) {
                len = segLen - segOff;
            }
            if (len > tile) {
                len = tile;
            }
            blockCount = 1;
        }

        auto x0Local = inQueX0.AllocTensor<T>();
        auto x1Local = inQueX1.AllocTensor<T>();
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        if (blockCount > 1) {
            AscendC::DataCopyExtParams copyParams{
                static_cast<uint16_t>(blockCount),
                static_cast<uint32_t>(segLen * esize),
                static_cast<uint32_t>(segLen * esize), 0, 0};
            AscendC::DataCopyPad(x0Local, xGm[segIdx * 2 * segLen], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, xGm[segIdx * 2 * segLen + segLen], copyParams, padParams);
        } else {
            AscendC::DataCopyExtParams copyParams{
                1, static_cast<uint32_t>(len * esize), 0, 0, 0};
            AscendC::DataCopyPad(x0Local, xGm[segIdx * 2 * segLen + segOff], copyParams, padParams);
            AscendC::DataCopyPad(x1Local, xGm[segIdx * 2 * segLen + segLen + segOff], copyParams, padParams);
        }
        inQueX0.EnQue(x0Local);
        inQueX1.EnQue(x1Local);
        x0Local = inQueX0.DeQue<T>();
        x1Local = inQueX1.DeQue<T>();

        auto outLocal = outQue.AllocTensor<T>();
        const uint32_t n = static_cast<uint32_t>(len);
        if constexpr (std::is_same<T, float>::value) {
            AscendC::Sigmoid(outLocal, x0Local, n);
            AscendC::Mul(outLocal, x0Local, outLocal, n);
            AscendC::Mul(outLocal, outLocal, x1Local, n);
        } else {
            auto f0Local = f0Buf.Get<float>();
            auto f1Local = f1Buf.Get<float>();
            auto sigLocal = sigBuf.Get<float>();
            AscendC::Cast(f0Local, x0Local, AscendC::RoundMode::CAST_NONE, n);
            AscendC::Cast(f1Local, x1Local, AscendC::RoundMode::CAST_NONE, n);
            AscendC::Sigmoid(sigLocal, f0Local, n);
            AscendC::Mul(f0Local, f0Local, sigLocal, n);
            AscendC::Mul(f0Local, f0Local, f1Local, n);
            AscendC::Cast(outLocal, f0Local, AscendC::RoundMode::CAST_ROUND, n);
        }
        outQue.EnQue(outLocal);
        inQueX0.FreeTensor(x0Local);
        inQueX1.FreeTensor(x1Local);
        outLocal = outQue.DeQue<T>();
        AscendC::DataCopyExtParams outParams{1, static_cast<uint32_t>(len * esize), 0, 0, 0};
        AscendC::DataCopyPad(yGm[s], outLocal, outParams);
        outQue.FreeTensor(outLocal);
        s += len;
    }
}

/*
 * Fast path for bfloat16 input with segLen == 1 (split dim of size 2, last dim).
 * Each output i pairs input elements (2i, 2i+1). Read the input as int32 words:
 *   R0[i] = {A[2i] low16, A[2i+1] high16}
 *   Rm[i] = int32 at byte offset 4i-2 = {A[2i-1] low16, A[2i] high16}
 * Then x1_i = high16(R0[i]) and x0_i = high16(Rm[i]); AND with 0xFFFF0000 keeps
 * the bf16 bits in the top half of an fp32 word, which is exactly the fp32
 * promotion of that bf16 value (bit-exact, preserves inf/nan). All GM accesses
 * are large contiguous copies.
 */
__global__ __aicore__ void swiglu_s1_bf16_kernel(GM_ADDR x, GM_ADDR y,
                                                 int64_t totalOut, int64_t blockLength,
                                                 uint32_t tileElems)
{
    if (totalOut <= 0 || blockLength <= 0 || tileElems == 0) {
        return;
    }
    int64_t start = static_cast<int64_t>(AscendC::GetBlockIdx()) * blockLength;
    if (start >= totalOut) {
        return;
    }
    int64_t end = start + blockLength;
    if (end > totalOut) {
        end = totalOut;
    }

    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> qR0;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> qRm;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> qOut;
    pipe.InitBuffer(qR0, PIPELINE_DEPTH, static_cast<uint32_t>(tileElems * sizeof(int32_t)));
    pipe.InitBuffer(qRm, PIPELINE_DEPTH, static_cast<uint32_t>(tileElems * sizeof(int32_t)));
    pipe.InitBuffer(qOut, PIPELINE_DEPTH, static_cast<uint32_t>(tileElems * sizeof(bfloat16_t)));
    AscendC::TBuf<AscendC::TPosition::VECCALC> aBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> cBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> mBuf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> e0Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> e1Buf;
    AscendC::TBuf<AscendC::TPosition::VECCALC> eoBuf;
    pipe.InitBuffer(aBuf, static_cast<uint32_t>(tileElems * sizeof(float)));
    pipe.InitBuffer(bBuf, static_cast<uint32_t>(tileElems * sizeof(float)));
    pipe.InitBuffer(cBuf, static_cast<uint32_t>(tileElems * sizeof(float)));
    pipe.InitBuffer(mBuf, static_cast<uint32_t>(tileElems * sizeof(int32_t)));
    pipe.InitBuffer(e0Buf, 64);
    pipe.InitBuffer(e1Buf, 64);
    pipe.InitBuffer(eoBuf, 64);

    AscendC::GlobalTensor<bfloat16_t> xGm16;
    AscendC::GlobalTensor<bfloat16_t> yGm16;
    xGm16.SetGlobalBuffer((__gm__ bfloat16_t *)x);
    yGm16.SetGlobalBuffer((__gm__ bfloat16_t *)y);
    AscendC::GlobalTensor<int32_t> r0Gm;
    AscendC::GlobalTensor<int32_t> rmGm;
    r0Gm.SetGlobalBuffer((__gm__ int32_t *)x);
    rmGm.SetGlobalBuffer((__gm__ int32_t *)((__gm__ int16_t *)x - 1));

    auto maskLocal = mBuf.Get<int32_t>();
    AscendC::Duplicate(maskLocal, static_cast<int32_t>(-65536), static_cast<int32_t>(tileElems));

    AscendC::DataCopyPadExtParams<bfloat16_t> padB{false, 0, 0, 0};
    AscendC::DataCopyPadExtParams<int32_t> padI{false, 0, 0, 0};

    if (start == 0) {
        auto x0h = e0Buf.Get<bfloat16_t>();
        auto x1h = e1Buf.Get<bfloat16_t>();
        auto outh = eoBuf.Get<bfloat16_t>();
        AscendC::DataCopyExtParams cp0{1, 2, 0, 0, 0};
        AscendC::DataCopyPad(x0h, xGm16[0], cp0, padB);
        AscendC::DataCopyPad(x1h, xGm16[1], cp0, padB);
        auto af0 = aBuf.Get<float>();
        auto bf0 = bBuf.Get<float>();
        auto cf0 = cBuf.Get<float>();
        AscendC::Cast(af0, x0h, AscendC::RoundMode::CAST_NONE, 1);
        AscendC::Cast(bf0, x1h, AscendC::RoundMode::CAST_NONE, 1);
        AscendC::Sigmoid(cf0, af0, 1);
        AscendC::Mul(af0, af0, cf0, 1);
        AscendC::Mul(af0, af0, bf0, 1);
        AscendC::Cast(outh, af0, AscendC::RoundMode::CAST_ROUND, 1);
        AscendC::DataCopyPad(yGm16[0], outh, cp0);
    }

    int64_t i = (start == 0) ? 1 : start;
    const int64_t tile = static_cast<int64_t>(tileElems);
    while (i < end) {
        int64_t n64 = end - i;
        if (n64 > tile) {
            n64 = tile;
        }
        const uint32_t n = static_cast<uint32_t>(n64);
        auto r0Local = qR0.AllocTensor<int32_t>();
        auto rmLocal = qRm.AllocTensor<int32_t>();
        AscendC::DataCopyExtParams cp{1, static_cast<uint32_t>(n64 * 4), 0, 0, 0};
        AscendC::DataCopyPad(r0Local, r0Gm[i], cp, padI);
        AscendC::DataCopyPad(rmLocal, rmGm[i], cp, padI);
        qR0.EnQue(r0Local);
        qRm.EnQue(rmLocal);
        r0Local = qR0.DeQue<int32_t>();
        rmLocal = qRm.DeQue<int32_t>();

        auto outLocal = qOut.AllocTensor<bfloat16_t>();
        auto a32 = aBuf.Get<int32_t>();
        auto b32 = bBuf.Get<int32_t>();
        AscendC::And(a32, rmLocal, maskLocal, static_cast<int32_t>(n));
        AscendC::And(b32, r0Local, maskLocal, static_cast<int32_t>(n));
        auto af = aBuf.Get<float>();
        auto bf = bBuf.Get<float>();
        auto cf = cBuf.Get<float>();
        AscendC::Sigmoid(cf, af, n);
        AscendC::Mul(af, af, cf, n);
        AscendC::Mul(af, af, bf, n);
        AscendC::Cast(outLocal, af, AscendC::RoundMode::CAST_ROUND, n);
        qOut.EnQue(outLocal);
        qR0.FreeTensor(r0Local);
        qRm.FreeTensor(rmLocal);
        outLocal = qOut.DeQue<bfloat16_t>();
        AscendC::DataCopyExtParams op{1, static_cast<uint32_t>(n64 * 2), 0, 0, 0};
        AscendC::DataCopyPad(yGm16[i], outLocal, op);
        qOut.FreeTensor(outLocal);
        i += n64;
    }
}

// Tiling: returns (numBlocks, blockLength, tileElems)
std::tuple<int64_t, int64_t, int64_t> calc_swiglu_tiling_params(int64_t totalOut, int64_t elemBytes)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = (totalOut + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    int64_t blockLength = (totalOut + numBlocks - 1) / numBlocks;

    // UB cost per tile element:
    //   queues: 3 queues x depth 2 x elemBytes
    //   fp32 scratch: 3 x 4 bytes for 16-bit dtypes (fp32 reuses the out buffer)
    int64_t bytesPerElem;
    if (elemBytes >= 4) {
        bytesPerElem = 6 * 4;
    } else {
        bytesPerElem = 6 * elemBytes + 12;
    }
    int64_t budget = static_cast<int64_t>(ubSize) * 9 / 10;
    if (budget < 8192) {
        budget = 8192;
    }
    int64_t tileElems = budget / bytesPerElem;
    const int64_t maxElems = MAX_TILE_BYTES / elemBytes;
    if (tileElems > maxElems) {
        tileElems = maxElems;
    }
    if (tileElems < 64) {
        tileElems = 64;
    }
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

// Tiling for the bfloat16 segLen==1 fast path: returns (numBlocks, blockLength, tileElems)
std::tuple<int64_t, int64_t, int64_t> calc_swiglu_s1_tiling_params(int64_t totalOut)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr static int64_t BYTES_PER_ELEM = 36;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t numBlocks = (totalOut + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    int64_t blockLength = (totalOut + numBlocks - 1) / numBlocks;

    int64_t budget = static_cast<int64_t>(ubSize) * 9 / 10;
    if (budget < 8192) {
        budget = 8192;
    }
    int64_t tileElems = budget / BYTES_PER_ELEM;
    if (tileElems > 16384) {
        tileElems = 16384;
    }
    if (tileElems < 64) {
        tileElems = 64;
    }
    return std::make_tuple(numBlocks, blockLength, tileElems);
}

extern "C" {

void launch_swiglu_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalOut, int64_t segLen,
                                int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalOut, segLen, blockLength, tileElems);
}

void launch_swiglu_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalOut, int64_t segLen,
                               int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalOut, segLen, blockLength, tileElems);
}

void launch_swiglu_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalOut, int64_t segLen,
                                   int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swi_glu_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalOut, segLen, blockLength, tileElems);
}

void launch_swiglu_s1_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalOut,
                               int64_t numBlocks, int64_t blockLength, uint32_t tileElems, void *stream)
{
    swiglu_s1_bf16_kernel<<<numBlocks, nullptr, stream>>>(x, y, totalOut, blockLength, tileElems);
}

}
