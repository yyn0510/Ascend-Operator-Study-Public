#include <cmath>

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>

#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/exp_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("exp(Tensor x, float base=-1.0, float scale=1.0, float shift=0.0) -> Tensor");
}

static bool IsSupportedExpDtype(const torch::Tensor &x)
{
    return x.scalar_type() == torch::kFloat16 ||
           x.scalar_type() == torch::kFloat32 ||
           x.scalar_type() == torch::kBFloat16;
}

torch::Tensor exp_meta(
    const torch::Tensor &x,
    double base,
    double scale,
    double shift)
{
    (void)base;
    (void)scale;
    (void)shift;
    TORCH_CHECK(
        IsSupportedExpDtype(x),
        "Exp only supports float16, float32 and bfloat16 inputs.");
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("exp", exp_meta);
}

torch::Tensor exp_npu(
    const torch::Tensor &x,
    double base,
    double scale,
    double shift)
{
    const c10::OptionalDeviceGuard guard(x.device());
    TORCH_CHECK(
        IsSupportedExpDtype(x),
        "Exp only supports float16, float32 and bfloat16 inputs.");

    auto xContiguous = x.contiguous();
    auto y = torch::empty_like(xContiguous);
    const int64_t totalLength = xContiguous.numel();
    if (totalLength == 0) {
        return y;
    }

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t numBlocks = 1;
    int64_t blockLength = 0;
    int64_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_exp_tiling_params(totalLength);

    // Fold the formula y = exp((x*scale + shift) * ln(base)) into
    // y = cCoef * exp(kCoef * x) so the kernel needs at most two vector
    // scalar ops around Exp.
    double kCoefD = 0.0;
    double cCoefD = 0.0;
    if (base > 0.0) {
        const double lnBase = std::log(base);
        kCoefD = scale * lnBase;
        cCoefD = std::exp(shift * lnBase);
    } else {
        kCoefD = scale;
        cCoefD = std::exp(shift);
    }
    const float kCoef = static_cast<float>(kCoefD);
    const float cCoef = static_cast<float>(cCoefD);

    auto xPtr = static_cast<GM_ADDR>(xContiguous.data_ptr());
    auto yPtr = static_cast<GM_ADDR>(y.data_ptr());
    const uint32_t tileSizeU32 = static_cast<uint32_t>(tileSize);

    auto aclCall = [=]() -> int {
        if (xContiguous.scalar_type() == torch::kFloat32) {
            launch_exp_kernel_float(
                xPtr,
                yPtr,
                totalLength,
                numBlocks,
                blockLength,
                tileSizeU32,
                kCoef,
                cCoef,
                stream);
        } else if (xContiguous.scalar_type() == torch::kFloat16) {
            launch_exp_kernel_half(
                xPtr,
                yPtr,
                totalLength,
                numBlocks,
                blockLength,
                tileSizeU32,
                kCoef,
                cCoef,
                stream);
        } else {
            launch_exp_kernel_bfloat16(
                xPtr,
                yPtr,
                totalLength,
                numBlocks,
                blockLength,
                tileSizeU32,
                kCoef,
                cCoef,
                stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Exp", aclCall);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("exp", exp_npu);
}

} // namespace cann_bench
