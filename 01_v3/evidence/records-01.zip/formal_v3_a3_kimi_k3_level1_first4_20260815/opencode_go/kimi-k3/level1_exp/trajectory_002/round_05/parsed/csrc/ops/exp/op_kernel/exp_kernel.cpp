#include <algorithm>
#include <cstdint>
#include <tuple>
#include <type_traits>

#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t MIN_ELEMS_PER_CORE = 4096;
constexpr static int64_t TILE_ALIGN_BYTES = 1024;
constexpr static int64_t UB_MARGIN_BYTES = 4096;

// y = cCoef * exp(kCoef * x), computed in float precision.
template <typename T>
__global__ __aicore__ void exp_kernel(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t blockLength,
    uint32_t tileSize,
    float kCoef,
    float cCoef)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> calcBuffer;

    constexpr bool kIsFp32 = (sizeof(T) == sizeof(float));
    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    if constexpr (!kIsFp32) {
        const uint32_t calcBytes = static_cast<uint32_t>(
            (static_cast<uint64_t>(tileSize) * sizeof(float)) / sizeof(T));
        pipe.InitBuffer(calcBuffer, calcBytes);
    }

    const int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    const int64_t blockStart = blockIdx * blockLength;
    if (blockStart >= totalLength || blockLength <= 0) {
        return;
    }

    int64_t currentBlockLength = totalLength - blockStart;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }

    xGm.SetGlobalBuffer(reinterpret_cast<__gm__ T *>(x) + blockStart);
    yGm.SetGlobalBuffer(reinterpret_cast<__gm__ T *>(y) + blockStart);

    const int64_t elementsPerTile = static_cast<int64_t>(tileSize / sizeof(T));
    if (elementsPerTile <= 0) {
        return;
    }

    const bool needK = (kCoef != 1.0F);
    const bool needC = (cCoef != 1.0F);

    for (int64_t offset = 0; offset < currentBlockLength; offset += elementsPerTile) {
        int64_t processLength64 = currentBlockLength - offset;
        if (processLength64 > elementsPerTile) {
            processLength64 = elementsPerTile;
        }
        const uint32_t processLength = static_cast<uint32_t>(processLength64);
        const bool useFastCopy = (processLength64 == elementsPerTile);

        AscendC::DataCopyExtParams copyParams{
            1,
            static_cast<uint32_t>(processLength * sizeof(T)),
            0,
            0,
            0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        if (useFastCopy) {
            AscendC::DataCopy(xLocal, xGm[offset], processLength);
        } else {
            AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        }
        inQueueX.EnQue(xLocal);

        xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();

        if constexpr (kIsFp32) {
            if (needK) {
                AscendC::Muls(yLocal, xLocal, kCoef, processLength);
                AscendC::Exp(yLocal, yLocal, processLength);
            } else {
                AscendC::Exp(yLocal, xLocal, processLength);
            }
            if (needC) {
                AscendC::Muls(yLocal, yLocal, cCoef, processLength);
            }
        } else {
            auto calcTensor = calcBuffer.Get<float>();
            AscendC::Cast(calcTensor, xLocal, AscendC::RoundMode::CAST_NONE, processLength);
            if (needK) {
                AscendC::Muls(calcTensor, calcTensor, kCoef, processLength);
            }
            AscendC::Exp(calcTensor, calcTensor, processLength);
            if (needC) {
                AscendC::Muls(calcTensor, calcTensor, cCoef, processLength);
            }
            if constexpr (std::is_same<T, bfloat16_t>::value) {
                AscendC::Cast(yLocal, calcTensor, AscendC::RoundMode::CAST_RINT, processLength);
            } else {
                AscendC::Cast(yLocal, calcTensor, AscendC::RoundMode::CAST_NONE, processLength);
            }
        }

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        if (useFastCopy) {
            AscendC::DataCopy(yGm[offset], yLocal, processLength);
        } else {
            AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        }
        outQueueY.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(int64_t totalLength, int64_t elementSize)
{
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);

    int64_t coreNum = static_cast<int64_t>(ascendcPlatform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (elementSize <= 0) {
        elementSize = 4;
    }

    int64_t numBlocks = 1;
    if (totalLength > 0) {
        numBlocks = std::min(
            coreNum,
            (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
        if (numBlocks <= 0) {
            numBlocks = 1;
        }
    }

    // fp32: in/out double buffers only -> 4 * tileSize.
    // fp16/bf16: in/out double buffers + one fp32 calc buffer -> 6 * tileSize.
    const int64_t bufferUnits = (elementSize == sizeof(float)) ? 4 : 6;
    int64_t tileSize = static_cast<int64_t>(ubSize) / bufferUnits - UB_MARGIN_BYTES;
    tileSize = (tileSize / TILE_ALIGN_BYTES) * TILE_ALIGN_BYTES;
    if (tileSize < TILE_ALIGN_BYTES) {
        tileSize = TILE_ALIGN_BYTES;
    }

    const int64_t elementsPerTile = tileSize / elementSize;
    int64_t blockLength = elementsPerTile;
    if (totalLength > 0 && elementsPerTile > 0) {
        const int64_t target = (totalLength + numBlocks - 1) / numBlocks;
        blockLength = ((target + elementsPerTile - 1) / elementsPerTile) * elementsPerTile;
        if (blockLength <= 0) {
            blockLength = elementsPerTile;
        }
        numBlocks = (totalLength + blockLength - 1) / blockLength;
        if (numBlocks <= 0) {
            numBlocks = 1;
        }
    }

    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_exp_kernel_float(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    float kCoef,
    float cCoef,
    void *stream)
{
    exp_kernel<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, kCoef, cCoef);
}

void launch_exp_kernel_half(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    float kCoef,
    float cCoef,
    void *stream)
{
    exp_kernel<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, kCoef, cCoef);
}

void launch_exp_kernel_bfloat16(
    GM_ADDR x,
    GM_ADDR y,
    int64_t totalLength,
    int64_t numBlocks,
    int64_t blockLength,
    uint32_t tileSize,
    float kCoef,
    float cCoef,
    void *stream)
{
    exp_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize, kCoef, cCoef);
}

}
