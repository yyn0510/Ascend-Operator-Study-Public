/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file exp_plugin.cpp
 * \brief Exp API layer - torch bindings (compiled with g++)
 */

#include <cmath>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/exp_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("exp(Tensor x, float base=-1.0, float scale=1.0, float shift=0.0) -> Tensor");
}

torch::Tensor exp_meta(const torch::Tensor &x, double base, double scale, double shift)
{
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("exp", exp_meta);
}

torch::Tensor exp_npu(const torch::Tensor &x, double base, double scale, double shift)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto xContig = x.contiguous();
    auto y = exp_meta(xContig, base, scale, shift);
    int64_t totalLength = xContig.numel();
    if (totalLength == 0) {
        return y;
    }
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    float logFactor = 1.0f;
    if (base > 0.0) {
        logFactor = std::log(static_cast<float>(base));
    }
    float mulFactor = static_cast<float>(scale) * logFactor;
    float addFactor = static_cast<float>(shift) * logFactor;

    // UB footprint per element with pipeline depth 3:
    // fp32 -> 3*(4+4)=24; fp16/bf16 -> 3*(2+2)+4(tmp fp32)=16
    int64_t bytesPerElem = (xContig.scalar_type() == torch::kFloat32) ? 24 : 16;
    int64_t numBlocks, blockLength, tileLength;
    std::tie(numBlocks, blockLength, tileLength) = calc_exp_tiling_params(totalLength, bytesPerElem);

    auto x_ptr = (GM_ADDR)xContig.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();

    auto acl_call = [=]() -> int {
        if (xContig.scalar_type() == torch::kFloat32) {
            launch_exp_kernel_float(x_ptr, y_ptr, mulFactor, addFactor, totalLength,
                                    numBlocks, blockLength, static_cast<uint32_t>(tileLength), stream);
        } else if (xContig.scalar_type() == torch::kFloat16) {
            launch_exp_kernel_half(x_ptr, y_ptr, mulFactor, addFactor, totalLength,
                                   numBlocks, blockLength, static_cast<uint32_t>(tileLength), stream);
        } else if (xContig.scalar_type() == torch::kBFloat16) {
            launch_exp_kernel_bfloat16(x_ptr, y_ptr, mulFactor, addFactor, totalLength,
                                       numBlocks, blockLength, static_cast<uint32_t>(tileLength), stream);
        } else {
            TORCH_CHECK(false, "exp: unsupported dtype ", xContig.scalar_type());
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Exp", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("exp", exp_npu);
}

} // namespace cann_bench
