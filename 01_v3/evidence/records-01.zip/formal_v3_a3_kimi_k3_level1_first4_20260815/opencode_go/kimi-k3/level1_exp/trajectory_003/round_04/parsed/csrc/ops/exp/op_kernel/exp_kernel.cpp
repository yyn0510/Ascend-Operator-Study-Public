/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file exp_kernel.cpp
 * \brief Exp kernel, host tiling and launch wrappers (compiled with bisheng + -xasc)
 *
 * y = exp(x * mulFactor + addFactor)
 *   base <= 0 : mulFactor = scale,            addFactor = shift
 *   base > 0  : mulFactor = scale * ln(base), addFactor = shift * ln(base)
 * FP16/BF16 inputs are computed in FP32 and cast back.
 * Software pipeline: the next tile's CopyIn is issued before the current
 * tile's compute, so MTE2 / VEC / MTE3 overlap across tiles.
 * Block length is aligned to 64 elements so that every full tile uses the
 * fast aligned DataCopy path; only the final partial tile uses DataCopyPad.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t EXP_PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void exp_kernel(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                                      int64_t totalLength, int64_t blockLength, uint32_t tileLength)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, EXP_PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, EXP_PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBuf;
    pipe.InitBuffer(inQueueX, EXP_PIPELINE_DEPTH, tileLength * sizeof(T));
    pipe.InitBuffer(outQueueY, EXP_PIPELINE_DEPTH, tileLength * sizeof(T));
    if constexpr (!std::is_same<T, float>::value) {
        pipe.InitBuffer(tmpBuf, tileLength * sizeof(float));
    }

    AscendC::GlobalTensor<T> xGm, yGm;
    int64_t blockOffset = blockLength * AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)x + blockOffset);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockOffset);

    int64_t currentBlockLength = totalLength - blockOffset;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;

    const bool needMul = (mulFactor != 1.0f);
    const bool needAdd = (addFactor != 0.0f);
    const int64_t tileLen = static_cast<int64_t>(tileLength);
    const int64_t tileNum = (currentBlockLength + tileLen - 1) / tileLen;

    // Prologue: prefetch tile 0
    {
        int64_t count = currentBlockLength;
        if (count > tileLen) count = tileLen;
        auto xLocal = inQueueX.AllocTensor<T>();
        if (count == tileLen) {
            AscendC::DataCopy(xLocal, xGm[0], static_cast<uint32_t>(count));
        } else {
            AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
            AscendC::DataCopyPad(xLocal, xGm[0], copyParams, padParams);
        }
        inQueueX.EnQue(xLocal);
    }

    for (int64_t i = 0; i < tileNum; ++i) {
        // Prefetch next tile so that MTE2 overlaps with current compute
        int64_t next = i + 1;
        if (next < tileNum) {
            int64_t offsetN = next * tileLen;
            int64_t countN = currentBlockLength - offsetN;
            if (countN > tileLen) countN = tileLen;
            auto xNext = inQueueX.AllocTensor<T>();
            if (countN == tileLen) {
                AscendC::DataCopy(xNext, xGm[offsetN], static_cast<uint32_t>(countN));
            } else {
                AscendC::DataCopyExtParams copyParamsN{1, static_cast<uint32_t>(countN * sizeof(T)), 0, 0, 0};
                AscendC::DataCopyPadExtParams<T> padParamsN{false, 0, 0, 0};
                AscendC::DataCopyPad(xNext, xGm[offsetN], copyParamsN, padParamsN);
            }
            inQueueX.EnQue(xNext);
        }

        int64_t offset = i * tileLen;
        int64_t count = currentBlockLength - offset;
        if (count > tileLen) count = tileLen;
        uint32_t calCount = static_cast<uint32_t>(count);

        auto xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();
        if constexpr (std::is_same<T, float>::value) {
            if (needMul && needAdd) {
                AscendC::Muls(yLocal, xLocal, mulFactor, calCount);
                AscendC::Adds(yLocal, yLocal, addFactor, calCount);
                AscendC::Exp(yLocal, yLocal, calCount);
            } else if (needMul) {
                AscendC::Muls(yLocal, xLocal, mulFactor, calCount);
                AscendC::Exp(yLocal, yLocal, calCount);
            } else if (needAdd) {
                AscendC::Adds(yLocal, xLocal, addFactor, calCount);
                AscendC::Exp(yLocal, yLocal, calCount);
            } else {
                AscendC::Exp(yLocal, xLocal, calCount);
            }
        } else {
            auto tmp = tmpBuf.Get<float>();
            AscendC::Cast(tmp, xLocal, AscendC::RoundMode::CAST_NONE, calCount);
            if (needMul) {
                AscendC::Muls(tmp, tmp, mulFactor, calCount);
            }
            if (needAdd) {
                AscendC::Adds(tmp, tmp, addFactor, calCount);
            }
            AscendC::Exp(tmp, tmp, calCount);
            AscendC::Cast(yLocal, tmp, AscendC::RoundMode::CAST_RINT, calCount);
        }
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        if (count == tileLen) {
            AscendC::DataCopy(yGm[offset], yLocal, calCount);
        } else {
            AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
            AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        }
        outQueueY.FreeTensor(yLocal);
    }
}

// Tiling function: bytesPerElem is the worst-case UB footprint per element
// (fp32: depth*(4+4)=16; fp16/bf16: depth*(2+2)+4(tmp fp32)=12)
// blockLength is aligned to 64 elements so full tiles can use aligned DataCopy.
std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(int64_t totalLength, int64_t bytesPerElem)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr static int64_t BLOCK_ALIGN = 64;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) numBlocks = coreNum;
    if (numBlocks <= 0) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    blockLength = ((blockLength + BLOCK_ALIGN - 1) / BLOCK_ALIGN) * BLOCK_ALIGN;
    if (bytesPerElem <= 0) bytesPerElem = 16;
    int64_t tileLength = static_cast<int64_t>(ubSize) / bytesPerElem;
    tileLength = (tileLength / 64) * 64;
    if (tileLength <= 0) tileLength = 1024;
    return std::make_tuple(numBlocks, blockLength, tileLength);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_exp_kernel_float(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                             int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileLength, void *stream)
{
    exp_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                      totalLength, blockLength, tileLength);
}

void launch_exp_kernel_half(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                            int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                            uint32_t tileLength, void *stream)
{
    exp_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                     totalLength, blockLength, tileLength);
}

void launch_exp_kernel_bfloat16(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                                int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                                uint32_t tileLength, void *stream)
{
    exp_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                           totalLength, blockLength, tileLength);
}

}
