/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file exp_kernel.cpp
 * \brief Exp kernel, host tiling and launch wrappers (compiled with bisheng + -xasc)
 *
 * y = exp(x * mulFactor + addFactor)
 *   base <= 0 : mulFactor = scale,            addFactor = shift
 *   base > 0  : mulFactor = scale * ln(base), addFactor = shift * ln(base)
 * FP16/BF16 inputs are computed in FP32 and cast back.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t EXP_PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void exp_kernel(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                                      int64_t totalLength, int64_t blockLength, uint32_t tileLength)
{
    AscendC::TPipe pipe;
    AscendC::TQue<AscendC::QuePosition::VECIN, EXP_PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, EXP_PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBuf;
    pipe.InitBuffer(inQueueX, EXP_PIPELINE_DEPTH, tileLength * sizeof(T));
    pipe.InitBuffer(outQueueY, EXP_PIPELINE_DEPTH, tileLength * sizeof(T));
    if constexpr (!std::is_same<T, float>::value) {
        pipe.InitBuffer(tmpBuf, tileLength * sizeof(float));
    }

    AscendC::GlobalTensor<T> xGm, yGm;
    int64_t blockOffset = blockLength * AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)x + blockOffset);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockOffset);

    int64_t currentBlockLength = totalLength - blockOffset;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;

    for (int64_t offset = 0; offset < currentBlockLength; offset += tileLength) {
        int64_t count = currentBlockLength - offset;
        if (count > static_cast<int64_t>(tileLength)) count = tileLength;
        uint32_t calCount = static_cast<uint32_t>(count);

        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();
        if constexpr (std::is_same<T, float>::value) {
            AscendC::Muls(yLocal, xLocal, mulFactor, calCount);
            AscendC::Adds(yLocal, yLocal, addFactor, calCount);
            AscendC::Exp(yLocal, yLocal, calCount);
        } else {
            auto tmp = tmpBuf.Get<float>();
            AscendC::Cast(tmp, xLocal, AscendC::RoundMode::CAST_NONE, calCount);
            AscendC::Muls(tmp, tmp, mulFactor, calCount);
            AscendC::Adds(tmp, tmp, addFactor, calCount);
            AscendC::Exp(tmp, tmp, calCount);
            AscendC::Cast(yLocal, tmp, AscendC::RoundMode::CAST_RINT, calCount);
        }
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

// Tiling function
std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    // Worst case per element: depth * (in + out) * sizeof(float) = 16 bytes
    constexpr static int64_t BYTES_PER_ELEM = EXP_PIPELINE_DEPTH * 2 * static_cast<int64_t>(sizeof(float));
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) numBlocks = coreNum;
    if (numBlocks <= 0) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    int64_t tileLength = static_cast<int64_t>(ubSize) / BYTES_PER_ELEM;
    if (tileLength <= 0) tileLength = 1024;
    return std::make_tuple(numBlocks, blockLength, tileLength);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_exp_kernel_float(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                             int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileLength, void *stream)
{
    exp_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                      totalLength, blockLength, tileLength);
}

void launch_exp_kernel_half(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                            int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                            uint32_t tileLength, void *stream)
{
    exp_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                     totalLength, blockLength, tileLength);
}

void launch_exp_kernel_bfloat16(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                                int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                                uint32_t tileLength, void *stream)
{
    exp_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                           totalLength, blockLength, tileLength);
}

}
