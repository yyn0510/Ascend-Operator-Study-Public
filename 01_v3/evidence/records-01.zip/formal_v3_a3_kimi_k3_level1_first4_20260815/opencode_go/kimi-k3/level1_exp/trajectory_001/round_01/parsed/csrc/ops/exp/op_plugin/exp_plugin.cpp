/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file exp_plugin.cpp
 * \brief Exp API layer - torch bindings (compiled with g++)
 */

#include <cmath>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/exp_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("exp(Tensor x, float base=-1.0, float scale=1.0, float shift=0.0) -> Tensor");
}

torch::Tensor exp_meta(const torch::Tensor &x, double base, double scale, double shift)
{
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("exp", exp_meta);
}

torch::Tensor exp_npu(const torch::Tensor &x, double base, double scale, double shift)
{
    const c10::OptionalDeviceGuard guard(x.device());
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 || x.scalar_type() == torch::kFloat16 ||
                x.scalar_type() == torch::kBFloat16,
                "cann_bench::exp only supports float32, float16 and bfloat16.");
    auto xContig = x.contiguous();
    auto y = exp_meta(xContig, base, scale, shift);
    int64_t totalLength = xContig.numel();
    if (totalLength == 0) {
        return y;
    }
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    // Fold the formula into y = exp(x * mulFactor + addFactor)
    double lnBase = 1.0;
    if (base > 0.0) {
        lnBase = std::log(base);
    }
    float mulFactor = static_cast<float>(scale * lnBase);
    float addFactor = static_cast<float>(shift * lnBase);

    int64_t dtypeSize = static_cast<int64_t>(xContig.element_size());
    int64_t numBlocks, blockLength, tileSize;
    std::tie(numBlocks, blockLength, tileSize) = calc_exp_tiling_params(totalLength, dtypeSize);

    auto x_ptr = (GM_ADDR)xContig.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();
    auto scalarType = xContig.scalar_type();

    auto acl_call = [=]() -> int {
        if (scalarType == torch::kFloat32) {
            launch_exp_kernel_float(x_ptr, y_ptr, mulFactor, addFactor,
                                    totalLength, numBlocks, blockLength, tileSize, stream);
        } else if (scalarType == torch::kFloat16) {
            launch_exp_kernel_half(x_ptr, y_ptr, mulFactor, addFactor,
                                   totalLength, numBlocks, blockLength, tileSize, stream);
        } else {
            launch_exp_kernel_bfloat16(x_ptr, y_ptr, mulFactor, addFactor,
                                       totalLength, numBlocks, blockLength, tileSize, stream);
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Exp", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("exp", exp_npu);
}

} // namespace cann_bench
