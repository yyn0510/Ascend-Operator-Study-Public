/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file exp_kernel.cpp
 * \brief Exp host code - kernel launch and tiling (compiled with bisheng + -xasc)
 *
 * y = exp(x * mulFactor + addFactor)
 *   base <= 0 : mulFactor = scale,          addFactor = shift
 *   base >  0 : mulFactor = scale*ln(base), addFactor = shift*ln(base)
 * fp16/bf16 are computed in fp32 for accuracy, then cast back.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

// Kernel implementation
template <typename T>
__global__ __aicore__ void exp_kernel(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                                      int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBufF32;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    int64_t elementNumPerTile = tileSize / sizeof(T);
    if constexpr (!std::is_same_v<T, float>) {
        pipe.InitBuffer(tmpBufF32, elementNumPerTile * sizeof(float));
    }

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - blockLength * AscendC::GetBlockIdx();
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    if (currentBlockLength <= 0) return;
    int64_t tileNum = (currentBlockLength + elementNumPerTile - 1) / elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        int64_t curElems = currentBlockLength - offset;
        if (curElems > elementNumPerTile) curElems = elementNumPerTile;

        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(curElems * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();

        if constexpr (std::is_same_v<T, float>) {
            AscendC::Muls(xLocal, xLocal, mulFactor, curElems);
            AscendC::Adds(xLocal, xLocal, addFactor, curElems);
            AscendC::Exp(yLocal, xLocal, curElems);
        } else {
            auto f32Local = tmpBufF32.Get<float>();
            AscendC::Cast(f32Local, xLocal, AscendC::RoundMode::CAST_NONE, curElems);
            AscendC::Muls(f32Local, f32Local, mulFactor, curElems);
            AscendC::Adds(f32Local, f32Local, addFactor, curElems);
            AscendC::Exp(f32Local, f32Local, curElems);
            if constexpr (std::is_same_v<T, bfloat16_t>) {
                AscendC::Cast(yLocal, f32Local, AscendC::RoundMode::CAST_RINT, curElems);
            } else {
                AscendC::Cast(yLocal, f32Local, AscendC::RoundMode::CAST_NONE, curElems);
            }
        }

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

// Tiling function
std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 2048;
    constexpr static int64_t MAX_ELEMS_PER_TILE = 8192;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    if (dtypeSize <= 0) dtypeSize = 4;
    if (totalLength < 1) totalLength = 1;

    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) numBlocks = coreNum;
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    // per-element UB bytes per stage: in + out (+ fp32 temp for 16-bit dtypes)
    int64_t extraBytes = (dtypeSize == 4) ? 0 : 4;
    int64_t bytesPerElem = 2 * dtypeSize + extraBytes;
    int64_t elementNumPerTile = static_cast<int64_t>(ubSize) / (PIPELINE_DEPTH * bytesPerElem);
    if (elementNumPerTile > MAX_ELEMS_PER_TILE) elementNumPerTile = MAX_ELEMS_PER_TILE;
    elementNumPerTile = elementNumPerTile / 64 * 64;
    if (elementNumPerTile < 64) elementNumPerTile = 64;
    int64_t tileSize = elementNumPerTile * dtypeSize;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_exp_kernel_float(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                             int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    exp_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor, totalLength, blockLength, tileSize);
}

void launch_exp_kernel_half(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                            int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                            uint32_t tileSize, void *stream)
{
    exp_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor, totalLength, blockLength, tileSize);
}

void launch_exp_kernel_bfloat16(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                                int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                                uint32_t tileSize, void *stream)
{
    exp_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor, totalLength, blockLength, tileSize);
}

}
