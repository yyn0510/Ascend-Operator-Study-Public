/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file exp_kernel.cpp
 * \brief Exp host code - kernel launch and tiling (compiled with bisheng + -xasc)
 *
 * y = exp(x * mulFactor + addFactor)
 *   base <= 0 : mulFactor = scale,          addFactor = shift
 *   base >  0 : mulFactor = scale*ln(base), addFactor = shift*ln(base)
 * fp16/bf16 default path computes in fp32 for accuracy, then casts back.
 * For fp16, when the affine coefficients are exactly representable in half,
 * a native half fast path (Muls/Adds/Exp in half, no Cast, no fp32 temp)
 * is used to reduce UB traffic and enlarge tiles.
 * The main loop is a 3-stage software pipeline (CopyIn i / Compute i-1 /
 * CopyOut i-2) so that MTE2, V and MTE3 run concurrently.
 * Block boundaries are aligned to 256 elements so that full tiles use the
 * plain DataCopy path; only tail tiles use DataCopyPad.
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t BLOCK_ALIGN_ELEMS = 256;

// Kernel implementation
template <typename T, bool HALF_FAST>
__global__ __aicore__ void exp_kernel(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                                      int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> tmpBufF32;

    constexpr bool isFloat = std::is_same_v<T, float>;
    constexpr bool isHalf = std::is_same_v<T, half>;
    constexpr bool halfFast = isHalf && HALF_FAST;
    constexpr bool needTmp = !isFloat && !halfFast;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    int64_t elementNumPerTile = tileSize / sizeof(T);
    if constexpr (needTmp) {
        pipe.InitBuffer(tmpBufF32, elementNumPerTile * sizeof(float));
    }

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - blockLength * AscendC::GetBlockIdx();
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    if (currentBlockLength <= 0) return;
    int64_t tileNum = (currentBlockLength + elementNumPerTile - 1) / elementNumPerTile;

    // compute mode: 0 = exp only, 1 = muls + exp, 2 = adds + exp, 3 = muls + adds + exp
    int mode = 0;
    if (mulFactor != 1.0f && addFactor != 0.0f) {
        mode = 3;
    } else if (mulFactor != 1.0f) {
        mode = 1;
    } else if (addFactor != 0.0f) {
        mode = 2;
    }

    // 3-stage software pipeline: CopyIn(i) / Compute(i-1) / CopyOut(i-2)
    for (int64_t i = 0; i < tileNum + 2; ++i) {
        // stage 1: async copy in of tile i (MTE2)
        if (i < tileNum) {
            int64_t offset = i * elementNumPerTile;
            int64_t curElems = currentBlockLength - offset;
            if (curElems > elementNumPerTile) curElems = elementNumPerTile;
            auto xLocal = inQueueX.AllocTensor<T>();
            if (curElems == elementNumPerTile) {
                AscendC::DataCopy(xLocal, xGm[offset], elementNumPerTile);
            } else {
                AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(curElems * sizeof(T)), 0, 0, 0};
                AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
                AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
            }
            inQueueX.EnQue(xLocal);
        }
        // stage 2: vector compute of tile i-1 (V), overlaps with MTE2 of tile i
        if (i >= 1 && i - 1 < tileNum) {
            int64_t offset = (i - 1) * elementNumPerTile;
            int64_t curElems = currentBlockLength - offset;
            if (curElems > elementNumPerTile) curElems = elementNumPerTile;
            auto xLocal = inQueueX.DeQue<T>();
            auto yLocal = outQueueY.AllocTensor<T>();
            if constexpr (isFloat) {
                if (mode == 3) {
                    AscendC::Muls(xLocal, xLocal, mulFactor, curElems);
                    AscendC::Adds(xLocal, xLocal, addFactor, curElems);
                } else if (mode == 1) {
                    AscendC::Muls(xLocal, xLocal, mulFactor, curElems);
                } else if (mode == 2) {
                    AscendC::Adds(xLocal, xLocal, addFactor, curElems);
                }
                AscendC::Exp(yLocal, xLocal, curElems);
            } else if constexpr (halfFast) {
                // coefficients are exactly representable in half; compute natively
                if (mode == 3) {
                    AscendC::Muls(xLocal, xLocal, (half)mulFactor, curElems);
                    AscendC::Adds(xLocal, xLocal, (half)addFactor, curElems);
                } else if (mode == 1) {
                    AscendC::Muls(xLocal, xLocal, (half)mulFactor, curElems);
                } else if (mode == 2) {
                    AscendC::Adds(xLocal, xLocal, (half)addFactor, curElems);
                }
                AscendC::Exp(yLocal, xLocal, curElems);
            } else {
                auto f32Local = tmpBufF32.Get<float>();
                AscendC::Cast(f32Local, xLocal, AscendC::RoundMode::CAST_NONE, curElems);
                if (mode == 3) {
                    AscendC::Muls(f32Local, f32Local, mulFactor, curElems);
                    AscendC::Adds(f32Local, f32Local, addFactor, curElems);
                } else if (mode == 1) {
                    AscendC::Muls(f32Local, f32Local, mulFactor, curElems);
                } else if (mode == 2) {
                    AscendC::Adds(f32Local, f32Local, addFactor, curElems);
                }
                AscendC::Exp(f32Local, f32Local, curElems);
                if constexpr (std::is_same_v<T, bfloat16_t>) {
                    AscendC::Cast(yLocal, f32Local, AscendC::RoundMode::CAST_RINT, curElems);
                } else {
                    AscendC::Cast(yLocal, f32Local, AscendC::RoundMode::CAST_NONE, curElems);
                }
            }
            outQueueY.EnQue(yLocal);
            inQueueX.FreeTensor(xLocal);
        }
        // stage 3: async copy out of tile i-2 (MTE3), overlaps with V and MTE2
        if (i >= 2) {
            int64_t offset = (i - 2) * elementNumPerTile;
            int64_t curElems = currentBlockLength - offset;
            if (curElems > elementNumPerTile) curElems = elementNumPerTile;
            auto yLocal = outQueueY.DeQue<T>();
            if (curElems == elementNumPerTile) {
                AscendC::DataCopy(yGm[offset], yLocal, elementNumPerTile);
            } else {
                AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(curElems * sizeof(T)), 0, 0, 0};
                AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
            }
            outQueueY.FreeTensor(yLocal);
        }
    }
}

// Tiling function
std::tuple<int64_t, int64_t, int64_t> calc_exp_tiling_params(int64_t totalLength, int64_t dtypeSize,
                                                             int64_t tmpBytesPerElem)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 2048;
    constexpr static int64_t MAX_ELEMS_PER_TILE = 24576;
    constexpr static int64_t UB_RESERVE_BYTES = 4096;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    if (dtypeSize <= 0) dtypeSize = 4;
    if (tmpBytesPerElem < 0) tmpBytesPerElem = 0;
    if (totalLength < 1) totalLength = 1;

    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) numBlocks = coreNum;
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    // Align block boundaries so every block starts at a 256-element multiple;
    // full tiles can then use aligned plain DataCopy.
    blockLength = ((blockLength + BLOCK_ALIGN_ELEMS - 1) / BLOCK_ALIGN_ELEMS) * BLOCK_ALIGN_ELEMS;
    numBlocks = (totalLength + blockLength - 1) / blockLength;

    // UB budget per tile element: depth * (in + out) * dtypeSize (+ fp32 temp when needed)
    int64_t bytesPerTileElem = PIPELINE_DEPTH * 2 * dtypeSize + tmpBytesPerElem;
    int64_t budget = static_cast<int64_t>(ubSize) - UB_RESERVE_BYTES;
    if (budget < bytesPerTileElem * BLOCK_ALIGN_ELEMS) budget = bytesPerTileElem * BLOCK_ALIGN_ELEMS;
    int64_t elementNumPerTile = budget / bytesPerTileElem;
    if (elementNumPerTile > MAX_ELEMS_PER_TILE) elementNumPerTile = MAX_ELEMS_PER_TILE;
    elementNumPerTile = elementNumPerTile / BLOCK_ALIGN_ELEMS * BLOCK_ALIGN_ELEMS;
    if (elementNumPerTile < BLOCK_ALIGN_ELEMS) elementNumPerTile = BLOCK_ALIGN_ELEMS;
    int64_t tileSize = elementNumPerTile * dtypeSize;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_exp_kernel_float(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                             int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    exp_kernel<float, false><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                             totalLength, blockLength, tileSize);
}

void launch_exp_kernel_half(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                            int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                            uint32_t tileSize, int64_t halfFast, void *stream)
{
    if (halfFast != 0) {
        exp_kernel<half, true><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                               totalLength, blockLength, tileSize);
    } else {
        exp_kernel<half, false><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                                totalLength, blockLength, tileSize);
    }
}

void launch_exp_kernel_bfloat16(GM_ADDR x, GM_ADDR y, float mulFactor, float addFactor,
                                int64_t totalLength, int64_t numBlocks, int64_t blockLength,
                                uint32_t tileSize, void *stream)
{
    exp_kernel<bfloat16_t, false><<<numBlocks, nullptr, stream>>>(x, y, mulFactor, addFactor,
                                                                  totalLength, blockLength, tileSize);
}

}
