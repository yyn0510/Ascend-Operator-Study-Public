/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file exp_kernel.cpp
 * \brief Exp host code - kernel launch and tiling (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t ALIGN_BYTES = 32;

// GM -> UB copy: use fast DataCopy when the tile is 32B aligned, otherwise DataCopyPad.
template <typename T>
__aicore__ inline void ExpCopyIn(const AscendC::LocalTensor<T> &dst, const AscendC::GlobalTensor<T> &src,
                                 int64_t offset, int64_t count, bool useFastCopy, int64_t alignElems)
{
    if (useFastCopy && (count % alignElems == 0)) {
        AscendC::DataCopy(dst, src[offset], static_cast<uint64_t>(count));
    } else {
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        AscendC::DataCopyPad(dst, src[offset], copyParams, padParams);
    }
}

// UB -> GM copy: use fast DataCopy when the tile is 32B aligned, otherwise DataCopyPad.
template <typename T>
__aicore__ inline void ExpCopyOut(const AscendC::GlobalTensor<T> &dst, const AscendC::LocalTensor<T> &src,
                                  int64_t offset, int64_t count, bool useFastCopy, int64_t alignElems)
{
    if (useFastCopy && (count % alignElems == 0)) {
        AscendC::DataCopy(dst[offset], src, static_cast<uint64_t>(count));
    } else {
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        AscendC::DataCopyPad(dst[offset], src, copyParams, padParams);
    }
}

// Kernel implementation for float / half.
// Computes y = exp(x * mulFactor + addOffset); the host folds base/scale/shift into
// mulFactor = scale * ln(base) (or scale) and addOffset = shift * ln(base) (or shift).
// half input is upcast to float for computation and cast back, matching the golden.
// The loop is software pipelined: the copy-in of tile i+1 is issued before the
// compute of tile i waits, so DMA and vector pipes overlap.
template <typename T>
__global__ __aicore__ void exp_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                      int64_t blockLength, uint32_t tileSize,
                                      float mulFactor, float addOffset, uint32_t alignMode)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t currentBlockLength = totalLength - blockLength * blockIdx;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elementNumPerTile <= 0) {
        return;
    }

    int64_t alignElems = ALIGN_BYTES / static_cast<int64_t>(sizeof(T));
    bool useFastCopy = (alignMode != 0) && (blockLength % alignElems == 0);

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf1;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf2;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpBuf1, static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float))));
    if constexpr (!std::is_same<T, float>::value) {
        pipe.InitBuffer(tmpBuf2, static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float))));
    }

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * blockIdx);

    auto t1 = tmpBuf1.Get<float>();

    int64_t tileNum = (currentBlockLength + elementNumPerTile - 1) / elementNumPerTile;

    // Issue the copy-in of the first tile.
    {
        int64_t calCount = currentBlockLength < elementNumPerTile ? currentBlockLength : elementNumPerTile;
        auto xFirst = inQueueX.AllocTensor<T>();
        ExpCopyIn(xFirst, xGm, 0, calCount, useFastCopy, alignElems);
        inQueueX.EnQue(xFirst);
    }

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        int64_t calCount = currentBlockLength - offset;
        if (calCount > elementNumPerTile) {
            calCount = elementNumPerTile;
        }

        // Prefetch: issue copy-in of tile i+1 before waiting on tile i compute.
        if (i + 1 < tileNum) {
            int64_t offsetNext = offset + elementNumPerTile;
            int64_t calNext = currentBlockLength - offsetNext;
            if (calNext > elementNumPerTile) {
                calNext = elementNumPerTile;
            }
            auto xNext = inQueueX.AllocTensor<T>();
            ExpCopyIn(xNext, xGm, offsetNext, calNext, useFastCopy, alignElems);
            inQueueX.EnQue(xNext);
        }

        auto xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();
        if constexpr (std::is_same<T, float>::value) {
            AscendC::Muls(yLocal, xLocal, mulFactor, calCount);
            AscendC::Adds(t1, yLocal, addOffset, calCount);
            AscendC::Exp(yLocal, t1, calCount);
        } else {
            auto t2 = tmpBuf2.Get<float>();
            AscendC::Cast(t1, xLocal, AscendC::RoundMode::CAST_NONE, calCount);
            AscendC::Muls(t2, t1, mulFactor, calCount);
            AscendC::Adds(t1, t2, addOffset, calCount);
            AscendC::Exp(t2, t1, calCount);
            AscendC::Cast(yLocal, t2, AscendC::RoundMode::CAST_NONE, calCount);
        }
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        ExpCopyOut(yGm, yLocal, offset, calCount, useFastCopy, alignElems);
        outQueueY.FreeTensor(yLocal);
    }
}

// Dedicated bfloat16 kernel. The __bf16 type is only supported inside device
// code on this target, so this is a standalone non-template __global__ kernel:
// the host launch wrapper below never names the __bf16 type.
__global__ __aicore__ void exp_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                           int64_t blockLength, uint32_t tileSize,
                                           float mulFactor, float addOffset, uint32_t alignMode)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t currentBlockLength = totalLength - blockLength * blockIdx;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    constexpr int64_t BF16_SIZE = 2;
    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / BF16_SIZE;
    if (elementNumPerTile <= 0) {
        return;
    }

    int64_t alignElems = ALIGN_BYTES / BF16_SIZE;
    bool useFastCopy = (alignMode != 0) && (blockLength % alignElems == 0);

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<__bf16> xGm;
    AscendC::GlobalTensor<__bf16> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf1;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf2;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpBuf1, static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float))));
    pipe.InitBuffer(tmpBuf2, static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float))));

    xGm.SetGlobalBuffer((__gm__ __bf16 *)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ __bf16 *)y + blockLength * blockIdx);

    auto t1 = tmpBuf1.Get<float>();
    auto t2 = tmpBuf2.Get<float>();

    int64_t tileNum = (currentBlockLength + elementNumPerTile - 1) / elementNumPerTile;

    // Issue the copy-in of the first tile.
    {
        int64_t calCount = currentBlockLength < elementNumPerTile ? currentBlockLength : elementNumPerTile;
        auto xFirst = inQueueX.AllocTensor<__bf16>();
        ExpCopyIn(xFirst, xGm, 0, calCount, useFastCopy, alignElems);
        inQueueX.EnQue(xFirst);
    }

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        int64_t calCount = currentBlockLength - offset;
        if (calCount > elementNumPerTile) {
            calCount = elementNumPerTile;
        }

        if (i + 1 < tileNum) {
            int64_t offsetNext = offset + elementNumPerTile;
            int64_t calNext = currentBlockLength - offsetNext;
            if (calNext > elementNumPerTile) {
                calNext = elementNumPerTile;
            }
            auto xNext = inQueueX.AllocTensor<__bf16>();
            ExpCopyIn(xNext, xGm, offsetNext, calNext, useFastCopy, alignElems);
            inQueueX.EnQue(xNext);
        }

        auto xLocal = inQueueX.DeQue<__bf16>();
        auto yLocal = outQueueY.AllocTensor<__bf16>();
        AscendC::Cast(t1, xLocal, AscendC::RoundMode::CAST_NONE, calCount);
        AscendC::Muls(t2, t1, mulFactor, calCount);
        AscendC::Adds(t1, t2, addOffset, calCount);
        AscendC::Exp(t2, t1, calCount);
        AscendC::Cast(yLocal, t2, AscendC::RoundMode::CAST_RINT, calCount);
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<__bf16>();
        ExpCopyOut(yGm, yLocal, offset, calCount, useFastCopy, alignElems);
        outQueueY.FreeTensor(yLocal);
    }
}

// Tiling function
std::tuple<int64_t, int64_t, uint32_t> calc_exp_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (dtypeSize <= 0) {
        dtypeSize = 4;
    }

    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    // UB usage per element: in-queue (depth 2) + out-queue (depth 2) = 4 * dtypeSize,
    // plus fp32 temp buffers: one for fp32 path, two for 16-bit dtypes.
    int64_t tempBytes = (dtypeSize >= 4) ? 4 : 8;
    int64_t bytesPerElem = 4 * dtypeSize + tempBytes;
    int64_t usableUb = static_cast<int64_t>(ubSize) - 32768;
    if (usableUb < 32768) {
        usableUb = static_cast<int64_t>(ubSize) / 2;
    }
    if (usableUb < 4096) {
        usableUb = 4096;
    }
    int64_t maxElems = usableUb / bytesPerElem;
    maxElems = maxElems / 256 * 256;
    if (maxElems < 256) {
        maxElems = 256;
    }
    uint32_t tileSize = static_cast<uint32_t>(maxElems * dtypeSize);
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_exp_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                             int64_t blockLength, uint32_t tileSize, float mulFactor,
                             float addOffset, uint32_t alignMode, void *stream)
{
    exp_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize,
                                                      mulFactor, addOffset, alignMode);
}

void launch_exp_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                            int64_t blockLength, uint32_t tileSize, float mulFactor,
                            float addOffset, uint32_t alignMode, void *stream)
{
    exp_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize,
                                                     mulFactor, addOffset, alignMode);
}

void launch_exp_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                int64_t blockLength, uint32_t tileSize, float mulFactor,
                                float addOffset, uint32_t alignMode, void *stream)
{
    exp_kernel_bf16<<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize,
                                                    mulFactor, addOffset, alignMode);
}

}
