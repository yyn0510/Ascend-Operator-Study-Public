/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file exp_plugin.cpp
 * \brief Exp API layer - torch bindings (compiled with g++)
 */

#include <cmath>
#include <cstdint>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/exp_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("exp(Tensor x, float base=-1.0, float scale=1.0, float shift=0.0) -> Tensor");
}

torch::Tensor exp_meta(const torch::Tensor &x, double base, double scale, double shift)
{
    (void)base;
    (void)scale;
    (void)shift;
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 || x.scalar_type() == torch::kFloat16 ||
                    x.scalar_type() == torch::kBFloat16,
                "exp: x must be float32, float16 or bfloat16");
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("exp", exp_meta);
}

// Fold base/scale/shift into a single multiply-add:
//   base > 0: y = exp((scale * x + shift) * ln(base)) = exp(x * (scale*ln(base)) + shift*ln(base))
//   base <= 0: y = exp(scale * x + shift)
static void calc_exp_factors(double base, double scale, double shift, float *mulFactor, float *addOffset)
{
    double lnBase = 1.0;
    if (base > 0.0) {
        lnBase = std::log(base);
    }
    *mulFactor = static_cast<float>(scale * lnBase);
    *addOffset = static_cast<float>(shift * lnBase);
}

torch::Tensor exp_npu(const torch::Tensor &x, double base, double scale, double shift)
{
    const c10::OptionalDeviceGuard guard(x.device());
    torch::Tensor xCont = x.is_contiguous() ? x : x.contiguous();
    torch::Tensor y = torch::empty(xCont.sizes(), xCont.options());
    int64_t totalLength = xCont.numel();
    if (totalLength == 0) {
        return y;
    }

    float mulFactor = 1.0f;
    float addOffset = 0.0f;
    calc_exp_factors(base, scale, shift, &mulFactor, &addOffset);

    int64_t dtypeSize = static_cast<int64_t>(xCont.element_size());
    int64_t numBlocks = 1;
    int64_t blockLength = 1;
    uint32_t tileSize = 0;
    std::tie(numBlocks, blockLength, tileSize) = calc_exp_tiling_params(totalLength, dtypeSize);

    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    auto x_ptr = (GM_ADDR)xCont.data_ptr();
    auto y_ptr = (GM_ADDR)y.data_ptr();
    auto dtype = x.scalar_type();

    // Align blockLength to 32B granularity when both tensors are 32B aligned,
    // enabling the fast DataCopy path inside the kernel.
    int64_t alignElems = 32 / dtypeSize;
    bool ptrAligned = ((reinterpret_cast<uintptr_t>(x_ptr) % 32) == 0) &&
                      ((reinterpret_cast<uintptr_t>(y_ptr) % 32) == 0);
    if (ptrAligned && (blockLength % alignElems != 0)) {
        blockLength = ((blockLength + alignElems - 1) / alignElems) * alignElems;
        numBlocks = (totalLength + blockLength - 1) / blockLength;
        if (numBlocks < 1) {
            numBlocks = 1;
        }
    }
    uint32_t alignMode = (ptrAligned && (blockLength % alignElems == 0)) ? 1u : 0u;

    auto acl_call = [=]() -> int {
        if (dtype == torch::kFloat32) {
            launch_exp_kernel_float(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize,
                                    mulFactor, addOffset, alignMode, stream);
        } else if (dtype == torch::kFloat16) {
            launch_exp_kernel_half(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize,
                                   mulFactor, addOffset, alignMode, stream);
        } else if (dtype == torch::kBFloat16) {
            launch_exp_kernel_bfloat16(x_ptr, y_ptr, totalLength, numBlocks, blockLength, tileSize,
                                       mulFactor, addOffset, alignMode, stream);
        } else {
            TORCH_CHECK(false, "exp: unsupported dtype");
        }
        return 0;
    };
    at_npu::native::OpCommand::RunOpApi("Exp", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("exp", exp_npu);
}

} // namespace cann_bench
