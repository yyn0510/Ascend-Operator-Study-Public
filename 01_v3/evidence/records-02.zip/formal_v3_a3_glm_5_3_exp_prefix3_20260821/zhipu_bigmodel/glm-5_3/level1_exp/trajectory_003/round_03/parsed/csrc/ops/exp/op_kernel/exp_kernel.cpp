/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file exp_kernel.cpp
 * \brief Exp host code - kernel launch and tiling (compiled with bisheng + -xasc)
 */

#include <tuple>
#include <algorithm>
#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

// Kernel implementation for float / half.
// Computes y = exp(x * mulFactor + addOffset), where the host folds
// base/scale/shift into mulFactor = scale * ln(base) (or scale) and
// addOffset = shift * ln(base) (or shift). half input is upcast to
// float for the computation and cast back at the end, matching the golden.
template <typename T>
__global__ __aicore__ void exp_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                      int64_t blockLength, uint32_t tileSize,
                                      float mulFactor, float addOffset)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t currentBlockLength = totalLength - blockLength * blockIdx;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elementNumPerTile <= 0) {
        return;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf1;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf2;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpBuf1, static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float))));
    pipe.InitBuffer(tmpBuf2, static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float))));

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * blockIdx);

    auto t1 = tmpBuf1.Get<float>();
    auto t2 = tmpBuf2.Get<float>();

    int64_t tileNum = (currentBlockLength + elementNumPerTile - 1) / elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        int64_t calCount = currentBlockLength - offset;
        if (calCount > elementNumPerTile) {
            calCount = elementNumPerTile;
        }
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(calCount * static_cast<int64_t>(sizeof(T))), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();
        if constexpr (std::is_same<T, float>::value) {
            AscendC::Muls(t1, xLocal, mulFactor, calCount);
            AscendC::Adds(t2, t1, addOffset, calCount);
            AscendC::Exp(yLocal, t2, calCount);
        } else {
            AscendC::Cast(t1, xLocal, AscendC::RoundMode::CAST_NONE, calCount);
            AscendC::Muls(t2, t1, mulFactor, calCount);
            AscendC::Adds(t1, t2, addOffset, calCount);
            AscendC::Exp(t2, t1, calCount);
            AscendC::Cast(yLocal, t2, AscendC::RoundMode::CAST_NONE, calCount);
        }
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

// Dedicated bfloat16 kernel. The __bf16 type is only supported inside device
// code on this target, so this is a standalone non-template __global__ kernel:
// the host launch wrapper below never names the __bf16 type.
__global__ __aicore__ void exp_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                           int64_t blockLength, uint32_t tileSize,
                                           float mulFactor, float addOffset)
{
    int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t currentBlockLength = totalLength - blockLength * blockIdx;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    if (currentBlockLength <= 0) {
        return;
    }

    constexpr int64_t BF16_SIZE = 2;
    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / BF16_SIZE;
    if (elementNumPerTile <= 0) {
        return;
    }

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<__bf16> xGm;
    AscendC::GlobalTensor<__bf16> yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf1;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf2;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpBuf1, static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float))));
    pipe.InitBuffer(tmpBuf2, static_cast<uint32_t>(elementNumPerTile * static_cast<int64_t>(sizeof(float))));

    xGm.SetGlobalBuffer((__gm__ __bf16 *)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ __bf16 *)y + blockLength * blockIdx);

    auto t1 = tmpBuf1.Get<float>();
    auto t2 = tmpBuf2.Get<float>();

    int64_t tileNum = (currentBlockLength + elementNumPerTile - 1) / elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        int64_t calCount = currentBlockLength - offset;
        if (calCount > elementNumPerTile) {
            calCount = elementNumPerTile;
        }
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(calCount * BF16_SIZE), 0, 0, 0};
        AscendC::DataCopyPadExtParams<__bf16> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<__bf16>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<__bf16>();

        auto yLocal = outQueueY.AllocTensor<__bf16>();
        AscendC::Cast(t1, xLocal, AscendC::RoundMode::CAST_NONE, calCount);
        AscendC::Muls(t2, t1, mulFactor, calCount);
        AscendC::Adds(t1, t2, addOffset, calCount);
        AscendC::Exp(t2, t1, calCount);
        AscendC::Cast(yLocal, t2, AscendC::RoundMode::CAST_RINT, calCount);
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<__bf16>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

// Tiling function
std::tuple<int64_t, int64_t, uint32_t> calc_exp_tiling_params(int64_t totalLength, int64_t dtypeSize)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 2048;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }
    if (dtypeSize <= 0) {
        dtypeSize = 4;
    }

    int64_t numBlocks = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks < 1) {
        numBlocks = 1;
    }
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    // UB usage per element: in-queue (depth 2) + out-queue (depth 2) + two fp32 temp buffers
    int64_t bytesPerElem = 4 * dtypeSize + 8;
    int64_t usableUb = static_cast<int64_t>(ubSize) - 32768;
    if (usableUb < 16384) {
        usableUb = static_cast<int64_t>(ubSize) / 2;
    }
    if (usableUb < 1024) {
        usableUb = 1024;
    }
    int64_t maxElems = usableUb / bytesPerElem;
    maxElems = maxElems / 128 * 128;
    if (maxElems < 128) {
        maxElems = 128;
    }
    uint32_t tileSize = static_cast<uint32_t>(maxElems * dtypeSize);
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_exp_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                             int64_t blockLength, uint32_t tileSize, float mulFactor,
                             float addOffset, void *stream)
{
    exp_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize,
                                                      mulFactor, addOffset);
}

void launch_exp_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                            int64_t blockLength, uint32_t tileSize, float mulFactor,
                            float addOffset, void *stream)
{
    exp_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize,
                                                     mulFactor, addOffset);
}

void launch_exp_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks,
                                int64_t blockLength, uint32_t tileSize, float mulFactor,
                                float addOffset, void *stream)
{
    exp_kernel_bf16<<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize,
                                                    mulFactor, addOffset);
}

}
