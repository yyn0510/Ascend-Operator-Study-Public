/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_kernel.cpp
 * \brief ForeachNorm host code - kernel launch and tiling (compiled with bisheng + -xasc)
 */

#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

// Reduction mode:
//   0: general finite p  -> partial = sum(|x|^p), final = sum^(1/p)
//   1: p == +inf         -> partial = max(|x|),   final = max
//   2: p == -inf         -> partial = min(|x|),   final = min
//   3: p == 1.0          -> partial = sum(|x|),   final = sum
//   4: p == 2.0          -> partial = sum(x*x),   final = sum^(1/2)
//   5: p == 0.0          -> partial = count(non-zero), final = count
constexpr static int32_t NORM_MODE_GENERAL = 0;
constexpr static int32_t NORM_MODE_POS_INF = 1;
constexpr static int32_t NORM_MODE_NEG_INF = 2;
constexpr static int32_t NORM_MODE_P_ONE = 3;
constexpr static int32_t NORM_MODE_P_TWO = 4;
constexpr static int32_t NORM_MODE_P_ZERO = 5;

constexpr static float NORM_FLOAT_MAX = 3.402823466e38f;
constexpr static float NORM_FLOAT_MIN_NORMAL = 1.17549435e-38f;

// fp32 partial reduction: each block reduces its chunk into a 32-byte
// aligned slot of 8 fp32 values at partial[blockIdx * 8]
__global__ __aicore__ void foreach_norm_partial_kernel(
    GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t blockLength,
    int32_t tileElemNum, float p, int32_t mode)
{
    const int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<float> xGm;
    AscendC::GlobalTensor<float> partialGm;
    xGm.SetGlobalBuffer((__gm__ float *)x + blockLength * blockIdx);
    partialGm.SetGlobalBuffer((__gm__ float *)partial + blockIdx * 8);

    constexpr int32_t PIPE_DEPTH = 2;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPE_DEPTH> inQueue;
    pipe.InitBuffer(inQueue, PIPE_DEPTH,
                    static_cast<uint32_t>(tileElemNum * sizeof(float)));

    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> f32Que;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> powQue;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> expQue;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> accQue;
    pipe.InitBuffer(f32Que, 1, static_cast<uint32_t>(tileElemNum * sizeof(float)));
    pipe.InitBuffer(powQue, 1, static_cast<uint32_t>(tileElemNum * sizeof(float)));
    pipe.InitBuffer(expQue, 1, static_cast<uint32_t>(tileElemNum * sizeof(float)));
    pipe.InitBuffer(accQue, 1, static_cast<uint32_t>(tileElemNum * sizeof(float)));

    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    pipe.InitBuffer(outQueue, 1, 32);

    auto f32Local = f32Que.AllocTensor<float>();
    auto powLocal = powQue.AllocTensor<float>();
    auto expLocal = expQue.AllocTensor<float>();
    auto accLocal = accQue.AllocTensor<float>();

    float initVal = 0.0f;
    if (mode == NORM_MODE_POS_INF) {
        initVal = -NORM_FLOAT_MAX;
    } else if (mode == NORM_MODE_NEG_INF) {
        initVal = NORM_FLOAT_MAX;
    }
    AscendC::Duplicate(accLocal, initVal, tileElemNum);
    if (mode == NORM_MODE_GENERAL) {
        AscendC::Duplicate(expLocal, p, tileElemNum);
    } else if (mode == NORM_MODE_P_ZERO) {
        AscendC::Duplicate(expLocal, NORM_FLOAT_MIN_NORMAL, tileElemNum);
    }

    int64_t currentBlockLength = totalLength - blockLength * blockIdx;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    int64_t tileNum = 0;
    int64_t tailElemNum = 0;
    if (currentBlockLength > 0) {
        tileNum = currentBlockLength / tileElemNum;
        tailElemNum = currentBlockLength - tileNum * tileElemNum;
    }
    const int64_t totalTiles = tileNum + (tailElemNum > 0 ? 1 : 0);

    AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};

    for (int64_t i = 0; i < totalTiles; ++i) {
        const int64_t count = (i < tileNum) ? tileElemNum : tailElemNum;
        const int64_t offset = i * tileElemNum;
        const int32_t calCount = static_cast<int32_t>(count);
        AscendC::DataCopyExtParams copyParams{
            1, static_cast<uint32_t>(count * sizeof(float)), 0, 0, 0};
        auto xLocal = inQueue.AllocTensor<float>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<float>();

        AscendC::Abs(f32Local, xLocal, calCount);
        if (mode == NORM_MODE_POS_INF) {
            AscendC::Max(accLocal, accLocal, f32Local, calCount);
        } else if (mode == NORM_MODE_NEG_INF) {
            AscendC::Min(accLocal, accLocal, f32Local, calCount);
        } else if (mode == NORM_MODE_P_ONE) {
            AscendC::Add(accLocal, accLocal, f32Local, calCount);
        } else if (mode == NORM_MODE_P_TWO) {
            AscendC::Mul(powLocal, f32Local, f32Local, calCount);
            AscendC::Add(accLocal, accLocal, powLocal, calCount);
        } else if (mode == NORM_MODE_P_ZERO) {
            // count non-zero: min(|x| / max(|x|, min_normal), 1)
            AscendC::Max(powLocal, f32Local, expLocal, calCount);
            AscendC::Div(f32Local, f32Local, powLocal, calCount);
            AscendC::Duplicate(powLocal, 1.0f, calCount);
            AscendC::Min(f32Local, f32Local, powLocal, calCount);
            AscendC::Add(accLocal, accLocal, f32Local, calCount);
        } else {
            // |x|^p = exp(p * ln|x|)
            AscendC::Ln(powLocal, f32Local, calCount);
            AscendC::Mul(powLocal, powLocal, expLocal, calCount);
            AscendC::Exp(powLocal, powLocal, calCount);
            AscendC::Add(accLocal, accLocal, powLocal, calCount);
        }
        inQueue.FreeTensor(xLocal);
    }

    // in-block tree reduction down to exactly 8 lanes (tileElemNum is a
    // power of two, so the halving chain always ends at 8); lanes that were
    // never touched by the per-tile accumulation keep the identity init
    // value, so reducing all 8 slots of the output word stays correct
    int32_t len = tileElemNum;
    while (len > 8) {
        const int32_t half = (len + 1) / 2;
        const int32_t cnt = len - half;
        if (mode == NORM_MODE_POS_INF) {
            AscendC::Max(accLocal, accLocal, accLocal[half], cnt);
        } else if (mode == NORM_MODE_NEG_INF) {
            AscendC::Min(accLocal, accLocal, accLocal[half], cnt);
        } else {
            AscendC::Add(accLocal, accLocal, accLocal[half], cnt);
        }
        len = half;
    }

    auto outLocal = outQueue.AllocTensor<float>();
    AscendC::Adds(outLocal, accLocal, 0.0f, 8);
    outQueue.EnQue(outLocal);
    outLocal = outQueue.DeQue<float>();
    AscendC::DataCopyExtParams outParams{1, 32, 0, 0, 0};
    AscendC::DataCopyPad(partialGm, outLocal, outParams);
    outQueue.FreeTensor(outLocal);
}

// single-block finalize: merge all block partials and write the scalar result
__global__ __aicore__ void foreach_norm_finalize_kernel(
    GM_ADDR partial, GM_ADDR y, int32_t numBlocks, float p, int32_t mode)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<float> partialGm;
    AscendC::GlobalTensor<float> yGm;
    partialGm.SetGlobalBuffer((__gm__ float *)partial);
    yGm.SetGlobalBuffer((__gm__ float *)y);

    uint32_t inBytes = static_cast<uint32_t>(numBlocks) * 32u;
    if (inBytes < 64u) {
        inBytes = 64u;
    }
    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue;
    pipe.InitBuffer(inQueue, 1, inBytes);

    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> invQue;
    pipe.InitBuffer(invQue, 1, 64);

    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    pipe.InitBuffer(outQueue, 1, 64);

    auto inLocal = inQueue.AllocTensor<float>();
    AscendC::DataCopyExtParams copyParams{
        1, static_cast<uint32_t>(numBlocks) * 32u, 0, 0, 0};
    AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};
    AscendC::DataCopyPad(inLocal, partialGm, copyParams, padParams);
    inQueue.EnQue(inLocal);
    inLocal = inQueue.DeQue<float>();

    auto invLocal = invQue.AllocTensor<float>();
    AscendC::Duplicate(invLocal, 1.0f / p, 16);

    // merge all block partials (each block contributed 8 fp32 slots whose
    // tail lanes hold the identity value, so a plain tree reduction over
    // numBlocks * 8 elements yields the global sum / max / min)
    int32_t len = numBlocks * 8;
    while (len > 1) {
        const int32_t half = (len + 1) / 2;
        const int32_t cnt = len - half;
        if (mode == NORM_MODE_POS_INF) {
            AscendC::Max(inLocal, inLocal, inLocal[half], cnt);
        } else if (mode == NORM_MODE_NEG_INF) {
            AscendC::Min(inLocal, inLocal, inLocal[half], cnt);
        } else {
            AscendC::Add(inLocal, inLocal, inLocal[half], cnt);
        }
        len = half;
    }

    if (mode == NORM_MODE_GENERAL || mode == NORM_MODE_P_TWO) {
        // sum^(1/p) = exp(ln(sum) / p)
        AscendC::Ln(inLocal, inLocal, 16);
        AscendC::Mul(inLocal, inLocal, invLocal, 16);
        AscendC::Exp(inLocal, inLocal, 16);
    }

    auto outLocal = outQueue.AllocTensor<float>();
    AscendC::Adds(outLocal, inLocal, 0.0f, 16);
    outQueue.EnQue(outLocal);
    outLocal = outQueue.DeQue<float>();
    AscendC::DataCopyExtParams outParams{
        1, static_cast<uint32_t>(sizeof(float)), 0, 0, 0};
    AscendC::DataCopyPad(yGm, outLocal, outParams);
    outQueue.FreeTensor(outLocal);
}

// Tiling function
extern "C" {

void calc_foreach_norm_tiling(int64_t totalLength, int64_t *numBlocks,
                              int64_t *blockLength, int32_t *tileElemNum)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 16384;
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t nb = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (nb < 1) {
        nb = 1;
    }
    if (nb > coreNum) {
        nb = coreNum;
    }
    int64_t bl = (totalLength + nb - 1) / nb;
    if (bl < 1) {
        bl = 1;
    }
    // round block length up to a multiple of 16 elements so that every
    // per-block GM base offset stays 32-byte aligned
    bl = (bl + 15) / 16 * 16;

    // per element UB cost: double buffered fp32 input + 4 fp32 scratch tiles
    const int64_t bytesPerElem = 24;
    int64_t budget = static_cast<int64_t>(ubSize) / 8 * 7 - 1024;
    if (budget < 4096) {
        budget = 4096;
    }
    int64_t te = budget / bytesPerElem;
    if (te > 8192) {
        te = 8192;
    }
    // round down to a power of two so the in-block tree reduction always
    // terminates with exactly 8 active lanes
    int64_t p2 = 64;
    while (p2 * 2 <= te) {
        p2 *= 2;
    }
    te = p2;

    *numBlocks = nb;
    *blockLength = bl;
    *tileElemNum = static_cast<int32_t>(te);
}

// Launch wrappers - regular C functions callable from g++
void launch_foreach_norm_partial(GM_ADDR x, GM_ADDR partial,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    int32_t tileElemNum, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<<<numBlocks, nullptr, stream>>>(
        x, partial, totalLength, blockLength, tileElemNum, p, mode);
}

void launch_foreach_norm_finalize(GM_ADDR partial, GM_ADDR y,
    int32_t numBlocks, float p, int32_t mode, void *stream)
{
    foreach_norm_finalize_kernel<<<1, nullptr, stream>>>(
        partial, y, numBlocks, p, mode);
}

}
