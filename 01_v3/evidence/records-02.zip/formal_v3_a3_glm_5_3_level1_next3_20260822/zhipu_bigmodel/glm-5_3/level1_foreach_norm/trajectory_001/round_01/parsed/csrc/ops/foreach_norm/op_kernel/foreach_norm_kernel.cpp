/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_kernel.cpp
 * \brief ForeachNorm host code - kernel launch and tiling (compiled with bisheng + -xasc)
 */

#include <type_traits>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

// Reduction mode:
//   0: general finite p  -> partial = sum(|x|^p), final = sum^(1/p)
//   1: p == +inf         -> partial = max(|x|),   final = max
//   2: p == -inf         -> partial = min(|x|),   final = min
//   3: p == 1.0          -> partial = sum(|x|),   final = sum
//   4: p == 2.0          -> partial = sum(x*x),   final = sqrt(sum)
//   5: p == 0.0          -> partial = count(non-zero), final = count
constexpr static int32_t NORM_MODE_GENERAL = 0;
constexpr static int32_t NORM_MODE_POS_INF = 1;
constexpr static int32_t NORM_MODE_NEG_INF = 2;
constexpr static int32_t NORM_MODE_P_ONE = 3;
constexpr static int32_t NORM_MODE_P_TWO = 4;
constexpr static int32_t NORM_MODE_P_ZERO = 5;

constexpr static float NORM_FLOAT_MAX = 3.402823466e38f;
constexpr static float NORM_FLOAT_MIN_NORMAL = 1.17549435e-38f;

template <typename T>
__global__ __aicore__ void foreach_norm_partial_kernel(
    GM_ADDR x, GM_ADDR partial, int64_t totalLength, int64_t blockLength,
    int32_t tileElemNum, float p, int32_t mode)
{
    const int64_t blockIdx = static_cast<int64_t>(AscendC::GetBlockIdx());
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<float> partialGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * blockIdx);
    partialGm.SetGlobalBuffer((__gm__ float *)partial + blockIdx);

    constexpr int32_t PIPE_DEPTH = 2;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPE_DEPTH> inQueue;
    pipe.InitBuffer(inQueue, PIPE_DEPTH,
                    static_cast<uint32_t>(tileElemNum * sizeof(T)));

    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> f32Que;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> powQue;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> expQue;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> accQue;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> tmpQue;
    pipe.InitBuffer(f32Que, 1, static_cast<uint32_t>(tileElemNum * sizeof(float)));
    pipe.InitBuffer(powQue, 1, static_cast<uint32_t>(tileElemNum * sizeof(float)));
    pipe.InitBuffer(expQue, 1, static_cast<uint32_t>(tileElemNum * sizeof(float)));
    pipe.InitBuffer(accQue, 1, static_cast<uint32_t>(tileElemNum * sizeof(float)));
    pipe.InitBuffer(tmpQue, 1, static_cast<uint32_t>(tileElemNum * 2 * sizeof(float)));

    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    pipe.InitBuffer(outQueue, 1, 64);

    auto f32Local = f32Que.AllocTensor<float>();
    auto powLocal = powQue.AllocTensor<float>();
    auto expLocal = expQue.AllocTensor<float>();
    auto accLocal = accQue.AllocTensor<float>();
    auto tmpLocal = tmpQue.AllocTensor<uint8_t>();

    float initVal = 0.0f;
    if (mode == NORM_MODE_POS_INF) {
        initVal = -NORM_FLOAT_MAX;
    } else if (mode == NORM_MODE_NEG_INF) {
        initVal = NORM_FLOAT_MAX;
    }
    AscendC::Duplicate(accLocal, initVal, tileElemNum);
    if (mode == NORM_MODE_GENERAL) {
        AscendC::Duplicate(expLocal, p, tileElemNum);
    } else if (mode == NORM_MODE_P_ZERO) {
        AscendC::Duplicate(expLocal, NORM_FLOAT_MIN_NORMAL, tileElemNum);
    }

    int64_t currentBlockLength = totalLength - blockLength * blockIdx;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    const int64_t tileNum = currentBlockLength / tileElemNum;
    const int64_t tailElemNum = currentBlockLength - tileNum * tileElemNum;
    const int64_t totalTiles = tileNum + (tailElemNum > 0 ? 1 : 0);

    AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

    for (int64_t i = 0; i < totalTiles; ++i) {
        const int64_t count = (i < tileNum) ? tileElemNum : tailElemNum;
        const int64_t offset = i * tileElemNum;
        const int32_t calCount = static_cast<int32_t>(count);
        AscendC::DataCopyExtParams copyParams{
            1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        if constexpr (std::is_same<T, float>::value) {
            AscendC::Abs(f32Local, xLocal, calCount);
        } else {
            AscendC::Cast(f32Local, xLocal, calCount, AscendC::RoundMode::CAST_NONE);
            AscendC::Abs(f32Local, f32Local, calCount);
        }

        if (mode == NORM_MODE_POS_INF) {
            AscendC::Max(accLocal, accLocal, f32Local, calCount);
        } else if (mode == NORM_MODE_NEG_INF) {
            AscendC::Min(accLocal, accLocal, f32Local, calCount);
        } else if (mode == NORM_MODE_P_ONE) {
            AscendC::Add(accLocal, accLocal, f32Local, calCount);
        } else if (mode == NORM_MODE_P_TWO) {
            AscendC::Mul(powLocal, f32Local, f32Local, calCount);
            AscendC::Add(accLocal, accLocal, powLocal, calCount);
        } else if (mode == NORM_MODE_P_ZERO) {
            AscendC::Max(powLocal, f32Local, expLocal, calCount);
            AscendC::Div(f32Local, f32Local, powLocal, calCount);
            AscendC::Add(accLocal, accLocal, f32Local, calCount);
        } else {
            AscendC::Pow(powLocal, f32Local, expLocal, calCount);
            AscendC::Add(accLocal, accLocal, powLocal, calCount);
        }
        inQueue.FreeTensor(xLocal);
    }

    auto outLocal = outQueue.AllocTensor<float>();
    if (mode == NORM_MODE_POS_INF) {
        AscendC::ReduceMax(outLocal, accLocal, tmpLocal, tileElemNum);
    } else if (mode == NORM_MODE_NEG_INF) {
        AscendC::ReduceMin(outLocal, accLocal, tmpLocal, tileElemNum);
    } else {
        AscendC::ReduceSum(outLocal, accLocal, tmpLocal, tileElemNum);
    }
    outQueue.EnQue(outLocal);
    outLocal = outQueue.DeQue<float>();
    AscendC::DataCopyExtParams outParams{1, 4, 0, 0, 0};
    AscendC::DataCopyPad(partialGm, outLocal, outParams);
    outQueue.FreeTensor(outLocal);
}

template <typename T>
__global__ __aicore__ void foreach_norm_finalize_kernel(
    GM_ADDR partial, GM_ADDR y, int32_t numBlocks, float p, int32_t mode)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<float> partialGm;
    AscendC::GlobalTensor<T> yGm;
    partialGm.SetGlobalBuffer((__gm__ float *)partial);
    yGm.SetGlobalBuffer((__gm__ T *)y);

    AscendC::TQue<AscendC::QuePosition::VECIN, 1> inQueue;
    uint32_t inBytes = (static_cast<uint32_t>(numBlocks) * 4u + 31u) & ~31u;
    if (inBytes < 64u) {
        inBytes = 64u;
    }
    pipe.InitBuffer(inQueue, 1, inBytes);

    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> tmpQue;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> invQue;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> resQue;
    pipe.InitBuffer(tmpQue, 1, 4096);
    pipe.InitBuffer(invQue, 1, 64);
    pipe.InitBuffer(resQue, 1, 64);

    AscendC::TQue<AscendC::QuePosition::VECOUT, 1> outQueue;
    pipe.InitBuffer(outQueue, 1, 64);

    auto inLocal = inQueue.AllocTensor<float>();
    AscendC::DataCopyExtParams copyParams{
        1, static_cast<uint32_t>(numBlocks * 4), 0, 0, 0};
    AscendC::DataCopyPadExtParams<float> padParams{false, 0, 0, 0};
    AscendC::DataCopyPad(inLocal, partialGm, copyParams, padParams);
    inQueue.EnQue(inLocal);
    inLocal = inQueue.DeQue<float>();

    auto tmpLocal = tmpQue.AllocTensor<uint8_t>();
    auto invLocal = invQue.AllocTensor<float>();

    if constexpr (std::is_same<T, float>::value) {
        auto outLocal = outQueue.AllocTensor<float>();
        if (mode == NORM_MODE_POS_INF) {
            AscendC::ReduceMax(outLocal, inLocal, tmpLocal, numBlocks);
        } else if (mode == NORM_MODE_NEG_INF) {
            AscendC::ReduceMin(outLocal, inLocal, tmpLocal, numBlocks);
        } else {
            AscendC::ReduceSum(outLocal, inLocal, tmpLocal, numBlocks);
        }
        if (mode == NORM_MODE_GENERAL) {
            AscendC::Duplicate(invLocal, 1.0f / p, 16);
            AscendC::Pow(outLocal, outLocal, invLocal, 16);
        } else if (mode == NORM_MODE_P_TWO) {
            AscendC::Sqrt(outLocal, outLocal, 16);
        }
        outQueue.EnQue(outLocal);
        outLocal = outQueue.DeQue<float>();
        AscendC::DataCopyExtParams outParams{1, 4, 0, 0, 0};
        AscendC::DataCopyPad(yGm, outLocal, outParams);
        outQueue.FreeTensor(outLocal);
    } else {
        auto resLocal = resQue.AllocTensor<float>();
        if (mode == NORM_MODE_POS_INF) {
            AscendC::ReduceMax(resLocal, inLocal, tmpLocal, numBlocks);
        } else if (mode == NORM_MODE_NEG_INF) {
            AscendC::ReduceMin(resLocal, inLocal, tmpLocal, numBlocks);
        } else {
            AscendC::ReduceSum(resLocal, inLocal, tmpLocal, numBlocks);
        }
        if (mode == NORM_MODE_GENERAL) {
            AscendC::Duplicate(invLocal, 1.0f / p, 16);
            AscendC::Pow(resLocal, resLocal, invLocal, 16);
        } else if (mode == NORM_MODE_P_TWO) {
            AscendC::Sqrt(resLocal, resLocal, 16);
        }
        auto outLocal = outQueue.AllocTensor<T>();
        AscendC::Cast(outLocal, resLocal, 16, AscendC::RoundMode::CAST_RINT);
        outQueue.EnQue(outLocal);
        outLocal = outQueue.DeQue<T>();
        AscendC::DataCopyExtParams outParams{
            1, static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm, outLocal, outParams);
        outQueue.FreeTensor(outLocal);
    }
}

// Tiling function
extern "C" {

void calc_foreach_norm_tiling(int64_t totalLength, int32_t elemSize,
                              int64_t *numBlocks, int64_t *blockLength,
                              int32_t *tileElemNum)
{
    constexpr int64_t MIN_ELEMS_PER_CORE = 16384;
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) {
        coreNum = 1;
    }

    int64_t nb = (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE;
    if (nb < 1) {
        nb = 1;
    }
    if (nb > coreNum) {
        nb = coreNum;
    }
    int64_t bl = (totalLength + nb - 1) / nb;
    if (bl < 1) {
        bl = 1;
    }

    // per element UB cost: 2*elemSize (double buffered input) + 5 fp32 tiles
    const int64_t bytesPerElem = 2LL * static_cast<int64_t>(elemSize) + 24LL;
    int64_t budget = static_cast<int64_t>(ubSize) / 8 * 7;
    int64_t te = budget / bytesPerElem;
    if (te > 8192) {
        te = 8192;
    }
    if (te < 64) {
        te = 64;
    }
    te = te / 64 * 64;
    if (te < 64) {
        te = 64;
    }

    *numBlocks = nb;
    *blockLength = bl;
    *tileElemNum = static_cast<int32_t>(te);
}

// Launch wrappers - regular C functions callable from g++
void launch_foreach_norm_partial_float(GM_ADDR x, GM_ADDR partial,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    int32_t tileElemNum, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<float><<<numBlocks, nullptr, stream>>>(
        x, partial, totalLength, blockLength, tileElemNum, p, mode);
}

void launch_foreach_norm_partial_half(GM_ADDR x, GM_ADDR partial,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    int32_t tileElemNum, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<half><<<numBlocks, nullptr, stream>>>(
        x, partial, totalLength, blockLength, tileElemNum, p, mode);
}

void launch_foreach_norm_partial_bfloat16(GM_ADDR x, GM_ADDR partial,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    int32_t tileElemNum, float p, int32_t mode, void *stream)
{
    foreach_norm_partial_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(
        x, partial, totalLength, blockLength, tileElemNum, p, mode);
}

void launch_foreach_norm_finalize_float(GM_ADDR partial, GM_ADDR y,
    int32_t numBlocks, float p, int32_t mode, void *stream)
{
    foreach_norm_finalize_kernel<float><<<1, nullptr, stream>>>(
        partial, y, numBlocks, p, mode);
}

void launch_foreach_norm_finalize_half(GM_ADDR partial, GM_ADDR y,
    int32_t numBlocks, float p, int32_t mode, void *stream)
{
    foreach_norm_finalize_kernel<half><<<1, nullptr, stream>>>(
        partial, y, numBlocks, p, mode);
}

void launch_foreach_norm_finalize_bfloat16(GM_ADDR partial, GM_ADDR y,
    int32_t numBlocks, float p, int32_t mode, void *stream)
{
    foreach_norm_finalize_kernel<bfloat16_t><<<1, nullptr, stream>>>(
        partial, y, numBlocks, p, mode);
}

}
