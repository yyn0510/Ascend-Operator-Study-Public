/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_launch.h
 * \brief Launch function declarations for g++
 */

#ifndef FOREACH_NORM_LAUNCH_H
#define FOREACH_NORM_LAUNCH_H

#include <cstdint>

#ifndef GM_ADDR
#define GM_ADDR void*
#endif

// Tiling function declaration
extern "C" {

void calc_foreach_norm_tiling(int64_t totalLength, int32_t elemSize,
                              int64_t *numBlocks, int64_t *blockLength,
                              int32_t *tileElemNum);

// Partial reduction kernels: each block reduces its chunk into a 32-byte
// aligned slot of 8 fp32 values at partial[blockIdx*8]
void launch_foreach_norm_partial_float(GM_ADDR x, GM_ADDR partial,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    int32_t tileElemNum, float p, int32_t mode, void *stream);

void launch_foreach_norm_partial_half(GM_ADDR x, GM_ADDR partial,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    int32_t tileElemNum, float p, int32_t mode, void *stream);

void launch_foreach_norm_partial_bfloat16(GM_ADDR x, GM_ADDR partial,
    int64_t totalLength, int64_t numBlocks, int64_t blockLength,
    int32_t tileElemNum, float p, int32_t mode, void *stream);

// Finalize kernels: single block merges partials and writes the scalar output
void launch_foreach_norm_finalize_float(GM_ADDR partial, GM_ADDR y,
    int32_t numBlocks, float p, int32_t mode, void *stream);

void launch_foreach_norm_finalize_half(GM_ADDR partial, GM_ADDR y,
    int32_t numBlocks, float p, int32_t mode, void *stream);

void launch_foreach_norm_finalize_bfloat16(GM_ADDR partial, GM_ADDR y,
    int32_t numBlocks, float p, int32_t mode, void *stream);

}

#endif // FOREACH_NORM_LAUNCH_H
