/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file foreach_norm_plugin.cpp
 * \brief ForeachNorm API layer - torch bindings (compiled with g++)
 */

#include <cmath>
#include <vector>

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/foreach_norm_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("foreach_norm(Tensor[] x, float scalar) -> Tensor[]");
}

std::vector<torch::Tensor> foreach_norm_meta(
    const std::vector<torch::Tensor> &x, double scalar)
{
    std::vector<torch::Tensor> y;
    y.reserve(x.size());
    for (const auto &t : x) {
        y.push_back(torch::empty({}, t.options()));
    }
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("foreach_norm", foreach_norm_meta);
}

// mode: 0 general p, 1 +inf, 2 -inf, 3 p==1, 4 p==2, 5 p==0
static int32_t foreach_norm_mode(double scalar)
{
    if (std::isinf(scalar)) {
        return (scalar > 0.0) ? 1 : 2;
    }
    if (scalar == 0.0) {
        return 5;
    }
    if (scalar == 1.0) {
        return 3;
    }
    if (scalar == 2.0) {
        return 4;
    }
    return 0;
}

std::vector<torch::Tensor> foreach_norm_npu(
    const std::vector<torch::Tensor> &x, double scalar)
{
    if (x.empty()) {
        return {};
    }
    const c10::OptionalDeviceGuard guard(x[0].device());
    auto stream = c10_npu::getCurrentNPUStream().stream(false);

    std::vector<torch::Tensor> xc;
    xc.reserve(x.size());
    for (const auto &t : x) {
        xc.push_back(t.contiguous());
    }

    const auto dt = xc[0].scalar_type();
    TORCH_CHECK(dt == torch::kFloat32 || dt == torch::kFloat16 ||
                    dt == torch::kBFloat16,
                "foreach_norm only supports float32/float16/bfloat16");
    for (const auto &t : xc) {
        TORCH_CHECK(t.scalar_type() == dt,
                    "foreach_norm requires all tensors to have the same dtype");
    }

    auto y = foreach_norm_meta(xc, scalar);

    const int64_t listLen = static_cast<int64_t>(xc.size());
    const int32_t mode = foreach_norm_mode(scalar);
    const float p = static_cast<float>(scalar);

    int32_t elemSize = 4;
    if (dt == torch::kFloat16 || dt == torch::kBFloat16) {
        elemSize = 2;
    }

    std::vector<int64_t> numBlocks(listLen);
    std::vector<int64_t> blockLength(listLen);
    std::vector<int32_t> tileElemNum(listLen);
    int64_t maxNumBlocks = 1;
    for (int64_t i = 0; i < listLen; ++i) {
        calc_foreach_norm_tiling(xc[i].numel(), elemSize,
                                 &numBlocks[i], &blockLength[i], &tileElemNum[i]);
        if (numBlocks[i] > maxNumBlocks) {
            maxNumBlocks = numBlocks[i];
        }
    }

    // 8 fp32 slots (32 bytes) per block for aligned partial results
    auto workspace = torch::empty({maxNumBlocks * 8},
                                  xc[0].options().dtype(torch::kFloat32));
    auto wsPtr = (GM_ADDR)workspace.data_ptr();

    auto acl_call = [=]() -> int {
        for (int64_t i = 0; i < listLen; ++i) {
            auto xp = (GM_ADDR)xc[i].data_ptr();
            auto yp = (GM_ADDR)y[i].data_ptr();
            const int64_t totalLength = xc[i].numel();
            if (dt == torch::kFloat32) {
                launch_foreach_norm_partial_float(
                    xp, wsPtr, totalLength, numBlocks[i], blockLength[i],
                    tileElemNum[i], p, mode, stream);
                launch_foreach_norm_finalize_float(
                    wsPtr, yp, static_cast<int32_t>(numBlocks[i]), p, mode, stream);
            } else if (dt == torch::kFloat16) {
                launch_foreach_norm_partial_half(
                    xp, wsPtr, totalLength, numBlocks[i], blockLength[i],
                    tileElemNum[i], p, mode, stream);
                launch_foreach_norm_finalize_half(
                    wsPtr, yp, static_cast<int32_t>(numBlocks[i]), p, mode, stream);
            } else {
                launch_foreach_norm_partial_bfloat16(
                    xp, wsPtr, totalLength, numBlocks[i], blockLength[i],
                    tileElemNum[i], p, mode, stream);
                launch_foreach_norm_finalize_bfloat16(
                    wsPtr, yp, static_cast<int32_t>(numBlocks[i]), p, mode, stream);
            }
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("ForeachNorm", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("foreach_norm", foreach_norm_npu);
}

} // namespace cann_bench
