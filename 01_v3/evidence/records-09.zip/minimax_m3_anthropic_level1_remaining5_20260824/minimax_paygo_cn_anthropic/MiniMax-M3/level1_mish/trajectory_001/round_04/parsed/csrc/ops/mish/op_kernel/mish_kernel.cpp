/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish activation kernel: y = x * tanh(softplus(x))
 *
 * Numerically stable computation:
 *   softplus(x) = max(x, 0) + ln(1 + exp(-|x|))
 *   y = x * tanh(softplus(x))
 *
 * All per-tile work is inlined into the __global__ __aicore__ kernel to avoid
 * any cross-function __aicore__ propagation issues.
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;

    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf1;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf2;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpBuf1, tileSize);
    pipe.InitBuffer(tmpBuf2, tileSize);

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - AscendC::GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    int64_t elementNumPerTile = tileSize / sizeof(T);
    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    // Persistent local tensor views over the temp UB buffers; reused across tiles
    auto tmp1 = tmpBuf1.Get<T>();
    auto tmp2 = tmpBuf2.Get<T>();

    // Full tiles
    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        int64_t count = elementNumPerTile;

        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        // Load x
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        // Compute ln(1 + exp(-|x|)) into tmp1
        AscendC::Abs(tmp1, xLocal, count);
        AscendC::Muls(tmp1, tmp1, T(-1.0f), count);
        AscendC::Exp(tmp1, tmp1, count);
        AscendC::Adds(tmp1, tmp1, T(1.0f), count);
        AscendC::Ln(tmp1, tmp1, count);

        // Compute max(x, 0) into tmp2
        AscendC::Maxs(tmp2, xLocal, T(0.0f), count);

        // softplus(x) = max(x, 0) + ln(1 + exp(-|x|))  -> tmp2
        AscendC::Add(tmp2, tmp2, tmp1, count);

        // tanh(softplus(x)) -> tmp2
        AscendC::Tanh(tmp2, tmp2, count);

        // y = x * tanh(softplus(x))
        auto yLocal = outQueueY.AllocTensor<T>();
        AscendC::Mul(yLocal, xLocal, tmp2, count);

        inQueueX.FreeTensor(xLocal);
        outQueueY.EnQue(yLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }

    // Tail tile (if any leftover elements)
    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        int64_t count = tailTileElementNum;

        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        AscendC::Abs(tmp1, xLocal, count);
        AscendC::Muls(tmp1, tmp1, T(-1.0f), count);
        AscendC::Exp(tmp1, tmp1, count);
        AscendC::Adds(tmp1, tmp1, T(1.0f), count);
        AscendC::Ln(tmp1, tmp1, count);
        AscendC::Maxs(tmp2, xLocal, T(0.0f), count);
        AscendC::Add(tmp2, tmp2, tmp1, count);
        AscendC::Tanh(tmp2, tmp2, count);

        auto yLocal = outQueueY.AllocTensor<T>();
        AscendC::Mul(yLocal, xLocal, tmp2, count);

        inQueueX.FreeTensor(xLocal);
        outQueueY.EnQue(yLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

/*!
 * \brief Compute tiling parameters: (numBlocks, blockLength, tileSize).
 *
 *   numBlocks  : number of AI Vector cores to use.
 *   blockLength: total elements per core (last core may be smaller).
 *   tileSize   : bytes per tile in UB.
 *
 * UB accounting (per core):
 *   2 in-queue slots  * tileSize
 * + 2 out-queue slots * tileSize
 * + 2 temp buffers   * tileSize
 * = 6 * tileSize  <=  ubSize
 * => tileSize = ubSize / 6, rounded down to a 32-byte boundary.
 */
std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr static int64_t BUFFER_NUM = 6;
    constexpr static int64_t ALIGN = 32;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    int64_t tileSize = static_cast<int64_t>(ubSize) / BUFFER_NUM;
    tileSize = (tileSize / ALIGN) * ALIGN;
    if (tileSize <= 0) tileSize = ALIGN;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
