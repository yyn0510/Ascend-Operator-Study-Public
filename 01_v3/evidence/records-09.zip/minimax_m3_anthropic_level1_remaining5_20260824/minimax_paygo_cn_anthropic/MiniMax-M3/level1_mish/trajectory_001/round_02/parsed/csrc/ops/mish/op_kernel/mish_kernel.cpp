/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish activation kernel: y = x * tanh(softplus(x))
 *
 * Numerically stable computation:
 *   softplus(x) = max(x, 0) + ln(1 + exp(-|x|))
 *   y = x * tanh(softplus(x))
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

/*!
 * \brief Mish elementwise kernel.
 *
 * Each AI Vector core processes a contiguous block of `blockLength` elements.
 * The last core may process a smaller block. Each block is processed as a
 * sequence of tiles that fit in the UB.
 */
template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;

    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;

    // Temporary UB buffers (single-buffered, reused across tiles)
    AscendC::TBuf<AscendC::TPosition::VECCALC> tempBuf1;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tempBuf2;

    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tempBuf1, tileSize);
    pipe.InitBuffer(tempBuf2, tileSize);

    // Per-core slice of the global tensors
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    // Effective length of this block (last block may be shorter)
    int64_t currentBlockLength = totalLength - AscendC::GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    int64_t elementNumPerTile = tileSize / sizeof(T);
    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    auto processTile = [&](int64_t offset, int64_t count) {
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(count * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        // Load x tile through the input queue
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto tmp1 = tempBuf1.Get<T>();
        auto tmp2 = tempBuf2.Get<T>();

        // Compute ln(1 + exp(-|x|)) into tmp2 (numerically stable softplus component)
        AscendC::Abs(tmp2, xLocal, count);                                // tmp2 = |x|
        AscendC::Muls(tmp2, tmp2, static_cast<T>(-1.0f), count);          // tmp2 = -|x|
        AscendC::Exp(tmp2, tmp2, count);                                  // tmp2 = exp(-|x|)
        AscendC::Adds(tmp2, tmp2, static_cast<T>(1.0f), count);           // tmp2 = 1 + exp(-|x|)
        AscendC::Ln(tmp2, tmp2, count);                                   // tmp2 = ln(1 + exp(-|x|))

        // Compute max(x, 0) into tmp1 (other softplus component)
        AscendC::Maxs(tmp1, xLocal, static_cast<T>(0.0f), count);         // tmp1 = max(x, 0)

        // softplus(x) = max(x, 0) + ln(1 + exp(-|x|))
        AscendC::Add(tmp1, tmp1, tmp2, count);                            // tmp1 = softplus(x)

        // tanh(softplus(x))
        AscendC::Tanh(tmp1, tmp1, count);                                 // tmp1 = tanh(softplus(x))

        // y = x * tanh(softplus(x))
        auto yLocal = outQueueY.AllocTensor<T>();
        AscendC::Mul(yLocal, xLocal, tmp1, count);

        inQueueX.FreeTensor(xLocal);
        outQueueY.EnQue(yLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    };

    // Full tiles
    for (int64_t i = 0; i < tileNum; ++i) {
        processTile(i * elementNumPerTile, elementNumPerTile);
    }

    // Tail tile (if any leftover elements)
    if (tailTileElementNum > 0) {
        processTile(tileNum * elementNumPerTile, tailTileElementNum);
    }
}

/*!
 * \brief Compute tiling parameters: (numBlocks, blockLength, tileSize).
 *
 * - numBlocks: number of AI Vector cores to use.
 * - blockLength: total elements per core (last may be smaller).
 * - tileSize: bytes per tile in UB. With 2 in + 2 out queue slots (PIPELINE_DEPTH=2)
 *   and 2 single temp buffers, the divisor is 6.
 */
std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    // 2 input queue slots + 2 output queue slots + 2 temp buffers = 6 buffer slots
    constexpr static int64_t BUFFER_NUM = 6;

    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    int64_t tileSize = ubSize / PIPELINE_DEPTH / BUFFER_NUM;
    // Round tileSize down to a multiple of element size for safety
    int64_t elementSize = static_cast<int64_t>(sizeof(float));
    if (tileSize > 0) {
        tileSize = (tileSize / elementSize) * elementSize;
    }
    if (tileSize <= 0) {
        tileSize = elementSize * 1024;
    }
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
