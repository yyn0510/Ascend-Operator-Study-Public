/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish activation: y = x * tanh(softplus(x))
 *        Numerically stable formulation:
 *          softplus(x) = max(x, 0) + ln(1 + exp(-|x|))
 *          tanh(s)     = (1 - exp(-2s)) / (1 + exp(-2s))
 *          mish(x)     = x * tanh(s)
 *  Intermediate scratch uses four TQue<QuePosition::VECCALC, 1> (no TBuf.Get).
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;

    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    AscendC::TQue<AscendC::QuePosition::VECIN,  PIPELINE_DEPTH> qX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> qY;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> qA;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> qB;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> qC;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> qD;

    pipe.InitBuffer(qX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(qY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(qA, 1, tileSize);
    pipe.InitBuffer(qB, 1, tileSize);
    pipe.InitBuffer(qC, 1, tileSize);
    pipe.InitBuffer(qD, 1, tileSize);

    int64_t currentBlockLength = totalLength - AscendC::GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    int64_t elementNumPerTile  = static_cast<int64_t>(tileSize) / sizeof(T);
    int64_t tileNum            = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    // ---- Main loop ----
    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        // Load x
        auto xLocal = qX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        qX.EnQue(xLocal);
        xLocal = qX.DeQue<T>();

        // Allocate tensors
        auto yLocal = qY.AllocTensor<T>();
        auto tA = qA.AllocTensor<T>();
        auto tB = qB.AllocTensor<T>();
        auto tC = qC.AllocTensor<T>();
        auto tD = qD.AllocTensor<T>();

        // softplus(x) = max(x, 0) + ln(1 + exp(-|x|))
        AscendC::Abs  (tA, xLocal, elementNumPerTile);
        AscendC::Muls (tA, tA, static_cast<T>(-1.0f), elementNumPerTile);
        AscendC::Exp  (tA, tA, elementNumPerTile);
        AscendC::Adds (tA, tA, static_cast<T>( 1.0f), elementNumPerTile);
        AscendC::Ln   (tA, tA, elementNumPerTile);
        AscendC::Maxs (tB, xLocal, static_cast<T>(0.0f), elementNumPerTile);
        AscendC::Add  (tB, tB, tA, elementNumPerTile);          // tB = softplus

        // tanh(s) = (1 - exp(-2s)) / (1 + exp(-2s))
        AscendC::Muls (tC, tB, static_cast<T>(-2.0f), elementNumPerTile);
        AscendC::Exp  (tD, tC, elementNumPerTile);              // tD = exp(-2s)
        AscendC::Muls (tC, tD, static_cast<T>(-1.0f), elementNumPerTile);
        AscendC::Adds (tC, tC, static_cast<T>( 1.0f), elementNumPerTile);  // 1 - exp(-2s)
        AscendC::Adds (tB, tD, static_cast<T>( 1.0f), elementNumPerTile);  // 1 + exp(-2s)
        AscendC::Div  (tC, tC, tB, elementNumPerTile);          // tC = tanh(s)

        // y = x * tanh(s)
        AscendC::Mul  (yLocal, xLocal, tC, elementNumPerTile);

        qA.FreeTensor(tA);
        qB.FreeTensor(tB);
        qC.FreeTensor(tC);
        qD.FreeTensor(tD);

        // Store y
        qY.EnQue(yLocal);
        qX.FreeTensor(xLocal);
        yLocal = qY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        qY.FreeTensor(yLocal);
    }

    // ---- Tail tile ----
    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailTileElementNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = qX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        qX.EnQue(xLocal);
        xLocal = qX.DeQue<T>();

        auto yLocal = qY.AllocTensor<T>();
        auto tA = qA.AllocTensor<T>();
        auto tB = qB.AllocTensor<T>();
        auto tC = qC.AllocTensor<T>();
        auto tD = qD.AllocTensor<T>();

        AscendC::Abs  (tA, xLocal, tailTileElementNum);
        AscendC::Muls (tA, tA, static_cast<T>(-1.0f), tailTileElementNum);
        AscendC::Exp  (tA, tA, tailTileElementNum);
        AscendC::Adds (tA, tA, static_cast<T>( 1.0f), tailTileElementNum);
        AscendC::Ln   (tA, tA, tailTileElementNum);
        AscendC::Maxs (tB, xLocal, static_cast<T>(0.0f), tailTileElementNum);
        AscendC::Add  (tB, tB, tA, tailTileElementNum);

        AscendC::Muls (tC, tB, static_cast<T>(-2.0f), tailTileElementNum);
        AscendC::Exp  (tD, tC, tailTileElementNum);
        AscendC::Muls (tC, tD, static_cast<T>(-1.0f), tailTileElementNum);
        AscendC::Adds (tC, tC, static_cast<T>( 1.0f), tailTileElementNum);
        AscendC::Adds (tB, tD, static_cast<T>( 1.0f), tailTileElementNum);
        AscendC::Div  (tC, tC, tB, tailTileElementNum);

        AscendC::Mul  (yLocal, xLocal, tC, tailTileElementNum);

        qA.FreeTensor(tA);
        qB.FreeTensor(tB);
        qC.FreeTensor(tC);
        qD.FreeTensor(tD);

        qY.EnQue(yLocal);
        qX.FreeTensor(xLocal);
        yLocal = qY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        qY.FreeTensor(yLocal);
    }
}

// Tiling function
std::tuple<int64_t, int64_t, uint32_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    constexpr static int64_t NUM_UB_SLOTS = 8; // 2 in (depth 2) + 2 out (depth 2) + 4 calc
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t tileSize = static_cast<int64_t>(ubSize) / NUM_UB_SLOTS;
    if (tileSize < 1024) tileSize = 1024;
    // Align down to 32 bytes (DataCopy requirement)
    tileSize = (tileSize / 32) * 32;

    int64_t numBlocks   = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileSize));
}

// Launch wrappers
extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                              int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                 int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
