/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish activation kernel: y = x * tanh(softplus(x))
 *        Numerically stable form:
 *          softplus(x) = max(x, 0) + log1p(exp(-|x|))
 *          tanh(s)     = (1 - exp(-2s)) / (1 + exp(-2s))
 *        so mish(x)    = x * (1 - exp(-2*sp)) / (1 + exp(-2*sp))
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t TMP_QUEUES     = 4; // workspace slots for intermediates

// Kernel implementation
template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN,  PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> tmpQueueA;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> tmpQueueB;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> tmpQueueC;
    AscendC::TQue<AscendC::QuePosition::VECCALC, 1> tmpQueueD;

    pipe.InitBuffer(inQueueX,  PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpQueueA, 1, tileSize);
    pipe.InitBuffer(tmpQueueB, 1, tileSize);
    pipe.InitBuffer(tmpQueueC, 1, tileSize);
    pipe.InitBuffer(tmpQueueD, 1, tileSize);

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - AscendC::GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    int64_t elementNumPerTile     = tileSize / sizeof(T);
    int64_t tileNum               = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum    = currentBlockLength - tileNum * elementNumPerTile;

    // Helper macro to perform mish for one tile
    #define MISH_COMPUTE_BODY(xLocal, yLocal, count)                                  \
        do {                                                                          \
            AscendC::LocalTensor<T> tA = tmpQueueA.AllocTensor<T>();                  \
            AscendC::LocalTensor<T> tB = tmpQueueB.AllocTensor<T>();                  \
            AscendC::LocalTensor<T> tC = tmpQueueC.AllocTensor<T>();                  \
            AscendC::LocalTensor<T> tD = tmpQueueD.AllocTensor<T>();                  \
                                                                                      \
            /* --- log1p(exp(-|x|)) --- */                                           \
            AscendC::Abs(tA, (xLocal), (count));                                      \
            AscendC::Muls(tA, tA, static_cast<T>(-1.0f), (count));                    \
            AscendC::Exp(tA, tA, (count));                                            \
            AscendC::Adds(tA, tA, static_cast<T>(1.0f), (count));                     \
            AscendC::Ln (tA, tA, (count));                                            \
                                                                                      \
            /* --- softplus(x) = max(x, 0) + log1p(exp(-|x|)) --- */                 \
            AscendC::Maxs(tB, (xLocal), static_cast<T>(0.0f), (count));               \
            AscendC::Add (tC, tB, tA, (count));                                       \
                                                                                      \
            /* --- exp(-2*sp) --- */                                                  \
            AscendC::Muls(tC, tC, static_cast<T>(-2.0f), (count));                    \
            AscendC::Exp (tC, tC, (count));                                           \
                                                                                      \
            /* --- tanh(sp) = (1 - e) / (1 + e) --- */                                \
            AscendC::Muls(tA, tC, static_cast<T>(-1.0f), (count));                    \
            AscendC::Adds(tA, tA, static_cast<T>(1.0f), (count));                     \
            AscendC::Adds(tB, tC, static_cast<T>(1.0f), (count));                     \
            AscendC::Div (tD, tA, tB, (count));                                       \
                                                                                      \
            /* --- y = x * tanh(sp) --- */                                            \
            AscendC::Mul((yLocal), (xLocal), tD, (count));                            \
                                                                                      \
            tmpQueueA.FreeTensor(tA);                                                 \
            tmpQueueB.FreeTensor(tB);                                                 \
            tmpQueueC.FreeTensor(tC);                                                 \
            tmpQueueD.FreeTensor(tD);                                                 \
        } while (0)

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();
        MISH_COMPUTE_BODY(xLocal, yLocal, elementNumPerTile);

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailTileElementNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();
        MISH_COMPUTE_BODY(xLocal, yLocal, tailTileElementNum);

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }

    #undef MISH_COMPUTE_BODY
}

// Tiling function
std::tuple<int64_t, int64_t, uint32_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    // UB consumption per tile:
    //   inQueue:  PIPELINE_DEPTH * tileSize
    //   outQueue: PIPELINE_DEPTH * tileSize
    //   4 tmp queues: 4 * 1 * tileSize
    int64_t totalSlots = 2 * PIPELINE_DEPTH + TMP_QUEUES;
    int64_t tileSize = ubSize / totalSlots;

    int64_t numBlocks   = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileSize));
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                              int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                 int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
