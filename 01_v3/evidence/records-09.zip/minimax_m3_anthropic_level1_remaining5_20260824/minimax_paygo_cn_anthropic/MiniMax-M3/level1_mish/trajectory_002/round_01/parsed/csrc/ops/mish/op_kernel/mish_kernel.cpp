/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish activation kernel: y = x * tanh(softplus(x))
 *        Numerically stable form:
 *          softplus(x) = max(x, 0) + log1p(exp(-|x|))
 *          tanh(s)     = (1 - exp(-2s)) / (1 + exp(-2s))
 *        so mish(x)    = x * (1 - exp(-2*sp)) / (1 + exp(-2*sp))
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t CALC_BUFFERS   = 4; // tmp1..tmp4 workspace slots

// Kernel implementation
template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN,  PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    AscendC::TBuf<AscendC::TPosition::VECCALC>                     calcBuf;

    pipe.InitBuffer(inQueueX,  PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(calcBuf,   tileSize * CALC_BUFFERS);

    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    int64_t currentBlockLength = totalLength - AscendC::GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    int64_t elementNumPerTile     = tileSize / sizeof(T);
    int64_t tileNum               = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum    = currentBlockLength - tileNum * elementNumPerTile;

    // Compute mish for one tile; result is written to yLocal
    auto compute_mish = [&](AscendC::LocalTensor<T>& xLocal,
                            AscendC::LocalTensor<T>& yLocal,
                            int64_t count)
    {
        AscendC::LocalTensor<T> ws = calcBuf.Get<T>();
        AscendC::LocalTensor<T> tmp1 = ws[0];
        AscendC::LocalTensor<T> tmp2 = ws[count];
        AscendC::LocalTensor<T> tmp3 = ws[2 * count];
        AscendC::LocalTensor<T> tmp4 = ws[3 * count];

        // --- log1p(exp(-|x|)) ---
        AscendC::Abs(tmp1, xLocal, count);                        // tmp1 = |x|
        AscendC::Muls(tmp1, tmp1, T(-1.0f), count);               // tmp1 = -|x|
        AscendC::Exp(tmp1, tmp1, count);                          // tmp1 = exp(-|x|)
        AscendC::Adds(tmp1, tmp1, T(1.0f), count);                // tmp1 = 1 + exp(-|x|)
        AscendC::Ln (tmp1, tmp1, count);                          // tmp1 = log1p(exp(-|x|))

        // --- softplus(x) = max(x, 0) + log1p(exp(-|x|)) ---
        AscendC::Maxs(tmp2, xLocal, T(0.0f), count);               // tmp2 = max(x, 0)
        AscendC::Add (tmp3, tmp2, tmp1, count);                   // tmp3 = sp

        // --- exp(-2*sp) ---
        AscendC::Muls(tmp3, tmp3, T(-2.0f), count);               // tmp3 = -2*sp
        AscendC::Exp (tmp3, tmp3, count);                          // tmp3 = exp(-2*sp)

        // --- tanh(sp) = (1 - exp(-2*sp)) / (1 + exp(-2*sp)) ---
        AscendC::Muls(tmp1, tmp3, T(-1.0f), count);               // tmp1 = -exp(-2*sp)
        AscendC::Adds(tmp1, tmp1, T( 1.0f), count);               // tmp1 = 1 - exp(-2*sp)
        AscendC::Adds(tmp2, tmp3, T( 1.0f), count);               // tmp2 = 1 + exp(-2*sp)
        AscendC::Div (tmp4, tmp1, tmp2, count);                   // tmp4 = tanh(sp)

        // --- y = x * tanh(sp) ---
        AscendC::Mul(yLocal, xLocal, tmp4, count);
    };

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();
        compute_mish(xLocal, yLocal, elementNumPerTile);

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailTileElementNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();
        compute_mish(xLocal, yLocal, tailTileElementNum);

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);

        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

// Tiling function
std::tuple<int64_t, int64_t, uint32_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    // Total UB consumption per tile: 2 (in) + 2 (out) + 4 (calc) = 8 slots of tileSize bytes
    int64_t totalBuffers = 2 * PIPELINE_DEPTH + CALC_BUFFERS;
    int64_t tileSize = ubSize / totalBuffers;

    int64_t numBlocks   = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileSize));
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                              int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                 int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
