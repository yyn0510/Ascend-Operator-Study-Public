/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish activation: y = x * tanh(softplus(x))
 *        Stable formulation:
 *          softplus(x) = max(x, 0) + ln(1 + exp(-|x|))
 *          tanh(s)     = (1 - exp(-2s)) / (1 + exp(-2s))
 *          mish(x)     = x * tanh(s)
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t NUM_SCRATCH_BUFS = 4;

// Kernel implementation
template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;

    AscendC::GlobalTensor<T> xGm;
    AscendC::GlobalTensor<T> yGm;
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * AscendC::GetBlockIdx());
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * AscendC::GetBlockIdx());

    AscendC::TQue<AscendC::QuePosition::VECIN,  PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;

    AscendC::TBuf<AscendC::TPosition::VECCALC> bufA;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufB;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufC;
    AscendC::TBuf<AscendC::TPosition::VECCALC> bufD;

    pipe.InitBuffer(inQueueX,  PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(bufA, tileSize);
    pipe.InitBuffer(bufB, tileSize);
    pipe.InitBuffer(bufC, tileSize);
    pipe.InitBuffer(bufD, tileSize);

    AscendC::LocalTensor<T> tA = bufA.Get<T>();
    AscendC::LocalTensor<T> tB = bufB.Get<T>();
    AscendC::LocalTensor<T> tC = bufC.Get<T>();
    AscendC::LocalTensor<T> tD = bufD.Get<T>();

    int64_t currentBlockLength = totalLength - AscendC::GetBlockIdx() * blockLength;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    int64_t elementNumPerTile  = tileSize / sizeof(T);
    int64_t tileNum            = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    // Main loop
    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        // Load x
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        // Allocate output buffer
        auto yLocal = outQueueY.AllocTensor<T>();

        // --- softplus(x) = max(x, 0) + ln(1 + exp(-|x|)) ---
        // tA = ln(1 + exp(-|x|))
        AscendC::Abs(tA, xLocal, elementNumPerTile);
        AscendC::Muls(tA, tA, static_cast<T>(-1.0f), elementNumPerTile);
        AscendC::Exp(tA, tA, elementNumPerTile);
        AscendC::Adds(tA, tA, static_cast<T>(1.0f), elementNumPerTile);
        AscendC::Ln (tA, tA, elementNumPerTile);
        // tC = softplus(x)
        AscendC::Maxs(tB, xLocal, static_cast<T>(0.0f), elementNumPerTile);
        AscendC::Add (tC, tB, tA, elementNumPerTile);

        // --- tanh(s) = (1 - exp(-2s)) / (1 + exp(-2s)) ---
        AscendC::Muls(tC, tC, static_cast<T>(-2.0f), elementNumPerTile);
        AscendC::Exp (tC, tC, elementNumPerTile);
        AscendC::Muls(tA, tC, static_cast<T>(-1.0f), elementNumPerTile);
        AscendC::Adds(tA, tA, static_cast<T>(1.0f), elementNumPerTile);
        AscendC::Adds(tB, tC, static_cast<T>(1.0f), elementNumPerTile);
        AscendC::Div (tD, tA, tB, elementNumPerTile);

        // --- y = x * tanh(s) ---
        AscendC::Mul(yLocal, xLocal, tD, elementNumPerTile);

        // Store
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }

    // Tail tile
    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailTileElementNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        xLocal = inQueueX.DeQue<T>();

        auto yLocal = outQueueY.AllocTensor<T>();

        AscendC::Abs(tA, xLocal, tailTileElementNum);
        AscendC::Muls(tA, tA, static_cast<T>(-1.0f), tailTileElementNum);
        AscendC::Exp(tA, tA, tailTileElementNum);
        AscendC::Adds(tA, tA, static_cast<T>(1.0f), tailTileElementNum);
        AscendC::Ln (tA, tA, tailTileElementNum);

        AscendC::Maxs(tB, xLocal, static_cast<T>(0.0f), tailTileElementNum);
        AscendC::Add (tC, tB, tA, tailTileElementNum);

        AscendC::Muls(tC, tC, static_cast<T>(-2.0f), tailTileElementNum);
        AscendC::Exp (tC, tC, tailTileElementNum);
        AscendC::Muls(tA, tC, static_cast<T>(-1.0f), tailTileElementNum);
        AscendC::Adds(tA, tA, static_cast<T>(1.0f), tailTileElementNum);
        AscendC::Adds(tB, tC, static_cast<T>(1.0f), tailTileElementNum);
        AscendC::Div (tD, tA, tB, tailTileElementNum);

        AscendC::Mul(yLocal, xLocal, tD, tailTileElementNum);

        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

// Tiling function
std::tuple<int64_t, int64_t, uint32_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    // UB usage per core: 2*PIPELINE_DEPTH*tileSize (in+out queues)
    //                   + NUM_SCRATCH_BUFS*tileSize (scratch TBufs)
    int64_t ubSlots = 2 * PIPELINE_DEPTH + NUM_SCRATCH_BUFS;
    int64_t tileSize = ubSize / ubSlots;
    if (tileSize < 32) tileSize = 32;

    int64_t numBlocks   = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks < 1) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(tileSize));
}

// Launch wrappers - regular C functions callable from g++
extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                              int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                 int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
