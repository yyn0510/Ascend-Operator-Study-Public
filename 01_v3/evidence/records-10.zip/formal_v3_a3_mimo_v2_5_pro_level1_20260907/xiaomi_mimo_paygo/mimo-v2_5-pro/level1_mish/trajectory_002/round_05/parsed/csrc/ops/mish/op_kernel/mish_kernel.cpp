/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);

    int64_t blockOffset = blockLength * AscendC::GetBlockIdx();
    int64_t currentLength = totalLength - blockOffset;
    if (currentLength > blockLength) currentLength = blockLength;
    if (currentLength <= 0) return;

    xGm.SetGlobalBuffer((__gm__ T *)x + blockOffset);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockOffset);

    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elementNumPerTile < 1) elementNumPerTile = 1;
    int64_t tileNum = currentLength / elementNumPerTile;
    int64_t tailNum = currentLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; i++) {
        int64_t offset = i * elementNumPerTile;
        uint32_t len = static_cast<uint32_t>(elementNumPerTile);

        AscendC::DataCopyExtParams copyInParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padInParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyInParams, padInParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        AscendC::Exp(yLocal, xLocal, len);
        AscendC::Adds(yLocal, yLocal, static_cast<T>(1.0f), len);
        AscendC::Ln(yLocal, yLocal, len);
        AscendC::Tanh(yLocal, yLocal, len);
        AscendC::Mul(yLocal, xLocal, yLocal, len);

        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);
        yLocal = outQueue.DeQue<T>();

        AscendC::DataCopyExtParams copyOutParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[offset], yLocal, copyOutParams);
        outQueue.FreeTensor(yLocal);
    }

    if (tailNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        uint32_t len = static_cast<uint32_t>(tailNum);

        AscendC::DataCopyExtParams copyInParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padInParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyInParams, padInParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        AscendC::Exp(yLocal, xLocal, len);
        AscendC::Adds(yLocal, yLocal, static_cast<T>(1.0f), len);
        AscendC::Ln(yLocal, yLocal, len);
        AscendC::Tanh(yLocal, yLocal, len);
        AscendC::Mul(yLocal, xLocal, yLocal, len);

        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);
        yLocal = outQueue.DeQue<T>();

        AscendC::DataCopyExtParams copyOutParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPad(yGm[offset], yLocal, copyOutParams);
        outQueue.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS = 1024;
    constexpr static int64_t BUF_NUM = 3;
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = static_cast<int64_t>(platform->GetCoreNumAiv());
    if (coreNum <= 0) coreNum = 1;

    int64_t numBlocks = (totalLength + MIN_ELEMS - 1) / MIN_ELEMS;
    if (numBlocks > coreNum) numBlocks = coreNum;
    if (numBlocks <= 0) numBlocks = 1;

    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    int64_t tileSize = static_cast<int64_t>(ubSize) / PIPELINE_DEPTH / BUF_NUM;

    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, static_cast<uint32_t>(tileSize));
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, static_cast<uint32_t>(tileSize));
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, int64_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, static_cast<uint32_t>(tileSize));
}

}
