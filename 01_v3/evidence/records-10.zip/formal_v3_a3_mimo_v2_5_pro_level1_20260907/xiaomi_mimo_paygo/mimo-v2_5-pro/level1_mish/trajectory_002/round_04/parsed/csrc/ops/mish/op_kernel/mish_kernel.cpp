/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel implementation - y = x * tanh(softplus(x))
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

using namespace AscendC;

constexpr static int32_t BUFFER_NUM = 2;

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    TPipe pipe;
    GlobalTensor<T> xGm, yGm;
    
    TQue<QuePosition::VECIN, BUFFER_NUM> inQueue;
    TQue<QuePosition::VECOUT, BUFFER_NUM> outQueue;
    
    pipe.InitBuffer(inQueue, BUFFER_NUM, tileSize);
    pipe.InitBuffer(outQueue, BUFFER_NUM, tileSize);
    
    int64_t blockIdx = GetBlockIdx();
    int64_t offset = blockLength * blockIdx;
    int64_t currentLength = totalLength - offset;
    if (currentLength > blockLength) {
        currentLength = blockLength;
    }
    if (currentLength <= 0) {
        return;
    }
    
    xGm.SetGlobalBuffer((__gm__ T *)x + offset);
    yGm.SetGlobalBuffer((__gm__ T *)y + offset);
    
    int64_t elementsPerTile = static_cast<int64_t>(tileSize) / static_cast<int64_t>(sizeof(T));
    if (elementsPerTile <= 0) elementsPerTile = 1;
    int64_t tileCount = currentLength / elementsPerTile;
    int64_t tailCount = currentLength - tileCount * elementsPerTile;
    
    DataCopyExtParams copyParams;
    copyParams.blockCount = 1;
    copyParams.srcStride = 0;
    copyParams.dstStride = 0;
    
    DataCopyPadExtParams<T> padParams;
    padParams.isPad = false;
    padParams.leftPadding = 0;
    padParams.rightPadding = 0;
    padParams.paddingValue = 0;
    
    for (int64_t i = 0; i < tileCount; i++) {
        int64_t tileOffset = i * elementsPerTile;
        uint32_t copyLen = static_cast<uint32_t>(elementsPerTile * sizeof(T));
        copyParams.blockLen = copyLen;
        
        LocalTensor<T> xLocal = inQueue.AllocTensor<T>();
        DataCopyPad(xLocal, xGm[tileOffset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        
        xLocal = inQueue.DeQue<T>();
        LocalTensor<T> yLocal = outQueue.AllocTensor<T>();
        
        uint32_t calCount = static_cast<uint32_t>(elementsPerTile);
        Exp(yLocal, xLocal, calCount);
        Adds(yLocal, yLocal, static_cast<T>(1.0f), calCount);
        Ln(yLocal, yLocal, calCount);
        Tanh(yLocal, yLocal, calCount);
        Mul(yLocal, xLocal, yLocal, calCount);
        
        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);
        
        yLocal = outQueue.DeQue<T>();
        DataCopyPad(yGm[tileOffset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }
    
    if (tailCount > 0) {
        int64_t tailOffset = tileCount * elementsPerTile;
        uint32_t copyLen = static_cast<uint32_t>(tailCount * sizeof(T));
        copyParams.blockLen = copyLen;
        
        LocalTensor<T> xLocal = inQueue.AllocTensor<T>();
        DataCopyPad(xLocal, xGm[tailOffset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        
        xLocal = inQueue.DeQue<T>();
        LocalTensor<T> yLocal = outQueue.AllocTensor<T>();
        
        uint32_t calCount = static_cast<uint32_t>(tailCount);
        Exp(yLocal, xLocal, calCount);
        Adds(yLocal, yLocal, static_cast<T>(1.0f), calCount);
        Ln(yLocal, yLocal, calCount);
        Tanh(yLocal, yLocal, calCount);
        Mul(yLocal, xLocal, yLocal, calCount);
        
        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);
        
        yLocal = outQueue.DeQue<T>();
        DataCopyPad(yGm[tailOffset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_mish_tiling_params(int64_t totalLength)
{
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = static_cast<int64_t>(platform->GetCoreNumAiv());
    if (coreNum <= 0) {
        coreNum = 1;
    }
    
    int64_t numBlocks = totalLength / 1024;
    if (numBlocks > coreNum) {
        numBlocks = coreNum;
    }
    if (numBlocks <= 0) {
        numBlocks = 1;
    }
    
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    
    uint32_t tileSize = static_cast<uint32_t>(ubSize / BUFFER_NUM / 2);
    if (tileSize > 256 * 1024) {
        tileSize = 256 * 1024;
    }
    
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
