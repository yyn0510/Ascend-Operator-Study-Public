/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel implementation and host tiling
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t PIPELINE_DEPTH = 2;
constexpr static int64_t BUFFER_NUM = 3;

// Mish kernel: y = x * tanh(softplus(x)) = x * tanh(ln(1 + exp(x)))
template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueueX;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueueY;
    
    // Allocate UB buffers
    pipe.InitBuffer(inQueueX, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueueY, PIPELINE_DEPTH, tileSize);
    
    // Calculate block data range
    int64_t blockOffset = blockLength * AscendC::GetBlockIdx();
    int64_t currentBlockLength = totalLength - blockOffset;
    if (currentBlockLength > blockLength) currentBlockLength = blockLength;
    
    // Early exit if no work
    if (currentBlockLength <= 0) return;
    
    // Setup global memory pointers
    xGm.SetGlobalBuffer((__gm__ T *)x + blockOffset);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockOffset);
    
    // Calculate tiling
    int64_t elementNumPerTile = tileSize / sizeof(T);
    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;
    
    // Process full tiles
    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        
        // Copy input tile to UB
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        
        // Dequeue for computation
        xLocal = inQueueX.DeQue<T>();
        
        // Compute mish: y = x * tanh(ln(1 + exp(x)))
        auto yLocal = outQueueY.AllocTensor<T>();
        
        // Step 1: exp(x)
        AscendC::Exp(yLocal, xLocal, elementNumPerTile);
        
        // Step 2: 1 + exp(x)
        AscendC::Adds(yLocal, yLocal, T(1.0), elementNumPerTile);
        
        // Step 3: ln(1 + exp(x)) = softplus(x)
        AscendC::Ln(yLocal, yLocal, elementNumPerTile);
        
        // Step 4: tanh(softplus(x))
        AscendC::Tanh(yLocal, yLocal, elementNumPerTile);
        
        // Step 5: x * tanh(softplus(x))
        AscendC::Mul(yLocal, xLocal, yLocal, elementNumPerTile);
        
        // Enqueue output and free input
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        
        // Copy output tile to GM
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
    
    // Process tail tile if exists
    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(tailTileElementNum * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
        auto xLocal = inQueueX.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueueX.EnQue(xLocal);
        
        xLocal = inQueueX.DeQue<T>();
        auto yLocal = outQueueY.AllocTensor<T>();
        
        // Compute mish for tail tile
        AscendC::Exp(yLocal, xLocal, tailTileElementNum);
        AscendC::Adds(yLocal, yLocal, T(1.0), tailTileElementNum);
        AscendC::Ln(yLocal, yLocal, tailTileElementNum);
        AscendC::Tanh(yLocal, yLocal, tailTileElementNum);
        AscendC::Mul(yLocal, xLocal, yLocal, tailTileElementNum);
        
        outQueueY.EnQue(yLocal);
        inQueueX.FreeTensor(xLocal);
        
        yLocal = outQueueY.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueueY.FreeTensor(yLocal);
    }
}

// Tiling calculation function
std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    
    // Calculate number of blocks (cores)
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    
    // Calculate tile size based on UB memory
    // We need space for input and output buffers
    int64_t tileSize = ubSize / PIPELINE_DEPTH / BUFFER_NUM;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

// Launch wrappers for different data types
extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength, int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void* stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
