/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish activation kernel: y = x * tanh(softplus(x))
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPE_DEPTH = 1;

template <typename T>
struct IsFp32 { static constexpr bool value = false; };
template <>
struct IsFp32<float> { static constexpr bool value = true; };

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
    int64_t totalLength, int64_t blockLength, uint32_t tileSize)
{
    AscendC::TPipe pipe;

    AscendC::GlobalTensor<T> xGm, yGm;
    int64_t base = blockLength * AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)x + base);
    yGm.SetGlobalBuffer((__gm__ T *)y + base);

    int64_t thisLen = totalLength - base;
    if (thisLen > blockLength) thisLen = blockLength;
    if (thisLen <= 0) return;

    int32_t ept = static_cast<int32_t>(tileSize / sizeof(T));
    if (ept <= 0) ept = 1;
    int64_t fullTiles = thisLen / ept;
    int64_t tailCnt = thisLen % ept;

    AscendC::TQue<AscendC::QuePosition::VECIN, PIPE_DEPTH> inQ;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPE_DEPTH> q1;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPE_DEPTH> q2;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPE_DEPTH> q3;

    uint32_t tBytes = static_cast<uint32_t>(ept) * static_cast<uint32_t>(sizeof(T));
    uint32_t fBytes = static_cast<uint32_t>(ept) * static_cast<uint32_t>(sizeof(float));

    pipe.InitBuffer(inQ, PIPE_DEPTH, tBytes);
    pipe.InitBuffer(q1, PIPE_DEPTH, fBytes);
    pipe.InitBuffer(q2, PIPE_DEPTH, fBytes);
    pipe.InitBuffer(q3, PIPE_DEPTH, fBytes);

    for (int64_t t = 0; t <= fullTiles; ++t) {
        int32_t cnt;
        int64_t off;
        if (t < fullTiles) {
            cnt = ept;
            off = t * ept;
        } else {
            cnt = static_cast<int32_t>(tailCnt);
            off = fullTiles * ept;
            if (cnt <= 0) break;
        }

        AscendC::DataCopyExtParams cp{1, static_cast<uint32_t>(cnt * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> pad{false, 0, 0, 0};

        auto xT = inQ.AllocTensor<T>();
        AscendC::DataCopyPad(xT, xGm[off], cp, pad);
        inQ.EnQue(xT);
        xT = inQ.DeQue<T>();

        auto xF = q1.AllocTensor<float>();
        if constexpr (IsFp32<T>::value) {
            AscendC::Adds(xF, xT, 0.0f, cnt);
        } else {
            AscendC::Cast(xF, xT, AscendC::RoundMode::CAST_NONE, cnt);
        }
        inQ.FreeTensor(xT);

        // Clamp x from below at -100 to prevent -inf*0=NaN
        {
            auto cb = q3.AllocTensor<float>();
            AscendC::Duplicate(cb, -100.0f, cnt);
            AscendC::Maximum(xF, xF, cb, cnt);
            q3.FreeTensor(cb);
        }

        // softplus(x) = max(x,0) + ln(1 + exp(-|x|))
        auto w = q2.AllocTensor<float>();
        AscendC::Abs(w, xF, cnt);
        AscendC::Muls(w, w, -1.0f, cnt);
        AscendC::Exp(w, w, cnt);
        AscendC::Adds(w, w, 1.0f, cnt);
        AscendC::Ln(w, w, cnt);

        auto mx = q3.AllocTensor<float>();
        AscendC::Abs(mx, xF, cnt);
        AscendC::Add(mx, mx, xF, cnt);
        AscendC::Muls(mx, mx, 0.5f, cnt);

        AscendC::Add(w, w, mx, cnt);
        q3.FreeTensor(mx);

        // tanh(softplus)
        AscendC::Tanh(w, w, cnt);

        // mish = x * tanh(softplus)
        AscendC::Mul(xF, xF, w, cnt);
        q2.FreeTensor(w);

        // Cast back
        auto yT = inQ.AllocTensor<T>();
        if constexpr (IsFp32<T>::value) {
            AscendC::Adds(yT, xF, 0.0f, cnt);
        } else {
            AscendC::Cast(yT, xF, AscendC::RoundMode::CAST_ROUND, cnt);
        }
        q1.FreeTensor(xF);

        inQ.EnQue(yT);
        yT = inQ.DeQue<T>();
        AscendC::DataCopyPad(yGm[off], yT, cp);
        inQ.FreeTensor(yT);
    }
}

std::tuple<int64_t, int64_t, uint32_t> calc_mish_tiling(int64_t totalLength, int32_t dtypeSize)
{
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int32_t bpe = dtypeSize + 3 * static_cast<int32_t>(sizeof(float));
    int32_t tileE = static_cast<int32_t>(ubSize / bpe);
    tileE = (tileE / 32) * 32;
    if (tileE < 32) tileE = 32;
    uint32_t tileS = static_cast<uint32_t>(tileE) * static_cast<uint32_t>(dtypeSize);

    int64_t nblk = std::min(coreNum, (totalLength + 255) / 256);
    if (nblk <= 0) nblk = 1;
    int64_t blkLen = (totalLength + nblk - 1) / nblk;

    return std::make_tuple(nblk, blkLen, tileS);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength,
    int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength,
    int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
    int64_t numBlocks, int64_t blockLength, uint32_t tileSize, void *stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
