/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish activation: y = x * tanh(softplus(x))
 *        softplus(x) = ln(1 + exp(x)) = x + ln(1 + exp(-x))  (numerically stable)
 *        bf16 path promotes to fp32 for precision, then casts back.
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t MISH_TILE_SIZE   = 256 * 1024;   // 256 KB per tile
constexpr static int64_t MISH_PIPE_DEPTH  = 2;

/* ====================================================================
 * fp32 / fp16 kernel  (native precision)
 * ==================================================================== */
template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength,
                                       int64_t blockLength,
                                       uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN,  MISH_PIPE_DEPTH> inQ;
    AscendC::TQue<AscendC::QuePosition::VECOUT, MISH_PIPE_DEPTH> outQ;
    pipe.InitBuffer(inQ,  MISH_PIPE_DEPTH, tileSize);
    pipe.InitBuffer(outQ, MISH_PIPE_DEPTH, tileSize);

    int64_t offset  = blockLength * static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t remain  = totalLength - offset;
    if (remain > blockLength) remain = blockLength;
    if (remain <= 0) return;

    xGm.SetGlobalBuffer((__gm__ T *)x + offset);
    yGm.SetGlobalBuffer((__gm__ T *)y + offset);

    int64_t elemsPerTile = static_cast<int64_t>(tileSize) / sizeof(T);
    int64_t tileNum      = remain / elemsPerTile;
    int64_t tailElems    = remain - tileNum * elemsPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t  off    = i * elemsPerTile;
        uint32_t bLen   = static_cast<uint32_t>(elemsPerTile * sizeof(T));
        AscendC::DataCopyExtParams       cp{1, bLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> pad{false, 0, 0, 0};

        /* 1. Load x */
        auto xL = inQ.AllocTensor<T>();
        AscendC::DataCopyPad(xL, xGm[off], cp, pad);
        inQ.EnQue(xL);
        xL = inQ.DeQue<T>();

        /* 2. negExp = exp(-x) */
        auto negExp = outQ.AllocTensor<T>();
        AscendC::Muls(negExp, xL, static_cast<T>(-1.0f), elemsPerTile);
        AscendC::Exp(negExp, negExp, elemsPerTile);

        /* 3. sp = ln(1 + exp(-x)) */
        auto sp = outQ.AllocTensor<T>();
        AscendC::Adds(sp, negExp, static_cast<T>(1.0f), elemsPerTile);
        AscendC::Ln(sp, sp, elemsPerTile);
        outQ.FreeTensor(negExp);

        /* 4. sp = x + ln(1+exp(-x))  =  softplus(x) */
        AscendC::Add(sp, xL, sp, elemsPerTile);
        inQ.FreeTensor(xL);

        /* 5. sp = tanh(softplus(x)) */
        AscendC::Tanh(sp, sp, elemsPerTile);

        /* 6. y = x * tanh(softplus(x)) */
        auto xL2 = inQ.AllocTensor<T>();
        AscendC::DataCopyPad(xL2, xGm[off], cp, pad);
        inQ.EnQue(xL2);
        xL2 = inQ.DeQue<T>();

        auto yL = outQ.AllocTensor<T>();
        AscendC::Mul(yL, xL2, sp, elemsPerTile);
        outQ.FreeTensor(sp);
        inQ.FreeTensor(xL2);
        outQ.EnQue(yL);

        yL = outQ.DeQue<T>();
        AscendC::DataCopyPad(yGm[off], yL, cp);
        outQ.FreeTensor(yL);
    }

    /* ---- tail ---- */
    if (tailElems > 0) {
        int64_t  off  = tileNum * elemsPerTile;
        uint32_t bLen = static_cast<uint32_t>(tailElems * sizeof(T));
        AscendC::DataCopyExtParams       cp{1, bLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> pad{false, 0, 0, 0};

        auto xL = inQ.AllocTensor<T>();
        AscendC::DataCopyPad(xL, xGm[off], cp, pad);
        inQ.EnQue(xL);
        xL = inQ.DeQue<T>();

        auto negExp = outQ.AllocTensor<T>();
        AscendC::Muls(negExp, xL, static_cast<T>(-1.0f), tailElems);
        AscendC::Exp(negExp, negExp, tailElems);

        auto sp = outQ.AllocTensor<T>();
        AscendC::Adds(sp, negExp, static_cast<T>(1.0f), tailElems);
        AscendC::Ln(sp, sp, tailElems);
        outQ.FreeTensor(negExp);

        AscendC::Add(sp, xL, sp, tailElems);
        inQ.FreeTensor(xL);
        AscendC::Tanh(sp, sp, tailElems);

        auto xL2 = inQ.AllocTensor<T>();
        AscendC::DataCopyPad(xL2, xGm[off], cp, pad);
        inQ.EnQue(xL2);
        xL2 = inQ.DeQue<T>();

        auto yL = outQ.AllocTensor<T>();
        AscendC::Mul(yL, xL2, sp, tailElems);
        outQ.FreeTensor(sp);
        inQ.FreeTensor(xL2);
        outQ.EnQue(yL);

        yL = outQ.DeQue<T>();
        AscendC::DataCopyPad(yGm[off], yL, cp);
        outQ.FreeTensor(yL);
    }
}

/* ====================================================================
 * bf16 kernel  – promote to fp32 for computation, cast back to bf16
 * Uses three queues: inQ (bf16 load/store), midQ (fp32 compute), outQ (bf16 store).
 * ==================================================================== */
__global__ __aicore__ void mish_kernel_bf16(GM_ADDR x, GM_ADDR y,
                                            int64_t totalLength,
                                            int64_t blockLength,
                                            uint32_t tileBytes)
{
    constexpr uint32_t FP32_TILE = 256 * 1024;

    AscendC::TPipe pipe;
    AscendC::GlobalTensor<bfloat16_t> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN,  MISH_PIPE_DEPTH> inQ;
    AscendC::TQue<AscendC::QuePosition::VECIN,  MISH_PIPE_DEPTH> midQ;
    AscendC::TQue<AscendC::QuePosition::VECOUT, MISH_PIPE_DEPTH> outQ;
    pipe.InitBuffer(inQ,  MISH_PIPE_DEPTH, tileBytes);
    pipe.InitBuffer(midQ, MISH_PIPE_DEPTH, FP32_TILE);
    pipe.InitBuffer(outQ, MISH_PIPE_DEPTH, tileBytes);

    int64_t offset = blockLength * static_cast<int64_t>(AscendC::GetBlockIdx());
    int64_t remain = totalLength - offset;
    if (remain > blockLength) remain = blockLength;
    if (remain <= 0) return;

    xGm.SetGlobalBuffer((__gm__ bfloat16_t *)x + offset);
    yGm.SetGlobalBuffer((__gm__ bfloat16_t *)y + offset);

    int64_t elemsPerTile = static_cast<int64_t>(tileBytes) / sizeof(bfloat16_t);
    int64_t tileNum      = remain / elemsPerTile;
    int64_t tailElems    = remain - tileNum * elemsPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t  off  = i * elemsPerTile;
        uint32_t bLen = static_cast<uint32_t>(elemsPerTile * sizeof(bfloat16_t));
        AscendC::DataCopyExtParams             cp{1, bLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<bfloat16_t> pad{false, 0, 0, 0};

        /* 1. Load bf16 x, cast to fp32 */
        auto xBf = inQ.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xBf, xGm[off], cp, pad);
        inQ.EnQue(xBf);
        xBf = inQ.DeQue<bfloat16_t>();

        auto xF = midQ.AllocTensor<float>();
        AscendC::Cast(xF, xBf, AscendC::RoundMode::CAST_NONE, elemsPerTile);
        inQ.FreeTensor(xBf);

        /* 2. negExp = exp(-x)  (in-place on xF / midQ buffer) */
        AscendC::Muls(xF, xF, -1.0f, elemsPerTile);
        AscendC::Exp(xF, xF, elemsPerTile);

        /* 3. sp = ln(1 + exp(-x)) */
        auto sp = midQ.AllocTensor<float>();
        AscendC::Adds(sp, xF, 1.0f, elemsPerTile);
        AscendC::Ln(sp, sp, elemsPerTile);
        midQ.FreeTensor(xF);          // xF done, midQ can reuse

        /* 4. sp = x + sp  =  softplus(x)  (re-load x) */
        xBf = inQ.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xBf, xGm[off], cp, pad);
        inQ.EnQue(xBf);
        xBf = inQ.DeQue<bfloat16_t>();
        xF = midQ.AllocTensor<float>();
        AscendC::Cast(xF, xBf, AscendC::RoundMode::CAST_NONE, elemsPerTile);
        inQ.FreeTensor(xBf);

        AscendC::Add(sp, xF, sp, elemsPerTile);
        midQ.FreeTensor(xF);

        /* 5. sp = tanh(sp)  (in-place) */
        AscendC::Tanh(sp, sp, elemsPerTile);

        /* 6. y = x * tanh(softplus(x))  (re-load x once more) */
        xBf = inQ.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xBf, xGm[off], cp, pad);
        inQ.EnQue(xBf);
        xBf = inQ.DeQue<bfloat16_t>();

        auto yBf = outQ.AllocTensor<bfloat16_t>();
        AscendC::Mul(yBf, xBf, sp, elemsPerTile);
        midQ.FreeTensor(sp);
        inQ.FreeTensor(xBf);
        outQ.EnQue(yBf);

        yBf = outQ.DeQue<bfloat16_t>();
        AscendC::DataCopyPad(yGm[off], yBf, cp);
        outQ.FreeTensor(yBf);
    }

    /* ---- tail ---- */
    if (tailElems > 0) {
        int64_t  off  = tileNum * elemsPerTile;
        uint32_t bLen = static_cast<uint32_t>(tailElems * sizeof(bfloat16_t));
        AscendC::DataCopyExtParams             cp{1, bLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<bfloat16_t> pad{false, 0, 0, 0};

        auto xBf = inQ.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xBf, xGm[off], cp, pad);
        inQ.EnQue(xBf);
        xBf = inQ.DeQue<bfloat16_t>();

        auto xF = midQ.AllocTensor<float>();
        AscendC::Cast(xF, xBf, AscendC::RoundMode::CAST_NONE, tailElems);
        inQ.FreeTensor(xBf);

        AscendC::Muls(xF, xF, -1.0f, tailElems);
        AscendC::Exp(xF, xF, tailElems);

        auto sp = midQ.AllocTensor<float>();
        AscendC::Adds(sp, xF, 1.0f, tailElems);
        AscendC::Ln(sp, sp, tailElems);
        midQ.FreeTensor(xF);

        xBf = inQ.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xBf, xGm[off], cp, pad);
        inQ.EnQue(xBf);
        xBf = inQ.DeQue<bfloat16_t>();
        xF = midQ.AllocTensor<float>();
        AscendC::Cast(xF, xBf, AscendC::RoundMode::CAST_NONE, tailElems);
        inQ.FreeTensor(xBf);

        AscendC::Add(sp, xF, sp, tailElems);
        midQ.FreeTensor(xF);
        AscendC::Tanh(sp, sp, tailElems);

        xBf = inQ.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xBf, xGm[off], cp, pad);
        inQ.EnQue(xBf);
        xBf = inQ.DeQue<bfloat16_t>();

        auto yBf = outQ.AllocTensor<bfloat16_t>();
        AscendC::Mul(yBf, xBf, sp, tailElems);
        midQ.FreeTensor(sp);
        inQ.FreeTensor(xBf);
        outQ.EnQue(yBf);

        yBf = outQ.DeQue<bfloat16_t>();
        AscendC::DataCopyPad(yGm[off], yBf, cp);
        outQ.FreeTensor(yBf);
    }
}

/* ====================================================================
 * Host tiling
 * ==================================================================== */
std::tuple<int64_t, int64_t, uint32_t> calc_mish_tiling_params(int64_t totalLength)
{
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t numBlocks   = std::min(coreNum, (totalLength + 1023) / 1024);
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    return std::make_tuple(numBlocks, blockLength,
                           static_cast<uint32_t>(MISH_TILE_SIZE));
}

/* ====================================================================
 * Launch wrappers  (extern "C", callable from g++)
 * ==================================================================== */
extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y,
                              int64_t totalLength,
                              int64_t numBlocks, int64_t blockLength,
                              uint32_t tileSize, void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y,
                             int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bf16(GM_ADDR x, GM_ADDR y,
                             int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    mish_kernel_bf16<<<numBlocks, nullptr, stream>>>(
        x, y, totalLength, blockLength, tileSize);
}

}
