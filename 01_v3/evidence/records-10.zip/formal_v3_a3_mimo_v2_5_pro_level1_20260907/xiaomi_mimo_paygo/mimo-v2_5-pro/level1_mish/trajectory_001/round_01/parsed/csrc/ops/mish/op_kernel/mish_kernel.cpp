/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel: y = x * tanh(ln(1 + exp(x)))
 *        Numerically stable via softplus(x) = x + ln(1 + exp(-x))
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int64_t MISH_TILE_SIZE = 256 * 1024; // 256KB per tile buffer
constexpr static int64_t MISH_PIPELINE_DEPTH = 2;

/* ---------- Native precision kernel (float16 / float32) ---------- */
template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength,
                                       int64_t blockLength,
                                       uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, MISH_PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, MISH_PIPELINE_DEPTH> outQueue;
    pipe.InitBuffer(inQueue, MISH_PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, MISH_PIPELINE_DEPTH, tileSize);

    int64_t offset = blockLength * AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)x + offset);
    yGm.SetGlobalBuffer((__gm__ T *)y + offset);

    int64_t remain = totalLength - offset;
    if (remain > blockLength) remain = blockLength;

    int64_t elemsPerTile = tileSize / sizeof(T);
    int64_t tileNum = remain / elemsPerTile;
    int64_t tailElems = remain - tileNum * elemsPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t off = i * elemsPerTile;
        uint32_t byteLen = static_cast<uint32_t>(elemsPerTile * sizeof(T));
        AscendC::DataCopyExtParams cpIn{1, byteLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padIn{false, 0, 0, 0};
        AscendC::DataCopyExtParams cpOut{1, byteLen, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[off], cpIn, padIn);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        /* softplus(x) = x + ln(1 + exp(-x))  — stable for large positive x */
        auto negLocal = inQueue.AllocTensor<T>();
        AscendC::Mul(negLocal, xLocal, (T)-1.0f, elemsPerTile);   // -x

        auto spLocal = outQueue.AllocTensor<T>();
        AscendC::Exp(negLocal, negLocal, elemsPerTile);            // exp(-x)
        AscendC::Adds(negLocal, negLocal, (T)1.0f, elemsPerTile); // 1+exp(-x)
        AscendC::Ln(negLocal, negLocal, elemsPerTile);             // ln(...)
        AscendC::Add(spLocal, xLocal, negLocal, elemsPerTile);     // softplus
        inQueue.FreeTensor(xLocal);
        inQueue.FreeTensor(negLocal);

        /* mish = x * tanh(softplus) */
        AscendC::Tanh(spLocal, spLocal, elemsPerTile);             // tanh(sp)

        /* Re-load x for the multiply (pipe-friendly re-fetch) */
        auto xLocal2 = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal2, xGm[off], cpIn, padIn);
        inQueue.EnQue(xLocal2);
        xLocal2 = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        AscendC::Mul(yLocal, xLocal2, spLocal, elemsPerTile);
        outQueue.FreeTensor(spLocal);
        inQueue.FreeTensor(xLocal2);
        outQueue.EnQue(yLocal);

        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[off], yLocal, cpOut);
        outQueue.FreeTensor(yLocal);
    }

    if (tailElems > 0) {
        int64_t off = tileNum * elemsPerTile;
        uint32_t byteLen = static_cast<uint32_t>(tailElems * sizeof(T));
        AscendC::DataCopyExtParams cpIn{1, byteLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padIn{false, 0, 0, 0};
        AscendC::DataCopyExtParams cpOut{1, byteLen, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[off], cpIn, padIn);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto negLocal = inQueue.AllocTensor<T>();
        AscendC::Mul(negLocal, xLocal, (T)-1.0f, tailElems);

        auto spLocal = outQueue.AllocTensor<T>();
        AscendC::Exp(negLocal, negLocal, tailElems);
        AscendC::Adds(negLocal, negLocal, (T)1.0f, tailElems);
        AscendC::Ln(negLocal, negLocal, tailElems);
        AscendC::Add(spLocal, xLocal, negLocal, tailElems);
        inQueue.FreeTensor(xLocal);
        inQueue.FreeTensor(negLocal);

        AscendC::Tanh(spLocal, spLocal, tailElems);

        auto xLocal2 = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal2, xGm[off], cpIn, padIn);
        inQueue.EnQue(xLocal2);
        xLocal2 = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        AscendC::Mul(yLocal, xLocal2, spLocal, tailElems);
        outQueue.FreeTensor(spLocal);
        inQueue.FreeTensor(xLocal2);
        outQueue.EnQue(yLocal);

        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[off], yLocal, cpOut);
        outQueue.FreeTensor(yLocal);
    }
}

/* ---------- BF16 kernel: compute in fp32 for precision ---------- */
__global__ __aicore__ void mish_kernel_bf16(GM_ADDR x, GM_ADDR y,
                                            int64_t totalLength,
                                            int64_t blockLength,
                                            uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<bfloat16_t> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, MISH_PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, MISH_PIPELINE_DEPTH> outQueue;
    pipe.InitBuffer(inQueue, MISH_PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, MISH_PIPELINE_DEPTH, tileSize);

    int64_t offset = blockLength * AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ bfloat16_t *)x + offset);
    yGm.SetGlobalBuffer((__gm__ bfloat16_t *)y + offset);

    int64_t remain = totalLength - offset;
    if (remain > blockLength) remain = blockLength;

    int64_t elemsPerTile = tileSize / sizeof(bfloat16_t);
    int64_t tileNum = remain / elemsPerTile;
    int64_t tailElems = remain - tileNum * elemsPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t off = i * elemsPerTile;
        uint32_t byteLen = static_cast<uint32_t>(elemsPerTile * sizeof(bfloat16_t));
        AscendC::DataCopyExtParams cpIn{1, byteLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<bfloat16_t> padIn{false, 0, 0, 0};
        AscendC::DataCopyExtParams cpOut{1, byteLen, 0, 0, 0};

        /* Load bf16, cast to fp32 for computation */
        auto xLocal = inQueue.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xLocal, xGm[off], cpIn, padIn);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<bfloat16_t>();

        auto xFp32 = outQueue.AllocTensor<float>();
        AscendC::Cast(xFp32, xLocal, AscendC::RoundMode::CAST_NONE, elemsPerTile);
        inQueue.FreeTensor(xLocal);

        /* softplus(x) = x + ln(1 + exp(-x)) */
        auto negFp32 = inQueue.AllocTensor<float>();
        AscendC::Mul(negFp32, xFp32, -1.0f, elemsPerTile);
        AscendC::Exp(negFp32, negFp32, elemsPerTile);
        AscendC::Adds(negFp32, negFp32, 1.0f, elemsPerTile);
        AscendC::Ln(negFp32, negFp32, elemsPerTile);
        auto spFp32 = outQueue.AllocTensor<float>();
        AscendC::Add(spFp32, xFp32, negFp32, elemsPerTile);
        inQueue.FreeTensor(negFp32);
        outQueue.FreeTensor(xFp32);

        /* tanh(softplus) */
        AscendC::Tanh(spFp32, spFp32, elemsPerTile);

        /* Re-load x for multiply */
        auto xLocal2 = inQueue.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xLocal2, xGm[off], cpIn, padIn);
        inQueue.EnQue(xLocal2);
        xLocal2 = inQueue.DeQue<bfloat16_t>();
        auto xFp32b = outQueue.AllocTensor<float>();
        AscendC::Cast(xFp32b, xLocal2, AscendC::RoundMode::CAST_NONE, elemsPerTile);
        inQueue.FreeTensor(xLocal2);

        /* mish = x * tanh(softplus) */
        auto resFp32 = outQueue.AllocTensor<float>();
        AscendC::Mul(resFp32, xFp32b, spFp32, elemsPerTile);
        outQueue.FreeTensor(spFp32);
        outQueue.FreeTensor(xFp32b);

        /* Cast back to bf16 */
        auto yLocal = outQueue.AllocTensor<bfloat16_t>();
        AscendC::Cast(yLocal, resFp32, AscendC::RoundMode::CAST_ROUND, elemsPerTile);
        outQueue.FreeTensor(resFp32);
        outQueue.EnQue(yLocal);

        yLocal = outQueue.DeQue<bfloat16_t>();
        AscendC::DataCopyPad(yGm[off], yLocal, cpOut);
        outQueue.FreeTensor(yLocal);
    }

    if (tailElems > 0) {
        int64_t off = tileNum * elemsPerTile;
        uint32_t byteLen = static_cast<uint32_t>(tailElems * sizeof(bfloat16_t));
        AscendC::DataCopyExtParams cpIn{1, byteLen, 0, 0, 0};
        AscendC::DataCopyPadExtParams<bfloat16_t> padIn{false, 0, 0, 0};
        AscendC::DataCopyExtParams cpOut{1, byteLen, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xLocal, xGm[off], cpIn, padIn);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<bfloat16_t>();

        auto xFp32 = outQueue.AllocTensor<float>();
        AscendC::Cast(xFp32, xLocal, AscendC::RoundMode::CAST_NONE, tailElems);
        inQueue.FreeTensor(xLocal);

        auto negFp32 = inQueue.AllocTensor<float>();
        AscendC::Mul(negFp32, xFp32, -1.0f, tailElems);
        AscendC::Exp(negFp32, negFp32, tailElems);
        AscendC::Adds(negFp32, negFp32, 1.0f, tailElems);
        AscendC::Ln(negFp32, negFp32, tailElems);
        auto spFp32 = outQueue.AllocTensor<float>();
        AscendC::Add(spFp32, xFp32, negFp32, tailElems);
        inQueue.FreeTensor(negFp32);
        outQueue.FreeTensor(xFp32);

        AscendC::Tanh(spFp32, spFp32, tailElems);

        auto xLocal2 = inQueue.AllocTensor<bfloat16_t>();
        AscendC::DataCopyPad(xLocal2, xGm[off], cpIn, padIn);
        inQueue.EnQue(xLocal2);
        xLocal2 = inQueue.DeQue<bfloat16_t>();
        auto xFp32b = outQueue.AllocTensor<float>();
        AscendC::Cast(xFp32b, xLocal2, AscendC::RoundMode::CAST_NONE, tailElems);
        inQueue.FreeTensor(xLocal2);

        auto resFp32 = outQueue.AllocTensor<float>();
        AscendC::Mul(resFp32, xFp32b, spFp32, tailElems);
        outQueue.FreeTensor(spFp32);
        outQueue.FreeTensor(xFp32b);

        auto yLocal = outQueue.AllocTensor<bfloat16_t>();
        AscendC::Cast(yLocal, resFp32, AscendC::RoundMode::CAST_ROUND, tailElems);
        outQueue.FreeTensor(resFp32);
        outQueue.EnQue(yLocal);

        yLocal = outQueue.DeQue<bfloat16_t>();
        AscendC::DataCopyPad(yGm[off], yLocal, cpOut);
        outQueue.FreeTensor(yLocal);
    }
}

/* ---------- Host tiling ---------- */
std::tuple<int64_t, int64_t, uint32_t> calc_mish_tiling_params(int64_t totalLength)
{
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t numBlocks = std::min(coreNum, (totalLength + 1023) / 1024);
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    return std::make_tuple(numBlocks, blockLength, static_cast<uint32_t>(MISH_TILE_SIZE));
}

/* ---------- Launch wrappers ---------- */
extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                              int64_t numBlocks, int64_t blockLength,
                              uint32_t tileSize, void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    mish_kernel_bf16<<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
