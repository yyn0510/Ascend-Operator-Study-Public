/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel - y = x * tanh(softplus(x))
 *        Numerically stable softplus(x) = |x| + ln(1 + exp(-|x|))
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

using namespace AscendC;

constexpr static int32_t PIPE_DEPTH = 2;
constexpr static int32_t TOTAL_BUFS = 4; /* 2*VECIN + 1*VECOUT + 1*VECCALC per stage */

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR xGmPtr, GM_ADDR yGmPtr,
                                       int64_t totalLen, int64_t blkLen,
                                       int64_t tileElems)
{
    TPipe pipe;
    GlobalTensor<T> xGm, yGm;

    TQue<QuePosition::VECIN,  PIPE_DEPTH> qIn;
    TQue<QuePosition::VECOUT, PIPE_DEPTH> qOut;
    TBuf<TPosition::VECCALC>  tmpBuf;

    int32_t tileBytes = static_cast<int32_t>(tileElems * sizeof(T));

    pipe.InitBuffer(qIn,    PIPE_DEPTH, tileBytes);
    pipe.InitBuffer(qOut,   PIPE_DEPTH, tileBytes);
    pipe.InitBuffer(tmpBuf, tileBytes);

    int64_t blk = GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)xGmPtr + blkLen * blk);
    yGm.SetGlobalBuffer((__gm__ T *)yGmPtr + blkLen * blk);

    int64_t myLen = totalLen - blk * blkLen;
    if (myLen > blkLen) myLen = blkLen;

    int64_t nFull  = myLen / tileElems;
    int64_t nTail  = myLen - nFull * tileElems;

    for (int64_t i = 0; i < nFull; ++i) {
        int64_t off = i * tileElems;
        int32_t cnt = static_cast<int32_t>(tileElems);
        uint32_t cpBytes = static_cast<uint32_t>(cnt * sizeof(T));

        DataCopyExtParams     cpExt{1, cpBytes, 0, 0, 0};
        DataCopyPadExtParams<T> cpPad{false, 0, 0, 0};

        auto inT = qIn.AllocTensor<T>();
        DataCopyPad(inT, xGm[off], cpExt, cpPad);
        qIn.EnQue(inT);
        inT = qIn.DeQue<T>();

        auto outT = qOut.AllocTensor<T>();
        auto tmpT = tmpBuf.Get<T>();

        Abs(tmpT, inT, cnt);
        Neg(tmpT, tmpT, cnt);
        Exp(tmpT, tmpT, cnt);
        Adds(tmpT, tmpT, static_cast<T>(1.0f), cnt);
        Ln(tmpT, tmpT, cnt);
        Abs(outT, inT, cnt);
        Add(tmpT, outT, tmpT, cnt);
        Tanh(tmpT, tmpT, cnt);
        Mul(outT, inT, tmpT, cnt);

        qOut.EnQue(outT);
        qIn.FreeTensor(inT);
        outT = qOut.DeQue<T>();
        DataCopyPad(yGm[off], outT, cpExt);
        qOut.FreeTensor(outT);
    }

    if (nTail > 0) {
        int64_t off = nFull * tileElems;
        int32_t cnt = static_cast<int32_t>(nTail);
        uint32_t cpBytes = static_cast<uint32_t>(cnt * sizeof(T));

        DataCopyExtParams     cpExt{1, cpBytes, 0, 0, 0};
        DataCopyPadExtParams<T> cpPad{false, 0, 0, 0};

        auto inT = qIn.AllocTensor<T>();
        DataCopyPad(inT, xGm[off], cpExt, cpPad);
        qIn.EnQue(inT);
        inT = qIn.DeQue<T>();

        auto outT = qOut.AllocTensor<T>();
        auto tmpT = tmpBuf.Get<T>();

        Abs(tmpT, inT, cnt);
        Neg(tmpT, tmpT, cnt);
        Exp(tmpT, tmpT, cnt);
        Adds(tmpT, tmpT, static_cast<T>(1.0f), cnt);
        Ln(tmpT, tmpT, cnt);
        Abs(outT, inT, cnt);
        Add(tmpT, outT, tmpT, cnt);
        Tanh(tmpT, tmpT, cnt);
        Mul(outT, inT, tmpT, cnt);

        qOut.EnQue(outT);
        qIn.FreeTensor(inT);
        outT = qOut.DeQue<T>();
        DataCopyPad(yGm[off], outT, cpExt);
        qOut.FreeTensor(outT);
    }
}

static std::tuple<int64_t, int64_t, int64_t>
calc_mish_tiling(int64_t totalLen)
{
    constexpr int64_t MIN_PER_CORE = 1024;
    auto plat = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubBytes = 0;
    plat->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubBytes);
    int64_t coreNum = plat->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t nBlocks = std::min(coreNum, (totalLen + MIN_PER_CORE - 1) / MIN_PER_CORE);
    if (nBlocks <= 0) nBlocks = 1;

    int64_t blkLen   = (totalLen + nBlocks - 1) / nBlocks;
    int64_t tileElem = static_cast<int64_t>(ubBytes) / (PIPE_DEPTH * TOTAL_BUFS * static_cast<int64_t>(sizeof(float)));
    if (tileElem < 32) tileElem = 32;
    /* Align down to 32 for vector-friendliness */
    tileElem = (tileElem / 32) * 32;

    return std::make_tuple(nBlocks, blkLen, tileElem);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLen,
                              int64_t numBlocks, int64_t blkLen,
                              int64_t tileElems, void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLen, blkLen, tileElems);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLen,
                             int64_t numBlocks, int64_t blkLen,
                             int64_t tileElems, void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLen, blkLen, tileElems);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLen,
                                 int64_t numBlocks, int64_t blkLen,
                                 int64_t tileElems, void *stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLen, blkLen, tileElems);
}

}
