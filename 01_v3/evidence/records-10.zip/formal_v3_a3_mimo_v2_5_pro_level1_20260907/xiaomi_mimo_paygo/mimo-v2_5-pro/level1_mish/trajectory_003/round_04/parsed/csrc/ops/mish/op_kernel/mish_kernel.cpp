/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr int32_t PIPE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR xPtr, GM_ADDR yPtr,
                                       int64_t totalLen, int64_t blkLen,
                                       int64_t tileElems)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPE_DEPTH> qIn;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPE_DEPTH> qOut;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tBuf;

    int32_t tb = static_cast<int32_t>(tileElems) * static_cast<int32_t>(sizeof(T));
    pipe.InitBuffer(qIn, PIPE_DEPTH, tb);
    pipe.InitBuffer(qOut, PIPE_DEPTH, tb);
    pipe.InitBuffer(tBuf, tb * 2);

    int64_t bid = AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T*)xPtr + blkLen * bid);
    yGm.SetGlobalBuffer((__gm__ T*)yPtr + blkLen * bid);

    int64_t myLen = totalLen - blkLen * bid;
    if (myLen > blkLen) myLen = blkLen;
    int32_t te = static_cast<int32_t>(tileElems);
    int64_t nFull = myLen / te;
    int32_t nTail = static_cast<int32_t>(myLen % te);

    for (int64_t i = 0; i <= nFull; i++) {
        int32_t cnt = (i < nFull) ? te : nTail;
        if (cnt <= 0) break;
        int64_t off = i * te;
        uint32_t cpSz = static_cast<uint32_t>(cnt) * static_cast<uint32_t>(sizeof(T));
        AscendC::DataCopyExtParams cp{1, cpSz, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> pad{false, 0, 0, 0};

        auto in = qIn.AllocTensor<T>();
        AscendC::DataCopyPad(in, xGm[off], cp, pad);
        qIn.EnQue(in);
        in = qIn.DeQue<T>();

        auto t0 = tBuf.Get<T>();
        auto t1 = t0[te];

        AscendC::Abs(t0, in, cnt);
        AscendC::Add(t1, in, t0, cnt);
        AscendC::Muls(t1, t1, static_cast<T>(0.5f), cnt);
        AscendC::Muls(t0, t0, static_cast<T>(-1.0f), cnt);
        AscendC::Exp(t0, t0, cnt);
        AscendC::Adds(t0, t0, static_cast<T>(1.0f), cnt);
        AscendC::Ln(t0, t0, cnt);
        AscendC::Add(t0, t1, t0, cnt);
        AscendC::Tanh(t0, t0, cnt);

        auto out = qOut.AllocTensor<T>();
        AscendC::Mul(out, in, t0, cnt);
        qOut.EnQue(out);
        qIn.FreeTensor(in);
        out = qOut.DeQue<T>();
        AscendC::DataCopyPad(yGm[off], out, cp);
        qOut.FreeTensor(out);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling(int64_t totalLen, int32_t elemSize)
{
    auto plat = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize = 0;
    plat->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = plat->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t nBlocks = std::min(coreNum, (totalLen + 1023) / 1024);
    if (nBlocks <= 0) nBlocks = 1;
    int64_t blkLen = (totalLen + nBlocks - 1) / nBlocks;

    int64_t tileElems = static_cast<int64_t>(ubSize) / (8 * elemSize);
    if (tileElems < 32) tileElems = 32;
    tileElems = (tileElems / 32) * 32;

    return std::make_tuple(nBlocks, blkLen, tileElems);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLen,
                              int64_t numBlocks, int64_t blkLen,
                              int64_t tileElems, void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLen, blkLen, tileElems);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLen,
                             int64_t numBlocks, int64_t blkLen,
                             int64_t tileElems, void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLen, blkLen, tileElems);
}

void launch_mish_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLen,
                             int64_t numBlocks, int64_t blkLen,
                             int64_t tileElems, void *stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLen, blkLen, tileElems);
}

}
