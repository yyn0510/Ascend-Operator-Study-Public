/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr int32_t PIPE_DEPTH = 2;

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength, int64_t blockLength,
                                       int32_t tileElements)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;
    AscendC::TQue<AscendC::QuePosition::VECIN, PIPE_DEPTH> qIn;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPE_DEPTH> qOut;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tBufA;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tBufB;

    int32_t tb = tileElements * static_cast<int32_t>(sizeof(T));
    pipe.InitBuffer(qIn, PIPE_DEPTH, tb);
    pipe.InitBuffer(qOut, PIPE_DEPTH, tb);
    pipe.InitBuffer(tBufA, tb);
    pipe.InitBuffer(tBufB, tb);

    int64_t blockOffset = blockLength * AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T*)x + blockOffset);
    yGm.SetGlobalBuffer((__gm__ T*)y + blockOffset);

    int64_t curLen = totalLength - blockOffset;
    if (curLen > blockLength) curLen = blockLength;
    int32_t te = tileElements;
    int64_t nFull = curLen / te;
    int32_t tail = static_cast<int32_t>(curLen - nFull * te);

    AscendC::DataCopyPadExtParams<T> noPad{false, 0, 0, 0};

    for (int64_t i = 0; i < nFull; ++i) {
        int64_t offset = i * te;
        uint32_t cpBytes = static_cast<uint32_t>(te * sizeof(T));
        AscendC::DataCopyExtParams cp{1, cpBytes, 0, 0, 0};

        auto inT = qIn.AllocTensor<T>();
        AscendC::DataCopyPad(inT, xGm[offset], cp, noPad);
        qIn.EnQue(inT);
        inT = qIn.DeQue<T>();

        auto softplus = tBufA.Get<T>();
        AscendC::Abs(softplus, inT, te);
        AscendC::Muls(softplus, softplus, static_cast<T>(-1.0f), te);
        AscendC::Exp(softplus, softplus, te);
        AscendC::Adds(softplus, softplus, static_cast<T>(1.0f), te);
        AscendC::Ln(softplus, softplus, te);
        AscendC::Abs(tBufB.Get<T>(), inT, te);
        AscendC::Add(softplus, softplus, tBufB.Get<T>(), te);

        AscendC::Tanh(softplus, softplus, te);

        auto outT = qOut.AllocTensor<T>();
        AscendC::Mul(outT, inT, softplus, te);
        qOut.EnQue(outT);
        qIn.FreeTensor(inT);
        outT = qOut.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], outT, cp);
        qOut.FreeTensor(outT);
    }

    if (tail > 0) {
        int64_t offset = nFull * te;
        uint32_t cpBytes = static_cast<uint32_t>(tail * sizeof(T));
        AscendC::DataCopyExtParams cp{1, cpBytes, 0, 0, 0};

        auto inT = qIn.AllocTensor<T>();
        AscendC::DataCopyPad(inT, xGm[offset], cp, noPad);
        qIn.EnQue(inT);
        inT = qIn.DeQue<T>();

        auto softplus = tBufA.Get<T>();
        AscendC::Abs(softplus, inT, tail);
        AscendC::Muls(softplus, softplus, static_cast<T>(-1.0f), tail);
        AscendC::Exp(softplus, softplus, tail);
        AscendC::Adds(softplus, softplus, static_cast<T>(1.0f), tail);
        AscendC::Ln(softplus, softplus, tail);
        AscendC::Abs(tBufB.Get<T>(), inT, tail);
        AscendC::Add(softplus, softplus, tBufB.Get<T>(), tail);

        AscendC::Tanh(softplus, softplus, tail);

        auto outT = qOut.AllocTensor<T>();
        AscendC::Mul(outT, inT, softplus, tail);
        qOut.EnQue(outT);
        qIn.FreeTensor(inT);
        outT = qOut.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], outT, cp);
        qOut.FreeTensor(outT);
    }
}

std::tuple<int64_t, int64_t, int32_t> calc_mish_tiling(int64_t totalLength, int32_t elemSize)
{
    auto platform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    platform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = platform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;

    int64_t numBlocks = std::min(coreNum, (totalLength + 1023) / 1024);
    if (numBlocks <= 0) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;

    constexpr int32_t TOTAL_BUFS = 6;
    int64_t raw = static_cast<int64_t>(ubSize) / (PIPE_DEPTH * TOTAL_BUFS * elemSize);
    if (raw < 32) raw = 32;
    int32_t tileElements = static_cast<int32_t>((raw / 32) * 32);

    return std::make_tuple(numBlocks, blockLength, tileElements);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                              int64_t numBlocks, int64_t blockLength,
                              int32_t tileElements, void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElements);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength,
                             int32_t tileElements, void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElements);
}

void launch_mish_kernel_bf16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength,
                             int32_t tileElements, void *stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileElements);
}

}
