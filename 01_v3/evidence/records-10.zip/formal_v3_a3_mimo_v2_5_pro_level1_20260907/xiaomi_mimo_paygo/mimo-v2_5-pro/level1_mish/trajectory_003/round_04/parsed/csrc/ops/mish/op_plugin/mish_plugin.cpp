/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>
#include "torch_npu/csrc/core/npu/NPUStream.h"
#include "torch_npu/csrc/framework/OpCommand.h"

#include "../op_kernel/mish_launch.h"

namespace cann_bench {

TORCH_LIBRARY_FRAGMENT(cann_bench, m)
{
    m.def("mish(Tensor x) -> Tensor");
}

torch::Tensor mish_meta(const torch::Tensor &x)
{
    return torch::empty_like(x);
}

TORCH_LIBRARY_IMPL(cann_bench, Meta, m)
{
    m.impl("mish", mish_meta);
}

torch::Tensor mish_npu(const torch::Tensor &x)
{
    const c10::OptionalDeviceGuard guard(x.device());
    auto y = mish_meta(x);
    auto stream = c10_npu::getCurrentNPUStream().stream(false);
    int64_t totalLen = x.numel();
    int32_t elemSize = static_cast<int32_t>(x.element_size());
    int64_t numBlocks, blkLen, tileElems;
    std::tie(numBlocks, blkLen, tileElems) = calc_mish_tiling(totalLen, elemSize);
    auto x_ptr = static_cast<GM_ADDR>(x.data_ptr());
    auto y_ptr = static_cast<GM_ADDR>(y.data_ptr());

    auto acl_call = [=]() -> int {
        if (x.scalar_type() == torch::kFloat32) {
            launch_mish_kernel_float(x_ptr, y_ptr, totalLen, numBlocks, blkLen, tileElems, stream);
        } else if (x.scalar_type() == torch::kFloat16) {
            launch_mish_kernel_half(x_ptr, y_ptr, totalLen, numBlocks, blkLen, tileElems, stream);
        } else if (x.scalar_type() == torch::kBFloat16) {
            launch_mish_kernel_bf16(x_ptr, y_ptr, totalLen, numBlocks, blkLen, tileElems, stream);
        }
        return 0;
    };

    at_npu::native::OpCommand::RunOpApi("Mish", acl_call);
    return y;
}

TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1, m)
{
    m.impl("mish", mish_npu);
}

}
