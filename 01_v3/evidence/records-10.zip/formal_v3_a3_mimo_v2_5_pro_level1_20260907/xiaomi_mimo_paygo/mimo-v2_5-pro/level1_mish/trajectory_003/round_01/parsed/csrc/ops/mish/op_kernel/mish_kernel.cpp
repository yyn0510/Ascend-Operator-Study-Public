/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file mish_kernel.cpp
 * \brief Mish kernel implementation - kernel, host tiling, and launch wrappers (compiled with bisheng -xasc)
 * Mish: y = x * tanh(softplus(x)) = x * tanh(ln(1 + e^x))
 * Numerically stable softplus: softplus(x) = |x| + ln(1 + e^{-|x|})
 */

#include <tuple>
#include <algorithm>
#include "kernel_operator.h"
#include "platform/platform_ascendc.h"

constexpr static int32_t PIPELINE_DEPTH = 2;
constexpr static int32_t BUFFER_NUM = 3;  // 1 input queue + 1 output queue + overhead

template <typename T>
__global__ __aicore__ void mish_kernel(GM_ADDR x, GM_ADDR y,
                                       int64_t totalLength, int64_t blockLength,
                                       uint32_t tileSize)
{
    AscendC::TPipe pipe;
    AscendC::GlobalTensor<T> xGm, yGm;

    AscendC::TQue<AscendC::QuePosition::VECIN, PIPELINE_DEPTH> inQueue;
    AscendC::TQue<AscendC::QuePosition::VECOUT, PIPELINE_DEPTH> outQueue;
    AscendC::TBuf<AscendC::TPosition::VECCALC> tmpBuf;

    pipe.InitBuffer(inQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(outQueue, PIPELINE_DEPTH, tileSize);
    pipe.InitBuffer(tmpBuf, tileSize);

    int64_t blockIdx = AscendC::GetBlockIdx();
    xGm.SetGlobalBuffer((__gm__ T *)x + blockLength * blockIdx);
    yGm.SetGlobalBuffer((__gm__ T *)y + blockLength * blockIdx);

    int64_t currentBlockLength = totalLength - blockIdx * blockLength;
    if (currentBlockLength > blockLength) {
        currentBlockLength = blockLength;
    }
    int64_t elementNumPerTile = static_cast<int64_t>(tileSize) / sizeof(T);
    int64_t tileNum = currentBlockLength / elementNumPerTile;
    int64_t tailTileElementNum = currentBlockLength - tileNum * elementNumPerTile;

    for (int64_t i = 0; i < tileNum; ++i) {
        int64_t offset = i * elementNumPerTile;
        AscendC::DataCopyExtParams copyParams{1, static_cast<uint32_t>(elementNumPerTile * sizeof(T)), 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        auto tmpLocal = tmpBuf.Get<T>();

        // softplus(x) = |x| + ln(1 + exp(-|x|))
        AscendC::Abs(tmpLocal, xLocal, elementNumPerTile);
        AscendC::Muls(tmpLocal, tmpLocal, (T)(-1.0f), elementNumPerTile);
        AscendC::Exp(tmpLocal, tmpLocal, elementNumPerTile);
        AscendC::Adds(tmpLocal, tmpLocal, (T)(1.0f), elementNumPerTile);
        AscendC::Ln(tmpLocal, tmpLocal, elementNumPerTile);
        AscendC::Abs(yLocal, xLocal, elementNumPerTile);
        AscendC::Add(tmpLocal, yLocal, tmpLocal, elementNumPerTile);

        // y = x * tanh(softplus(x))
        AscendC::Tanh(tmpLocal, tmpLocal, elementNumPerTile);
        AscendC::Mul(yLocal, xLocal, tmpLocal, elementNumPerTile);

        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);
        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }

    if (tailTileElementNum > 0) {
        int64_t offset = tileNum * elementNumPerTile;
        uint32_t tailSize = static_cast<uint32_t>(tailTileElementNum * sizeof(T));
        AscendC::DataCopyExtParams copyParams{1, tailSize, 0, 0, 0};
        AscendC::DataCopyPadExtParams<T> padParams{false, 0, 0, 0};

        auto xLocal = inQueue.AllocTensor<T>();
        AscendC::DataCopyPad(xLocal, xGm[offset], copyParams, padParams);
        inQueue.EnQue(xLocal);
        xLocal = inQueue.DeQue<T>();

        auto yLocal = outQueue.AllocTensor<T>();
        auto tmpLocal = tmpBuf.Get<T>();

        AscendC::Abs(tmpLocal, xLocal, tailTileElementNum);
        AscendC::Muls(tmpLocal, tmpLocal, (T)(-1.0f), tailTileElementNum);
        AscendC::Exp(tmpLocal, tmpLocal, tailTileElementNum);
        AscendC::Adds(tmpLocal, tmpLocal, (T)(1.0f), tailTileElementNum);
        AscendC::Ln(tmpLocal, tmpLocal, tailTileElementNum);
        AscendC::Abs(yLocal, xLocal, tailTileElementNum);
        AscendC::Add(tmpLocal, yLocal, tmpLocal, tailTileElementNum);
        AscendC::Tanh(tmpLocal, tmpLocal, tailTileElementNum);
        AscendC::Mul(yLocal, xLocal, tmpLocal, tailTileElementNum);

        outQueue.EnQue(yLocal);
        inQueue.FreeTensor(xLocal);
        yLocal = outQueue.DeQue<T>();
        AscendC::DataCopyPad(yGm[offset], yLocal, copyParams);
        outQueue.FreeTensor(yLocal);
    }
}

std::tuple<int64_t, int64_t, int64_t> calc_mish_tiling_params(int64_t totalLength)
{
    constexpr static int64_t MIN_ELEMS_PER_CORE = 1024;
    auto ascendcPlatform = platform_ascendc::PlatformAscendCManager::GetInstance();
    uint64_t ubSize;
    ascendcPlatform->GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    int64_t coreNum = ascendcPlatform->GetCoreNumAiv();
    if (coreNum <= 0) coreNum = 1;
    int64_t numBlocks = std::min(coreNum, (totalLength + MIN_ELEMS_PER_CORE - 1) / MIN_ELEMS_PER_CORE);
    if (numBlocks <= 0) numBlocks = 1;
    int64_t blockLength = (totalLength + numBlocks - 1) / numBlocks;
    int64_t tileSize = static_cast<int64_t>(ubSize) / PIPELINE_DEPTH / BUFFER_NUM;
    return std::make_tuple(numBlocks, blockLength, tileSize);
}

extern "C" {

void launch_mish_kernel_float(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                              int64_t numBlocks, int64_t blockLength,
                              uint32_t tileSize, void *stream)
{
    mish_kernel<float><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_half(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                             int64_t numBlocks, int64_t blockLength,
                             uint32_t tileSize, void *stream)
{
    mish_kernel<half><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

void launch_mish_kernel_bfloat16(GM_ADDR x, GM_ADDR y, int64_t totalLength,
                                 int64_t numBlocks, int64_t blockLength,
                                 uint32_t tileSize, void *stream)
{
    mish_kernel<bfloat16_t><<<numBlocks, nullptr, stream>>>(x, y, totalLength, blockLength, tileSize);
}

}
