from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import httpx
import yaml
from openai import APIConnectionError, APITimeoutError, RateLimitError

from assemble_submission import DEFAULT_SKELETON, assemble
from benchsite_mcp_client import (
    DEFAULT_KERMINAL_CONFIG,
    DEFAULT_PLATFORM_CONFIG,
    StdioMcpClient,
    load_benchsite_server,
    load_platform_profile,
    poll_job,
    submit_kernel_rest,
    validate_submission_path,
    verify_job_environment,
    verify_live_runner_profile,
)
from feedback_builder import (
    build_parse_feedback,
    build_platform_feedback,
    build_platform_fallback_feedback,
    build_platform_feedback_v2,
    error_fingerprint,
    render_feedback_prompt,
    sha256_text,
)
from modelscope_common import (
    RUNS_PATH,
    create_client,
    load_config,
    load_selected_model,
    response_to_dict,
    timestamp,
    write_json,
)
from parse_output import parse_run


ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
DEFAULT_PROTOCOL = ROOT / "experiment_protocol_iterative_5round_3trajectory_one_shot_add_v3.yaml"
DEFAULT_FEEDBACK_TEMPLATE = (
    PROJECT_ROOT / "文档" / "提示词模板" / "多轮反馈迭代-评测反馈提示词模板.md"
)
RETRYABLE_ERRORS = (
    APIConnectionError,
    APITimeoutError,
    RateLimitError,
    httpx.TransportError,
)

DEFAULT_LONG_GENERATION_THRESHOLD_SECONDS = 1200.0


class MalformedProviderResponse(RuntimeError):
    pass


def cost_budget_limit() -> float | None:
    """Return the per-run USD limit configured for this process, if any."""
    raw = os.environ.get("MODEL_EVAL_COST_LIMIT_USD", "").strip()
    if not raw:
        return None
    try:
        limit = float(raw)
    except ValueError as error:
        raise ValueError("MODEL_EVAL_COST_LIMIT_USD 必须是正数") from error
    if limit <= 0:
        raise ValueError("MODEL_EVAL_COST_LIMIT_USD 必须大于 0")
    return limit


def cost_budget_ledger_path() -> Path | None:
    raw = os.environ.get("MODEL_EVAL_COST_LEDGER", "").strip()
    if not raw:
        return None
    return Path(raw).expanduser().resolve()


def read_cost_budget() -> dict[str, Any] | None:
    limit = cost_budget_limit()
    ledger_path = cost_budget_ledger_path()
    if limit is None or ledger_path is None:
        return None
    if not ledger_path.is_file():
        state: dict[str, Any] = {
            "limit_usd": limit,
            "spent_usd": 0.0,
            "cost_unknown": False,
            "events": [],
        }
        write_json(ledger_path, state)
        return state
    state = load_json(ledger_path)
    configured_limit = float(state.get("limit_usd", limit))
    if abs(configured_limit - limit) > 1e-9:
        raise ValueError(
            "预算账本与 MODEL_EVAL_COST_LIMIT_USD 不一致: "
            f"ledger={configured_limit}, env={limit}"
        )
    state.setdefault("spent_usd", 0.0)
    state.setdefault("cost_unknown", False)
    state.setdefault("events", [])
    return state


def cost_budget_exhausted() -> tuple[bool, dict[str, Any] | None]:
    state = read_cost_budget()
    if state is None:
        return False, None
    limit = float(state["limit_usd"])
    spent = float(state.get("spent_usd", 0.0))
    exhausted = bool(state.get("cost_unknown")) or spent >= limit
    return exhausted, state


def record_model_cost(
    *, raw_response: dict[str, Any], round_dir: Path, model_id: str
) -> float | None:
    """Persist OpenRouter's billed response cost to the shared run ledger."""
    state = read_cost_budget()
    usage = raw_response.get("usage")
    cost: float | None = None
    if isinstance(usage, dict) and usage.get("cost") is not None:
        try:
            cost = float(usage["cost"])
        except (TypeError, ValueError):
            cost = None
    if state is not None:
        if cost is None:
            state["cost_unknown"] = True
        else:
            state["spent_usd"] = float(state.get("spent_usd", 0.0)) + cost
            state.setdefault("events", []).append(
                {
                    "recorded_at": timestamp(),
                    "model": model_id,
                    "round_directory": str(round_dir),
                    "cost_usd": cost,
                    "cumulative_spent_usd": state["spent_usd"],
                }
            )
        write_json(cost_budget_ledger_path(), state)
    return cost


def safe_name(value: str) -> str:
    cleaned = "".join(char if char.isalnum() or char in "-_" else "_" for char in value)
    if not cleaned:
        raise ValueError("名称不能为空")
    return cleaned


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON 顶层必须是对象: {path}")
    return value


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_protocol(path: Path) -> dict[str, Any]:
    protocol = yaml.safe_load(path.read_text(encoding="utf-8-sig"))
    if not isinstance(protocol, dict):
        raise ValueError("实验协议必须是 YAML 对象")
    experiment = protocol.get("experiment", {})
    if experiment.get("track") != "iterative_platform_feedback_tool_free":
        raise ValueError("当前脚本只允许 iterative_platform_feedback_tool_free")
    trajectories = experiment.get("trajectories_per_model_task")
    rounds = experiment.get("rounds_per_trajectory")
    if not isinstance(trajectories, int) or trajectories < 1:
        raise ValueError("trajectories_per_model_task 必须是正整数")
    if not isinstance(rounds, int) or rounds < 2:
        raise ValueError("rounds_per_trajectory 必须至少为 2")
    generation = protocol.get("generation", {})
    if generation.get("tools") is not False:
        raise ValueError("该赛道必须关闭模型工具")
    if int(generation.get("content_retries", -1)) != 0:
        raise ValueError("模型内容失败不得自动重试")
    context = protocol.get("context", {})
    if context.get("policy") != "rolling_latest_state":
        raise ValueError("当前实现只支持 rolling_latest_state")
    if context.get("include_earlier_rounds") is not False:
        raise ValueError("为冻结上下文压力，禁止发送更早轮次历史")
    if protocol.get("stopping", {}).get("always_run_all_rounds") is not True:
        raise ValueError("正式多轮协议必须运行协议规定的全部轮次")
    template_version = protocol.get("task_input", {}).get("prompt_template_version")
    if template_version in {"iterative_one_shot_add_v2", "iterative_one_shot_add_v3"}:
        feedback = protocol.get("feedback", {})
        if feedback.get("stage_aware") is not True:
            raise ValueError("v2/v3 协议必须启用 stage_aware 阶段感知反馈")
        if context.get("include_attempt_log") is not True:
            raise ValueError("v2/v3 协议必须启用 include_attempt_log 历轮尝试记录")
        summary = protocol.get("change_summary", {})
        if int(summary.get("max_characters", 0)) <= 0:
            raise ValueError("v2/v3 协议必须设置 change_summary.max_characters")
    if template_version == "iterative_one_shot_add_v3":
        purpose = experiment.get("purpose", "formal")
        if purpose == "formal":
            if trajectories != 3 or rounds != 5:
                raise ValueError("V3 正式协议必须固定为 3 条轨迹 × 5 轮")
            if experiment.get("primary_metric") != "best_score_within_5_rounds":
                raise ValueError("V3 主指标必须是 best_score_within_5_rounds")
        elif purpose == "smoke_test":
            if trajectories != 1 or rounds != 2:
                raise ValueError("V3 smoke test 必须固定为 1 条轨迹 × 2 轮")
            if experiment.get("primary_metric") != "best_score_within_2_rounds":
                raise ValueError("V3 smoke test 主指标必须是 best_score_within_2_rounds")
        else:
            raise ValueError(f"未知的 V3 experiment.purpose: {purpose}")
        if generation.get("seed_policy") != "provider_unseeded_independent_trajectories":
            raise ValueError("V3 必须显式声明托管 Provider 的未设 seed 独立轨迹策略")
        feedback = protocol.get("feedback", {})
        if feedback.get("schema") != "cannbench_iterative_feedback_v3":
            raise ValueError("V3 反馈 schema 不匹配")
        if int(feedback.get("success_max_performance_cases", 0)) != 3:
            raise ValueError("V3 成功反馈必须固定选择性能最差的 3 个 case")
        submission = protocol.get("submission", {})
        if submission.get("settings_source") != "protocol":
            raise ValueError("V3 提交可见性与标签必须由冻结协议控制")
        if submission.get("private_submission") is not True:
            raise ValueError("V3 必须使用私有提交")
        artifacts = protocol.get("artifacts", {})
        for artifact_key in (
            "save_submission_receipt_every_round",
            "save_runner_warnings_every_round",
            "save_raw_platform_result_every_round",
            "save_environment_verification_every_round",
        ):
            if artifacts.get(artifact_key) is not True:
                raise ValueError(f"V3 必须启用审计项: {artifact_key}")
    return protocol


def response_is_structurally_valid(response: Any) -> bool:
    choices = getattr(response, "choices", None)
    if not choices:
        return False
    message = getattr(choices[0], "message", None)
    return message is not None


def retry_delay_seconds(error: Exception, attempt_number: int) -> int:
    if isinstance(error, RateLimitError) and "limit_burst_rate" in str(error):
        return 30 * attempt_number
    return 5 * attempt_number


def completion_token_kwargs(max_tokens: int, parameter_name: str) -> dict[str, int]:
    if parameter_name not in {"max_tokens", "max_completion_tokens"}:
        raise ValueError(
            "generation.max_tokens_parameter 只允许 max_tokens 或 "
            "max_completion_tokens"
        )
    return {parameter_name: max_tokens}


def completion_request_kwargs(
    *,
    model: str,
    messages: list[dict[str, str]],
    temperature: float | None,
    max_tokens: int,
    max_tokens_parameter: str,
    extra_body: dict[str, Any] | None,
    stream: bool,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "model": model,
        "messages": messages,
        **completion_token_kwargs(max_tokens, max_tokens_parameter),
    }
    if temperature is not None:
        kwargs["temperature"] = temperature
    if extra_body is not None:
        kwargs["extra_body"] = extra_body
    if stream:
        kwargs["stream"] = True
    return kwargs


def create_streaming_response(
    client: Any,
    *,
    model: str,
    messages: list[dict[str, str]],
    temperature: float | None,
    max_tokens: int,
    max_tokens_parameter: str,
    extra_body: dict[str, Any] | None,
    save_stream_chunks: bool = True,
) -> Any:
    stream = client.chat.completions.create(**completion_request_kwargs(
        model=model,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
        max_tokens_parameter=max_tokens_parameter,
        extra_body=extra_body,
        stream=True,
    ))
    content_parts: list[str] = []
    reasoning_content_parts: list[str] = []
    reasoning_parts: list[str] = []
    reasoning_details: list[Any] = []
    raw_chunks: list[dict[str, Any]] = []
    response_id = ""
    returned_model = model
    provider: str | None = None
    created = 0
    finish_reason: str | None = None
    usage: dict[str, Any] | None = None
    system_fingerprint: str | None = None
    stream_chunk_count = 0
    for chunk in stream:
        raw_chunk = response_to_dict(chunk)
        stream_chunk_count += 1
        if save_stream_chunks:
            raw_chunks.append(raw_chunk)
        response_id = str(raw_chunk.get("id") or response_id)
        returned_model = str(raw_chunk.get("model") or returned_model)
        provider = raw_chunk.get("provider") or provider
        created = int(raw_chunk.get("created") or created)
        system_fingerprint = raw_chunk.get("system_fingerprint") or system_fingerprint
        if raw_chunk.get("usage") is not None:
            usage = raw_chunk["usage"]
        choices = getattr(chunk, "choices", None) or []
        if not choices:
            continue
        choice = choices[0]
        delta = getattr(choice, "delta", None)
        raw_choices = raw_chunk.get("choices") or []
        raw_choice = raw_choices[0] if raw_choices else {}
        raw_delta = raw_choice.get("delta") or {}
        content = raw_delta.get("content")
        if content is None and delta is not None:
            content = getattr(delta, "content", None)
        if isinstance(content, str):
            content_parts.append(content)
        reasoning_content = raw_delta.get("reasoning_content")
        if reasoning_content is None and delta is not None:
            reasoning_content = getattr(delta, "reasoning_content", None)
        if isinstance(reasoning_content, str):
            reasoning_content_parts.append(reasoning_content)
        reasoning = raw_delta.get("reasoning")
        if reasoning is None and delta is not None:
            reasoning = getattr(delta, "reasoning", None)
        if isinstance(reasoning, str):
            reasoning_parts.append(reasoning)
        details = raw_delta.get("reasoning_details")
        if details is None and delta is not None:
            details = getattr(delta, "reasoning_details", None)
        if isinstance(details, list):
            reasoning_details.extend(details)
        elif details is not None:
            reasoning_details.append(details)
        if getattr(choice, "finish_reason", None) is not None:
            finish_reason = str(choice.finish_reason)
    output_text = "".join(content_parts)
    raw_response = {
        "id": response_id,
        "object": "chat.completion.stream.aggregate",
        "created": created,
        "model": returned_model,
        "provider": provider,
        "system_fingerprint": system_fingerprint,
        "choices": [{
            "index": 0,
            "message": {
                "role": "assistant",
                "content": output_text,
                "reasoning_content": "".join(reasoning_content_parts) or None,
                "reasoning": "".join(reasoning_parts) or None,
                "reasoning_details": reasoning_details or None,
            },
            "finish_reason": finish_reason,
        }],
        "usage": usage,
        "stream": True,
        "stream_chunk_count": stream_chunk_count,
        "stream_chunks_saved": save_stream_chunks,
    }
    if save_stream_chunks:
        raw_response["stream_chunks"] = raw_chunks
    return SimpleNamespace(
        choices=[SimpleNamespace(
            message=SimpleNamespace(content=output_text),
            finish_reason=finish_reason,
        )],
        model_dump=lambda mode=None: raw_response,
    )


EXPECTED_FILES = (
    "op_kernel/{op}_kernel.cpp",
    "op_kernel/{op}_launch.h",
    "op_plugin/{op}_plugin.cpp",
    "CMakeLists.txt",
)


def five_file_hashes(round_dir: Path, op_name: str) -> dict[str, str] | None:
    parsed = round_dir / "parsed" / "csrc" / "ops" / op_name
    if not parsed.is_dir():
        return None
    hashes: dict[str, str] = {}
    for relative in EXPECTED_FILES:
        path = parsed / relative.format(op=op_name)
        if path.is_file():
            hashes[relative] = file_sha256(path)
        else:
            return None
    append = round_dir / "parsed" / "cann_bench" / "__init__.py.append"
    if append.is_file():
        hashes["cann_bench/__init__.py.append"] = file_sha256(append)
    else:
        return None
    return hashes


def combined_source_hash(hashes: dict[str, str] | None) -> str | None:
    if not hashes:
        return None
    return sha256_text(json.dumps(hashes, ensure_ascii=False, sort_keys=True))


def changed_files(
    previous: dict[str, str] | None, current: dict[str, str] | None
) -> list[str]:
    if previous is None or current is None:
        return []
    return sorted(
        name for name in current if previous.get(name) != current[name]
    )


def build_attempt_log(
    trajectory_dir: Path,
    op_name: str,
    *,
    max_characters: int = 12000,
) -> str:
    """机械生成历轮尝试记录，供下一轮上下文携带。

    模型简述只视为模型声明；改动文件、平台结果、错误指纹与哈希均由 Harness 生成。
    """
    entries: list[str] = []
    previous_hashes: dict[str, str] | None = None
    for round_number in range(1, 100):
        round_dir = trajectory_dir / f"round_{round_number:02d}"
        status_path = round_dir / "status.json"
        if not status_path.is_file():
            break
        status: dict[str, Any] = load_json(status_path)
        if status.get("status") != "round_completed":
            break
        summary_path = round_dir / "change_summary.json"
        summary: dict[str, Any] = {}
        if summary_path.is_file():
            summary = load_json(summary_path)
        model_summary = summary.get("summary_truncated") or summary.get("summary")
        hashes = five_file_hashes(round_dir, op_name)
        current_hash = combined_source_hash(hashes)
        changed = [
            name.format(op=op_name) for name in changed_files(previous_hashes, hashes)
        ]

        job_status = status.get("job_status") or status.get("outcome") or "unknown"
        result_path = round_dir / "benchsite_result.json"
        fingerprint = None
        if result_path.is_file():
            fingerprint = error_fingerprint(load_json(result_path))
        consistency: bool | None = None
        if previous_hashes is not None and hashes is not None:
            if model_summary:
                consistency = current_hash != previous_hash
            else:
                consistency = None
        previous_hash = current_hash
        previous_hashes = hashes

        entry_lines = [f"R{round_number}"]
        entry_lines.append(
            f"模型简述：{model_summary if model_summary else '（缺失）'}"
        )
        entry_lines.append(
            "实际改动文件："
            + (
                ", ".join(changed)
                if changed
                else (
                    "（无可比较源码快照）"
                    if hashes is None
                    else (
                        "（无上一轮可比较快照）"
                        if previous_hashes is None
                        else "（无，与上一轮完全相同）"
                    )
                )
            )
        )
        entry_lines.append(f"平台结果：{job_status}")
        entry_lines.append(
            f"关键错误指纹：{fingerprint if fingerprint else '-'}"
        )
        entry_lines.append(f"源码哈希：{current_hash if current_hash else '-'}")
        if consistency is not None:
            entry_lines.append(f"change_summary_consistency: {str(consistency).lower()}")
        entries.append("\n".join(entry_lines))

    log = "\n\n".join(entries)
    if len(log) > max_characters:
        log = (
            log[:max_characters].rstrip()
            + f"\n...[历轮尝试记录被固定规则截断，超出 {max_characters} 字符]"
        )
    return log


def generation_elapsed_seconds(round_dir: Path | None) -> float | None:
    """读取上一轮模型生成耗时；缺少记录时返回 None。"""
    if round_dir is None:
        return None
    generation_status_path = round_dir / "generation_status.json"
    if not generation_status_path.is_file():
        return None
    generation_status = load_json(generation_status_path)
    elapsed = generation_status.get("elapsed_seconds")
    if isinstance(elapsed, bool) or not isinstance(elapsed, (int, float)):
        return None
    return float(elapsed)


def long_generation_notice(
    elapsed_seconds: float,
    threshold_seconds: float,
) -> str:
    return (
        "!!! 上一轮生成耗时过长，本轮必须适当精简思考并尽快输出！！！\n"
        f"上一轮模型生成耗时约 {elapsed_seconds:.0f} 秒，超过 "
        f"{threshold_seconds:.0f} 秒的长耗时阈值。"
        "本轮请直接基于上一轮代码与反馈完成修改，减少无关分析、反复推演和大段自我讨论，"
        "优先尽快输出完整的五个文件和不超过 300 字的 CHANGE SUMMARY。"
        "不要省略必要实现或文件内容。"
    )


def build_messages(
    initial_prompt: str,
    previous_round_dir: Path | None,
    attempt_log: str | None = None,
    long_generation_threshold_seconds: float | None = None,
) -> list[dict[str, str]]:
    messages = [{"role": "user", "content": initial_prompt}]
    if previous_round_dir is None:
        return messages
    previous_output = (previous_round_dir / "model_output.txt").read_text(
        encoding="utf-8-sig"
    )
    previous_feedback = (previous_round_dir / "feedback_prompt.txt").read_text(
        encoding="utf-8-sig"
    )
    messages.extend(
        [
            {"role": "assistant", "content": previous_output},
            {"role": "user", "content": previous_feedback},
        ]
    )
    if attempt_log:
        messages.append(
            {
                "role": "user",
                "content": "## 历轮尝试记录（Harness 机械记录，仅供避免重复尝试）\n\n"
                + attempt_log,
            }
        )
    previous_elapsed_seconds = generation_elapsed_seconds(previous_round_dir)
    if (
        long_generation_threshold_seconds is not None
        and previous_elapsed_seconds is not None
        and previous_elapsed_seconds > long_generation_threshold_seconds
    ):
        messages.append(
            {
                "role": "user",
                "content": long_generation_notice(
                    previous_elapsed_seconds,
                    long_generation_threshold_seconds,
                ),
            }
        )
    previous_status_path = previous_round_dir / "status.json"
    if previous_status_path.is_file():
        previous_status = load_json(previous_status_path)
        if (
            previous_status.get("format_recovered") is True
            and previous_status.get("strict_protocol_pass") is False
        ):
            messages.append(
                {
                    "role": "user",
                    "content": (
                        "!!! 严格格式提醒！！！\n"
                        "上一轮虽然通过了宽松格式恢复，但没有严格遵循固定输出协议！"
                        "本轮必须严格按照原始提示词输出，不能依赖宽松恢复！！！\n"
                        "必须且只能按规定顺序输出 5 个完整文件块；每个文件都要有准确的 "
                        "`=== FILE: ... ===` 与 `=== END FILE ===` 边界；不得输出 Markdown 代码围栏、"
                        "文件块外解释或额外文件；五个文件之后必须紧接不超过 300 字的 "
                        "`=== CHANGE SUMMARY ===` 块。请严格遵守！！！"
                    ),
                }
            )
    return messages


def message_metadata(messages: list[dict[str, str]]) -> list[dict[str, Any]]:
    return [
        {
            "role": message["role"],
            "characters": len(message["content"]),
            "content_sha256": sha256_text(message["content"]),
        }
        for message in messages
    ]


def render_request_transcript(messages: list[dict[str, str]]) -> str:
    """把精确 API messages 渲染成人可读文本，便于人工审计每轮 Prompt。"""
    blocks: list[str] = []
    for index, message in enumerate(messages, start=1):
        blocks.append(
            f"===== MESSAGE {index}: {message['role']} =====\n{message['content']}"
        )
    return "\n\n".join(blocks).rstrip() + "\n"


def call_model(
    *,
    client: Any,
    model_id: str,
    messages: list[dict[str, str]],
    generation: dict[str, Any],
    request_control: dict[str, Any],
    round_dir: Path,
    save_stream_chunks: bool = True,
) -> tuple[Any, list[dict[str, Any]], float]:
    attempts: list[dict[str, Any]] = []
    response = None
    start_clock = time.perf_counter()
    max_attempts = int(request_control.get("network_retries", 0)) + 1
    max_tokens_parameter = str(generation.get("max_tokens_parameter", "max_tokens"))
    for attempt_number in range(1, max_attempts + 1):
        attempt_start = time.perf_counter()
        try:
            if generation.get("stream", False):
                response = create_streaming_response(
                    client,
                    model=model_id,
                    messages=messages,
                    temperature=generation["temperature"],
                    max_tokens=generation["max_output_tokens"],
                    max_tokens_parameter=max_tokens_parameter,
                    extra_body=generation.get("extra_body"),
                    save_stream_chunks=save_stream_chunks,
                )
            else:
                response = client.chat.completions.create(**completion_request_kwargs(
                    model=model_id,
                    messages=messages,
                    temperature=generation.get("temperature"),
                    max_tokens=generation["max_output_tokens"],
                    max_tokens_parameter=max_tokens_parameter,
                    extra_body=generation.get("extra_body"),
                    stream=False,
                ))
            if not response_is_structurally_valid(response):
                write_json(
                    round_dir / f"malformed_response_attempt_{attempt_number:03d}.json",
                    response_to_dict(response),
                )
                raise MalformedProviderResponse("供应端响应缺少 choices/message")
            attempts.append({
                "attempt_number": attempt_number,
                "status": "completed",
                "elapsed_seconds": time.perf_counter() - attempt_start,
            })
            break
        except MalformedProviderResponse as error:
            attempts.append({
                "attempt_number": attempt_number,
                "status": "retryable_malformed_provider_response",
                "error": str(error),
                "elapsed_seconds": time.perf_counter() - attempt_start,
            })
            response = None
            if attempt_number == max_attempts:
                raise
            time.sleep(5 * attempt_number)
        except RETRYABLE_ERRORS as error:
            attempts.append({
                "attempt_number": attempt_number,
                "status": "retryable_transport_failure",
                "error_type": type(error).__name__,
                "error": str(error),
                "elapsed_seconds": time.perf_counter() - attempt_start,
            })
            response = None
            if attempt_number == max_attempts:
                raise
            time.sleep(retry_delay_seconds(error, attempt_number))
    if response is None:
        raise RuntimeError("模型请求未返回响应")
    return response, attempts, time.perf_counter() - start_clock


def receipt_job_id(receipt: dict[str, Any]) -> str:
    job = receipt.get("response", {}).get("job", {})
    job_id = job.get("id") if isinstance(job, dict) else None
    if not job_id:
        raise ValueError("BenchSite 提交回执缺少 job.id")
    return str(job_id)


def is_missing_environment_error(error: Exception | str) -> bool:
    """Return whether an environment-metadata error is safe for the zero-score fallback."""
    message = str(error).lower()
    return "setup_info.environment" in message and any(
        marker in message for marker in ("缺少", "missing", "cannot", "unable")
    )


def prepare_missing_environment_infra_retry(
    round_dir: Path, *, allow_platform_zero_fallback: bool = False
) -> bool:
    """Archive one incomplete BenchSite result so the exact source can be resubmitted.

    A terminal platform fallback can occasionally omit ``setup_info.environment``.
    Such a result cannot pass the runtime-version comparability gate.  It is an
    infrastructure result rather than usable model feedback, so resume may submit
    the already-generated project once more without consuming another model round.
    A second occurrence can either remain a hard stop (the historical helper
    behavior) or be converted to the platform-authoritative zero-score fallback
    for the formal experiment.
    """
    status_path = round_dir / "status.json"
    receipt_path = round_dir / "submission_receipt.json"
    result_path = round_dir / "benchsite_result.json"
    if not (status_path.is_file() and receipt_path.is_file() and result_path.is_file()):
        return False
    status = load_json(status_path)
    if status.get("status") != "platform_operation_failed":
        return False
    if "setup_info.environment" not in str(status.get("error", "")):
        return False

    retry_number = 1
    retry_record = round_dir / f"platform_infra_retry_{retry_number:03d}.json"
    if retry_record.exists():
        if allow_platform_zero_fallback:
            return False
        raise RuntimeError(
            "同一模型源码重提后仍缺少 setup_info.environment；"
            "为保证分数可比性，停止后续提交"
        )

    receipt = load_json(receipt_path)
    result = load_json(result_path)
    archived_receipt = round_dir / f"submission_receipt_infra_{retry_number:03d}.json"
    archived_result = round_dir / f"benchsite_result_infra_{retry_number:03d}.json"
    archived_status = round_dir / f"status_infra_{retry_number:03d}.json"
    receipt_path.rename(archived_receipt)
    result_path.rename(archived_result)
    status_path.rename(archived_status)
    write_json(
        retry_record,
        {
            "retry_number": retry_number,
            "reason": "terminal_result_missing_setup_info_environment",
            "original_job_id": result.get("job_id") or receipt_job_id(receipt),
            "original_terminal_status": result.get("terminal_status"),
            "same_model_output": True,
            "same_submission_project": True,
            "model_round_incremented": False,
            "archived_receipt": str(archived_receipt),
            "archived_result": str(archived_result),
            "archived_status": str(archived_status),
            "prepared_at": timestamp(),
        },
    )
    return True


def mark_platform_zero_fallback(
    round_dir: Path, result: dict[str, Any], error: Exception
) -> dict[str, Any]:
    """Record the internal audit state and let the platform result enter as score 0."""
    write_json(
        round_dir / "environment_verification.json",
        {
            "status": "fallback_zero_missing_environment",
            "verified": False,
            "score_policy": "platform_result_zero",
            "error": str(error),
            "recorded_at": timestamp(),
        },
    )
    result["__harness_platform_zero_fallback"] = True
    return result


def evaluate_round(
    *,
    round_dir: Path,
    op_name: str,
    platform_name: str,
    mcp_config: Path,
    platform_config: Path,
    poll_interval: int,
    poll_timeout: int,
    submission_private: bool | None = None,
    submission_tag: str | None = None,
    aggregation_token: str | None = None,
    verify_runner: bool = True,
    allow_platform_zero_fallback: bool = True,
) -> dict[str, Any]:
    if not aggregation_token or not aggregation_token.strip():
        raise ValueError("BenchSite aggregation scheme 未配置；请在实验协议中填写已有 scheme 的 aggregation_token")
    aggregation_token = aggregation_token.strip()
    project_dir = round_dir / "submission_project"
    validate_submission_path(project_dir, [op_name])
    receipt_path = round_dir / "submission_receipt.json"
    result_path = round_dir / "benchsite_result.json"
    prepare_missing_environment_infra_retry(
        round_dir,
        allow_platform_zero_fallback=allow_platform_zero_fallback,
    )
    profile = load_platform_profile(platform_config, platform_name)
    effective_private = (
        bool(profile["submission_private"])
        if submission_private is None
        else bool(submission_private)
    )
    effective_tag = str(submission_tag or profile["submission_tag"])
    server = load_benchsite_server(mcp_config)
    with StdioMcpClient(server) as client:
        if not receipt_path.is_file():
            runner_verification = {"warnings": []}
            if verify_runner:
                runner_verification = verify_live_runner_profile(
                    client.call_tool("list_runners", {}), profile
                )
            request = {
                "submission_path": str(project_dir.resolve()),
                "target_hardware": profile["target_hardware"],
                "selected_operators": [op_name],
                "benchmark_slug": profile["benchmark_slug"],
                "benchmark_version": profile["benchmark_version"],
                "submission_tag": effective_tag,
                "aggregation_token": aggregation_token,
                "is_private": effective_private,
            }
            response = submit_kernel_rest(project_dir,
                {**profile, "submission_tag": effective_tag, "submission_private": effective_private},
                [op_name], aggregation_token, server)
            response_source = "benchsite_rest_submissions_versioned"
            write_json(
                receipt_path,
                {
                    "submitted_at": timestamp(),
                    "request": request,
                    "response": response,
                    "response_source": response_source,
                    "mcp_config_source": server["source"],
                    "platform_profile": platform_name,
                    "expected_cann_bench_ref": profile["cann_bench_ref"],
                    "runner_warnings": runner_verification.get("warnings", []),
                    "runner_verification_skipped": not verify_runner,
                },
            )
        receipt = load_json(receipt_path)
        job_id = receipt_job_id(receipt)
        if result_path.is_file():
            result = load_json(result_path)
            if not result.get("timed_out"):
                try:
                    environment_verification = verify_job_environment(result, profile)
                except RuntimeError as error:
                    if allow_platform_zero_fallback and is_missing_environment_error(error):
                        return mark_platform_zero_fallback(round_dir, result, error)
                    raise
                else:
                    write_json(
                        round_dir / "environment_verification.json",
                        environment_verification,
                    )
                    return result
            archive = round_dir / f"benchsite_result_timeout_{timestamp()}.json"
            result_path.rename(archive)
        result = poll_job(client, job_id, result_path, poll_interval, poll_timeout)
        if not result.get("timed_out"):
            try:
                environment_verification = verify_job_environment(result, profile)
            except RuntimeError as error:
                if allow_platform_zero_fallback and is_missing_environment_error(error):
                    return mark_platform_zero_fallback(round_dir, result, error)
                raise
            else:
                write_json(
                    round_dir / "environment_verification.json",
                    environment_verification,
                )
        return result


def nested_job(result: dict[str, Any]) -> dict[str, Any]:
    job = result.get("job", {})
    if isinstance(job, dict) and isinstance(job.get("job"), dict):
        job = job["job"]
    return job if isinstance(job, dict) else {}


def write_feedback_artifacts(
    *,
    round_dir: Path,
    round_number: int,
    total_rounds: int,
    payload: dict[str, Any],
    template_text: str,
) -> None:
    write_json(round_dir / "feedback_payload.json", payload)
    if round_number < total_rounds:
        prompt = render_feedback_prompt(
            template_text,
            round_number=round_number,
            total_rounds=total_rounds,
            payload=payload,
        )
        (round_dir / "feedback_prompt.txt").write_text(prompt, encoding="utf-8")
        write_json(
            round_dir / "feedback_metadata.json",
            {
                "round_number": round_number,
                "next_round_number": round_number + 1,
                "feedback_payload_sha256": sha256_text(
                    json.dumps(payload, ensure_ascii=False, sort_keys=True)
                ),
                "feedback_prompt_sha256": sha256_text(prompt),
                "feedback_prompt_characters": len(prompt),
            },
        )


def round_is_complete(round_dir: Path) -> bool:
    status_path = round_dir / "status.json"
    return status_path.is_file() and load_json(status_path).get("status") == "round_completed"


def print_round_summary(
    *,
    round_dir: Path,
    round_number: int,
    total_rounds: int,
    op_name: str,
    outcome: str,
) -> None:
    """每轮结束后打印一轮概况，便于长时间运行中人工查看进度。"""
    try:
        hashes = five_file_hashes(round_dir, op_name)
        source_hash = combined_source_hash(hashes)
        status = load_json(round_dir / "status.json") if (round_dir / "status.json").is_file() else {}
        gen = (
            load_json(round_dir / "generation_status.json")
            if (round_dir / "generation_status.json").is_file()
            else {}
        )
        summary: dict[str, Any] = {}
        if (round_dir / "change_summary.json").is_file():
            summary = load_json(round_dir / "change_summary.json")
        fingerprint = "-"
        if (round_dir / "benchsite_result.json").is_file():
            fingerprint = error_fingerprint(load_json(round_dir / "benchsite_result.json")) or "-"
        feedback_chars = None
        if (round_dir / "feedback_payload.json").is_file():
            feedback_chars = len(
                json.dumps(
                    load_json(round_dir / "feedback_payload.json"),
                    ensure_ascii=False,
                    indent=2,
                )
            )
        reuse = ""
        if (round_dir / "evaluation_reuse.json").is_file():
            reuse = " [评测结果复用]"
        print("=" * 60)
        print(
            f"轮次 {round_number}/{total_rounds} | 结果: {outcome}{reuse} | "
            f"得分: {status.get('result_score')} | 平台: {status.get('job_status') or '-'}"
        )
        print(f"  源码哈希: {source_hash[:16] if source_hash else '-'}")
        print(f"  生成耗时: {gen.get('elapsed_seconds'):.0f}s | 输出字符: {gen.get('output_characters')}")
        print(f"  模型简述: {(summary.get('summary') or '(缺失)')[:120]}")
        print(f"  错误指纹: {fingerprint[:150]}")
        if feedback_chars is not None:
            print(f"  下一轮反馈载荷: {feedback_chars} 字符")
    except Exception as error:  # 概况打印失败不影响实验流程
        print(f"  (概况打印失败: {type(error).__name__})")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="执行固定轮数的模型生成→BenchSite评测→反馈→修改轨迹。"
    )
    parser.add_argument("--prompt", required=True, type=Path)
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--op-name", required=True)
    parser.add_argument("--platform", required=True)
    parser.add_argument("--protocol", type=Path, default=DEFAULT_PROTOCOL)
    parser.add_argument("--feedback-template", type=Path)
    parser.add_argument("--experiment-id")
    parser.add_argument("--model")
    parser.add_argument("--mcp-config", type=Path, default=DEFAULT_KERMINAL_CONFIG)
    parser.add_argument("--platform-config", type=Path, default=DEFAULT_PLATFORM_CONFIG)
    parser.add_argument("--skeleton", type=Path, default=DEFAULT_SKELETON)
    parser.add_argument("--allow-submit", action="store_true")
    parser.add_argument(
        "--skip-runner-verify",
        action="store_true",
        help="小规模测试专用：跳过提交前 runner 版本校验（正式实验不得使用）",
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(
        "--max-trajectories",
        type=int,
        help="只执行协议前缀中的前 N 条轨迹；实验目录仍保留完整协议身份，可恢复",
    )
    parser.add_argument(
        "--max-rounds",
        type=int,
        help="每条轨迹只执行前 N 轮；实验目录仍保留完整协议身份，可恢复",
    )
    parser.add_argument(
        "--long-generation-threshold-seconds",
        type=float,
        default=DEFAULT_LONG_GENERATION_THRESHOLD_SECONDS,
        help=(
            "若上一轮模型生成耗时超过该阈值，在下一轮 Prompt 追加精简思考提醒；"
            f"只改变提示词，不截断、不改分（默认 {DEFAULT_LONG_GENERATION_THRESHOLD_SECONDS:g} 秒）"
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if (
        args.long_generation_threshold_seconds is not None
        and args.long_generation_threshold_seconds <= 0
    ):
        raise ValueError("--long-generation-threshold-seconds 必须大于 0")
    prompt_path = args.prompt.resolve()
    protocol_path = args.protocol.resolve()
    initial_prompt = prompt_path.read_text(encoding="utf-8-sig")
    protocol = load_protocol(protocol_path)
    configured_feedback_template = protocol.get("feedback", {}).get("template")
    if args.feedback_template is not None:
        feedback_template_path = args.feedback_template.resolve()
    elif configured_feedback_template:
        configured_path = Path(str(configured_feedback_template))
        candidate = (
            configured_path.resolve()
            if configured_path.is_absolute()
            else (PROJECT_ROOT / configured_path).resolve()
        )
        # 兼容早期协议中已损坏的路径；新协议必须提供可解析路径。
        feedback_template_path = (
            candidate if candidate.is_file() else DEFAULT_FEEDBACK_TEMPLATE.resolve()
        )
    else:
        feedback_template_path = DEFAULT_FEEDBACK_TEMPLATE.resolve()
    feedback_template_text = feedback_template_path.read_text(encoding="utf-8-sig")
    provider_config = load_config()
    model_id = args.model or load_selected_model()
    experiment_id = safe_name(args.experiment_id or timestamp())
    task_id = safe_name(args.task_id)
    op_name = safe_name(args.op_name)
    provider_name = safe_name(str(provider_config["provider"]))
    model_name = safe_name(model_id)
    trajectories = int(protocol["experiment"]["trajectories_per_model_task"])
    total_rounds = int(protocol["experiment"]["rounds_per_trajectory"])
    max_trajectories = args.max_trajectories or trajectories
    max_rounds = args.max_rounds or total_rounds
    if not 1 <= max_trajectories <= trajectories:
        raise ValueError(
            f"--max-trajectories 必须在 1 到 {trajectories} 之间"
        )
    if not 1 <= max_rounds <= total_rounds:
        raise ValueError(f"--max-rounds 必须在 1 到 {total_rounds} 之间")
    generation = protocol["generation"]
    max_tokens_parameter = str(generation.get("max_tokens_parameter", "max_tokens"))
    completion_token_kwargs(int(generation["max_output_tokens"]), max_tokens_parameter)
    request_control = protocol["request_control"]
    feedback_config = protocol["feedback"]
    submission_config = protocol["submission"]
    template_version = protocol["task_input"]["prompt_template_version"]
    is_stage_aware = bool(feedback_config.get("stage_aware"))
    uses_attempt_log = bool(protocol.get("context", {}).get("include_attempt_log"))
    change_summary_limit = int(protocol.get("change_summary", {}).get("max_characters", 300))
    initial_prompt_hash = sha256_text(initial_prompt)
    protocol_hash = file_sha256(protocol_path)
    feedback_template_hash = file_sha256(feedback_template_path)
    protocol_submission_settings = submission_config.get("settings_source") == "protocol"
    resolved_submission_private: bool | None = None
    resolved_submission_tag: str | None = None
    resolved_aggregation_token: str | None = None
    if protocol_submission_settings:
        resolved_submission_private = bool(submission_config["private_submission"])
        tag_template = str(submission_config["submission_tag_template"])
        resolved_submission_tag = tag_template.format(
            model=model_name,
            model_tag=model_name.replace("-", "_"),
            provider=provider_name,
        )
        if not resolved_submission_tag.strip():
            raise ValueError("submission_tag_template 渲染后不能为空")
        if submission_config.get("aggregation_token") is not None:
            resolved_aggregation_token = str(submission_config["aggregation_token"]).strip()
            if not resolved_aggregation_token:
                raise ValueError("aggregation_token 不能为空")
    if not args.dry_run and not resolved_aggregation_token:
        raise ValueError("实验协议缺少已有 BenchSite aggregation scheme 的 aggregation_token；模型调用前停止")

    render_metadata_path = prompt_path.parent / "render_metadata.json"
    if not render_metadata_path.is_file():
        raise FileNotFoundError("多轮协议要求 Prompt 旁存在 render_metadata.json")
    render_metadata = load_json(render_metadata_path)
    if render_metadata.get("prompt_sha256") != initial_prompt_hash:
        raise ValueError("Prompt 与 render_metadata.json 哈希不一致")
    required_template = protocol["task_input"]["prompt_template_version"]
    if render_metadata.get("prompt_template_version") != required_template:
        raise ValueError(
            f"多轮协议要求模板 {required_template}，实际为 "
            f"{render_metadata.get('prompt_template_version')}"
        )
    if render_metadata.get("interaction_mode") not in (
        "ten_round_rolling_platform_feedback",
        "iterative_rolling_platform_feedback_change_summary",
        "iterative_rolling_platform_feedback_change_summary_v3",
    ):
        raise ValueError("Prompt 不是固定轮数滚动反馈派生版本")
    if int(render_metadata.get("iterative_rounds") or 0) != total_rounds:
        raise ValueError(
            "初始Prompt冻结轮数与协议不一致: "
            f"prompt={render_metadata.get('iterative_rounds')}, protocol={total_rounds}"
        )
    if render_metadata.get("platform_profile") != args.platform:
        raise ValueError("Prompt 平台与 --platform 不一致")
    if render_metadata.get("platform_runtime_source") != "benchsite_job_setup_info":
        raise ValueError("正式多轮协议要求由真实 BenchSite job 核验平台版本")
    if not render_metadata.get("platform_snapshot_sha256"):
        raise ValueError("Prompt 缺少冻结的平台快照哈希")

    from next_harness.benchmark_release import BENCHMARK_VERSION
    if (render_metadata.get("platform", {}).get("benchmark_version") != BENCHMARK_VERSION
            or render_metadata.get("benchmark_release", {}).get("benchmark_version") != BENCHMARK_VERSION):
        raise ValueError("new/continued experiments require a prompt rendered from frozen 2.0.0 task materials")

    task_root = (
        RUNS_PATH
        / "feedback_experiments"
        / experiment_id
        / provider_name
        / model_name
        / task_id
    )
    plan = {
        "experiment_id": experiment_id,
        "provider": provider_config["provider"],
        "provider_base_url": provider_config["base_url"],
        "model": model_id,
        "task_id": task_id,
        "op_name": op_name,
        "platform": args.platform,
        "track": protocol["experiment"]["track"],
        "trajectories": trajectories,
        "rounds_per_trajectory": total_rounds,
        "primary_metric": protocol["experiment"]["primary_metric"],
        "context_policy": protocol["context"]["policy"],
        "initial_prompt_sha256": initial_prompt_hash,
        "protocol_sha256": protocol_hash,
        "feedback_template_sha256": feedback_template_hash,
        "platform_snapshot_sha256": render_metadata["platform_snapshot_sha256"],
        "temperature": generation["temperature"],
        "max_output_tokens": generation["max_output_tokens"],
        "max_tokens_parameter": max_tokens_parameter,
        "stream": bool(generation.get("stream", False)),
        "extra_body": generation.get("extra_body"),
        "seed_policy": generation.get("seed_policy", "not_declared"),
        "long_generation_threshold_seconds": args.long_generation_threshold_seconds,
        "submission_private": resolved_submission_private,
        "submission_tag": resolved_submission_tag,
        "aggregation_token": resolved_aggregation_token,
        "maximum_model_generations": trajectories * total_rounds,
        "maximum_platform_submissions": trajectories * total_rounds,
        "output_directory": str(task_root),
    }
    configured_cost_limit = cost_budget_limit()
    if configured_cost_limit is not None:
        budget_state = read_cost_budget()
        plan["cost_budget_limit_usd"] = configured_cost_limit
        plan["cost_budget_ledger"] = str(cost_budget_ledger_path())
        if budget_state is not None:
            plan["cost_budget_spent_usd_at_start"] = float(
                budget_state.get("spent_usd", 0.0)
            )
    if args.dry_run:
        print(yaml.safe_dump(plan, allow_unicode=True, sort_keys=False))
        return
    if not args.allow_submit:
        raise ValueError("真实多轮轨迹会连续提交平台，必须显式添加 --allow-submit")

    manifest_path = task_root / "experiment_manifest.json"
    if task_root.exists():
        if not args.resume:
            raise FileExistsError(f"实验目录已存在；恢复请加 --resume: {task_root}")
        if not manifest_path.is_file():
            raise FileNotFoundError(f"缺少实验 manifest: {manifest_path}")
        old_plan = load_json(manifest_path)
        for key in (
            "provider", "model", "task_id", "op_name", "platform", "track",
            "trajectories", "rounds_per_trajectory", "initial_prompt_sha256",
            "protocol_sha256", "feedback_template_sha256", "platform_snapshot_sha256",
            "temperature", "max_output_tokens", "max_tokens_parameter", "stream",
            "extra_body", "seed_policy",
            "submission_private", "submission_tag",
            "aggregation_token",
        ):
            if old_plan.get(key) != plan.get(key):
                raise ValueError(
                    f"恢复参数不一致: {key}: existing={old_plan.get(key)!r}, "
                    f"current={plan.get(key)!r}"
                )
    else:
        task_root.mkdir(parents=True, exist_ok=False)
    write_json(
        manifest_path,
        {
            **plan,
            "status": "running",
            "resumed": bool(args.resume),
            "invocation_limits": {
                "max_trajectories": max_trajectories,
                "max_rounds": max_rounds,
            },
        },
    )
    (task_root / "initial_prompt.txt").write_text(initial_prompt, encoding="utf-8")
    write_json(task_root / "render_metadata.json", render_metadata)
    client = create_client()

    completed_trajectories = 0
    budget_exhausted = False
    for trajectory_number in range(1, max_trajectories + 1):
        trajectory_dir = task_root / f"trajectory_{trajectory_number:03d}"
        trajectory_dir.mkdir(parents=True, exist_ok=True)
        write_json(
            trajectory_dir / "trajectory_manifest.json",
            {
                **plan,
                "trajectory_number": trajectory_number,
                "status": "running",
                "invocation_limits": {
                    "max_trajectories": max_trajectories,
                    "max_rounds": max_rounds,
                },
            },
        )
        previous_round_dir: Path | None = None
        previous_hashes: dict[str, str] | None = None
        for round_number in range(1, max_rounds + 1):
            round_dir = trajectory_dir / f"round_{round_number:02d}"
            if round_is_complete(round_dir):
                print(
                    f"trajectory {trajectory_number:03d}, round {round_number:02d} 已完成，跳过"
                )
                previous_round_dir = round_dir
                previous_hashes = five_file_hashes(round_dir, op_name)
                continue
            round_dir.mkdir(parents=True, exist_ok=True)
            write_json(round_dir / "render_metadata.json", render_metadata)
            attempt_log = None
            if uses_attempt_log and previous_round_dir is not None:
                attempt_log = build_attempt_log(
                    trajectory_dir,
                    op_name,
                    max_characters=int(protocol["context"].get("max_attempt_log_characters", 12000)),
                )
            previous_elapsed_seconds = generation_elapsed_seconds(previous_round_dir)
            long_notice_applied = (
                args.long_generation_threshold_seconds is not None
                and previous_elapsed_seconds is not None
                and previous_elapsed_seconds > args.long_generation_threshold_seconds
            )
            messages = build_messages(
                initial_prompt,
                previous_round_dir,
                attempt_log,
                args.long_generation_threshold_seconds,
            )
            request_characters = sum(len(message["content"]) for message in messages)
            maximum_request_characters = int(
                protocol["context"].get("max_request_characters", 500000)
            )
            if request_characters > maximum_request_characters:
                raise ValueError(
                    f"第 {round_number} 轮请求 {request_characters} 字符，超过固定上限 "
                    f"{maximum_request_characters}"
                )
            write_json(round_dir / "request_messages.json", {"messages": messages})
            (round_dir / "request_prompt.txt").write_text(
                render_request_transcript(messages), encoding="utf-8"
            )
            request_metadata = {
                "experiment_id": experiment_id,
                "trajectory_number": trajectory_number,
                "round_number": round_number,
                "provider": provider_config["provider"],
                "base_url": provider_config["base_url"],
                "model": model_id,
                "context_policy": "rolling_latest_state",
                "messages": message_metadata(messages),
                "request_characters": request_characters,
                "temperature": generation["temperature"],
                "max_output_tokens": generation["max_output_tokens"],
                "max_tokens_parameter": max_tokens_parameter,
                "stream": bool(generation.get("stream", False)),
                "extra_body": generation.get("extra_body"),
                "seed_policy": generation.get("seed_policy", "not_declared"),
                "protocol_sha256": protocol_hash,
                "initial_prompt_notice_applied": False,
                "initial_prompt_notice_characters": 0,
                "long_generation_threshold_seconds": args.long_generation_threshold_seconds,
                "previous_generation_elapsed_seconds": previous_elapsed_seconds,
                "long_generation_notice_applied": long_notice_applied,
                "started_at": timestamp(),
            }
            write_json(round_dir / "request_metadata.json", request_metadata)

            output_path = round_dir / "model_output.txt"
            if not output_path.is_file():
                budget_exhausted, budget_state = cost_budget_exhausted()
                if budget_exhausted:
                    write_json(
                        round_dir / "status.json",
                        {
                            "status": "cost_budget_exhausted_before_model_call",
                            "cost_budget_limit_usd": (
                                budget_state.get("limit_usd")
                                if budget_state is not None
                                else None
                            ),
                            "cost_budget_spent_usd": (
                                budget_state.get("spent_usd")
                                if budget_state is not None
                                else None
                            ),
                            "cost_unknown": (
                                budget_state.get("cost_unknown")
                                if budget_state is not None
                                else False
                            ),
                            "recorded_at": timestamp(),
                        },
                    )
                    print(
                        "达到费用预算，停止发起新的模型请求: "
                        f"spent=${budget_state.get('spent_usd', 0.0):.6f} / "
                        f"limit=${budget_state.get('limit_usd', 0.0):.6f}"
                    )
                    break
                try:
                    response, attempts, elapsed = call_model(
                        client=client,
                        model_id=model_id,
                        messages=messages,
                        generation=generation,
                        request_control=request_control,
                        round_dir=round_dir,
                        save_stream_chunks=bool(
                            protocol.get("artifacts", {}).get("save_stream_chunks", True)
                        ),
                    )
                except Exception as error:
                    write_json(
                        round_dir / "status.json",
                        {
                            "status": "model_request_failed",
                            "error_type": type(error).__name__,
                            "error": str(error),
                        },
                    )
                    raise
                raw = response_to_dict(response)
                model_cost_usd = record_model_cost(
                    raw_response=raw,
                    round_dir=round_dir,
                    model_id=model_id,
                )
                output_text = response.choices[0].message.content or ""
                output_path.write_text(output_text, encoding="utf-8")
                write_json(round_dir / "raw_response.json", raw)
                write_json(
                    round_dir / "generation_status.json",
                    {
                        "status": "completed",
                        "requested_model": model_id,
                        "returned_model": raw.get("model"),
                        "system_fingerprint": raw.get("system_fingerprint"),
                        "finish_reason": response.choices[0].finish_reason,
                        "elapsed_seconds": elapsed,
                        "attempts": attempts,
                        "network_retry_count": len(attempts) - 1,
                        "content_retry_count": 0,
                        "output_characters": len(output_text),
                        "model_output_sha256": sha256_text(output_text),
                        "cost_usd": model_cost_usd,
                    },
                )

            parse_report = parse_run(round_dir, op_name)
            outcome = ""
            payload: dict[str, Any]
            platform_zero_fallback = False
            if not parse_report["recoverable_parse_pass"]:
                outcome = "parse_failed"
                payload = build_parse_feedback(parse_report, feedback_config)
            else:
                current_hashes = five_file_hashes(round_dir, op_name)
                reuse_source = False
                if (
                    is_stage_aware
                    and previous_hashes is not None
                    and current_hashes == previous_hashes
                    and previous_round_dir is not None
                    and (previous_round_dir / "benchsite_result.json").is_file()
                ):
                    reuse_source = True
                    previous_result = load_json(
                        previous_round_dir / "benchsite_result.json"
                    )
                    write_json(round_dir / "benchsite_result.json", previous_result)
                    write_json(
                        round_dir / "evaluation_reuse.json",
                        {
                            "reused_from": str(previous_round_dir),
                            "source_unchanged": True,
                            "reused_at": timestamp(),
                        },
                    )
                try:
                    if not (round_dir / "submission_project").is_dir():
                        assemble(round_dir, op_name, args.skeleton.resolve())
                except Exception as error:
                    write_json(
                        round_dir / "status.json",
                        {
                            "status": "harness_assembly_failed",
                            "error_type": type(error).__name__,
                            "error": str(error),
                            "note": (
                                "Harness装配属于基础设施步骤，不反馈给模型，也不消费有效轮次；"
                                "修复后使用 --resume 继续当前源码。"
                            ),
                        },
                    )
                    raise
                else:
                    if reuse_source:
                        outcome = "platform_evaluated"
                        payload = build_platform_feedback_v2(
                            previous_result,
                            feedback_config,
                            source_unchanged=True,
                            evaluation_reused=True,
                        )
                    else:
                        try:
                            result = evaluate_round(
                                round_dir=round_dir,
                                op_name=op_name,
                                platform_name=args.platform,
                                mcp_config=args.mcp_config.resolve(),
                                platform_config=args.platform_config.resolve(),
                                poll_interval=int(submission_config["poll_interval_seconds"]),
                                poll_timeout=int(submission_config["poll_timeout_seconds"]),
                                submission_private=resolved_submission_private,
                                submission_tag=resolved_submission_tag,
                                aggregation_token=resolved_aggregation_token,
                                verify_runner=not args.skip_runner_verify,
                            )
                            platform_zero_fallback = bool(
                                result.pop("__harness_platform_zero_fallback", False)
                            )
                        except Exception as error:
                            write_json(
                                round_dir / "status.json",
                                {
                                    "status": "platform_operation_failed",
                                    "error_type": type(error).__name__,
                                    "error": str(error),
                                    "note": "基础设施操作失败不消费模型内容轮；使用 --resume 继续。",
                                },
                            )
                            raise
                        if result.get("timed_out"):
                            write_json(
                                round_dir / "status.json",
                                {
                                    "status": "platform_poll_timed_out",
                                    "note": "已有 job 不会重提；使用 --resume 继续轮询。",
                                },
                            )
                            raise TimeoutError("BenchSite job 在固定轮询窗口内未结束")
                        outcome = (
                            "platform_fallback_zero"
                            if platform_zero_fallback
                            else "platform_evaluated"
                        )
                        if platform_zero_fallback:
                            payload = build_platform_fallback_feedback(
                                result, feedback_config
                            )
                        elif is_stage_aware:
                            payload = build_platform_feedback_v2(result, feedback_config)
                        else:
                            payload = build_platform_feedback(result, feedback_config)

            write_feedback_artifacts(
                round_dir=round_dir,
                round_number=round_number,
                total_rounds=total_rounds,
                payload=payload,
                template_text=feedback_template_text,
            )
            status_record: dict[str, Any] = {
                "status": "round_completed",
                "trajectory_number": trajectory_number,
                "round_number": round_number,
                "outcome": outcome,
                "submitted": (round_dir / "submission_receipt.json").is_file(),
                "evaluated": (round_dir / "benchsite_result.json").is_file(),
                "completed_at": timestamp(),
                "recoverable_parse_pass": bool(parse_report["recoverable_parse_pass"]),
                "strict_protocol_pass": bool(parse_report["strict_protocol_pass"]),
                "format_recovered": bool(parse_report.get("format_recovered")),
                "format_recovery_reasons": parse_report.get(
                    "format_recovery_reasons", []
                ),
                "platform_fallback": platform_zero_fallback,
            }
            if outcome in {"parse_failed", "assembly_failed"}:
                status_record.update(
                    {
                        "result_score": 0.0,
                        "score_source": "harness_model_content_failure",
                        "passed_cases": 0,
                        "total_cases": None,
                    }
                )
            if (round_dir / "benchsite_result.json").is_file():
                job = nested_job(load_json(round_dir / "benchsite_result.json"))
                if platform_zero_fallback:
                    status_record.update(
                        {
                            "job_status": job.get("status"),
                            "result_score": 0.0,
                            "passed_cases": job.get("passed_cases") or 0,
                            "total_cases": job.get("total_cases") or 0,
                            "score_source": "platform_result_fallback_zero",
                        }
                    )
                else:
                    status_record.update(
                        {
                            "job_status": job.get("status"),
                            "result_score": job.get("result_score"),
                            "passed_cases": job.get("passed_cases"),
                            "total_cases": job.get("total_cases"),
                            "score_source": "benchsite",
                        }
                    )
            write_json(round_dir / "status.json", status_record)
            previous_round_dir = round_dir
            if parse_report["recoverable_parse_pass"]:
                previous_hashes = current_hashes
            print_round_summary(
                round_dir=round_dir,
                round_number=round_number,
                total_rounds=total_rounds,
                op_name=op_name,
                outcome=outcome,
            )
            print(
                f"trajectory {trajectory_number:03d}, round {round_number:02d}/{total_rounds}: "
                f"{outcome}, score={status_record.get('result_score')}"
            )

        trajectory_completed = all(
            round_is_complete(trajectory_dir / f"round_{index:02d}")
            for index in range(1, total_rounds + 1)
        )
        if trajectory_completed:
            completed_trajectories += 1
        write_json(
            trajectory_dir / "trajectory_manifest.json",
            {
                **plan,
                "trajectory_number": trajectory_number,
                "status": (
                    "partial_budget"
                    if budget_exhausted
                    else ("completed" if trajectory_completed else "partial")
                ),
                "completed_rounds": sum(
                    round_is_complete(trajectory_dir / f"round_{index:02d}")
                    for index in range(1, total_rounds + 1)
                ),
                "completed_at": timestamp(),
                "invocation_limits": {
                    "max_trajectories": max_trajectories,
                    "max_rounds": max_rounds,
                },
            },
        )
        if budget_exhausted:
            break

    if budget_exhausted:
        budget_state = read_cost_budget()
        write_json(
            manifest_path,
            {
                **plan,
                "status": "budget_exhausted",
                "completed_trajectories": completed_trajectories,
                "cost_budget": budget_state,
                "completed_at": timestamp(),
            },
        )
        print(
            f"多轮反馈实验因费用预算停止: {task_root} "
            f"({completed_trajectories} 条完整轨迹)"
        )
        return

    if max_trajectories < trajectories or max_rounds < total_rounds:
        write_json(
            manifest_path,
            {
                **plan,
                "status": "partial",
                "completed_trajectories": completed_trajectories,
                "invocation_limits": {
                    "max_trajectories": max_trajectories,
                    "max_rounds": max_rounds,
                },
                "note": "本次只执行了正式协议的前缀；使用 --resume 且不设前缀限制可继续完成协议。",
                "completed_at": timestamp(),
            },
        )
        print(
            f"多轮反馈实验已完成前缀: {task_root} "
            f"({max_trajectories} 条轨迹 × 前 {max_rounds} 轮)"
        )
        return

    write_json(
        manifest_path,
        {
            **plan,
            "status": "completed",
            "completed_trajectories": trajectories,
            "completed_at": timestamp(),
        },
    )
    print(f"多轮反馈实验完成: {task_root}")


if __name__ == "__main__":
    main()
