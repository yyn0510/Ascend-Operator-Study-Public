from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

import yaml

from modelscope_common import write_json
from next_harness.scoring_rules import SCORE_FIELDS, FIELD_NOTE


ANSI_PATTERN = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
SUBMISSION_PREFIX_PATTERN = re.compile(
    r"(?:[A-Za-z]:\\|/)[^\r\n]*?[\\/]input[\\/]submission[\\/]",
    re.IGNORECASE,
)
PLACEHOLDER_PATTERN = re.compile(r"\{\{[A-Z_]+\}\}")
ERROR_LINE_PATTERN = re.compile(r"(?m)^.*?\berror:\b.*$")
SUCCESS_JOB_STATUSES = {"success", "succeeded", "completed", "passed"}


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON 顶层必须是对象: {path}")
    return value


def clean_text(value: Any, limit: int) -> str | None:
    if value is None:
        return None
    text = ANSI_PATTERN.sub("", str(value)).replace("\x00", "")
    text = SUBMISSION_PREFIX_PATTERN.sub("<SUBMISSION>/", text)
    text = text.strip()
    if not text:
        return None
    if len(text) > limit:
        omitted = len(text) - limit
        text = text[:limit].rstrip() + f"\n...[truncated {omitted} characters by fixed harness rule]"
    return text


def nested_job(result: dict[str, Any]) -> dict[str, Any]:
    value = result.get("job", {})
    if isinstance(value, dict) and isinstance(value.get("job"), dict):
        value = value["job"]
    return value if isinstance(value, dict) else {}


def find_operator(job: dict[str, Any]) -> dict[str, Any]:
    results = job.get("results", {})
    operators = results.get("operators", []) if isinstance(results, dict) else []
    return operators[0] if operators and isinstance(operators[0], dict) else {}


def accuracy_summary(accuracy: Any) -> dict[str, Any] | None:
    if not isinstance(accuracy, dict):
        return None
    metadata = accuracy.get("metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
    output_results = accuracy.get("output_results", [])
    compact_outputs: list[dict[str, Any]] = []
    if isinstance(output_results, list):
        for item in output_results:
            if not isinstance(item, dict):
                continue
            compact_outputs.append(
                {
                    key: item.get(key)
                    for key in (
                        "index",
                        "name",
                        "dtype",
                        "passed",
                        "mismatch_count",
                        "total_count",
                        "threshold",
                        "mere",
                        "mare",
                        "max_diff",
                        "mean_diff",
                        "small_value_passed",
                        "cancel_passed",
                        "normal_passed",
                    )
                    if item.get(key) is not None
                }
            )
    result = {
        "passed": accuracy.get("passed"),
        "checker_name": metadata.get("checker_name"),
        "threshold": accuracy.get("threshold"),
        "mismatch_count": metadata.get("mismatch_count"),
        "total_count": metadata.get("total_count"),
        "mismatch_ratio": metadata.get("mismatch_ratio"),
        "mere": metadata.get("mere"),
        "mare": metadata.get("mare"),
        "max_diff": metadata.get("max_diff"),
        "mean_diff": metadata.get("mean_diff"),
        "failure_type": metadata.get("failure_type"),
        "outputs": compact_outputs,
    }
    return {key: value for key, value in result.items() if value is not None and value != []}


def add_unique_error(
    errors: list[str], value: Any, *, limit: int, maximum: int
) -> int | None:
    cleaned = clean_text(value, limit)
    if not cleaned:
        return None
    if cleaned not in errors and len(errors) < maximum:
        errors.append(cleaned)
    try:
        return errors.index(cleaned) + 1
    except ValueError:
        return None


def group_compile_errors(
    compilation_error: str,
    *,
    max_groups: int = 3,
    max_characters_each: int = 1200,
    max_notes_each: int = 2,
) -> list[str]:
    """按 error: 行分组编译错误，每组保留首行与少量紧邻 note/候选签名。

    不简单截取日志前缀；对同一文件同一位置的重复报错按组首行去重。
    """
    if not compilation_error:
        return []
    lines = compilation_error.splitlines()
    groups: list[list[str]] = []
    for line in lines:
        if re.search(r"\berror\s*:", line):
            groups.append([line])
        elif groups:
            groups[-1].append(line)
    groups = [group for group in groups if group]
    seen: set[str] = set()
    result: list[str] = []
    for group in groups:
        first = group[0]
        key = re.sub(r":\d+(:\d+)?:", ":", first)
        if key in seen:
            continue
        seen.add(key)
        notes = [
            line
            for line in group[1:]
            if re.search(r"\bnote:\b|candidate|required from|expected", line, re.IGNORECASE)
        ][:max_notes_each]
        block = "\n".join([first, *notes])
        cleaned = clean_text(block, max_characters_each)
        if cleaned is None:
            continue
        result.append(cleaned)
        if len(result) >= max_groups:
            break
    return result


def error_fingerprint(result: dict[str, Any], limit: int = 200) -> str | None:
    """机械提取单条错误指纹，用于历轮尝试记录。"""
    job = nested_job(result)
    operator = find_operator(job)
    compilation_error = operator.get("compilation_error")
    if compilation_error:
        match = re.search(r"^.*?\berror:\b[^\r\n]*", str(compilation_error), re.MULTILINE)
        if match:
            return clean_text(match.group(0), limit)
    cases = operator.get("cases", [])
    if isinstance(cases, list):
        for case in cases:
            if isinstance(case, dict) and case.get("status") != "success":
                reason = case.get("failure_reason") or case.get("error_msg")
                if reason:
                    return clean_text(reason, limit)
    return None


PLATFORM_LOG_SIGNAL_PATTERN = re.compile(
    r"(?:\bwhat\(\):|terminate called|\b(?:error|fatal|exception|assert|failed|failure|missing)\b|"
    r"not found|no matching|type mismatch)",
    re.IGNORECASE,
)
PLATFORM_LOG_CONTEXT_PATTERN = re.compile(
    r"(?:expected schema|inferred schema|reason:|\bwhat\(\):|\berror:\b|"
    r"terminate called|type mismatch|failed|failure)",
    re.IGNORECASE,
)


def _iter_named_text_values(value: Any, names: set[str]):
    """Yield useful text fields from the platform response without exposing the full log."""
    if isinstance(value, dict):
        for key, child in value.items():
            if key in names and isinstance(child, (str, int, float)):
                yield str(child)
            elif isinstance(child, (dict, list)):
                yield from _iter_named_text_values(child, names)
    elif isinstance(value, list):
        for child in value:
            if isinstance(child, (dict, list)):
                yield from _iter_named_text_values(child, names)


def _platform_failure_signals(
    result: dict[str, Any],
    job: dict[str, Any],
    stage_summary: dict[str, Any],
    feedback_config: dict[str, Any],
) -> list[str]:
    """Extract a small deterministic error summary when the platform has no operator report."""
    max_error_chars = int(feedback_config.get("max_error_characters_each", 1200))
    maximum = max(1, int(feedback_config.get("max_unique_errors", 3)))
    results = job.get("results", {})
    if not isinstance(results, dict):
        results = {}
    failure = results.get("failure", {})
    if not isinstance(failure, dict):
        failure = {}
    summary = results.get("summary", {})
    if not isinstance(summary, dict):
        summary = {}

    candidate_signals: list[str] = []
    candidates = (
        result.get("error"),
        result.get("error_message"),
        job.get("error_message"),
        job.get("error"),
        stage_summary.get("failed_message"),
        failure.get("error_message"),
        failure.get("message"),
        failure.get("reason"),
        summary.get("score_unavailable_reason"),
    )
    for candidate in candidates:
        add_unique_error(
            candidate_signals,
            candidate,
            limit=max_error_chars,
            maximum=max(50, maximum),
        )

    log_signals: list[str] = []
    for log_text in _iter_named_text_values(
        result.get("logs"),
        {"log_tail", "stderr", "stdout", "error_message", "message"},
    ):
        lines = log_text.splitlines()
        for index, line in enumerate(lines):
            if not PLATFORM_LOG_SIGNAL_PATTERN.search(line):
                continue
            block = [line.strip()]
            for context_line in lines[index + 1 : index + 4]:
                if PLATFORM_LOG_CONTEXT_PATTERN.search(context_line):
                    block.append(context_line.strip())
            add_unique_error(
                log_signals,
                "\n".join(block),
                limit=max_error_chars,
                maximum=max(50, maximum),
            )
            # One compact context block per log is enough; avoid filling the
            # whitelist with overlapping lines from the same tail.
            break

    signals: list[str] = []
    for signal in [*log_signals, *candidate_signals]:
        add_unique_error(
            signals,
            signal,
            limit=max_error_chars,
            maximum=maximum,
        )
        if len(signals) >= maximum:
            break

    if not signals:
        signals.append("平台终态未返回可用的逐 case 评测错误摘要。")
    return signals


def build_platform_fallback_feedback(
    result: dict[str, Any], feedback_config: dict[str, Any]
) -> dict[str, Any]:
    """Build feedback for a terminal platform result whose score is defined as zero.

    This path is intentionally distinct from a local harness failure: the platform
    did process the submission and its displayed result is the authoritative score.
    The model still receives the current source on the next round plus a compact
    platform error summary, while the experiment summary can count the round as 0.
    """
    job = nested_job(result)
    stage_summary = job.get("stage_summary", {})
    if not isinstance(stage_summary, dict):
        stage_summary = {}
    job_status = job.get("status") or result.get("terminal_status") or "platform_failed"
    status_text = str(job_status).lower()
    failed_stage = stage_summary.get("failed_stage")
    if not failed_stage:
        if "compile" in status_text:
            failed_stage = "compile"
        elif "correctness" in status_text or "accuracy" in status_text:
            failed_stage = "correctness"
        elif "runtime" in status_text or "subprocess" in status_text:
            failed_stage = "runtime"
        else:
            failed_stage = "platform"

    job_summary = {
        "status": job_status,
        "failed_stage": failed_stage,
        "failure_kind": job.get("failure_kind"),
        "error_code": job.get("error_code"),
        "result_score": 0.0,
        "passed_cases": job.get("passed_cases") or 0,
        "total_cases": job.get("total_cases") or 0,
    }
    payload: dict[str, Any] = {
        "feedback_schema": feedback_config.get(
            "schema", "cannbench_iterative_feedback_v3"
        ),
        "source": "harness_platform_zero_fallback",
        "score_source": "platform_result_fallback_zero",
        "evaluation_performed": True,
        "job_summary": job_summary,
        "failure_stage": failed_stage,
        "root_errors": [
            {"index": index, "text": text}
            for index, text in enumerate(
                _platform_failure_signals(result, job, stage_summary, feedback_config),
                start=1,
            )
        ],
        "platform_result_note": (
            "平台已返回本轮终态；本轮分数按平台结果记为 0 分。"
            "由于平台未提供完整逐 case 报告，反馈仅保留平台错误摘要；下一轮继续使用本轮代码。"
        ),
        "omitted_by_policy": [
            "cases",
            "accuracy_details",
            "baseline_perf_us",
            "hardware_limit_us",
            "performance_metrics",
            "raw_platform_json",
            "environment_metadata",
        ],
    }
    return enforce_feedback_size(payload, feedback_config)


def build_platform_feedback_v2(
    result: dict[str, Any],
    feedback_config: dict[str, Any],
    *,
    source_unchanged: bool = False,
    evaluation_reused: bool = False,
) -> dict[str, Any]:
    """阶段感知反馈：按失败阶段决定反馈哪些字段，压缩为模型可聚焦的最小集合。

    - 编译失败：前 3 组根错误 + 得分，不反馈 case/性能/基线；
    - 运行失败：失败阶段 + 去重运行错误 + 受影响 case；
    - 正确性失败：通过数 + 失败 case + 精度指标 + 去重错误；
    - 正确性通过：才反馈各 case 耗时/baseline/hardware limit/speedup/性能分项。
    """
    job = nested_job(result)
    operator = find_operator(job)
    stage_summary = job.get("stage_summary", {})
    if not isinstance(stage_summary, dict):
        stage_summary = {}
    job_status = job.get("status") or result.get("terminal_status") or ""
    max_error_chars = int(feedback_config.get("max_error_characters_each", 1200))
    max_unique_errors = int(feedback_config.get("max_unique_errors", 3))
    compilation_limit = int(feedback_config.get("max_compilation_error_characters", 24000))

    job_summary = {
        key: value
        for key, value in {
            "status": job_status,
            "failed_stage": stage_summary.get("failed_stage"),
            "failure_kind": job.get("failure_kind"),
            "error_code": job.get("error_code"),
            "result_score": job.get("result_score"),
            "passed_cases": job.get("passed_cases"),
            "total_cases": job.get("total_cases"),
        }.items()
        if value is not None
    }
    payload: dict[str, Any] = {
        "feedback_schema": feedback_config.get(
            "schema", "cannbench_iterative_feedback_v2"
        ),
        "source": "benchsite_deterministic_whitelist",
        "evaluation_performed": True,
        "job_summary": job_summary,
    }
    if source_unchanged:
        payload["source_unchanged"] = True
    if evaluation_reused:
        payload["evaluation_reused"] = True
        payload["reuse_note"] = (
            "本轮五文件与上一轮完全相同，Harness 未消耗提交额度，直接复用了上一轮评测结果。"
            "模型本轮没有产生实际改动。"
        )

    compilation_error = clean_text(operator.get("compilation_error"), compilation_limit)
    unique_errors: list[str] = []
    add_unique_error(
        unique_errors,
        operator.get("subprocess_failure_reason"),
        limit=max_error_chars,
        maximum=max_unique_errors,
    )
    add_unique_error(
        unique_errors,
        operator.get("score_error"),
        limit=max_error_chars,
        maximum=max_unique_errors,
    )
    for case in operator.get("cases", []):
        if not isinstance(case, dict):
            continue
        for error_value in (case.get("error_msg"), case.get("performance_error_msg")):
            add_unique_error(
                unique_errors,
                error_value,
                limit=max_error_chars,
                maximum=max_unique_errors,
            )

    is_compile_failure = bool(compilation_error) or "compile" in str(job_status).lower()
    is_correctness_failure = "correctness" in str(job_status).lower() or (
        operator.get("accuracy_passed_cases") is not None
        and operator.get("passed_cases") != operator.get("total_cases")
    )
    is_full_success = str(job_status).lower() in SUCCESS_JOB_STATUSES
    if is_compile_failure:
        grouped = group_compile_errors(
            compilation_error or "",
            max_groups=int(feedback_config.get("max_compile_error_groups", 3)),
            max_characters_each=max_error_chars,
            max_notes_each=int(feedback_config.get("max_compile_notes_each", 2)),
        )
        payload["failure_stage"] = "compile"
        payload["root_errors"] = [
            {"index": index, "text": text} for index, text in enumerate(grouped, start=1)
        ]
        payload["omitted_by_policy"] = [
            "cases",
            "baseline_perf_us",
            "hardware_limit_us",
            "performance_metrics",
            "repeated_compiler_errors",
            "unrelated_notes",
        ]
    elif is_correctness_failure:
        payload["failure_stage"] = "correctness"
        payload["accuracy_summary"] = {
            "passed_cases": operator.get("passed_cases"),
            "total_cases": operator.get("total_cases"),
            "accuracy_passed_cases": operator.get("accuracy_passed_cases"),
            "anti_cheat_failed_cases": operator.get("anti_cheat_failed_cases"),
        }
        failed_cases: list[dict[str, Any]] = []
        cases = operator.get("cases", [])
        if isinstance(cases, list):
            for case in cases:
                if not isinstance(case, dict) or case.get("status") == "success":
                    continue
                accuracy = accuracy_summary(case.get("accuracy")) or {}
                failed_cases.append(
                    {
                        key: value
                        for key, value in {
                            "case_id": case.get("case_id"),
                            "failure_type": case.get("failure_type"),
                            "failure_reason": clean_text(
                                case.get("failure_reason")
                                or case.get("error_msg"),
                                max_error_chars,
                            ),
                            "mere": accuracy.get("mere"),
                            "mare": accuracy.get("mare"),
                            "mismatch_ratio": accuracy.get("mismatch_ratio"),
                        }.items()
                        if value is not None
                    }
                )
        payload["failed_cases"] = failed_cases[: int(feedback_config.get("max_failed_cases", 20))]
        if unique_errors:
            payload["runtime_errors"] = [
                {"ref": index, "text": text}
                for index, text in enumerate(unique_errors, start=1)
            ]
        payload["omitted_by_policy"] = [
            "baseline_perf_us",
            "hardware_limit_us",
            "performance_metrics",
            "passed_case_details",
        ]
    elif is_full_success:
        payload["failure_stage"] = None
        compact_cases: list[dict[str, Any]] = []
        cases = operator.get("cases", [])
        if isinstance(cases, list):
            for case in cases:
                if not isinstance(case, dict):
                    continue
                compact_cases.append({
                    key: value
                    for key, value in {
                        "case_id": case.get("case_id"),
                        "status": case.get("status"),
                        "elapsed_us": case.get("elapsed_us"),
                        "baseline_perf_us": (
                            case.get("baseline_perf_us")
                            if feedback_config.get(
                                "include_baseline_performance_after_round", True
                            )
                            else None
                        ),
                        "hardware_limit_us": (
                            case.get("hardware_limit_us", case.get("t_hw_us"))
                            if feedback_config.get(
                                "include_hardware_limit_after_round", True
                            )
                            else None
                        ),
                        "speedup": case.get("speedup"),
                        "speedup_vs_hw": case.get("speedup_vs_hw"),
                        "perf_score": case.get("perf_score"),
                    }.items()
                    if value is not None
                })
        if feedback_config.get("include_performance_metrics", True):
            maximum = int(feedback_config.get("success_max_performance_cases", 3))
            compact_cases.sort(
                key=lambda case: (
                    case.get("perf_score") is None,
                    float(case.get("perf_score") or 0.0),
                    str(case.get("case_id") or ""),
                )
            )
            payload["lowest_performance_cases"] = compact_cases[:maximum]
            payload["performance_case_selection"] = (
                f"lowest perf_score, at most {maximum} cases"
            )
        if feedback_config.get("include_score_breakdown", True):
            payload["operator_score_breakdown"] = {
                key: operator.get(key)
                for key in SCORE_FIELDS
                                if operator.get(key) is not None
            }
        if payload.get("operator_score_breakdown", {}).get("bonus_score") is not None:
            payload["score_breakdown_note"] = FIELD_NOTE
        payload["omitted_by_policy"] = ["raw_platform_json", "runner_identity"]
    else:
        payload["failure_stage"] = stage_summary.get("failed_stage") or "runtime"
        if unique_errors:
            payload["runtime_errors"] = [
                {"ref": index, "text": text}
                for index, text in enumerate(unique_errors, start=1)
            ]
        affected = [
            case.get("case_id")
            for case in operator.get("cases", [])
            if isinstance(case, dict) and case.get("status") != "success"
        ]
        if affected:
            payload["affected_cases"] = affected[:20]
        payload["omitted_by_policy"] = [
            "baseline_perf_us",
            "hardware_limit_us",
            "performance_metrics",
        ]
    return enforce_feedback_size(payload, feedback_config)


def build_platform_feedback(
    result: dict[str, Any], feedback_config: dict[str, Any]
) -> dict[str, Any]:
    job = nested_job(result)
    operator = find_operator(job)
    max_error_chars = int(feedback_config.get("max_error_characters_each", 2000))
    max_unique_errors = int(feedback_config.get("max_unique_errors", 20))
    compilation_limit = int(
        feedback_config.get("max_compilation_error_characters", 24000)
    )
    unique_errors: list[str] = []

    compilation_error = clean_text(operator.get("compilation_error"), compilation_limit)
    add_unique_error(
        unique_errors,
        operator.get("subprocess_failure_reason"),
        limit=max_error_chars,
        maximum=max_unique_errors,
    )
    add_unique_error(
        unique_errors,
        operator.get("score_error"),
        limit=max_error_chars,
        maximum=max_unique_errors,
    )

    compact_cases: list[dict[str, Any]] = []
    cases = operator.get("cases", [])
    if isinstance(cases, list):
        for case in cases:
            if not isinstance(case, dict):
                continue
            error_refs: list[int] = []
            for error_value in (case.get("error_msg"), case.get("performance_error_msg")):
                ref = add_unique_error(
                    unique_errors,
                    error_value,
                    limit=max_error_chars,
                    maximum=max_unique_errors,
                )
                if ref is not None and ref not in error_refs:
                    error_refs.append(ref)
            compact = {
                "case_id": case.get("case_id"),
                "status": case.get("status"),
                "failure_type": case.get("failure_type"),
                "elapsed_us": case.get("elapsed_us"),
                "baseline_perf_us": (
                    case.get("baseline_perf_us")
                    if feedback_config.get("include_baseline_performance_after_round", True)
                    else None
                ),
                "hardware_limit_us": (
                    case.get("hardware_limit_us", case.get("t_hw_us"))
                    if feedback_config.get("include_hardware_limit_after_round", True)
                    else None
                ),
                "speedup": case.get("speedup"),
                "speedup_vs_hw": case.get("speedup_vs_hw"),
                "perf_score": case.get("perf_score"),
                "accuracy": (
                    accuracy_summary(case.get("accuracy"))
                    if feedback_config.get("include_accuracy_metrics", True)
                    else None
                ),
                "error_refs": error_refs or None,
            }
            compact_cases.append(
                {key: value for key, value in compact.items() if value is not None}
            )

    score_breakdown = {
        key: operator.get(key)
        for key in SCORE_FIELDS
                if operator.get(key) is not None
    }
    stage_summary = job.get("stage_summary", {})
    if not isinstance(stage_summary, dict):
        stage_summary = {}
    payload = {
        "feedback_schema": feedback_config.get(
            "schema", "cannbench_iterative_feedback_v1"
        ),
        "source": "benchsite_deterministic_whitelist",
        "evaluation_performed": True,
        "job_summary": {
            key: value
            for key, value in {
                "status": job.get("status", result.get("terminal_status")),
                "failed_stage": stage_summary.get("failed_stage"),
                "failure_kind": job.get("failure_kind"),
                "error_code": job.get("error_code"),
                "error_message": clean_text(job.get("error_message"), max_error_chars),
                "result_score": job.get("result_score"),
                "passed_cases": job.get("passed_cases"),
                "total_cases": job.get("total_cases"),
            }.items()
            if value is not None
        },
        "operator_score_breakdown": score_breakdown,
        **({"score_breakdown_note": FIELD_NOTE} if score_breakdown.get("bonus_score") is not None else {}),
        "compilation_error": compilation_error,
        "unique_errors": [
            {"ref": index, "text": text}
            for index, text in enumerate(unique_errors, start=1)
        ],
        "cases": compact_cases,
        "omitted_by_policy": [
            "raw_platform_json",
            "runner_identity",
            "user_identity",
            "submission_paths",
            "polling_history",
        ],
    }
    return enforce_feedback_size(payload, feedback_config)


def build_parse_feedback(
    parse_report: dict[str, Any], feedback_config: dict[str, Any]
) -> dict[str, Any]:
    payload = {
        "feedback_schema": feedback_config.get(
            "schema", "cannbench_iterative_feedback_v1"
        ),
        "source": "local_harness_parser",
        "evaluation_performed": False,
        "failure_stage": "output_parsing",
        "reason": "输出中缺少可安全识别的完整目标文件，因此本轮没有提交 BenchSite。",
        "parse_report": {
            key: parse_report.get(key)
            for key in (
                "file_block_count",
                "paths",
                "expected_paths",
                "duplicate_paths",
                "missing_paths",
                "unexpected_paths",
                "order_matches",
                "all_files_nonempty",
                "outer_markdown_fence",
                "internal_markdown_fence_paths",
                "residual_text",
                "recoverable_parse_pass",
                "strict_protocol_pass",
                "format_recovered",
                "format_recovery_reasons",
                "unclosed_file_paths",
            )
        },
        "change_summary": {
            key: (parse_report.get("change_summary") or {}).get(key)
            for key in ("present", "characters", "truncated", "violation")
        },
    }
    residual_limit = int(feedback_config.get("max_error_characters_each", 2000))
    payload["parse_report"]["residual_text"] = clean_text(
        payload["parse_report"].get("residual_text"), residual_limit
    )
    return enforce_feedback_size(payload, feedback_config)


def build_harness_feedback(
    stage: str, error: Exception, feedback_config: dict[str, Any]
) -> dict[str, Any]:
    payload = {
        "feedback_schema": feedback_config.get(
            "schema", "cannbench_iterative_feedback_v1"
        ),
        "source": "local_harness",
        "evaluation_performed": False,
        "failure_stage": stage,
        "reason": clean_text(
            error,
            int(feedback_config.get("max_error_characters_each", 2000)),
        ),
        "error_type": type(error).__name__,
    }
    return enforce_feedback_size(payload, feedback_config)


def enforce_feedback_size(
    payload: dict[str, Any], feedback_config: dict[str, Any]
) -> dict[str, Any]:
    maximum = int(feedback_config.get("max_feedback_characters", 60000))

    def size() -> int:
        return len(json.dumps(payload, ensure_ascii=False, indent=2))

    if size() <= maximum:
        payload["feedback_characters_before_template"] = size()
        return payload

    payload["unique_errors"] = payload.get("unique_errors", [])[:10]
    for case in payload.get("cases", []):
        accuracy = case.get("accuracy")
        if isinstance(accuracy, dict):
            accuracy.pop("outputs", None)
    if size() <= maximum:
        payload["feedback_truncation"] = "dropped_extra_unique_errors_and_per_output_accuracy"
        payload["feedback_characters_before_template"] = size()
        return payload

    root_errors = payload.get("root_errors")
    if isinstance(root_errors, list):
        payload["root_errors"] = root_errors[:5]
    failed_cases = payload.get("failed_cases")
    if isinstance(failed_cases, list):
        for case in failed_cases:
            case.pop("failure_reason", None)
    if size() <= maximum:
        payload["feedback_truncation"] = "shortened_v2_root_errors_and_failed_cases"
        payload["feedback_characters_before_template"] = size()
        return payload

    compilation_error = payload.get("compilation_error")
    if isinstance(compilation_error, str):
        payload["compilation_error"] = clean_text(compilation_error, 8000)
    if size() <= maximum:
        payload["feedback_truncation"] = "also_shortened_compilation_error"
        payload["feedback_characters_before_template"] = size()
        return payload

    raise ValueError(
        f"固定反馈白名单在确定性压缩后仍超过 {maximum} 字符，拒绝静默裁剪 JSON"
    )


def render_feedback_prompt(
    template_text: str,
    *,
    round_number: int,
    total_rounds: int,
    payload: dict[str, Any],
) -> str:
    replacements = {
        "{{ROUND_NUMBER}}": str(round_number),
        "{{NEXT_ROUND_NUMBER}}": str(round_number + 1),
        "{{TOTAL_ROUNDS}}": str(total_rounds),
        "{{FEEDBACK_JSON}}": json.dumps(payload, ensure_ascii=False, indent=2),
    }
    rendered = template_text
    for placeholder, value in replacements.items():
        rendered = rendered.replace(placeholder, value)
    unresolved = sorted(set(PLACEHOLDER_PATTERN.findall(rendered)))
    if unresolved:
        raise ValueError(f"反馈模板仍有未替换占位符: {unresolved}")
    return rendered.rstrip() + "\n"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="从既有评测结果生成固定白名单反馈。")
    parser.add_argument("--result", required=True, type=Path)
    parser.add_argument("--protocol", required=True, type=Path)
    parser.add_argument("--template", required=True, type=Path)
    parser.add_argument("--round", required=True, type=int)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    protocol = yaml.safe_load(args.protocol.read_text(encoding="utf-8-sig"))
    feedback_config = protocol["feedback"]
    total_rounds = int(protocol["experiment"]["rounds_per_trajectory"])
    result = load_json(args.result)
    payload = (
        build_platform_feedback_v2(result, feedback_config)
        if feedback_config.get("stage_aware") is True
        else build_platform_feedback(result, feedback_config)
    )
    template_text = args.template.read_text(encoding="utf-8-sig")
    prompt = render_feedback_prompt(
        template_text,
        round_number=args.round,
        total_rounds=total_rounds,
        payload=payload,
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_json(args.output_dir / "feedback_payload.json", payload)
    (args.output_dir / "feedback_prompt.txt").write_text(prompt, encoding="utf-8")
    print(f"反馈 JSON: {args.output_dir / 'feedback_payload.json'}")
    print(f"反馈提示词: {args.output_dir / 'feedback_prompt.txt'}")
    print(f"反馈提示词 SHA-256: {sha256_text(prompt)}")


if __name__ == "__main__":
    main()
