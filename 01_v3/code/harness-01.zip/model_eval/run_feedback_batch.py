from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import yaml

from modelscope_common import ROOT, timestamp, write_json


PROJECT_ROOT = ROOT.parent
RUNNER = ROOT / "run_feedback_trials.py"
DEFAULT_LONG_GENERATION_THRESHOLD_SECONDS = 1200.0


def safe_name(value: str) -> str:
    cleaned = "".join(char if char.isalnum() or char in "-_" else "_" for char in value)
    if not cleaned:
        raise ValueError("名称不能为空")
    return cleaned


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="批量调度多轮反馈轨迹。")
    parser.add_argument("--batch", required=True, type=Path)
    parser.add_argument("--allow-submit", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--max-workers", type=int)
    parser.add_argument(
        "--long-generation-threshold-seconds",
        type=float,
        help=(
            "转发给轨迹执行器：上一轮超过该耗时后，在下一轮追加精简思考提醒；"
            f"默认 {DEFAULT_LONG_GENERATION_THRESHOLD_SECONDS:g} 秒"
        ),
    )
    return parser.parse_args()


def resolve_from_project(value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def load_batch(path: Path) -> dict[str, Any]:
    data = yaml.safe_load(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        raise ValueError("批次 YAML 必须包含 items 列表")
    batch = data.get("batch", {})
    for key in ("experiment_id", "platform", "protocol"):
        if not batch.get(key):
            raise ValueError(f"batch 缺少 {key}")
    identities: set[tuple[str, str]] = set()
    for index, item in enumerate(data["items"], start=1):
        if not isinstance(item, dict):
            raise ValueError(f"items[{index}] 必须是对象")
        for key in ("task_id", "op_name", "prompt", "model"):
            if not item.get(key):
                raise ValueError(f"items[{index}] 缺少 {key}")
        identity = (str(item["model"]), str(item["task_id"]))
        if identity in identities:
            raise ValueError(f"批次存在重复 model×task: {identity}")
        identities.add(identity)
    return data


def cost_budget_reached() -> bool:
    """Read the shared response-cost ledger used by a budgeted batch."""
    ledger_raw = os.environ.get("MODEL_EVAL_COST_LEDGER", "").strip()
    if not ledger_raw:
        return False
    ledger_path = Path(ledger_raw).expanduser().resolve()
    if not ledger_path.is_file():
        return False
    try:
        state = json.loads(ledger_path.read_text(encoding="utf-8-sig"))
        return bool(state.get("cost_unknown")) or float(state.get("spent_usd", 0.0)) >= float(
            state["limit_usd"]
        )
    except Exception:
        # A corrupt ledger must fail closed: never start another paid request.
        return True


def main() -> None:
    args = parse_args()
    batch_path = args.batch.resolve()
    data = load_batch(batch_path)
    batch = data["batch"]
    experiment_id = safe_name(str(batch["experiment_id"]))
    max_workers = args.max_workers or int(batch.get("max_workers", 1))
    configured_threshold = batch.get("long_generation_threshold_seconds")
    if args.long_generation_threshold_seconds is not None:
        long_generation_threshold_seconds = args.long_generation_threshold_seconds
    elif configured_threshold is not None:
        long_generation_threshold_seconds = float(configured_threshold)
    else:
        long_generation_threshold_seconds = DEFAULT_LONG_GENERATION_THRESHOLD_SECONDS
    if max_workers < 1 or max_workers > 3:
        raise ValueError("max-workers 必须在 1 到 3 之间，以符合当前平台并发上限")
    if os.environ.get("MODEL_EVAL_COST_LIMIT_USD", "").strip() and max_workers != 1:
        raise ValueError("启用费用预算时必须使用 max_workers=1，避免并发请求超出预算")
    if (
        long_generation_threshold_seconds is not None
        and long_generation_threshold_seconds <= 0
    ):
        raise ValueError("--long-generation-threshold-seconds 必须大于 0")
    if not args.dry_run and not args.allow_submit:
        raise ValueError("真实批量运行必须显式添加 --allow-submit")

    maximum_submissions = 0
    maximum_model_calls = 0
    for item in data["items"]:
        protocol_path = resolve_from_project(str(item.get("protocol", batch["protocol"])))
        protocol = yaml.safe_load(protocol_path.read_text(encoding="utf-8-sig"))
        experiment = protocol.get("experiment", {})
        item_calls = int(experiment.get("trajectories_per_model_task", 0)) * int(
            experiment.get("rounds_per_trajectory", 0)
        )
        if item_calls < 1:
            raise ValueError(f"无效多轮协议: {protocol_path}")
        maximum_model_calls += item_calls
        maximum_submissions += item_calls

    batch_run_dir = ROOT / "runs" / "feedback_batches" / experiment_id
    batch_run_dir.mkdir(parents=True, exist_ok=True)
    state_path = batch_run_dir / "batch_state.json"
    state_lock = threading.Lock()
    state: dict[str, Any] = {
        "experiment_id": experiment_id,
        "batch_source": str(batch_path),
        "platform": batch["platform"],
        "protocol": str(resolve_from_project(str(batch["protocol"]))),
        "max_workers": max_workers,
        "long_generation_threshold_seconds": long_generation_threshold_seconds,
        "dry_run": bool(args.dry_run),
        "maximum_model_calls": maximum_model_calls,
        "maximum_platform_submissions": maximum_submissions,
        "status": "running",
        "started_or_resumed_at": timestamp(),
        "items": {},
    }

    def update_state(key: str, value: dict[str, Any]) -> None:
        with state_lock:
            state["items"][key] = value
            write_json(state_path, state)

    def run_item(item: dict[str, Any]) -> tuple[str, int]:
        key = safe_name(f"{item['model']}__{item['task_id']}")
        command = [
            sys.executable,
            str(RUNNER),
            "--prompt", str(resolve_from_project(str(item["prompt"]))),
            "--task-id", str(item["task_id"]),
            "--op-name", str(item["op_name"]),
            "--platform", str(batch["platform"]),
            "--protocol", str(resolve_from_project(str(item.get("protocol", batch["protocol"])))),
            "--experiment-id", experiment_id,
            "--model", str(item["model"]),
        ]
        feedback_template = item.get("feedback_template", batch.get("feedback_template"))
        if feedback_template:
            command.extend(
                ["--feedback-template", str(resolve_from_project(str(feedback_template)))]
            )
        if args.dry_run:
            command.append("--dry-run")
        else:
            command.append("--allow-submit")
        if args.resume:
            command.append("--resume")
        if long_generation_threshold_seconds is not None:
            command.extend(
                [
                    "--long-generation-threshold-seconds",
                    str(long_generation_threshold_seconds),
                ]
            )
        update_state(key, {"status": "running", "started_at": timestamp()})
        completed = subprocess.run(
            command,
            cwd=PROJECT_ROOT,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            check=False,
        )
        log_path = batch_run_dir / f"{key}.log"
        log_path.write_text(
            completed.stdout + "\n===== STDERR =====\n" + completed.stderr,
            encoding="utf-8",
        )
        update_state(
            key,
            {
                "status": "completed" if completed.returncode == 0 else "failed",
                "returncode": completed.returncode,
                "finished_at": timestamp(),
                "log": str(log_path),
            },
        )
        return key, completed.returncode

    failures: list[str] = []
    if max_workers == 1:
        # 正式批次默认串行。任何子实验非零退出都表示基础设施、环境或 API
        # 失败；模型自身的编译/正确性失败仍会正常返回 0。因此这里必须立即
        # 停止，避免运行时版本硬校验失败后继续提交后续算子。
        for index, item in enumerate(data["items"]):
            if cost_budget_reached():
                for pending in data["items"][index:]:
                    pending_key = safe_name(
                        f"{pending['model']}__{pending['task_id']}"
                    )
                    update_state(
                        pending_key,
                        {"status": "not_started_due_to_cost_budget"},
                    )
                break
            key, returncode = run_item(item)
            if returncode != 0:
                failures.append(key)
                for pending in data["items"][index + 1:]:
                    pending_key = safe_name(
                        f"{pending['model']}__{pending['task_id']}"
                    )
                    update_state(
                        pending_key,
                        {
                            "status": "not_started_due_to_prior_failure",
                            "blocked_by": key,
                        },
                    )
                break
            if cost_budget_reached():
                for pending in data["items"][index + 1:]:
                    pending_key = safe_name(
                        f"{pending['model']}__{pending['task_id']}"
                    )
                    update_state(
                        pending_key,
                        {"status": "not_started_due_to_cost_budget"},
                    )
                break
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # 按并发上限分波次提交。一个波次内已经运行的任务允许完成；若任一
            # 任务发生基础设施失败，则不再启动后续波次，避免版本硬校验失败后
            # 继续创建新的平台任务。
            items = data["items"]
            for wave_start in range(0, len(items), max_workers):
                wave = items[wave_start:wave_start + max_workers]
                futures = [executor.submit(run_item, item) for item in wave]
                for future in as_completed(futures):
                    key, returncode = future.result()
                    if returncode != 0:
                        failures.append(key)
                if failures:
                    for pending in items[wave_start + len(wave):]:
                        pending_key = safe_name(
                            f"{pending['model']}__{pending['task_id']}"
                        )
                        update_state(
                            pending_key,
                            {
                                "status": "not_started_due_to_prior_failure",
                                "blocked_by": failures[0],
                            },
                        )
                    break

    state["status"] = "completed" if not failures else "completed_with_failures"
    state["failed_items"] = failures
    state["finished_at"] = timestamp()
    write_json(state_path, state)
    print(f"批次状态: {state['status']}")
    print(f"计划上限: {maximum_model_calls} 次模型生成 / {maximum_submissions} 次平台提交")
    print(f"批次记录: {state_path}")
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
