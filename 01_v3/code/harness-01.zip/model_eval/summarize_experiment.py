from __future__ import annotations

import argparse
import json
import re
import statistics
from collections import Counter
from pathlib import Path
from typing import Any

from modelscope_common import timestamp, write_json


ANSI_PATTERN = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
TRIAL_DIR_PATTERN = re.compile(r"^trial_\d{3}$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="汇总一次模型×任务×平台正式实验。")
    parser.add_argument("--experiment-dir", required=True, type=Path)
    return parser.parse_args()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def nested_job(result: dict[str, Any]) -> dict[str, Any]:
    value = result.get("job", {})
    return value.get("job", value) if isinstance(value, dict) else {}


def extract_compile_errors(result: dict[str, Any]) -> list[str]:
    text = json.dumps(result.get("logs", {}), ensure_ascii=False)
    text = ANSI_PATTERN.sub("", text)
    errors: list[str] = []
    for line in text.split("\\n"):
        line = line.strip()
        if any(
            marker in line.lower()
            for marker in ("error:", "fatal error", "aborted (core dumped)")
        ):
            if line not in errors:
                errors.append(line)
    return errors[:8]


def find_score_breakdown(value: Any) -> dict[str, Any]:
    wanted = {
        "score",
        "compilation_score",
        "compile_runtime_score",
        "function_score",
        "bonus_score",
        "performance_score",
        "avg_speedup",
    }
    if isinstance(value, dict):
        if "compilation_score" in value and "function_score" in value:
            return {key: value.get(key) for key in wanted}
        for child in value.values():
            found = find_score_breakdown(child)
            if found:
                return found
    elif isinstance(value, list):
        for child in value:
            found = find_score_breakdown(child)
            if found:
                return found
    return {}


def main() -> None:
    args = parse_args()
    root = args.experiment_dir.resolve()
    trial_dirs = sorted(
        path
        for path in root.glob("trial_*")
        if path.is_dir() and TRIAL_DIR_PATTERN.fullmatch(path.name)
    )
    if not trial_dirs:
        raise ValueError(f"未找到 trial 目录: {root}")

    trials: list[dict[str, Any]] = []
    prompt_versions: set[str] = set()
    for trial_dir in trial_dirs:
        status = load_json(trial_dir / "status.json")
        parse_report = load_json(trial_dir / "parse_report.json")
        raw_response = load_json(trial_dir / "raw_response.json")
        receipt = load_json(trial_dir / "submission_receipt.json")
        result = load_json(trial_dir / "benchsite_result.json")
        render_metadata = load_json(trial_dir / "render_metadata.json")
        prompt_version = render_metadata.get("prompt_template_version")
        if not prompt_version:
            template_path = str(
                render_metadata.get("sources", {}).get("template", {}).get("path", "")
            )
            match = re.search(r"(?:模板-|模板（)(v\d+)", template_path)
            prompt_version = match.group(1) if match else "unknown"
        prompt_versions.add(str(prompt_version))
        job = nested_job(result)
        score_breakdown = find_score_breakdown(result)
        usage = raw_response.get("usage") or {}
        trials.append(
            {
                "trial": trial_dir.name,
                "prompt_template_version": prompt_version,
                "generation": {
                    "finish_reason": status.get("finish_reason"),
                    "elapsed_seconds": status.get("elapsed_seconds"),
                    "network_retry_count": status.get("network_retry_count"),
                    "content_retry_count": status.get("content_retry_count"),
                    "prompt_tokens": usage.get("prompt_tokens"),
                    "completion_tokens": usage.get("completion_tokens"),
                    "total_tokens": usage.get("total_tokens"),
                },
                "format": {
                    "recoverable_parse_pass": parse_report.get("recoverable_parse_pass"),
                    "strict_protocol_pass": parse_report.get("strict_protocol_pass"),
                    "outer_markdown_fence": parse_report.get("outer_markdown_fence"),
                    "explicit_meta_dispatch": parse_report.get("static_contract_checks", {}).get(
                        "plugin_registers_meta"
                    ),
                },
                "submission": {
                    "submission_id": receipt.get("response", {}).get("submission", {}).get("id"),
                    "job_id": receipt.get("response", {}).get("job", {}).get("id"),
                    "target_hardware": receipt.get("request", {}).get("target_hardware"),
                    "submission_tag": receipt.get("request", {}).get("submission_tag"),
                    "is_private": receipt.get("request", {}).get("is_private"),
                },
                "score": {
                    "status": job.get("status"),
                    "result_score": job.get("result_score"),
                    "passed_cases": job.get("passed_cases"),
                    "total_cases": job.get("total_cases"),
                    "error_code": job.get("error_code"),
                    "failure_kind": job.get("failure_kind"),
                    "compile_errors": extract_compile_errors(result),
                    "breakdown": score_breakdown,
                },
            }
        )

    scores = [
        float(trial["score"]["result_score"])
        for trial in trials
        if trial["score"]["result_score"] is not None
    ]
    status_counts = Counter(str(trial["score"]["status"]) for trial in trials)
    positive_score_count = sum(score > 0 for score in scores)
    succeeded_count = sum(trial["score"]["status"] == "succeeded" for trial in trials)
    full_correctness_count = sum(
        trial["score"]["total_cases"] is not None
        and trial["score"]["passed_cases"] == trial["score"]["total_cases"]
        for trial in trials
    )
    compile_success_count = sum(
        float(trial["score"]["breakdown"].get("compilation_score") or 0) > 0
        for trial in trials
    )
    breakdown_fields = (
        "compilation_score",
        "compile_runtime_score",
        "function_score",
        "bonus_score",
        "performance_score",
        "avg_speedup",
    )
    breakdown_means = {}
    for field in breakdown_fields:
        values = [
            float(trial["score"]["breakdown"][field])
            for trial in trials
            if trial["score"]["breakdown"].get(field) is not None
        ]
        breakdown_means[field] = statistics.mean(values) if values else None
    summary = {
        "summarized_at": timestamp(),
        "experiment_dir": str(root),
        "trial_count": len(trials),
        "prompt_template_versions": sorted(prompt_versions),
        "generation_completed": sum(
            trial["generation"]["finish_reason"] is not None for trial in trials
        ),
        "recoverable_parse_passes": sum(
            bool(trial["format"]["recoverable_parse_pass"]) for trial in trials
        ),
        "strict_protocol_passes": sum(
            bool(trial["format"]["strict_protocol_pass"]) for trial in trials
        ),
        "submitted_jobs": sum(bool(trial["submission"]["job_id"]) for trial in trials),
        "job_status_counts": dict(status_counts),
        "positive_score_count": positive_score_count,
        "positive_score_rate": positive_score_count / len(trials),
        "compile_success_count": compile_success_count,
        "compile_success_rate": compile_success_count / len(trials),
        "full_correctness_count": full_correctness_count,
        "full_correctness_rate": full_correctness_count / len(trials),
        "succeeded_count": succeeded_count,
        "succeeded_rate": succeeded_count / len(trials),
        "score_breakdown_means": breakdown_means,
        "score": {
            "values": scores,
            "mean": statistics.mean(scores) if scores else None,
            "median": statistics.median(scores) if scores else None,
            "minimum": min(scores) if scores else None,
            "maximum": max(scores) if scores else None,
            "population_stddev": statistics.pstdev(scores) if scores else None,
            "sample_stddev": statistics.stdev(scores) if len(scores) >= 2 else None,
        },
        "trials": trials,
    }
    write_json(root / "experiment_summary.json", summary)
    manifest_path = root / "experiment_manifest.json"
    if manifest_path.is_file():
        manifest = load_json(manifest_path)
        manifest.update(
            {
                "status": "evaluation_completed",
                "job_status_counts": dict(status_counts),
                "score_values": scores,
                "mean_score": summary["score"]["mean"],
                "completed_trials": len(trials),
            }
        )
        write_json(manifest_path, manifest)

    lines = [
        "# 正式实验结果汇总",
        "",
        f"- Trial 数：{summary['trial_count']}",
        f"- 可恢复解析：{summary['recoverable_parse_passes']}/{summary['trial_count']}",
        f"- 严格格式通过：{summary['strict_protocol_passes']}/{summary['trial_count']}",
        f"- 已提交 Job：{summary['submitted_jobs']}/{summary['trial_count']}",
        f"- Job 状态：{dict(status_counts)}",
        f"- 分数：{scores}",
        f"- 平均分：{summary['score']['mean']}",
        f"- 非零分成功率：{summary['positive_score_count']}/{summary['trial_count']} ({summary['positive_score_rate']:.2%})",
        f"- 编译成功率：{summary['compile_success_count']}/{summary['trial_count']} ({summary['compile_success_rate']:.2%})",
        f"- 20/20 正确率：{summary['full_correctness_count']}/{summary['trial_count']} ({summary['full_correctness_rate']:.2%})",
        f"- Job succeeded：{summary['succeeded_count']}/{summary['trial_count']} ({summary['succeeded_rate']:.2%})",
        f"- 最低分 / 最高分：{summary['score']['minimum']} / {summary['score']['maximum']}",
        f"- 总体标准差：{summary['score']['population_stddev']}",
        f"- 平均分项：{summary['score_breakdown_means']}",
        "",
        "| Trial | Job ID | 状态 | 通过用例 | 分数 |",
        "|---|---|---|---:|---:|",
    ]
    for trial in trials:
        score = trial["score"]
        submission = trial["submission"]
        lines.append(
            f"| {trial['trial']} | {submission['job_id']} | {score['status']} | "
            f"{score['passed_cases']}/{score['total_cases']} | {score['result_score']} |"
        )
    (root / "experiment_summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"实验汇总: {root / 'experiment_summary.json'}")
    print(f"可读摘要: {root / 'experiment_summary.md'}")


if __name__ == "__main__":
    main()
