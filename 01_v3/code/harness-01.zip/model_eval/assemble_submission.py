from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path

from modelscope_common import timestamp, write_json
from parse_output import parse_run


ROOT = Path(__file__).resolve().parent
DEFAULT_SKELETON = ROOT.parent / "examples" / "direct_launch_example"
INIT_MARKER = "# Direct function calls:"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="把一份模型输出机械装入统一的 CannBench direct-launch 工程骨架。"
    )
    parser.add_argument("--run-dir", required=True, type=Path, help="单个 trial 目录")
    parser.add_argument("--op-name", required=True, help="算子目录名")
    parser.add_argument("--skeleton", type=Path, default=DEFAULT_SKELETON, help="固定工程骨架")
    return parser.parse_args()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tree_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        relative = path.relative_to(root).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(bytes.fromhex(file_sha256(path)))
    return digest.hexdigest()


def clean_example_content(project_dir: Path) -> None:
    for relative in ("csrc/ops/add", "csrc/ops/sqrt", "tests/add", "tests/sqrt"):
        target = project_dir / relative
        if target.exists():
            shutil.rmtree(target)

    init_path = project_dir / "cann_bench" / "__init__.py"
    init_text = init_path.read_text(encoding="utf-8-sig")
    if INIT_MARKER not in init_text:
        raise ValueError(f"统一工程骨架中的 __init__.py 缺少固定标记: {INIT_MARKER}")
    fixed_prefix = init_text.split(INIT_MARKER, 1)[0].rstrip()
    init_path.write_text(fixed_prefix + "\n", encoding="utf-8")


def configure_platform_build(
    project_dir: Path, platform: dict[str, object]
) -> dict[str, str]:
    npu_arch = str(platform["npu_arch"])
    expected_bisheng_arch = str(platform["bisheng_npu_arch"])
    cmake_path = project_dir / "CMakeLists.txt"
    cmake_text = cmake_path.read_text(encoding="utf-8-sig")
    pattern = re.compile(
        rf'(elseif\(NPU_ARCH STREQUAL "{re.escape(npu_arch)}"\)\s*'
        rf'set\(BISHENG_NPU_ARCH ")(?P<arch>[^"]+)("\))'
    )
    match = pattern.search(cmake_text)
    if not match:
        raise ValueError(f"统一工程骨架中没有 {npu_arch} 的 Bisheng 架构映射")
    previous_bisheng_arch = match.group("arch")
    configured = pattern.sub(
        rf'\g<1>{expected_bisheng_arch}\g<3>', cmake_text, count=1
    )
    cmake_path.write_text(configured, encoding="utf-8")
    return {
        "npu_arch": npu_arch,
        "previous_bisheng_npu_arch": previous_bisheng_arch,
        "configured_bisheng_npu_arch": expected_bisheng_arch,
    }


def assemble(run_dir: Path, op_name: str, skeleton: Path) -> Path:
    run_dir = run_dir.resolve()
    skeleton = skeleton.resolve()
    report = parse_run(run_dir, op_name)
    if not report["recoverable_parse_pass"]:
        raise ValueError("模型输出中缺少可安全识别的完整目标文件，不能装配提交工程")

    project_dir = run_dir / "submission_project"
    if project_dir.exists():
        raise FileExistsError(f"提交工程已存在，为避免覆盖而停止: {project_dir}")
    if not (skeleton / "build.sh").is_file():
        raise ValueError(f"统一工程骨架根部缺少 build.sh: {skeleton}")

    shutil.copytree(skeleton, project_dir)
    clean_example_content(project_dir)

    render_metadata = json.loads(
        (run_dir / "render_metadata.json").read_text(encoding="utf-8-sig")
    )
    platform_build = configure_platform_build(project_dir, render_metadata["platform"])

    parsed_root = Path(report["parsed_root"])
    generated_op_dir = parsed_root / "csrc" / "ops" / op_name
    destination_op_dir = project_dir / "csrc" / "ops" / op_name
    shutil.copytree(generated_op_dir, destination_op_dir)

    append_path = parsed_root / "cann_bench" / "__init__.py.append"
    generated_append = append_path.read_text(encoding="utf-8-sig").rstrip()
    package_init = project_dir / "cann_bench" / "__init__.py"
    with package_init.open("a", encoding="utf-8", newline="\n") as file:
        file.write("\n" + generated_append + "\n")

    manifest = {
        "assembled_at": timestamp(),
        "run_dir": str(run_dir),
        "op_name": op_name,
        "skeleton": str(skeleton),
        "skeleton_sha256": tree_hash(skeleton),
        "model_output_sha256": file_sha256(run_dir / "model_output.txt"),
        "submission_project": str(project_dir),
        "submission_project_sha256": tree_hash(project_dir),
        "source_code_repaired": False,
        "format_recovered": bool(report.get("format_recovered")),
        "format_recovery_reasons": report.get("format_recovery_reasons", []),
        "strict_protocol_pass": bool(report.get("strict_protocol_pass")),
        "internal_markdown_fence_paths": report.get("internal_markdown_fence_paths", []),
        "example_operators_removed": ["add", "sqrt"],
        "build_sh_at_archive_root": (project_dir / "build.sh").is_file(),
        "platform_build": platform_build,
    }
    write_json(run_dir / "assembly_manifest.json", manifest)
    return project_dir


def main() -> None:
    args = parse_args()
    project_dir = assemble(args.run_dir, args.op_name, args.skeleton)
    print(f"统一提交工程已装配: {project_dir}")
    print(f"装配记录: {args.run_dir.resolve() / 'assembly_manifest.json'}")


if __name__ == "__main__":
    main()
