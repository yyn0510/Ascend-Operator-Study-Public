from __future__ import annotations

from modelscope_common import (
    RUNS_PATH,
    choose_preferred_model,
    create_client,
    list_live_models,
    load_config,
    timestamp,
    write_json,
)


def main() -> None:
    config = load_config()
    client = create_client()
    records = list_live_models(client)
    selected_model = choose_preferred_model(records, config)
    captured_at = timestamp()

    snapshot_path = RUNS_PATH / "provider_snapshots" / f"{captured_at}.json"
    write_json(
        snapshot_path,
        {
            "provider": config["provider"],
            "base_url": config["base_url"],
            "captured_at": captured_at,
            "models": records,
        },
    )
    write_json(
        RUNS_PATH / "selected_model.json",
        {
            "provider": config["provider"],
            "model_id": selected_model,
            "selected_at": captured_at,
            "snapshot": str(snapshot_path.relative_to(RUNS_PATH.parent)),
        },
    )

    print(f"在线模型数量: {len(records)}")
    print(f"已选择模型: {selected_model}")
    print(f"模型快照: {snapshot_path}")


if __name__ == "__main__":
    main()
