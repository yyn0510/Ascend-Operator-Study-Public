from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import yaml
import httpx
from openai import APIConnectionError, APITimeoutError, RateLimitError

from modelscope_common import (
    RUNS_PATH,
    create_client,
    load_config,
    load_selected_model,
    response_to_dict,
    timestamp,
    write_json,
)
from parse_output import parse_run


ROOT = Path(__file__).resolve().parent
DEFAULT_PROTOCOL = ROOT / "experiment_protocol.yaml"
# Streaming responses can surface transport exceptions directly from httpx
# while iterating response chunks, before the OpenAI client wraps them.
RETRYABLE_ERRORS = (
    APIConnectionError,
    APITimeoutError,
    RateLimitError,
    httpx.TransportError,
)


class MalformedProviderResponse(RuntimeError):
    pass


def retry_delay_seconds(error: Exception, attempt_number: int) -> int:
    """Use a slower backoff for provider burst-rate protection."""
    if isinstance(error, RateLimitError) and "limit_burst_rate" in str(error):
        return 30 * attempt_number
    return 5 * attempt_number


def response_has_content(response: Any) -> bool:
    choices = getattr(response, "choices", None)
    if not choices:
        return False
    message = getattr(choices[0], "message", None)
    content = getattr(message, "content", None) if message is not None else None
    return isinstance(content, str) and bool(content.strip())


def create_streaming_response(
    client: Any,
    *,
    model: str,
    prompt: str,
    temperature: float,
    max_tokens: int,
    extra_body: dict[str, Any] | None = None,
) -> Any:
    stream = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
        max_tokens=max_tokens,
        stream=True,
        extra_body=extra_body,
    )
    content_parts: list[str] = []
    reasoning_parts: list[str] = []
    raw_chunks: list[dict[str, Any]] = []
    response_id = ""
    returned_model = model
    created = 0
    finish_reason: str | None = None
    usage: dict[str, Any] | None = None

    for chunk in stream:
        raw_chunk = response_to_dict(chunk)
        raw_chunks.append(raw_chunk)
        response_id = str(raw_chunk.get("id") or response_id)
        returned_model = str(raw_chunk.get("model") or returned_model)
        created = int(raw_chunk.get("created") or created)
        if raw_chunk.get("usage") is not None:
            usage = raw_chunk["usage"]
        choices = getattr(chunk, "choices", None) or []
        if not choices:
            continue
        choice = choices[0]
        delta = getattr(choice, "delta", None)
        content = getattr(delta, "content", None) if delta is not None else None
        if isinstance(content, str):
            content_parts.append(content)
        reasoning = (
            getattr(delta, "reasoning_content", None) if delta is not None else None
        )
        if isinstance(reasoning, str):
            reasoning_parts.append(reasoning)
        if getattr(choice, "finish_reason", None) is not None:
            finish_reason = str(choice.finish_reason)

    output_text = "".join(content_parts)
    raw_response = {
        "id": response_id,
        "object": "chat.completion.stream.aggregate",
        "created": created,
        "model": returned_model,
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": output_text,
                    "reasoning_content": "".join(reasoning_parts) or None,
                },
                "finish_reason": finish_reason,
            }
        ],
        "usage": usage,
        "stream": True,
        "stream_chunk_count": len(raw_chunks),
        "stream_chunks": raw_chunks,
    }
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=output_text),
                finish_reason=finish_reason,
            )
        ],
        model_dump=lambda mode=None: raw_response,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="按统一协议执行每模型、每任务的多次独立单轮生成。"
    )
    parser.add_argument("--prompt", required=True, type=Path, help="渲染后的完整提示词")
    parser.add_argument("--task-id", required=True, help="任务标识")
    parser.add_argument("--op-name", required=True, help="模型输出协议中的算子目录名")
    parser.add_argument("--protocol", type=Path, default=DEFAULT_PROTOCOL, help="实验协议 YAML")
    parser.add_argument("--experiment-id", help="实验批次名；省略时自动使用时间戳")
    parser.add_argument(
        "--model",
        help="显式指定模型 ID；省略时使用 runs/selected_model.json 中的模型",
    )
    parser.add_argument("--dry-run", action="store_true", help="只验证并展示计划，不调用模型")
    parser.add_argument(
        "--resume",
        action="store_true",
        help="恢复因传输失败中断的批次；已完成 trial 不重做",
    )
    return parser.parse_args()


def safe_name(value: str) -> str:
    cleaned = "".join(char if char.isalnum() or char in "-_" else "_" for char in value)
    if not cleaned:
        raise ValueError("名称不能为空")
    return cleaned


def load_protocol(path: Path) -> dict[str, Any]:
    protocol = yaml.safe_load(path.read_text(encoding="utf-8-sig"))
    if not isinstance(protocol, dict):
        raise ValueError("实验协议必须是 YAML 对象")
    allowed_tracks = {
        "single_turn_tool_free",
        "single_turn_tool_free_oneshot_interface",
        "single_turn_tool_free_oneshot_public_cann_reference",
        "single_turn_tool_free_universal_five_file",
    }
    if protocol.get("experiment", {}).get("track") not in allowed_tracks:
        raise ValueError(f"当前脚本只允许以下赛道: {sorted(allowed_tracks)}")
    if protocol.get("generation", {}).get("turns") != 1:
        raise ValueError("当前脚本只允许单轮生成")
    if protocol.get("generation", {}).get("tools") is not False:
        raise ValueError("裸基模实验必须关闭工具")
    trials = protocol.get("experiment", {}).get("trials_per_model_task")
    if not isinstance(trials, int) or trials < 1:
        raise ValueError("trials_per_model_task 必须是正整数")
    return protocol


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def main() -> None:
    args = parse_args()
    prompt_path = args.prompt.resolve()
    protocol_path = args.protocol.resolve()
    prompt = prompt_path.read_text(encoding="utf-8-sig")
    if not prompt.strip():
        raise ValueError("提示词文件为空")

    protocol = load_protocol(protocol_path)
    provider_config = load_config()
    model_id = args.model or load_selected_model()
    experiment_id = safe_name(args.experiment_id or timestamp())
    task_id = safe_name(args.task_id)
    model_dir_name = safe_name(model_id)
    trials = protocol["experiment"]["trials_per_model_task"]
    generation = protocol["generation"]
    request_extra_body = generation.get("extra_body")
    if request_extra_body is not None and not isinstance(request_extra_body, dict):
        raise ValueError("generation.extra_body 必须是 YAML 对象")
    request_control = protocol["request_control"]
    prompt_hash = sha256_text(prompt)
    protocol_hash = sha256_text(protocol_path.read_text(encoding="utf-8-sig"))
    experiment_dir = (
        RUNS_PATH
        / "experiments"
        / experiment_id
        / safe_name(provider_config["provider"])
        / model_dir_name
        / task_id
    )

    render_metadata_path = prompt_path.parent / "render_metadata.json"
    render_metadata: dict[str, Any] | None = None
    if render_metadata_path.is_file():
        render_metadata = json.loads(render_metadata_path.read_text(encoding="utf-8-sig"))
        if render_metadata.get("prompt_sha256") != prompt_hash:
            raise ValueError("渲染元数据中的 Prompt 哈希与实际提示词不一致")

    task_input = protocol.get("task_input", {})
    if task_input.get("platform_snapshot") is True:
        if render_metadata is None:
            raise ValueError("当前协议要求平台快照，但Prompt旁缺少render_metadata.json")
        if not render_metadata.get("platform_snapshot_sha256"):
            raise ValueError("当前协议要求平台快照，但渲染元数据没有快照哈希")
        if render_metadata.get("platform_runtime_source") != "benchsite_job_setup_info":
            raise ValueError("当前协议要求由真实平台job核验运行时版本，不能使用静态平台配置")
    required_template_version = task_input.get("prompt_template_version")
    if required_template_version:
        actual_template_version = (
            render_metadata.get("prompt_template_version") if render_metadata else None
        )
        if actual_template_version != required_template_version:
            raise ValueError(
                f"Prompt模板版本不符合协议: expected={required_template_version}, "
                f"actual={actual_template_version}"
            )

    plan = {
        "experiment_id": experiment_id,
        "provider": provider_config["provider"],
        "model": model_id,
        "task_id": task_id,
        "op_name": args.op_name,
        "track": protocol["experiment"]["track"],
        "trial_count": trials,
        "prompt_sha256": prompt_hash,
        "protocol_sha256": protocol_hash,
        "temperature": generation["temperature"],
        "max_output_tokens": generation["max_output_tokens"],
        "stream": bool(generation.get("stream", False)),
        "extra_body": request_extra_body,
        "network_retries": request_control["network_retries"],
        "content_retries": generation["content_retries"],
        "platform_profile": (
            render_metadata.get("platform_profile") if render_metadata else None
        ),
        "prompt_template_version": (
            render_metadata.get("prompt_template_version") if render_metadata else None
        ),
        "target_hardware": (
            render_metadata.get("platform", {}).get("target_hardware")
            if render_metadata
            else None
        ),
        "benchmark_slug": (
            render_metadata.get("platform", {}).get("benchmark_slug")
            if render_metadata
            else None
        ),
        "benchmark_version": (
            render_metadata.get("platform", {}).get("benchmark_version")
            if render_metadata
            else None
        ),
        "platform_snapshot_sha256": (
            render_metadata.get("platform_snapshot_sha256") if render_metadata else None
        ),
        "platform_runtime_source": (
            render_metadata.get("platform_runtime_source") if render_metadata else None
        ),
        "output_directory": str(experiment_dir),
    }
    if args.dry_run:
        print(yaml.safe_dump(plan, allow_unicode=True, sort_keys=False))
        return

    manifest_path = experiment_dir / "experiment_manifest.json"
    if experiment_dir.exists():
        if not args.resume:
            raise FileExistsError(f"实验目录已存在；如需恢复传输失败请加 --resume: {experiment_dir}")
        if not manifest_path.is_file():
            raise FileNotFoundError(f"现有实验目录缺少 manifest: {manifest_path}")
        existing_manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
        audit_fields = (
            "experiment_id",
            "provider",
            "model",
            "task_id",
            "op_name",
            "track",
            "trial_count",
            "prompt_sha256",
            "protocol_sha256",
            "temperature",
            "max_output_tokens",
            "stream",
            "extra_body",
            "platform_snapshot_sha256",
            "platform_runtime_source",
        )
        mismatches = {
            field: {"existing": existing_manifest.get(field), "current": plan.get(field)}
            for field in audit_fields
            if existing_manifest.get(field) != plan.get(field)
        }
        if mismatches:
            raise ValueError(f"恢复参数与原批次不一致: {mismatches}")
    else:
        experiment_dir.mkdir(parents=True, exist_ok=False)
    write_json(manifest_path, {**plan, "status": "running", "resumed": bool(args.resume)})
    client = create_client()
    completed = 0

    for trial_number in range(1, trials + 1):
        trial_dir = experiment_dir / f"trial_{trial_number:03d}"
        if trial_dir.exists():
            status_path = trial_dir / "status.json"
            existing_status = (
                json.loads(status_path.read_text(encoding="utf-8-sig"))
                if status_path.is_file()
                else {}
            )
            if existing_status.get("status") == "completed":
                completed += 1
                print(f"trial {trial_number:03d}/{trials} 已完成，恢复时跳过")
                continue
            if not args.resume:
                raise FileExistsError(f"trial 目录已存在: {trial_dir}")
            archive_number = 1
            while True:
                archive_dir = experiment_dir / (
                    f"trial_{trial_number:03d}_transport_failure_{archive_number:03d}"
                )
                if not archive_dir.exists():
                    break
                archive_number += 1
            trial_dir.rename(archive_dir)
            print(f"归档传输失败 trial: {archive_dir.name}")
        trial_dir.mkdir(parents=True, exist_ok=False)
        (trial_dir / "rendered_prompt.txt").write_text(prompt, encoding="utf-8")
        if render_metadata is not None:
            write_json(trial_dir / "render_metadata.json", render_metadata)
        request_metadata = {
            "experiment_id": experiment_id,
            "trial_number": trial_number,
            "provider": provider_config["provider"],
            "base_url": provider_config["base_url"],
            "model": model_id,
            "messages": [{"role": "user", "content_sha256": prompt_hash}],
            "temperature": generation["temperature"],
            "max_tokens": generation["max_output_tokens"],
            "stream": bool(generation.get("stream", False)),
            "extra_body": request_extra_body,
            "prompt_source": str(prompt_path),
            "protocol_source": str(protocol_path),
            "protocol_sha256": protocol_hash,
            "started_at": timestamp(),
        }
        write_json(trial_dir / "request_metadata.json", request_metadata)

        attempts: list[dict[str, Any]] = []
        response = None
        start_clock = time.perf_counter()
        max_attempts = int(request_control["network_retries"]) + 1
        for attempt_number in range(1, max_attempts + 1):
            attempt_start = time.perf_counter()
            try:
                if generation.get("stream", False):
                    response = create_streaming_response(
                        client,
                        model=model_id,
                        prompt=prompt,
                        temperature=generation["temperature"],
                        max_tokens=generation["max_output_tokens"],
                        extra_body=request_extra_body,
                    )
                else:
                    response = client.chat.completions.create(
                        model=model_id,
                        messages=[{"role": "user", "content": prompt}],
                        temperature=generation["temperature"],
                        max_tokens=generation["max_output_tokens"],
                        extra_body=request_extra_body,
                    )
                if not response_has_content(response):
                    malformed = response_to_dict(response)
                    write_json(
                        trial_dir / f"malformed_response_attempt_{attempt_number:03d}.json",
                        malformed,
                    )
                    attempts.append(
                        {
                            "attempt_number": attempt_number,
                            "status": "retryable_malformed_provider_response",
                            "elapsed_seconds": time.perf_counter() - attempt_start,
                        }
                    )
                    response = None
                    if attempt_number == max_attempts:
                        write_json(
                            trial_dir / "status.json",
                            {
                                "status": "request_failed",
                                "failure_kind": "malformed_provider_response",
                                "elapsed_seconds": time.perf_counter() - start_clock,
                                "attempts": attempts,
                                "content_retry_count": 0,
                            },
                        )
                        raise MalformedProviderResponse(
                            "模型供应端连续返回缺少 choices/content 的异常响应"
                        )
                    time.sleep(5 * attempt_number)
                    continue
                attempts.append(
                    {
                        "attempt_number": attempt_number,
                        "status": "completed",
                        "elapsed_seconds": time.perf_counter() - attempt_start,
                    }
                )
                break
            except RETRYABLE_ERRORS as error:
                attempts.append(
                    {
                        "attempt_number": attempt_number,
                        "status": "retryable_transport_failure",
                        "error_type": type(error).__name__,
                        "error": str(error),
                        "elapsed_seconds": time.perf_counter() - attempt_start,
                    }
                )
                if attempt_number == max_attempts:
                    write_json(
                        trial_dir / "status.json",
                        {
                            "status": "request_failed",
                            "elapsed_seconds": time.perf_counter() - start_clock,
                            "attempts": attempts,
                            "content_retry_count": 0,
                        },
                    )
                    raise
                time.sleep(retry_delay_seconds(error, attempt_number))
            except MalformedProviderResponse:
                raise
            except Exception as error:
                attempts.append(
                    {
                        "attempt_number": attempt_number,
                        "status": "non_retryable_failure",
                        "error_type": type(error).__name__,
                        "error": str(error),
                        "elapsed_seconds": time.perf_counter() - attempt_start,
                    }
                )
                write_json(
                    trial_dir / "status.json",
                    {
                        "status": "request_failed",
                        "elapsed_seconds": time.perf_counter() - start_clock,
                        "attempts": attempts,
                        "content_retry_count": 0,
                    },
                )
                raise

        if response is None:
            raise RuntimeError("模型请求未返回响应")

        raw = response_to_dict(response)
        output_text = response.choices[0].message.content or ""
        (trial_dir / "model_output.txt").write_text(output_text, encoding="utf-8")
        write_json(trial_dir / "raw_response.json", raw)
        parse_report = parse_run(trial_dir, args.op_name)
        write_json(
            trial_dir / "status.json",
            {
                "status": "completed",
                "requested_model": model_id,
                "returned_model": raw.get("model"),
                "finish_reason": response.choices[0].finish_reason,
                "elapsed_seconds": time.perf_counter() - start_clock,
                "attempts": attempts,
                "network_retry_count": len(attempts) - 1,
                "content_retry_count": 0,
                "output_characters": len(output_text),
                "recoverable_parse_pass": parse_report["recoverable_parse_pass"],
                "strict_protocol_pass": parse_report["strict_protocol_pass"],
                "format_recovered": parse_report.get("format_recovered", False),
                "format_recovery_reasons": parse_report.get(
                    "format_recovery_reasons", []
                ),
            },
        )
        completed += 1
        print(
            f"trial {trial_number:03d}/{trials} 完成："
            f"finish_reason={response.choices[0].finish_reason}, "
            f"parse={parse_report['recoverable_parse_pass']}"
        )

    write_json(
        experiment_dir / "experiment_manifest.json",
        {**plan, "status": "generation_completed", "completed_trials": completed},
    )
    print(f"{trials} 次独立生成完成，结果目录: {experiment_dir}")


if __name__ == "__main__":
    main()
