from __future__ import annotations

import argparse
import re
from pathlib import Path, PurePosixPath
from typing import Any

from modelscope_common import write_json


BLOCK_PATTERN = re.compile(
    r"^=== FILE: (?P<path>[^\r\n]+) ===\r?\n"
    r"(?P<content>.*?)\r?\n"
    r"=== END FILE ===$",
    re.MULTILINE | re.DOTALL,
)

CHANGE_SUMMARY_PATTERN = re.compile(
    r"^=== CHANGE SUMMARY ===\r?\n(?P<content>.*?)\r?\n=== END CHANGE SUMMARY ===$",
    re.MULTILINE | re.DOTALL,
)

# The model-facing format is intentionally simple, but the source files are
# the object being evaluated.  These recovery patterns tolerate harmless
# whitespace, an inline END marker, and ordinary prose around the blocks.
# They do not infer missing source or accept an unclosed file block.
RECOVERABLE_FILE_START_PATTERN = re.compile(
    r"^[ \t]*===[ \t]*FILE[ \t]*:[ \t]*"
    r"(?P<path>[^\r\n]+?)[ \t]*===[ \t]*$",
    re.MULTILINE | re.IGNORECASE,
)
RECOVERABLE_FILE_END_PATTERN = re.compile(
    r"===[ \t]*END[ \t]+FILE[ \t]*===",
    re.IGNORECASE,
)
RECOVERABLE_CHANGE_SUMMARY_PATTERN = re.compile(
    r"^[ \t]*===[ \t]*CHANGE[ \t]+SUMMARY[ \t]*===[ \t]*\r?\n"
    r"(?P<content>.*?)(?:\r?\n|[ \t]*)"
    r"===[ \t]*END[ \t]+CHANGE[ \t]+SUMMARY[ \t]*===(?=\r?$)",
    re.MULTILINE | re.DOTALL | re.IGNORECASE,
)

DEFAULT_CHANGE_SUMMARY_LIMIT = 300


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="机械解析模型输出中的文件块。")
    parser.add_argument("--run-dir", required=True, type=Path, help="单次生成结果目录")
    parser.add_argument("--op-name", required=True, help="算子目录名")
    return parser.parse_args()


def strip_one_outer_fence(text: str) -> tuple[str, bool, str | None]:
    stripped = text.strip()
    lines = stripped.splitlines()
    if len(lines) >= 2 and lines[0].startswith("```") and lines[-1].strip() == "```":
        return "\n".join(lines[1:-1]).strip(), True, lines[0].strip()
    return stripped, False, None


def safe_output_path(root: Path, relative: str) -> Path:
    posix_path = PurePosixPath(relative)
    if posix_path.is_absolute() or ".." in posix_path.parts:
        raise ValueError(f"不安全的输出路径: {relative}")
    return root.joinpath(*posix_path.parts)


def normalize_output_path(value: str) -> str:
    """Normalize harmless presentation differences without changing scope."""

    normalized = value.strip()
    if len(normalized) >= 2 and normalized[0] == normalized[-1] and normalized[0] in "`'\"":
        normalized = normalized[1:-1].strip()
    if normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized.replace("\\", "/")


def expected_paths_for_op(op_name: str) -> list[str]:
    return [
        f"csrc/ops/{op_name}/op_kernel/{op_name}_kernel.cpp",
        f"csrc/ops/{op_name}/op_kernel/{op_name}_launch.h",
        f"csrc/ops/{op_name}/op_plugin/{op_name}_plugin.cpp",
        f"csrc/ops/{op_name}/CMakeLists.txt",
        "cann_bench/__init__.py.append",
    ]


def extract_recoverable_file_blocks(text: str) -> tuple[list[dict[str, Any]], list[str]]:
    """Extract complete file blocks while ignoring non-source text around them.

    A block still needs both a recognizable FILE header and an END FILE marker.
    If the next FILE header arrives first, the preceding block is considered
    unclosed rather than guessing where its source ends.
    """

    starts = list(RECOVERABLE_FILE_START_PATTERN.finditer(text))
    blocks: list[dict[str, Any]] = []
    unclosed_paths: list[str] = []
    for index, start in enumerate(starts):
        next_start = starts[index + 1].start() if index + 1 < len(starts) else len(text)
        end = RECOVERABLE_FILE_END_PATTERN.search(text, start.end(), next_start)
        raw_path = start.group("path").strip()
        path = normalize_output_path(raw_path)
        if end is None:
            unclosed_paths.append(path)
            continue
        blocks.append(
            {
                "path": path,
                "raw_path": raw_path,
                "content": text[start.end() : end.start()].strip("\r\n"),
                "start": start.start(),
                "end": end.end(),
            }
        )
    return blocks, unclosed_paths


def residual_outside_blocks(text: str, blocks: list[dict[str, Any]]) -> str:
    parts: list[str] = []
    cursor = 0
    for block in sorted(blocks, key=lambda item: int(item["start"])):
        parts.append(text[cursor : int(block["start"])])
        cursor = int(block["end"])
    parts.append(text[cursor:])
    return "".join(parts).strip()


def extract_change_summary(
    text: str, limit: int = DEFAULT_CHANGE_SUMMARY_LIMIT
) -> tuple[dict[str, Any], str]:
    """从模型输出中提取 CHANGE SUMMARY 块。

    返回 (报告, 去掉该块后的剩余文本)。该块不是第六个文件：
    缺失或超长只记录格式违规，不影响五文件解析与提交。
    """
    match = CHANGE_SUMMARY_PATTERN.search(text)
    marker_recovered = False
    if match is None:
        match = RECOVERABLE_CHANGE_SUMMARY_PATTERN.search(text)
        marker_recovered = match is not None
    if match is None:
        return (
            {
                "present": False,
                "characters": 0,
                "truncated": False,
                "summary": None,
                "summary_truncated": None,
                "violation": "missing",
                "marker_recovered": False,
            },
            text,
        )
    summary_raw = match.group("content").strip()
    report: dict[str, Any] = {
        "present": True,
        "characters": len(summary_raw),
        "truncated": len(summary_raw) > limit,
        "summary": summary_raw,
        "summary_truncated": (
            summary_raw[:limit].rstrip()
            + f"\n...[truncated {len(summary_raw) - limit} characters by fixed harness rule]"
            if len(summary_raw) > limit
            else summary_raw
        ),
        "violation": "too_long" if len(summary_raw) > limit else None,
        "marker_recovered": marker_recovered,
    }
    remaining = text[: match.start()] + text[match.end() :]
    return report, remaining


def parse_run(run_dir: Path, op_name: str) -> dict[str, Any]:
    run_dir = run_dir.resolve()
    output_path = run_dir / "model_output.txt"
    raw_output = output_path.read_text(encoding="utf-8-sig")
    parse_text, had_outer_fence, fence_header = strip_one_outer_fence(raw_output)

    change_summary_limit = DEFAULT_CHANGE_SUMMARY_LIMIT
    change_summary, parse_text = extract_change_summary(parse_text, change_summary_limit)
    write_json(run_dir / "change_summary.json", change_summary)

    expected_paths = expected_paths_for_op(op_name)
    blocks, unclosed_file_paths = extract_recoverable_file_blocks(parse_text)
    paths = [str(block["path"]) for block in blocks]
    raw_paths = [str(block["raw_path"]) for block in blocks]
    residual_text = residual_outside_blocks(parse_text, blocks)

    strict_matches = list(BLOCK_PATTERN.finditer(parse_text))
    strict_paths = [normalize_output_path(match.group("path")) for match in strict_matches]
    strict_block_protocol_pass = (
        len(strict_matches) == len(expected_paths)
        and strict_paths == expected_paths
        and all(match.group("content").strip() for match in strict_matches)
    )

    duplicate_paths = sorted({path for path in paths if paths.count(path) > 1})
    missing_paths = [path for path in expected_paths if path not in paths]
    unexpected_paths = [path for path in paths if path not in expected_paths]
    order_matches = paths == expected_paths
    all_nonempty = bool(blocks) and all(str(block["content"]).strip() for block in blocks)
    recoverable = (
        len(blocks) == len(expected_paths)
        and not duplicate_paths
        and not missing_paths
        and not unexpected_paths
        and all_nonempty
        and not unclosed_file_paths
    )

    format_recovery_reasons: list[str] = []
    if change_summary.get("marker_recovered"):
        format_recovery_reasons.append("change_summary_marker_recovered")
    if change_summary.get("violation") == "missing":
        format_recovery_reasons.append("change_summary_missing")
    elif change_summary.get("violation") == "too_long":
        format_recovery_reasons.append("change_summary_too_long")
    if not strict_block_protocol_pass:
        format_recovery_reasons.append("file_block_markers_recovered")
    if recoverable and not order_matches:
        format_recovery_reasons.append("file_block_order_recovered")
    if residual_text:
        format_recovery_reasons.append("residual_text_ignored")
    if had_outer_fence:
        format_recovery_reasons.append("outer_markdown_fence_stripped")

    parsed_root = run_dir / "parsed"
    if recoverable:
        content_by_path = {str(block["path"]): str(block["content"]) for block in blocks}
        for relative in expected_paths:
            destination = safe_output_path(parsed_root, relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(content_by_path[relative].rstrip() + "\n", encoding="utf-8")

    content_by_path = {str(block["path"]): str(block["content"]) for block in blocks}
    internal_fence_paths = sorted(
        path
        for path, content in content_by_path.items()
        if re.search(r"(?m)^\s*```", content)
    )
    kernel = content_by_path.get(expected_paths[0], "")
    launch = content_by_path.get(expected_paths[1], "")
    plugin = content_by_path.get(expected_paths[2], "")
    cmake = content_by_path.get(expected_paths[3], "")
    python_append = content_by_path.get(expected_paths[4], "")
    static_contract_checks = {
        "kernel_includes_kernel_operator": '#include "kernel_operator.h"' in kernel,
        "kernel_exports_extern_c": 'extern "C"' in kernel,
        "launch_has_include_guard": "#ifndef" in launch and "#define" in launch and "#endif" in launch,
        "launch_declares_extern_c": 'extern "C"' in launch,
        "plugin_registers_schema": "TORCH_LIBRARY_FRAGMENT(cann_bench" in plugin,
        "plugin_registers_meta": "TORCH_LIBRARY_IMPL(cann_bench, Meta" in plugin,
        "plugin_registers_privateuse1": "TORCH_LIBRARY_IMPL(cann_bench, PrivateUse1" in plugin,
        "cmake_registers_direct_launch": "register_direct_launch_op(" in cmake,
        "python_append_calls_torch_ops": f"torch.ops.cann_bench.{op_name}" in python_append,
        "contains_internal_markdown_fence": bool(internal_fence_paths),
        "contains_todo": bool(
            re.search(r"\bTODO\b", "\n".join(content_by_path.values()))
        ),
    }
    if internal_fence_paths:
        format_recovery_reasons.append("internal_markdown_fence_present")

    format_recovered = recoverable and bool(format_recovery_reasons)
    strict_protocol_pass = (
        recoverable
        and strict_block_protocol_pass
        and order_matches
        and not residual_text
        and not had_outer_fence
        and not internal_fence_paths
        and bool(change_summary.get("present"))
        and not bool(change_summary.get("marker_recovered"))
        and change_summary.get("violation") is None
    )

    report = {
        "run_dir": str(run_dir),
        "model_output": str(output_path),
        "outer_markdown_fence": had_outer_fence,
        "outer_fence_header": fence_header,
        "change_summary": change_summary,
        "file_block_count": len(blocks),
        "paths": paths,
        "raw_paths": raw_paths,
        "expected_paths": expected_paths,
        "duplicate_paths": duplicate_paths,
        "missing_paths": missing_paths,
        "unexpected_paths": unexpected_paths,
        "order_matches": order_matches,
        "all_files_nonempty": all_nonempty,
        "residual_text": residual_text,
        "recoverable_parse_pass": recoverable,
        "strict_protocol_pass": strict_protocol_pass,
        "format_recovered": format_recovered,
        "format_recovery_reasons": format_recovery_reasons,
        "unclosed_file_paths": unclosed_file_paths,
        "strict_block_protocol_pass": strict_block_protocol_pass,
        "internal_markdown_fence_paths": internal_fence_paths,
        "parsed_root": str(parsed_root) if recoverable else None,
        "static_contract_checks": static_contract_checks,
    }
    write_json(run_dir / "parse_report.json", report)
    return report


def main() -> None:
    args = parse_args()
    report = parse_run(args.run_dir, args.op_name)
    print(f"文件块: {report['file_block_count']} / {len(report['expected_paths'])}")
    print(f"路径与顺序正确: {'是' if report['order_matches'] else '否'}")
    print(f"外层 Markdown 围栏: {'有' if report['outer_markdown_fence'] else '无'}")
    print(f"可恢复解析: {'通过' if report['recoverable_parse_pass'] else '失败'}")
    print(f"严格格式协议: {'通过' if report['strict_protocol_pass'] else '失败'}")
    print(f"格式恢复: {'是' if report['format_recovered'] else '否'}")
    print(f"解析报告: {Path(report['run_dir']) / 'parse_report.json'}")
    if report["recoverable_parse_pass"]:
        print(f"拆分文件目录: {report['parsed_root']}")
    else:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
