from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from openai import OpenAI


ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG_PATH = ROOT / "configs" / "provider_active.json"
TOKEN_PATH = ROOT / ".env.local"
RUNS_PATH = ROOT / "runs"


def load_config() -> dict[str, Any]:
    configured_path = os.environ.get("MODEL_EVAL_CONFIG", "").strip()
    config_path = Path(configured_path).expanduser() if configured_path else DEFAULT_CONFIG_PATH
    if not config_path.is_absolute():
        config_path = ROOT / config_path
    config = json.loads(config_path.resolve().read_text(encoding="utf-8"))
    config["config_path"] = str(config_path.resolve())
    return config


def load_token(config: dict[str, Any] | None = None) -> str:
    config = config or load_config()
    token_env = str(config.get("api_key_env") or "MODELSCOPE_SDK_TOKEN")
    token = os.environ.get(token_env, "").strip()
    if token:
        return token

    if TOKEN_PATH.exists():
        for raw_line in TOKEN_PATH.read_text(encoding="utf-8-sig").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            if key.strip() == token_env:
                token = value.strip().strip('"').strip("'")
                if token and not token.startswith("replace_with_your_"):
                    return token

    raise RuntimeError(
        f"未找到 {token_env}。请只在 model_eval/.env.local 中填写 "
        f"{token_env}=你的API_Key，不要把密钥发到聊天中。"
    )


def create_client() -> OpenAI:
    config = load_config()
    if config.get("api_protocol") == "anthropic":
        from minimax_anthropic_client import MiniMaxAnthropicClient

        return MiniMaxAnthropicClient(
            api_key=load_token(config),
            base_url=config["base_url"],
            timeout=3600.0,
        )
    return OpenAI(
        api_key=load_token(config),
        base_url=config["base_url"],
        timeout=3600.0,
        max_retries=0,
    )


def timestamp() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%z")


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def response_to_dict(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    raise TypeError(f"无法序列化响应类型: {type(value)!r}")


def list_live_models(client: OpenAI) -> list[dict[str, Any]]:
    page = client.models.list()
    return [response_to_dict(item) for item in page.data]


def choose_preferred_model(
    model_records: list[dict[str, Any]], config: dict[str, Any]
) -> str:
    available = {str(record.get("id")) for record in model_records}
    for model_id in config["preferred_models"]:
        if model_id in available:
            return model_id

    coder_models = sorted(
        model_id
        for model_id in available
        if "coder" in model_id.lower() or "code" in model_id.lower()
    )
    preview = "\n".join(f"  - {model_id}" for model_id in coder_models[:30])
    raise RuntimeError(
        "当前 ModelScope 在线模型列表中没有配置的首选模型。"
        + (f"\n当前可见的代码模型包括:\n{preview}" if preview else "")
    )


def load_selected_model() -> str:
    selected_path = RUNS_PATH / "selected_model.json"
    if not selected_path.exists():
        raise RuntimeError("尚未选择模型，请先运行 list_models.py。")
    selected = json.loads(selected_path.read_text(encoding="utf-8"))
    return str(selected["model_id"])
