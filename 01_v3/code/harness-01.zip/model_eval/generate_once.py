from __future__ import annotations

import argparse
import hashlib
import time
from pathlib import Path

from modelscope_common import (
    RUNS_PATH,
    create_client,
    load_config,
    load_selected_model,
    response_to_dict,
    timestamp,
    write_json,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="以单轮、无工具方式调用当前选中的 ModelScope 模型。"
    )
    parser.add_argument("--prompt", required=True, type=Path, help="完整提示词文本路径")
    parser.add_argument("--task-id", required=True, help="任务标识，用于结果目录")
    return parser.parse_args()


def safe_task_id(value: str) -> str:
    cleaned = "".join(char if char.isalnum() or char in "-_" else "_" for char in value)
    if not cleaned:
        raise ValueError("task-id 不能为空")
    return cleaned


def main() -> None:
    args = parse_args()
    prompt_path = args.prompt.resolve()
    prompt = prompt_path.read_text(encoding="utf-8")
    if not prompt.strip():
        raise ValueError("提示词文件为空")

    config = load_config()
    model_id = load_selected_model()
    generation = config["generation"]
    started_at = timestamp()
    run_dir = RUNS_PATH / "generations" / safe_task_id(args.task_id) / started_at
    run_dir.mkdir(parents=True, exist_ok=False)

    rendered_prompt_path = run_dir / "rendered_prompt.txt"
    rendered_prompt_path.write_text(prompt, encoding="utf-8")
    request_record = {
        "provider": config["provider"],
        "base_url": config["base_url"],
        "model": model_id,
        "messages": [{"role": "user", "content_sha256": hashlib.sha256(prompt.encode()).hexdigest()}],
        "temperature": generation["temperature"],
        "max_tokens": generation["max_tokens"],
        "protocol": config["protocol"],
        "prompt_source": str(prompt_path),
        "started_at": started_at,
    }
    write_json(run_dir / "request_metadata.json", request_record)

    client = create_client()
    start_clock = time.perf_counter()
    try:
        response = client.chat.completions.create(
            model=model_id,
            messages=[{"role": "user", "content": prompt}],
            temperature=generation["temperature"],
            max_tokens=generation["max_tokens"],
        )
    except Exception as error:
        write_json(
            run_dir / "status.json",
            {
                "status": "request_failed",
                "error_type": type(error).__name__,
                "error": str(error),
                "elapsed_seconds": time.perf_counter() - start_clock,
                "content_retry_count": 0,
            },
        )
        raise

    elapsed = time.perf_counter() - start_clock
    raw = response_to_dict(response)
    output_text = response.choices[0].message.content or ""
    (run_dir / "model_output.txt").write_text(output_text, encoding="utf-8")
    write_json(run_dir / "raw_response.json", raw)
    write_json(
        run_dir / "status.json",
        {
            "status": "completed",
            "requested_model": model_id,
            "returned_model": raw.get("model"),
            "finish_reason": response.choices[0].finish_reason,
            "elapsed_seconds": elapsed,
            "content_retry_count": 0,
            "output_characters": len(output_text),
        },
    )

    print(f"模型生成完成: {model_id}")
    print(f"结束原因: {response.choices[0].finish_reason}")
    print(f"输出字符数: {len(output_text)}")
    print(f"结果目录: {run_dir}")


if __name__ == "__main__":
    main()
