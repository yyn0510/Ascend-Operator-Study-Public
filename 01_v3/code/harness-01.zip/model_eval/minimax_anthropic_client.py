from __future__ import annotations

import json
import time
from types import SimpleNamespace
from typing import Any, Iterator

import httpx


def _text_blocks(value: Any) -> list[dict[str, str]]:
    if isinstance(value, str):
        return [{"type": "text", "text": value}]
    if isinstance(value, list):
        blocks: list[dict[str, str]] = []
        for block in value:
            if isinstance(block, str):
                blocks.append({"type": "text", "text": block})
            elif isinstance(block, dict) and block.get("type") == "text":
                blocks.append({"type": "text", "text": str(block.get("text", ""))})
        return blocks
    return [{"type": "text", "text": str(value)}]


class MiniMaxAnthropicChunk:
    """Small OpenAI-shaped stream chunk consumed by the existing harness."""

    def __init__(
        self,
        *,
        response_id: str,
        model: str,
        created: int,
        content: str | None = None,
        reasoning: str | None = None,
        finish_reason: str | None = None,
        usage: dict[str, Any] | None = None,
    ) -> None:
        self.id = response_id
        self.object = "chat.completion.chunk"
        self.created = created
        self.model = model
        self.system_fingerprint = None
        self.usage = usage
        delta: dict[str, Any] = {}
        if content is not None:
            delta["content"] = content
        if reasoning is not None:
            delta["reasoning_content"] = reasoning
        if delta or finish_reason is not None:
            self.choices = [
                SimpleNamespace(
                    index=0,
                    delta=SimpleNamespace(**delta),
                    finish_reason=finish_reason,
                )
            ]
        else:
            self.choices = []

    def model_dump(self, mode: str = "json") -> dict[str, Any]:
        choices: list[dict[str, Any]] = []
        for choice in self.choices:
            delta = {
                key: value
                for key in ("content", "reasoning_content")
                if (value := getattr(choice.delta, key, None)) is not None
            }
            choices.append(
                {
                    "index": choice.index,
                    "delta": delta,
                    "finish_reason": choice.finish_reason,
                }
            )
        return {
            "id": self.id,
            "object": self.object,
            "created": self.created,
            "model": self.model,
            "system_fingerprint": self.system_fingerprint,
            "choices": choices,
            "usage": self.usage,
        }


class MiniMaxAnthropicResponse:
    def __init__(
        self,
        *,
        response_id: str,
        model: str,
        content: str,
        reasoning: str,
        finish_reason: str | None,
        usage: dict[str, Any] | None,
    ) -> None:
        self.id = response_id
        self.object = "chat.completion"
        self.created = int(time.time())
        self.model = model
        self.system_fingerprint = None
        self.choices = [
            SimpleNamespace(
                index=0,
                message=SimpleNamespace(
                    role="assistant",
                    content=content,
                    reasoning_content=reasoning or None,
                ),
                finish_reason=finish_reason,
            )
        ]
        self.usage = usage

    def model_dump(self, mode: str = "json") -> dict[str, Any]:
        choice = self.choices[0]
        return {
            "id": self.id,
            "object": self.object,
            "created": self.created,
            "model": self.model,
            "system_fingerprint": self.system_fingerprint,
            "choices": [
                {
                    "index": choice.index,
                    "message": {
                        "role": choice.message.role,
                        "content": choice.message.content,
                        "reasoning_content": choice.message.reasoning_content,
                    },
                    "finish_reason": choice.finish_reason,
                }
            ],
            "usage": self.usage,
        }


class _ModelsResource:
    def __init__(self, owner: "MiniMaxAnthropicClient") -> None:
        self._owner = owner

    def list(self) -> Any:
        response = self._owner._http.get(
            f"{self._owner.base_url}/v1/models",
            headers=self._owner._headers(accept="application/json"),
        )
        response.raise_for_status()
        payload = response.json()
        records = payload.get("data", []) if isinstance(payload, dict) else []
        return SimpleNamespace(data=[
            SimpleNamespace(
                id=str(record.get("id")),
                object=record.get("object", "model"),
                created=record.get("created"),
                owned_by=record.get("owned_by", "minimax"),
                model_dump=lambda mode="json", record=record: record,
            )
            for record in records
        ])


class MiniMaxAnthropicClient:
    """Anthropic-compatible MiniMax client with the harness's chat interface."""

    def __init__(self, *, api_key: str, base_url: str, timeout: float = 3600.0) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = httpx.Timeout(timeout)
        self._http = httpx.Client(timeout=self.timeout)
        self.chat = SimpleNamespace(
            completions=SimpleNamespace(create=self._create_completion)
        )
        self.models = _ModelsResource(self)

    def _headers(self, *, accept: str) -> dict[str, str]:
        return {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
            "accept": accept,
        }

    @staticmethod
    def _convert_messages(messages: list[dict[str, Any]]) -> tuple[str | None, list[dict[str, Any]]]:
        system_parts: list[str] = []
        converted: list[dict[str, Any]] = []
        for message in messages:
            role = str(message.get("role", "user"))
            content = message.get("content", "")
            if role == "system":
                system_parts.extend(
                    block["text"] for block in _text_blocks(content) if block["text"]
                )
                continue
            if role not in {"user", "assistant"}:
                role = "user"
            converted.append({"role": role, "content": _text_blocks(content)})
        return ("\n\n".join(system_parts) or None), converted

    def _request_body(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        temperature: float | None,
        token_limit: int | None,
        extra_body: dict[str, Any] | None,
        stream: bool,
    ) -> dict[str, Any]:
        system, converted = self._convert_messages(messages)
        body: dict[str, Any] = {
            "model": model,
            "messages": converted,
            "max_tokens": int(token_limit or 131072),
            "stream": stream,
        }
        if system is not None:
            body["system"] = system
        if temperature is not None:
            body["temperature"] = temperature
        extras = extra_body or {}
        if "top_p" in extras:
            body["top_p"] = extras["top_p"]
        if "thinking" in extras:
            body["thinking"] = extras["thinking"]
        for key in ("service_tier", "stop_sequences"):
            if key in extras:
                body[key] = extras[key]
        return body

    def _create_completion(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        temperature: float | None = None,
        max_tokens: int | None = None,
        max_completion_tokens: int | None = None,
        stream: bool = False,
        extra_body: dict[str, Any] | None = None,
        **_: Any,
    ) -> Any:
        body = self._request_body(
            model=model,
            messages=messages,
            temperature=temperature,
            token_limit=max_tokens if max_tokens is not None else max_completion_tokens,
            extra_body=extra_body,
            stream=stream,
        )
        if stream:
            return self._stream(body)
        response = self._http.post(
            f"{self.base_url}/v1/messages",
            headers=self._headers(accept="application/json"),
            json=body,
        )
        response.raise_for_status()
        payload = response.json()
        content_parts: list[str] = []
        reasoning_parts: list[str] = []
        for block in payload.get("content", []):
            if block.get("type") == "text":
                content_parts.append(str(block.get("text", "")))
            elif block.get("type") == "thinking":
                reasoning_parts.append(str(block.get("thinking", "")))
        usage = payload.get("usage")
        return MiniMaxAnthropicResponse(
            response_id=str(payload.get("id", "")),
            model=str(payload.get("model", model)),
            content="".join(content_parts),
            reasoning="".join(reasoning_parts),
            finish_reason=payload.get("stop_reason"),
            usage=usage if isinstance(usage, dict) else None,
        )

    def _stream(self, body: dict[str, Any]) -> Iterator[MiniMaxAnthropicChunk]:
        response_id = ""
        model = str(body["model"])
        created = int(time.time())
        usage: dict[str, Any] = {}
        event_name = ""
        data_lines: list[str] = []

        with self._http.stream(
            "POST",
            f"{self.base_url}/v1/messages",
            headers=self._headers(accept="text/event-stream"),
            json=body,
        ) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line == "":
                    if data_lines:
                        event_payload = "\n".join(data_lines)
                        if event_name == "message_start":
                            payload = json.loads(event_payload)
                            message = payload.get("message", {})
                            response_id = str(message.get("id", response_id))
                            model = str(message.get("model", model))
                            start_usage = message.get("usage", {})
                            if isinstance(start_usage, dict):
                                usage.update(start_usage)
                        elif event_name == "message_delta":
                            payload = json.loads(event_payload)
                            delta_usage = payload.get("usage", {})
                            if isinstance(delta_usage, dict):
                                usage.update(delta_usage)
                        yield from self._handle_event(
                            event_name,
                            event_payload,
                            response_id,
                            model,
                            created,
                            usage,
                        )
                    event_name = ""
                    data_lines = []
                    continue
                if line.startswith("event:"):
                    event_name = line[6:].strip()
                elif line.startswith("data:"):
                    data_lines.append(line[5:].lstrip())

            if data_lines:
                yield from self._handle_event(
                    event_name,
                    "\n".join(data_lines),
                    response_id,
                    model,
                    created,
                    usage,
                )

    @staticmethod
    def _handle_event(
        event_name: str,
        data_text: str,
        response_id: str,
        model: str,
        created: int,
        usage: dict[str, Any],
    ) -> Iterator[MiniMaxAnthropicChunk]:
        if data_text == "[DONE]":
            return
        payload = json.loads(data_text)
        if event_name == "content_block_delta":
            delta = payload.get("delta", {})
            delta_type = delta.get("type")
            if delta_type == "thinking_delta":
                thinking = delta.get("thinking", "")
                if thinking:
                    yield MiniMaxAnthropicChunk(
                        response_id=response_id,
                        model=model,
                        created=created,
                        reasoning=str(thinking),
                        usage=dict(usage) or None,
                    )
            elif delta_type == "text_delta":
                text = delta.get("text", "")
                if text:
                    yield MiniMaxAnthropicChunk(
                        response_id=response_id,
                        model=model,
                        created=created,
                        content=str(text),
                        usage=dict(usage) or None,
                    )
        elif event_name == "message_delta":
            stop_reason = payload.get("delta", {}).get("stop_reason")
            yield MiniMaxAnthropicChunk(
                response_id=response_id,
                model=model,
                created=created,
                finish_reason=str(stop_reason) if stop_reason else None,
                usage=dict(usage) or None,
            )
