from __future__ import annotations

from modelscope_common import (
    RUNS_PATH,
    create_client,
    load_config,
    load_selected_model,
    response_to_dict,
    timestamp,
    write_json,
)
from run_trials import create_streaming_response


EXPECTED_TEXT = "PROVIDER_API_OK"


def main() -> None:
    config = load_config()
    model_id = load_selected_model()
    client = create_client()
    started_at = timestamp()

    response = create_streaming_response(
        client,
        model=model_id,
        prompt=f"只输出字符串 {EXPECTED_TEXT}，不要输出其他内容。",
        temperature=0,
        max_tokens=512,
        extra_body={"thinking": {"type": "enabled"}, "reasoning_effort": "high"},
    )
    raw = response_to_dict(response)
    output_text = response.choices[0].message.content or ""
    passed = output_text.strip() == EXPECTED_TEXT

    run_dir = RUNS_PATH / "smoke_tests" / started_at
    write_json(run_dir / "raw_response.json", raw)
    write_json(
        run_dir / "status.json",
        {
            "provider": config["provider"],
            "requested_model": model_id,
            "returned_model": raw.get("model"),
            "started_at": started_at,
            "expected": EXPECTED_TEXT,
            "actual": output_text,
            "passed": passed,
        },
    )

    print(f"请求模型: {model_id}")
    print(f"返回模型: {raw.get('model')}")
    print(f"响应内容: {output_text!r}")
    print(f"连接测试: {'通过' if passed else '未通过'}")
    print(f"记录目录: {run_dir}")

    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
