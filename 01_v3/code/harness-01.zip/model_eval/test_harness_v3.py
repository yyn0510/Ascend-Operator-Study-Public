from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import yaml

from feedback_builder import build_platform_fallback_feedback, build_platform_feedback_v2
from benchsite_mcp_client import verify_job_environment, verify_live_runner_profile
from run_feedback_trials import (
    build_messages,
    call_model,
    create_streaming_response,
    load_protocol,
    prepare_missing_environment_infra_retry,
)


ROOT = Path(__file__).resolve().parent
PROTOCOL = ROOT / "experiment_protocol_iterative_5round_3trajectory_one_shot_add_v3.yaml"
SMOKE_PROTOCOL = ROOT / "experiment_protocol_iterative_2round_1trajectory_one_shot_add_v3_smoke.yaml"
GROK_PROTOCOL = ROOT / "experiment_protocol_iterative_5round_3trajectory_one_shot_add_v3_grok_4_6_openrouter.yaml"


class FakeChatCompletions:
    def __init__(self, response) -> None:
        self.response = response
        self.calls: list[dict] = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return self.response


def fake_client(response) -> tuple[SimpleNamespace, FakeChatCompletions]:
    completions = FakeChatCompletions(response)
    client = SimpleNamespace(
        chat=SimpleNamespace(completions=completions),
    )
    return client, completions


def fake_stream_chunk(raw: dict) -> SimpleNamespace:
    raw_choice = (raw.get("choices") or [{}])[0]
    raw_delta = raw_choice.get("delta") or {}
    delta = SimpleNamespace(**raw_delta)
    choice = SimpleNamespace(
        delta=delta,
        finish_reason=raw_choice.get("finish_reason"),
    )
    return SimpleNamespace(
        choices=[choice],
        model_dump=lambda mode=None: raw,
    )


def successful_result() -> dict:
    cases = []
    for index, perf_score in enumerate((0.8, 0.2, 0.5, 0.1, 0.9), start=1):
        cases.append({
            "case_id": f"level1/exp_{index}",
            "status": "success",
            "elapsed_us": float(index),
            "baseline_perf_us": float(index * 2),
            "hardware_limit_us": float(index) / 2,
            "speedup": 2.0,
            "speedup_vs_hw": 0.5,
            "perf_score": perf_score,
        })
    return {
        "terminal_status": "succeeded",
        "job": {
            "job": {
                "status": "succeeded",
                "result_score": 84.0,
                "passed_cases": 5,
                "total_cases": 5,
                "stage_summary": {"failed_stage": None},
                "results": {
                    "operators": [{
                        "score": 84.0,
                        "compilation_score": 20.0,
                        "function_score": 30.0,
                        "performance_score": 34.0,
                        "passed_cases": 5,
                        "total_cases": 5,
                        "accuracy_passed_cases": 5,
                        "anti_cheat_failed_cases": 0,
                        "cases": cases,
                    }]
                },
            }
        },
    }


def failed_result_without_environment() -> dict:
    return {
        "job_id": "job_missing_environment",
        "terminal_status": "correctness_failed",
        "logs": {
            "stages": [
                {
                    "payload": {
                        "log_tail": (
                            "terminate called after throwing an instance of 'c10::Error'\n"
                            "what(): expected schema: cann_bench::gelu(Tensor x, str approximate=\"none\") -> Tensor\n"
                            "inferred schema: (Tensor _0, str? _1) -> Tensor _0\n"
                            "reason: Type mismatch in argument 2: str vs str?."
                        )
                    }
                }
            ]
        },
        "job": {
            "job": {
                "status": "correctness_failed",
                "failure_kind": "submission_failure",
                "error_code": "submission_process_signal_5",
                "stage_summary": {
                    "failed_stage": "correctness",
                    "failed_message": "平台未生成 evaluation_results.json",
                },
                "results": {
                    "summary": {
                        "score_unavailable_reason": "平台未返回逐 case 结果"
                    },
                    "failure": {
                        "error_message": "submission evaluation process terminated by signal 5"
                    },
                },
            }
        },
    }


class HarnessV3Tests(unittest.TestCase):
    def test_streaming_request_omits_null_temperature(self) -> None:
        chunks = [
            fake_stream_chunk({
                "id": "response-1",
                "model": "anthropic/claude-sonnet-5",
                "choices": [{
                    "delta": {"content": "complete"},
                    "finish_reason": "stop",
                }],
            })
        ]
        client, completions = fake_client(iter(chunks))

        create_streaming_response(
            client,
            model="anthropic/claude-sonnet-5",
            messages=[{"role": "user", "content": "test"}],
            temperature=None,
            max_tokens=128000,
            max_tokens_parameter="max_tokens",
            extra_body={"reasoning": {"effort": "high"}},
            save_stream_chunks=False,
        )

        self.assertNotIn("temperature", completions.calls[0])

    def test_non_streaming_request_keeps_zero_temperature(self) -> None:
        response = SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content="complete"))]
        )
        client, completions = fake_client(response)

        with tempfile.TemporaryDirectory() as directory:
            call_model(
                client=client,
                model_id="x-ai/grok-4.6",
                messages=[{"role": "user", "content": "test"}],
                generation={
                    "temperature": 0,
                    "max_output_tokens": 128000,
                    "max_tokens_parameter": "max_tokens",
                    "stream": False,
                    "extra_body": {"reasoning": {"effort": "high"}},
                },
                request_control={"network_retries": 0},
                round_dir=Path(directory),
            )

        self.assertIn("temperature", completions.calls[0])
        self.assertEqual(completions.calls[0]["temperature"], 0)

    def test_non_streaming_request_omits_null_temperature(self) -> None:
        response = SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content="complete"))]
        )
        client, completions = fake_client(response)

        with tempfile.TemporaryDirectory() as directory:
            call_model(
                client=client,
                model_id="openai/gpt-5.6-sol",
                messages=[{"role": "user", "content": "test"}],
                generation={
                    "temperature": None,
                    "max_output_tokens": 128000,
                    "max_tokens_parameter": "max_completion_tokens",
                    "stream": False,
                    "extra_body": {"reasoning": {"effort": "high"}},
                },
                request_control={"network_retries": 0},
                round_dir=Path(directory),
            )

        self.assertNotIn("temperature", completions.calls[0])

    def test_complete_empty_length_response_is_not_retried(self) -> None:
        response = SimpleNamespace(
            choices=[SimpleNamespace(
                message=SimpleNamespace(content=""),
                finish_reason="length",
            )],
            model_dump=lambda mode=None: {
                "choices": [{
                    "message": {"role": "assistant", "content": ""},
                    "finish_reason": "length",
                }]
            },
        )
        client, completions = fake_client(response)

        with tempfile.TemporaryDirectory() as directory:
            returned, attempts, _ = call_model(
                client=client,
                model_id="x-ai/grok-4.6",
                messages=[{"role": "user", "content": "test"}],
                generation={
                    "temperature": 0,
                    "max_output_tokens": 131072,
                    "max_tokens_parameter": "max_tokens",
                    "stream": False,
                    "extra_body": {"reasoning": {"effort": "high"}},
                },
                request_control={"network_retries": 2},
                round_dir=Path(directory),
            )

        self.assertIs(returned, response)
        self.assertEqual(len(completions.calls), 1)
        self.assertEqual([attempt["status"] for attempt in attempts], ["completed"])

    def test_streaming_response_archives_openrouter_reasoning_and_provider(self) -> None:
        chunks = [
            fake_stream_chunk({
                "id": "response-2",
                "model": "anthropic/claude-sonnet-5",
                "provider": "Anthropic",
                "choices": [{
                    "delta": {
                        "reasoning_content": "legacy reasoning",
                        "reasoning": "normalized reasoning",
                        "reasoning_details": [{
                            "type": "reasoning.text",
                            "text": "structured reasoning",
                        }],
                    },
                    "finish_reason": None,
                }],
            }),
            fake_stream_chunk({
                "id": "response-2",
                "model": "anthropic/claude-sonnet-5",
                "provider": "Anthropic",
                "choices": [{
                    "delta": {"content": "complete"},
                    "finish_reason": "stop",
                }],
            }),
        ]
        client, _ = fake_client(iter(chunks))

        response = create_streaming_response(
            client,
            model="anthropic/claude-sonnet-5",
            messages=[{"role": "user", "content": "test"}],
            temperature=None,
            max_tokens=128000,
            max_tokens_parameter="max_tokens",
            extra_body={"reasoning": {"effort": "high"}},
            save_stream_chunks=False,
        )
        raw = response.model_dump(mode="json")
        message = raw["choices"][0]["message"]

        self.assertEqual(raw["provider"], "Anthropic")
        self.assertEqual(message["reasoning_content"], "legacy reasoning")
        self.assertEqual(message["reasoning"], "normalized reasoning")
        self.assertEqual(
            message["reasoning_details"],
            [{"type": "reasoning.text", "text": "structured reasoning"}],
        )

    def test_protocol_is_five_rounds_three_trajectories(self) -> None:
        protocol = load_protocol(PROTOCOL)
        self.assertEqual(protocol["experiment"]["rounds_per_trajectory"], 5)
        self.assertEqual(protocol["experiment"]["trajectories_per_model_task"], 3)
        self.assertEqual(
            protocol["experiment"]["primary_metric"],
            "best_score_within_5_rounds",
        )

    def test_grok_protocol_freezes_reasoning_and_provider_route(self) -> None:
        protocol = load_protocol(GROK_PROTOCOL)
        generation = protocol["generation"]

        self.assertEqual(generation["temperature"], 0)
        self.assertEqual(generation["max_output_tokens"], 131072)
        self.assertEqual(generation["max_tokens_parameter"], "max_tokens")
        self.assertEqual(
            generation["extra_body"]["reasoning"],
            {"effort": "high", "exclude": False},
        )
        self.assertEqual(
            generation["extra_body"]["provider"],
            {
                "only": ["xai/zdr"],
                "allow_fallbacks": False,
                "require_parameters": True,
            },
        )

    def test_smoke_protocol_is_two_rounds_one_trajectory(self) -> None:
        protocol = load_protocol(SMOKE_PROTOCOL)
        self.assertEqual(protocol["experiment"]["purpose"], "smoke_test")
        self.assertEqual(protocol["experiment"]["rounds_per_trajectory"], 2)
        self.assertEqual(protocol["experiment"]["trajectories_per_model_task"], 1)
        self.assertEqual(
            protocol["experiment"]["primary_metric"],
            "best_score_within_2_rounds",
        )

    def test_succeeded_is_success_and_feedback_is_compact(self) -> None:
        protocol = yaml.safe_load(PROTOCOL.read_text(encoding="utf-8"))
        payload = build_platform_feedback_v2(successful_result(), protocol["feedback"])
        self.assertIsNone(payload["failure_stage"])
        self.assertEqual(payload["feedback_schema"], "cannbench_iterative_feedback_v3")
        self.assertEqual(payload["operator_score_breakdown"]["performance_score"], 34.0)
        selected = payload["lowest_performance_cases"]
        self.assertEqual(len(selected), 3)
        self.assertEqual([item["perf_score"] for item in selected], [0.1, 0.2, 0.5])
        self.assertNotIn("cases", payload)

    def test_platform_zero_fallback_is_compact_and_keeps_platform_error_signal(self) -> None:
        protocol = yaml.safe_load(PROTOCOL.read_text(encoding="utf-8"))
        payload = build_platform_fallback_feedback(
            failed_result_without_environment(), protocol["feedback"]
        )
        self.assertEqual(payload["source"], "harness_platform_zero_fallback")
        self.assertEqual(payload["score_source"], "platform_result_fallback_zero")
        self.assertTrue(payload["evaluation_performed"])
        self.assertEqual(payload["job_summary"]["result_score"], 0.0)
        self.assertEqual(payload["failure_stage"], "correctness")
        errors = "\n".join(item["text"] for item in payload["root_errors"])
        self.assertIn("schema", errors)
        self.assertIn("Type mismatch", errors)
        self.assertLess(len(json.dumps(payload, ensure_ascii=False)), 60000)

    def test_runner_revision_change_is_warning_only(self) -> None:
        result = verify_live_runner_profile(
            {
                "devices": [{
                    "hardware": "910c",
                    "online": True,
                    "runners": [{"status": "online", "cann_bench_ref": "new-ref"}],
                }]
            },
            {"target_hardware": "910c", "cann_bench_ref": "frozen-ref"},
        )
        self.assertEqual(len(result["warnings"]), 1)

    def test_long_generation_threshold_does_not_add_initial_notice(self) -> None:
        initial_messages = build_messages(
            "固定任务提示",
            None,
            long_generation_threshold_seconds=1200.0,
        )
        self.assertEqual(initial_messages, [{"role": "user", "content": "固定任务提示"}])

        with tempfile.TemporaryDirectory() as directory:
            previous_round = Path(directory)
            (previous_round / "model_output.txt").write_text("上一轮输出", encoding="utf-8")
            (previous_round / "feedback_prompt.txt").write_text("上一轮反馈", encoding="utf-8")
            (previous_round / "generation_status.json").write_text(
                json.dumps({"elapsed_seconds": 1201.0}),
                encoding="utf-8",
            )
            messages = build_messages(
                "固定任务提示",
                previous_round,
                long_generation_threshold_seconds=1200.0,
            )
            self.assertEqual(messages[0], {"role": "user", "content": "固定任务提示"})
            self.assertTrue(any("上一轮生成耗时过长" in item["content"] for item in messages))

    def test_runtime_versions_match_and_missing_or_changed_versions_stop(self) -> None:
        profile = {
            "cann_version": "9.1.0",
            "pytorch_version": "2.9.0",
            "torch_npu_version": "2.9.0",
        }
        matched = {
            "job": {"job": {"results": {"setup_info": {"environment": {
                "cann": "9.1.0",
                "pytorch": "2.9.0+cpu",
                "pytorch_npu": "2.9.0",
            }}}}}
        }
        verification = verify_job_environment(matched, profile)
        self.assertEqual(verification["status"], "matched")

        changed = json.loads(json.dumps(matched))
        changed["job"]["job"]["results"]["setup_info"]["environment"]["cann"] = "9.2.0"
        with self.assertRaises(RuntimeError):
            verify_job_environment(changed, profile)

        missing = json.loads(json.dumps(matched))
        del missing["job"]["job"]["results"]["setup_info"]["environment"]["pytorch_npu"]
        with self.assertRaises(RuntimeError):
            verify_job_environment(missing, profile)

    def test_summary_uses_best_score_and_excludes_incomplete_trajectory(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "experiment_manifest.json").write_text(
                json.dumps({
                    "rounds_per_trajectory": 5,
                    "trajectories": 3,
                    "primary_metric": "best_score_within_5_rounds",
                }),
                encoding="utf-8",
            )
            score_sets = ([0, 20, 10, 40, 30], [0, 0, 50, 45, 42])
            for trajectory_number, scores in enumerate(score_sets, start=1):
                trajectory = root / f"trajectory_{trajectory_number:03d}"
                for round_number, score in enumerate(scores, start=1):
                    round_dir = trajectory / f"round_{round_number:02d}"
                    round_dir.mkdir(parents=True)
                    (round_dir / "status.json").write_text(
                        json.dumps({
                            "status": "round_completed",
                            "outcome": "platform_evaluated",
                            "job_status": "succeeded" if score else "compile_failed",
                            "result_score": score,
                            "passed_cases": 20 if score >= 40 else 0,
                            "total_cases": 20,
                        }),
                        encoding="utf-8",
                    )
                    if trajectory_number == 1 and round_number == 1:
                        (round_dir / "submission_receipt.json").write_text(
                            json.dumps({
                                "runner_warnings": ["runner revision changed"],
                                "runner_verification_skipped": False,
                            }),
                            encoding="utf-8",
                        )
                        (round_dir / "environment_verification.json").write_text(
                            json.dumps({"status": "matched"}),
                            encoding="utf-8",
                        )
            incomplete = root / "trajectory_003" / "round_01"
            incomplete.mkdir(parents=True)
            (incomplete / "status.json").write_text(
                json.dumps({"status": "platform_operation_failed"}),
                encoding="utf-8",
            )
            completed = subprocess.run(
                [
                    sys.executable,
                    str(ROOT / "summarize_feedback_experiment.py"),
                    "--experiment-dir",
                    str(root),
                ],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            summary = json.loads(
                (root / "feedback_experiment_summary.json").read_text(encoding="utf-8")
            )
            self.assertEqual(summary["trajectory_best_scores"], [40.0, 50.0])
            self.assertEqual(summary["mean_trajectory_best_score"], 45.0)
            self.assertEqual(summary["complete_trajectory_count"], 2)
            self.assertFalse(summary["formal_result_complete"])
            self.assertEqual(summary["runner_warnings"], ["runner revision changed"])
            self.assertEqual(
                summary["trajectories"][0]["rounds"][0][
                    "environment_verification_status"
                ],
                "matched",
            )

    def test_missing_environment_allows_one_exact_source_infra_retry(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            round_dir = Path(directory)
            (round_dir / "status.json").write_text(
                json.dumps({
                    "status": "platform_operation_failed",
                    "error": "评测结果缺少 setup_info.environment",
                }),
                encoding="utf-8",
            )
            (round_dir / "submission_receipt.json").write_text(
                json.dumps({"response": {"job": {"id": "job_old"}}}),
                encoding="utf-8",
            )
            (round_dir / "benchsite_result.json").write_text(
                json.dumps({"job_id": "job_old", "terminal_status": "compile_failed"}),
                encoding="utf-8",
            )

            self.assertTrue(prepare_missing_environment_infra_retry(round_dir))
            self.assertFalse((round_dir / "status.json").exists())
            self.assertFalse((round_dir / "submission_receipt.json").exists())
            self.assertFalse((round_dir / "benchsite_result.json").exists())
            retry = json.loads(
                (round_dir / "platform_infra_retry_001.json").read_text(encoding="utf-8")
            )
            self.assertEqual(retry["original_job_id"], "job_old")
            self.assertFalse(retry["model_round_incremented"])

            (round_dir / "status.json").write_text(
                json.dumps({
                    "status": "platform_operation_failed",
                    "error": "评测结果缺少 setup_info.environment",
                }),
                encoding="utf-8",
            )
            (round_dir / "submission_receipt.json").write_text(
                json.dumps({"response": {"job": {"id": "job_new"}}}),
                encoding="utf-8",
            )
            (round_dir / "benchsite_result.json").write_text(
                json.dumps({"job_id": "job_new", "terminal_status": "compile_failed"}),
                encoding="utf-8",
            )
            with self.assertRaises(RuntimeError):
                prepare_missing_environment_infra_retry(round_dir)
            self.assertFalse(
                prepare_missing_environment_infra_retry(
                    round_dir, allow_platform_zero_fallback=True
                )
            )


if __name__ == "__main__":
    unittest.main()
