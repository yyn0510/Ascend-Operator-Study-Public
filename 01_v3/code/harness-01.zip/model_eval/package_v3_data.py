#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把 V3 流程（Level1）的实验数据整理成可分析的数据包。

产出（默认写入 文档/实验记录/正式-v3/V3数据包/）：
  v3_rounds.csv              逐轮明细长表，每轮一行（主表）
  v3_round_scores_wide.csv   逐轮分数宽表，每 (模型,算子,轨迹) 一行、R1..R5 五列
  v3_trajectories.csv        轨迹级汇总，每 (模型,算子,轨迹) 一行
  v3_operators.csv           算子级汇总，每 (模型,算子) 一行
  v3_op_means_wide.csv       算子均值矩阵，行=模型、列=八个算子
  v3_models.csv              模型级汇总，每模型一行

口径见 MODEL_WHITELIST 注释与 README。所有 CSV 使用 utf-8-sig，便于 Excel 直接打开。

用法：
    python model_eval/package_v3_data.py
    python model_eval/package_v3_data.py --out <目录>
"""

from __future__ import annotations

import argparse
import collections
import csv
import glob
import json
import os
import statistics
import sys

LEVEL1_OPERATORS = [
    "exp",
    "foreach_addcdiv_scalar",
    "foreach_norm",
    "gelu",
    "masked_scale",
    "mish",
    "sigmoid",
    "swi_glu",
]
TRAJECTORIES = ["trajectory_001", "trajectory_002", "trajectory_003"]

# 模型 -> (provider, [V3 正式实验目录], 是否已完成 8 算子)
#
# ===== 这是本数据包唯一可信的取数边界，务必不要改成"扫描全部目录" =====
# 1) 只取 V3 正式实验目录。早期 V2 十轮试跑目录（formal_l1_10round_v2_*、
#    feedback_pilot_*、v3_smoke_*）复用了 opencode_go/deepseek-v4-flash 路径，
#    不加白名单会让 DeepSeek V4 Flash 变成 160 轮、宏平均从 34.764 虚高到 44.036。
# 2) 每个模型只取真实 provider 层。GLM 在 opencode_go/glm-5_3、MiniMax 在
#    opencode_go/MiniMax-M3 下各留有误用入口产生的空目录，真实父层分别是
#    zhipu_bigmodel 与 minimax_paygo_cn_anthropic。
MODEL_WHITELIST: dict[str, tuple[str, list[str], bool]] = {
    "Kimi K3": (
        "opencode_go",
        [
            "formal_v3_a3_kimi_k3_level1_first4_20260815",
            "formal_v3_a3_kimi_k3_level1_remaining4_20260817",
        ],
        True,
    ),
    "GLM-5.3": (
        "zhipu_bigmodel",
        [
            "formal_v3_a3_glm_5_3_exp_prefix3_20260821",
            "formal_v3_a3_glm_5_3_level1_next3_20260822",
            "formal_v3_a3_glm_5_3_level1_remaining4_20260826",
        ],
        True,
    ),
    "Qwen3.8-Max": (
        "qwencloud_paygo",
        [
            "qwen38max_exp_prefix3_20260820",
            "qwen38max_exp_remaining4_20260820",
        ],
        True,
    ),
    "DeepSeek V4 Flash": (
        "opencode_go",
        [
            "formal_v3_a3_deepseek_v4_flash_level1_first4_20260814",
            "formal_v3_a3_deepseek_v4_flash_level1_next2_20260814",
            "formal_v3_a3_deepseek_v4_flash_level1_final2_20260815",
        ],
        True,
    ),
    "DeepSeek V4.1 Flash": (
        "deepseek_official",
        ["formal_v3_a1_deepseek_flash_exp_20260910"],
        True,
    ),
    "Grok 4.6": (
        "openrouter_xai_zdr",
        ["formal_v3_a3_grok_4_6_openrouter_level1_20260916"],
        True,
    ),
    "DeepSeek V4 Pro": (
        "deepseek_official",
        [
            "formal_v3_a3_deepseek_v4_pro_official_clean_20260828",
            "formal_v3_a3_deepseek_v4_pro_official_remaining_clean_20260828",
            "formal_v3_a3_deepseek_v4_pro_official_last2_clean_20260828",
        ],
        True,
    ),
    "MiniMax-M3": (
        "minimax_paygo_cn_anthropic",
        [
            "minimax_m3_anthropic_level1_rerun_first3_20260824",
            "minimax_m3_anthropic_level1_remaining5_20260824",
        ],
        True,
    ),
    "MiMo-V2.5-Pro": (
        "xiaomi_mimo_paygo",
        ["formal_v3_a3_mimo_v2_5_pro_level1_20260907"],
        True,
    ),
    "Claude Opus 5": (
        "openrouter_anthropic",
        ["formal_v3_a3_claude_opus_5_openrouter_level1_20260917"],
        False,
    ),
}

ROUND_COLUMNS = [
    "model",
    "provider",
    "experiment_dir",
    "operator",
    "trajectory",
    "round",
    "score",
    "passed_cases",
    "total_cases",
    "job_status",
    "round_category",
    "submitted",
    "evaluated",
    "score_source",
    "platform_fallback",
    "strict_protocol_pass",
    "recoverable_parse_pass",
    "format_recovered",
    "format_recovery_reasons",
    "completed_at",
    "elapsed_seconds",
    "output_characters",
    "finish_reason",
    "returned_model",
    "network_retry_count",
    "content_retry_count",
    "tokens_in",
    "tokens_out",
    "tokens_total",
    "tokens_reasoning",
    "cost_usd",
]


def default_root() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, "runs", "feedback_experiments")


def default_out() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(here)
    return os.path.join(
        project_root, "文档", "实验记录", "正式-v3", "V3数据包"
    )


def load_json(path: str) -> dict:
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return {}


def classify(status: dict) -> str:
    """轮次归类：格式失败 / 未完成 / 编译失败 / 设备执行异常 / 部分正确 / 全正确。"""
    if not status.get("submitted"):
        return "format_failure"
    score = status.get("result_score")
    if score is None:
        return "incomplete"
    job_status = status.get("job_status")
    if score == 0 and job_status == "correctness_failed":
        return "device_exception"
    if score == 0:
        return "compile_failed"
    passed, total = status.get("passed_cases"), status.get("total_cases")
    if passed is not None and total is not None and passed == total:
        return "succeeded"
    return "partial_correctness"


def number(value: object) -> object:
    """把 None / 缺失值统一成空字符串，其余保留。"""
    if value is None:
        return ""
    if isinstance(value, float):
        return round(value, 6)
    return value


def collect_rounds(root: str, provider: str, experiment_dirs: list[str], model: str) -> list[dict]:
    rows: list[dict] = []
    for exp in experiment_dirs:
        pattern = os.path.join(
            root, exp, provider, "*", "level1_*", "trajectory_*", "round_*", "status.json"
        )
        for status_path in sorted(glob.glob(pattern)):
            round_dir = os.path.dirname(status_path)
            rel = os.path.relpath(round_dir, os.path.join(root, exp)).split(os.sep)
            if len(rel) < 5:
                continue
            op = rel[2].replace("level1_", "")
            trajectory = rel[3]
            round_number = int(rel[4].split("_")[-1])

            status = load_json(status_path)
            generation = load_json(os.path.join(round_dir, "generation_status.json"))
            raw = load_json(os.path.join(round_dir, "raw_response.json"))
            parse_report = load_json(os.path.join(round_dir, "parse_report.json"))
            usage = raw.get("usage") if isinstance(raw.get("usage"), dict) else {}

            details = usage.get("completion_tokens_details") or {}
            tokens_in = usage.get("prompt_tokens", usage.get("input_tokens"))
            tokens_out = usage.get("completion_tokens", usage.get("output_tokens"))
            reasons = parse_report.get("format_recovery_reasons") or status.get(
                "format_recovery_reasons"
            )
            if isinstance(reasons, list):
                reasons = ";".join(str(item) for item in reasons)

            cost = generation.get("cost_usd", usage.get("cost"))

            rows.append(
                {
                    "model": model,
                    "provider": provider,
                    "experiment_dir": exp,
                    "operator": op,
                    "trajectory": trajectory,
                    "round": round_number,
                    "score": number(status.get("result_score")),
                    "passed_cases": number(status.get("passed_cases")),
                    "total_cases": number(status.get("total_cases")),
                    "job_status": status.get("job_status") or "",
                    "round_category": classify(status),
                    "submitted": bool(status.get("submitted")),
                    "evaluated": bool(status.get("evaluated")),
                    "score_source": status.get("score_source") or "",
                    "platform_fallback": bool(status.get("platform_fallback")),
                    "strict_protocol_pass": status.get("strict_protocol_pass"),
                    "recoverable_parse_pass": status.get("recoverable_parse_pass"),
                    "format_recovered": status.get("format_recovered"),
                    "format_recovery_reasons": reasons or "",
                    "completed_at": status.get("completed_at") or "",
                    "elapsed_seconds": number(generation.get("elapsed_seconds")),
                    "output_characters": number(generation.get("output_characters")),
                    "finish_reason": generation.get("finish_reason") or "",
                    "returned_model": generation.get("returned_model") or "",
                    "network_retry_count": number(generation.get("network_retry_count")),
                    "content_retry_count": number(generation.get("content_retry_count")),
                    "tokens_in": number(tokens_in),
                    "tokens_out": number(tokens_out),
                    "tokens_total": number(usage.get("total_tokens")),
                    "tokens_reasoning": number(details.get("reasoning_tokens")),
                    "cost_usd": number(cost),
                }
            )
    rows.sort(key=lambda row: (row["model"], LEVEL1_OPERATORS.index(row["operator"])
                               if row["operator"] in LEVEL1_OPERATORS else 99,
                               row["trajectory"], row["round"]))
    return rows


def build_trajectories(rows: list[dict]) -> list[dict]:
    grouped: dict[tuple, list[dict]] = collections.defaultdict(list)
    for row in rows:
        grouped[(row["model"], row["provider"], row["operator"], row["trajectory"])].append(row)

    out = []
    for (model, provider, op, trajectory), items in grouped.items():
        items.sort(key=lambda item: item["round"])
        scored = [item["score"] for item in items if item["score"] != ""]
        census = collections.Counter(item["round_category"] for item in items)
        regression = 0
        for index in range(1, len(items)):
            earlier = [v for v in scored[:index]]
            current = items[index]["score"]
            if current != "" and earlier and current < max(earlier):
                regression += 1
        best = max(scored) if scored else ""
        best_round = ""
        if best != "":
            best_round = next(item["round"] for item in items if item["score"] == best)
        out.append(
            {
                "model": model,
                "provider": provider,
                "operator": op,
                "trajectory": trajectory,
                "rounds": len(items),
                "best_score": number(best),
                "best_round": best_round,
                "final_round_score": number(items[-1]["score"]) if items else "",
                "regression_count": regression,
                "n_succeeded": census["succeeded"],
                "n_partial_correctness": census["partial_correctness"],
                "n_compile_failed": census["compile_failed"],
                "n_device_exception": census["device_exception"],
                "n_format_failure": census["format_failure"],
                "n_incomplete": census["incomplete"],
                "tokens_out": number(sum(item["tokens_out"] for item in items if item["tokens_out"] != "") or None),
                "elapsed_seconds_total": number(sum(item["elapsed_seconds"] for item in items if item["elapsed_seconds"] != "") or None),
            }
        )
    return out


def build_operators(trajectories: list[dict]) -> list[dict]:
    grouped: dict[tuple, dict[str, dict]] = collections.defaultdict(dict)
    for row in trajectories:
        grouped[(row["model"], row["provider"], row["operator"])][row["trajectory"]] = row

    out = []
    for (model, provider, op), per_traj in grouped.items():
        bests = []
        for trajectory in TRAJECTORIES:
            entry = per_traj.get(trajectory)
            if entry and entry["rounds"] == 5 and entry["best_score"] != "":
                bests.append(entry["best_score"])
        record = {
            "model": model,
            "provider": provider,
            "operator": op,
            "complete_trajectories": len(bests),
        }
        for index, trajectory in enumerate(TRAJECTORIES, start=1):
            entry = per_traj.get(trajectory) or {}
            record[f"T{index}_best"] = number(entry.get("best_score"))
            record[f"T{index}_best_round"] = entry.get("best_round", "")
            record[f"T{index}_final"] = number(entry.get("final_round_score"))
            record[f"T{index}_regressions"] = entry.get("regression_count", "")
        if bests:
            record.update(
                {
                    "mean": number(sum(bests) / len(bests)),
                    "sigma": number(statistics.stdev(bests)) if len(bests) > 1 else "",
                    "min": number(min(bests)),
                    "max": number(max(bests)),
                    "nonzero_trajectories": sum(1 for value in bests if value > 0),
                }
            )
        else:
            record.update({"mean": "", "sigma": "", "min": "", "max": "", "nonzero_trajectories": 0})
        out.append(record)
    return out


def build_models(rows: list[dict], trajectories: list[dict], operators: list[dict]) -> list[dict]:
    out = []
    for model in MODEL_WHITELIST:
        model_rows = [row for row in rows if row["model"] == model]
        if not model_rows:
            continue
        census = collections.Counter(row["round_category"] for row in model_rows)
        scored = [row["score"] for row in model_rows if row["score"] != ""]
        op_entries = [
            entry for entry in operators
            if entry["model"] == model and entry["complete_trajectories"] == 3
        ]
        means = [entry["mean"] for entry in op_entries]
        sigmas = sorted(entry["sigma"] for entry in op_entries if entry["sigma"] != "")
        total_rounds = len(model_rows)
        elapsed = [row["elapsed_seconds"] for row in model_rows if row["elapsed_seconds"] != ""]
        costs = [row["cost_usd"] for row in model_rows if row["cost_usd"] != ""]
        out.append(
            {
                "model": model,
                "provider": MODEL_WHITELIST[model][0],
                "complete": MODEL_WHITELIST[model][2],
                "rounds": total_rounds,
                "n_succeeded": census["succeeded"],
                "n_partial_correctness": census["partial_correctness"],
                "n_compile_failed": census["compile_failed"],
                "n_device_exception": census["device_exception"],
                "n_format_failure": census["format_failure"],
                "n_incomplete": census["incomplete"],
                "full_correct_rate": number(census["succeeded"] / total_rounds) if total_rounds else "",
                "zero_rounds": census["compile_failed"] + census["device_exception"] + census["format_failure"],
                "macro_average": number(sum(means) / len(means)) if means else "",
                "operators_counted": len(means),
                "sigma_median": number(statistics.median(sigmas)) if sigmas else "",
                "nonzero_operators": sum(1 for entry in op_entries if entry["nonzero_trajectories"] > 0),
                "nonzero_trajectories": sum(
                    entry["nonzero_trajectories"] for entry in op_entries
                ),
                "nonzero_rounds": sum(1 for value in scored if value > 0),
                "tokens_in": number(sum(row["tokens_in"] for row in model_rows if row["tokens_in"] != "") or None),
                "tokens_out": number(sum(row["tokens_out"] for row in model_rows if row["tokens_out"] != "") or None),
                "tokens_reasoning": number(sum(row["tokens_reasoning"] for row in model_rows if row["tokens_reasoning"] != "") or None),
                "elapsed_mean": number(sum(elapsed) / len(elapsed)) if elapsed else "",
                "elapsed_max": number(max(elapsed)) if elapsed else "",
                "rounds_over_1200s": sum(1 for value in elapsed if value > 1200),
                "cost_usd_total": number(sum(costs)) if costs else "",
                "cost_rounds_available": len(costs),
            }
        )
    return out


def write_csv(path: str, columns: list[str], rows: list[dict]) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> int:
    parser = argparse.ArgumentParser(description="打包 V3 Level1 实验数据")
    parser.add_argument("--root", default=default_root(), help="feedback_experiments 目录")
    parser.add_argument("--out", default=default_out(), help="输出目录")
    args = parser.parse_args()

    if not os.path.isdir(args.root):
        print(f"找不到归档目录: {args.root}", file=sys.stderr)
        return 1
    os.makedirs(args.out, exist_ok=True)

    all_rows: list[dict] = []
    for model, (provider, experiment_dirs, _) in MODEL_WHITELIST.items():
        all_rows.extend(collect_rounds(args.root, provider, experiment_dirs, model))

    trajectories = build_trajectories(all_rows)
    operators = build_operators(trajectories)
    models = build_models(all_rows, trajectories, operators)

    write_csv(os.path.join(args.out, "v3_rounds.csv"), ROUND_COLUMNS, all_rows)

    wide_rows = []
    grouped: dict[tuple, dict[int, object]] = collections.defaultdict(dict)
    for row in all_rows:
        grouped[(row["model"], row["provider"], row["operator"], row["trajectory"])][row["round"]] = number(row["score"])
    for (model, provider, op, trajectory), rounds in grouped.items():
        wide_rows.append(
            {
                "model": model,
                "operator": op,
                "trajectory": trajectory,
                **{f"R{i}": rounds.get(i, "") for i in range(1, 6)},
            }
        )
    wide_rows.sort(key=lambda row: (row["model"], row["operator"], row["trajectory"]))
    write_csv(
        os.path.join(args.out, "v3_round_scores_wide.csv"),
        ["model", "operator", "trajectory", "R1", "R2", "R3", "R4", "R5"],
        wide_rows,
    )

    write_csv(
        os.path.join(args.out, "v3_trajectories.csv"),
        [
            "model", "provider", "operator", "trajectory", "rounds", "best_score", "best_round",
            "final_round_score", "regression_count", "n_succeeded", "n_partial_correctness",
            "n_compile_failed", "n_device_exception", "n_format_failure", "n_incomplete",
            "tokens_out", "elapsed_seconds_total",
        ],
        trajectories,
    )

    write_csv(
        os.path.join(args.out, "v3_operators.csv"),
        [
            "model", "provider", "operator", "complete_trajectories",
            "T1_best", "T1_best_round", "T1_final", "T1_regressions",
            "T2_best", "T2_best_round", "T2_final", "T2_regressions",
            "T3_best", "T3_best_round", "T3_final", "T3_regressions",
            "mean", "sigma", "min", "max", "nonzero_trajectories",
        ],
        operators,
    )

    mean_matrix = []
    for model in MODEL_WHITELIST:
        record = {"model": model}
        for op in LEVEL1_OPERATORS:
            entry = next(
                (item for item in operators if item["model"] == model and item["operator"] == op),
                None,
            )
            record[op] = number(entry["mean"]) if entry and entry["mean"] != "" else ""
        entry = next((item for item in models if item["model"] == model), None)
        record["macro_average"] = number(entry["macro_average"]) if entry else ""
        mean_matrix.append(record)
    write_csv(
        os.path.join(args.out, "v3_op_means_wide.csv"),
        ["model"] + LEVEL1_OPERATORS + ["macro_average"],
        mean_matrix,
    )

    write_csv(
        os.path.join(args.out, "v3_models.csv"),
        [
            "model", "provider", "complete", "rounds", "n_succeeded", "n_partial_correctness",
            "n_compile_failed", "n_device_exception", "n_format_failure", "n_incomplete",
            "full_correct_rate", "zero_rounds", "macro_average", "operators_counted",
            "sigma_median", "nonzero_operators", "nonzero_trajectories", "nonzero_rounds",
            "tokens_in", "tokens_out", "tokens_reasoning",
            "elapsed_mean", "elapsed_max", "rounds_over_1200s",
            "cost_usd_total", "cost_rounds_available",
        ],
        models,
    )

    print(f"输出目录: {args.out}")
    print(f"逐轮行数: {len(all_rows)}  轨迹行数: {len(trajectories)}  算子行数: {len(operators)}  模型行数: {len(models)}")
    print()
    print(f'{"模型":22s} {"轮次":>4s} {"宏平均":>11s} {"全正确":>7s}')
    for entry in models:
        macro = f'{entry["macro_average"]:.6f}' if entry["macro_average"] != "" else "--"
        rate = f'{entry["full_correct_rate"]*100:.1f}%' if entry["full_correct_rate"] != "" else "--"
        print(f'{entry["model"]:22s} {entry["rounds"]:4d} {macro:>11s} {rate:>7s}')
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
