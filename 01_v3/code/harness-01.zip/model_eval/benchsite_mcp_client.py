from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import tomllib
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

import yaml

from modelscope_common import timestamp, write_json


DEFAULT_KERMINAL_CONFIG = Path.home() / ".kerminal" / "config.toml"
DEFAULT_PLATFORM_CONFIG = Path(__file__).resolve().parent / "platform_profiles.yaml"


def load_benchsite_server(config_path: Path) -> dict[str, Any]:
    """读取 Kerminal 的 BenchSite stdio 配置，但不打印或复制其中的密钥。"""
    data = tomllib.loads(config_path.read_text(encoding="utf-8-sig"))
    servers = data.get("mcp", {}).get("servers", [])
    for server in servers:
        if server.get("name") == "benchsite":
            if server.get("type", "stdio") != "stdio":
                raise ValueError("当前 harness 只支持 stdio 类型的 BenchSite MCP")
            command = server.get("command")
            if not command:
                raise ValueError("BenchSite MCP 配置缺少 command")
            return {
                "command": str(command),
                "args": [str(value) for value in server.get("args", [])],
                "env": {str(key): str(value) for key, value in server.get("env", {}).items()},
                "source": str(config_path.resolve()),
            }
    raise ValueError(f"未在 {config_path} 中找到名为 benchsite 的 MCP server")


def load_platform_profile(config_path: Path, profile_name: str) -> dict[str, Any]:
    data = yaml.safe_load(config_path.read_text(encoding="utf-8-sig"))
    profiles = data.get("profiles", {})
    if profile_name not in profiles:
        raise ValueError(f"未知平台配置 {profile_name!r}，可用配置: {sorted(profiles)}")
    profile = profiles[profile_name]
    required = (
        "target_hardware",
        "benchmark_slug",
        "benchmark_version",
        "cann_bench_ref",
        "submission_private",
        "submission_tag",
    )
    missing = [key for key in required if key not in profile]
    if missing:
        raise ValueError(f"平台配置缺少字段: {missing}")
    return profile


class StdioMcpClient:
    def __init__(self, server: dict[str, Any]) -> None:
        self.server = server
        self.process: subprocess.Popen[str] | None = None
        self.next_id = 1

    def __enter__(self) -> "StdioMcpClient":
        env = os.environ.copy()
        env.update(self.server["env"])
        # MCP JSON-RPC 必须固定使用 UTF-8；否则 Windows 中文路径可能被子进程按本地代码页误解码。
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        self.process = subprocess.Popen(
            [self.server["command"], *self.server["args"]],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            env=env,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
        )
        self.request(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "cannbench-model-eval-harness", "version": "0.1.0"},
            },
        )
        self.notify("notifications/initialized", {})
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        if self.process is None:
            return
        if self.process.stdin:
            self.process.stdin.close()
        try:
            self.process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            self.process.wait(timeout=3)

    def _send(self, payload: dict[str, Any]) -> None:
        if self.process is None or self.process.stdin is None:
            raise RuntimeError("MCP server 尚未启动")
        self.process.stdin.write(json.dumps(payload, ensure_ascii=False) + "\n")
        self.process.stdin.flush()

    def request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        if self.process is None or self.process.stdout is None:
            raise RuntimeError("MCP server 尚未启动")
        request_id = self.next_id
        self.next_id += 1
        self._send({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
        line = self.process.stdout.readline()
        if not line:
            stderr = self.process.stderr.read() if self.process.stderr else ""
            raise RuntimeError(f"MCP server 未返回响应。stderr={stderr.strip()}")
        response = json.loads(line)
        if response.get("id") != request_id:
            raise RuntimeError(f"MCP 响应 ID 不匹配: {response.get('id')} != {request_id}")
        if "error" in response:
            raise RuntimeError(f"MCP 错误: {response['error']}")
        return response["result"]

    def notify(self, method: str, params: dict[str, Any]) -> None:
        self._send({"jsonrpc": "2.0", "method": method, "params": params})

    def list_tools(self) -> list[dict[str, Any]]:
        return self.request("tools/list", {})["tools"]

    def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
        result = self.request("tools/call", {"name": name, "arguments": arguments})
        if result.get("isError"):
            raise RuntimeError(f"BenchSite MCP 工具调用失败: {result}")
        content = result.get("content", [])
        if len(content) != 1 or content[0].get("type") != "text":
            return result
        text = content[0].get("text", "")
        try:
            value = json.loads(text)
        except json.JSONDecodeError:
            return text
        if isinstance(value, dict) and value.get("error"):
            raise RuntimeError(f"BenchSite API 调用失败: {value}")
        return value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="由实验 harness 调用 BenchSite MCP。")
    parser.add_argument(
        "--config",
        type=Path,
        default=DEFAULT_KERMINAL_CONFIG,
        help="包含 BenchSite stdio server 的 Kerminal TOML 配置",
    )
    parser.add_argument(
        "--platform-config",
        type=Path,
        default=DEFAULT_PLATFORM_CONFIG,
        help="固定 A3/950PR 环境和提交参数的 YAML",
    )
    subparsers = parser.add_subparsers(dest="action", required=True)
    subparsers.add_parser("doctor", help="仅检查 MCP 握手和工具列表，不访问 BenchSite 网络")
    subparsers.add_parser("probe", help="只读检查身份、runner 和 benchmark API 是否可用")
    subparsers.add_parser("whoami", help="检查 BenchSite 身份和配额")
    subparsers.add_parser("get-credits", help="查询提交配额")
    subparsers.add_parser("list-runners", help="查询当前硬件 runner")
    subparsers.add_parser("list-benchmarks", help="查询 benchmark slug")

    verify_platform = subparsers.add_parser(
        "verify-platform", help="只读核对平台配置与当前在线 runner 版本"
    )
    verify_platform.add_argument("--platform", required=True, help="a3 或 950pr")

    catalog = subparsers.add_parser("snapshot-catalog", help="保存 runner 和 benchmark 的只读快照")
    catalog.add_argument("--output", required=True, type=Path)

    platform_snapshot = subparsers.add_parser(
        "snapshot-platform",
        help="在模型调用前冻结一个平台批次快照；可从指定真实任务提取运行时版本",
    )
    platform_snapshot.add_argument("--platform", required=True, help="a3 或 950pr")
    platform_snapshot.add_argument("--output", required=True, type=Path)
    platform_snapshot.add_argument(
        "--probe-job-id",
        help="可选：一个已结束且与当前平台revision一致的任务，用于提取CANN/PyTorch环境",
    )

    jobs = subparsers.add_parser("list-jobs", help="查询最近任务")
    jobs.add_argument("--limit", type=int, default=10)
    jobs.add_argument("--status", default="")

    get_job = subparsers.add_parser("get-job", help="查询一个任务的状态和结果")
    get_job.add_argument("--job-id", required=True)

    logs = subparsers.add_parser("get-job-logs", help="查询一个任务的日志")
    logs.add_argument("--job-id", required=True)

    rerun_job = subparsers.add_parser(
        "rerun-job", help="基于已有上传内容重新创建一个评测任务"
    )
    rerun_job.add_argument("--job-id", required=True)
    rerun_job.add_argument("--operator", required=True, action="append")
    rerun_job.add_argument("--receipt", required=True, type=Path)
    rerun_job.add_argument(
        "--allow-submit",
        action="store_true",
        help="显式确认本次调用会创建新的平台评测任务",
    )

    poll = subparsers.add_parser("poll-job", help="轮询任务直到结束并保存结果与日志")
    poll.add_argument("--job-id", required=True)
    poll.add_argument("--output", required=True, type=Path)
    poll.add_argument("--interval-seconds", type=int, default=15)
    poll.add_argument("--timeout-seconds", type=int, default=7200)

    submit = subparsers.add_parser("submit", help="提交一个已装配好的工程")
    submit.add_argument("--submission-path", required=True, type=Path)
    submit.add_argument("--platform", required=True, help="a3 或 950pr")
    submit.add_argument("--operator", required=True, action="append")
    submit.add_argument("--receipt", required=True, type=Path)
    submit.add_argument(
        "--private-submission",
        action="store_true",
        help="覆盖平台默认值，使用私有提交（当前仍需要 aggregation scheme）",
    )
    submit.add_argument("--submission-tag")
    submit.add_argument("--aggregation-token", help="当前账号已有 aggregation scheme 的 token")
    submit.add_argument(
        "--allow-submit",
        action="store_true",
        help="显式确认本次调用会消耗平台提交额度",
    )

    validate = subparsers.add_parser("validate-submission", help="本地检查待提交目录，不访问平台")
    validate.add_argument("--submission-path", required=True, type=Path)
    validate.add_argument("--operator", required=True, action="append")
    return parser.parse_args()


def validate_submission_path(submission_path: Path, operators: list[str]) -> dict[str, Any]:
    submission_path = submission_path.resolve()
    if not submission_path.exists():
        raise FileNotFoundError(submission_path)
    if submission_path.is_dir() and not (submission_path / "build.sh").is_file():
        raise ValueError("提交目录根部缺少 build.sh")
    if submission_path.is_file() and submission_path.suffix.lower() != ".zip":
        raise ValueError("提交文件必须是 .zip，或者直接提供包含 build.sh 的目录")
    if submission_path.is_dir():
        for operator in operators:
            op_dir = submission_path / "csrc" / "ops" / operator
            if not op_dir.is_dir():
                raise ValueError(f"提交目录缺少算子目录: {op_dir}")
        files = [path for path in submission_path.rglob("*") if path.is_file()]
        return {
            "status": "ok",
            "submission_path": str(submission_path),
            "operators": operators,
            "file_count": len(files),
            "total_bytes": sum(path.stat().st_size for path in files),
            "build_sh_at_root": True,
        }
    return {
        "status": "ok",
        "submission_path": str(submission_path),
        "operators": operators,
        "archive_bytes": submission_path.stat().st_size,
    }


def validate_submission(args: argparse.Namespace) -> None:
    if not args.allow_submit:
        raise ValueError("真实提交必须显式添加 --allow-submit")
    validate_submission_path(args.submission_path, args.operator)
    if args.receipt.exists():
        raise FileExistsError(f"提交回执已存在，为防止重复提交而停止: {args.receipt}")


def collection_size(value: Any, likely_keys: tuple[str, ...]) -> int | None:
    if isinstance(value, list):
        return len(value)
    if isinstance(value, dict):
        for key in likely_keys:
            items = value.get(key)
            if isinstance(items, list):
                return len(items)
    return None


def find_job_status(value: Any) -> str | None:
    if not isinstance(value, dict):
        return None
    for key in ("status", "state", "job_status"):
        status = value.get(key)
        if isinstance(status, str):
            return status.lower()
    for key in ("job", "data", "result"):
        nested = find_job_status(value.get(key))
        if nested:
            return nested
    return None


def find_job_completed(value: Any) -> bool:
    if not isinstance(value, dict):
        return False
    if value.get("job_completed") is True:
        return True
    return any(
        find_job_completed(value.get(key)) for key in ("job", "data", "result")
    )


def submit_kernel_rest(
    project_dir: Path,
    profile: dict[str, Any],
    op_names: list[str],
    aggregation_token: str,
    server: dict[str, Any],
) -> dict[str, Any]:
    """Submit through REST with an explicit benchmark version and privacy flag."""
    from benchsite_mcp.client import BenchSiteClient
    from benchsite_mcp.zip import prepare_submission_zip

    env = server.get("env", {})
    client = BenchSiteClient(
        base_url=env.get("BENCHSITE_URL", "https://cannbench.com"),
        token=env.get("BENCHSITE_API_TOKEN", ""),
    )
    with prepare_submission_zip(str(project_dir.resolve())) as zip_path:
        client.retries = 1  # Never blindly retry a submission POST after a timeout.
        fields = {"target_hardware": profile["target_hardware"],
                  "selected_operators": json.dumps(op_names),
                  "benchmark_slug": profile["benchmark_slug"],
                  "benchmark_version": profile["benchmark_version"],
                  "submission_tag": profile["submission_tag"],
                  "aggregation_token": aggregation_token,
                  "is_private": str(bool(profile["submission_private"])).lower(),
                  "source": "harness"}
        response = client._post_multipart("/api/submissions", fields, zip_path, mcp_tool="submit_kernel")
    return response


def rerun_job_rest(
    server: dict[str, Any], job_id: str, selected_operators: list[str]
) -> dict[str, Any]:
    """Create a sibling evaluation job from an existing uploaded submission."""
    server_env = server.get("env", {})
    base_url = str(server_env.get("BENCHSITE_URL", "https://cannbench.com")).rstrip("/")
    api_token = str(server_env.get("BENCHSITE_API_TOKEN", ""))
    url = f"{base_url}/api/jobs/{urllib.parse.quote(job_id, safe='')}/rerun"
    body = json.dumps({"selected_operators": selected_operators}).encode()
    request = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {api_token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            value = json.loads(response.read().decode())
    except urllib.error.HTTPError as error:
        error_body = error.read().decode() if error.fp else ""
        value = {"error": True, "status": error.code, "detail": error_body}
    except Exception as error:
        value = {"error": True, "detail": str(error)}
    if isinstance(value, dict) and value.get("error"):
        raise RuntimeError(f"BenchSite API 调用失败: {value}")
    if not isinstance(value, dict):
        raise RuntimeError("BenchSite Rerun 响应格式异常")
    return value


def verify_live_runner_profile(runners: Any, profile: dict[str, Any]) -> dict[str, list[str]]:
    """核对提交前平台状态。返回警告列表。

    硬性拦截：目标硬件没有在线 runner（无法提交）。
    降级为警告：CANN-Bench/benchsite revision 与冻结快照不一致——同代码跨
    revision 曾在旧版复测中差异 <0.01 分；这不证明新 revision 评分不变。当前仅警告，
    但会打印警告便于审计。真正影响算子行为的是运行时版本，由
    verify_job_environment 在评测结果返回后严格核对。
    """
    warnings: list[str] = []
    if not isinstance(runners, dict):
        raise ValueError("BenchSite runner 响应格式异常")
    target = profile["target_hardware"]
    device = next(
        (
            item
            for item in runners.get("devices", [])
            if item.get("hardware") == target and item.get("online") is True
        ),
        None,
    )
    if device is None:
        raise RuntimeError(f"目标硬件当前没有在线 runner: {target}")
    live_refs = {
        runner.get("cann_bench_ref")
        for runner in device.get("runners", [])
        if runner.get("status") == "online" and runner.get("cann_bench_ref")
    }
    if live_refs != {profile["cann_bench_ref"]}:
        warnings.append(
            "CANN-Bench runner revision 与冻结快照不一致 "
            f"(快照={profile['cann_bench_ref']}, 在线={sorted(live_refs)})；"
            "仅旧版本有过小差异复测，新 revision 的评分一致性未验证；请记录当前 revision 和评测版本。"
        )
    for warning in warnings:
        print(f"[runner-verify 警告] {warning}", file=sys.stderr)
    return {"warnings": warnings}


def verify_job_environment(result: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    """评测结果返回后核对 job 实际运行时环境与冻结快照是否一致。

    这是长周期实验中唯一需要硬性拦截的变化：CANN / PyTorch / torch_npu
    任一运行时版本变化都会改变算子编译与数值行为，分数不再可比。
    """
    job = result.get("job", {})
    if isinstance(job, dict) and isinstance(job.get("job"), dict):
        job = job["job"]
    results = job.get("results", {}) if isinstance(job, dict) else {}
    setup = results.get("setup_info", {}) if isinstance(results, dict) else {}
    environment = setup.get("environment", {}) if isinstance(setup, dict) else {}
    if not isinstance(environment, dict) or not environment:
        raise RuntimeError(
            "评测结果缺少 setup_info.environment，无法核对 CANN/PyTorch/torch_npu；"
            "为保证分数可比性，停止后续提交"
        )
    checks = (
        (("cann",), "cann_version"),
        (("pytorch",), "pytorch_version"),
        (("pytorch_npu", "torch_npu"), "torch_npu_version"),
    )
    mismatches: list[str] = []
    expected_versions: dict[str, str] = {}
    actual_versions: dict[str, str] = {}
    for env_keys, profile_key in checks:
        expected = profile.get(profile_key)
        actual_key = next((key for key in env_keys if environment.get(key)), None)
        actual = environment.get(actual_key) if actual_key else None
        if not expected:
            mismatches.append(f"冻结平台配置缺少 {profile_key}")
            continue
        expected_versions[profile_key] = str(expected)
        if not actual:
            mismatches.append(
                f"job setup_info.environment 缺少 {'/'.join(env_keys)}"
            )
            continue
        actual_versions[profile_key] = str(actual)
        # 前缀匹配：profile 记录基础版本（如 2.9.0），job 环境带构建后缀（如 2.9.0+cpu）
        if not str(actual).startswith(str(expected)):
            mismatches.append(
                f"{profile_key}={expected!r} vs 实际 {actual_key}={actual!r}"
            )
    if mismatches:
        raise RuntimeError(
            "评测 job 的运行时版本与冻结快照不一致，分数不可比，停止后续提交: "
            + "; ".join(mismatches)
        )
    return {
        "status": "matched",
        "expected": expected_versions,
        "actual": actual_versions,
        "warnings": [],
    }


def select_live_device(runners: Any, profile: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if not isinstance(runners, dict):
        raise ValueError("BenchSite runner 响应格式异常")
    target = profile["target_hardware"]
    device = next(
        (
            item
            for item in runners.get("devices", [])
            if item.get("hardware") == target and item.get("online") is True
        ),
        None,
    )
    if not isinstance(device, dict):
        raise RuntimeError(f"目标硬件当前没有在线 runner: {target}")
    online_runners = [
        runner
        for runner in device.get("runners", [])
        if isinstance(runner, dict) and runner.get("status") == "online"
    ]
    if not online_runners:
        raise RuntimeError(f"目标硬件没有可用于快照的在线 runner: {target}")
    live_refs = {
        runner.get("cann_bench_ref")
        for runner in online_runners
        if runner.get("cann_bench_ref")
    }
    if len(live_refs) != 1:
        raise RuntimeError(f"在线runner存在多个CANN-Bench revision，停止冻结批次: {sorted(live_refs)}")
    live_ref = next(iter(live_refs))
    if live_ref != profile["cann_bench_ref"]:
        raise RuntimeError(
            "平台CANN-Bench revision与本地配置不一致；请先审查平台变化并更新配置，"
            "Harness不会静默改写正式实验环境"
        )
    return device, online_runners


def select_benchmark(benchmarks: Any, profile: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(benchmarks, dict):
        raise ValueError("BenchSite benchmark 响应格式异常")
    benchmark = next(
        (
            item
            for item in benchmarks.get("benchmarks", [])
            if isinstance(item, dict) and item.get("slug") == profile["benchmark_slug"]
        ),
        None,
    )
    if not isinstance(benchmark, dict):
        raise RuntimeError(f"平台不存在benchmark: {profile['benchmark_slug']}")
    accepted = benchmark.get("accepted_submission_versions", [])
    if profile["benchmark_version"] not in accepted:
        raise RuntimeError(
            f"本地benchmark版本 {profile['benchmark_version']} 不在平台当前可提交版本中: {accepted}"
        )
    return benchmark


def unwrap_job(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("BenchSite job 响应格式异常")
    job = value.get("job")
    if isinstance(job, dict) and isinstance(job.get("job"), dict):
        job = job["job"]
    if isinstance(job, dict):
        return job
    return value


def extract_probe_environment(
    job_response: Any,
    profile: dict[str, Any],
    live_ref: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    job = unwrap_job(job_response)
    status = find_job_status(job)
    if not find_job_completed(job) and not (
        isinstance(status, str)
        and (status in {"completed", "complete", "succeeded", "success", "failed", "error"} or status.endswith("_failed"))
    ):
        raise RuntimeError(f"环境探针任务尚未结束，当前状态: {status}")
    target = job.get("target_hardware") or job.get("runner_hardware")
    if target != profile["target_hardware"]:
        raise RuntimeError(
            f"环境探针任务硬件不匹配: job={target}, expected={profile['target_hardware']}"
        )
    runner = job.get("runner") if isinstance(job.get("runner"), dict) else {}
    job_ref = runner.get("cann_bench_ref")
    if job_ref != live_ref:
        raise RuntimeError(
            f"环境探针任务revision不是当前在线revision: job={job_ref}, live={live_ref}"
        )
    results = job.get("results") if isinstance(job.get("results"), dict) else {}
    setup_info = results.get("setup_info") if isinstance(results.get("setup_info"), dict) else {}
    environment = setup_info.get("environment")
    if not isinstance(environment, dict):
        raise RuntimeError("环境探针任务结果没有 setup_info.environment")
    torch_npu_version = environment.get("torch_npu") or environment.get("pytorch_npu")
    required = ("cann", "pytorch")
    missing = [key for key in required if not environment.get(key)]
    if not torch_npu_version:
        missing.append("torch_npu/pytorch_npu")
    if missing:
        raise RuntimeError(f"环境探针缺少运行时字段: {missing}")
    probe = {
        "job_id": job.get("id"),
        "terminal_status": status,
        "runner_id": runner.get("id") or job.get("runner_id"),
        "runner_name": runner.get("name") or job.get("runner_name"),
        "cann_bench_ref": job_ref,
        "finished_at": job.get("finished_at"),
        "environment": environment,
    }
    normalized_environment = dict(environment)
    normalized_environment["torch_npu"] = str(torch_npu_version)
    return normalized_environment, probe


def snapshot_digest(value: dict[str, Any]) -> str:
    unsigned = dict(value)
    unsigned.pop("snapshot_sha256", None)
    encoded = json.dumps(
        unsigned,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def build_platform_snapshot(
    *,
    profile_name: str,
    profile: dict[str, Any],
    profile_path: Path,
    runners: Any,
    benchmarks: Any,
    probe_job: Any | None,
) -> dict[str, Any]:
    device, online_runners = select_live_device(runners, profile)
    benchmark = select_benchmark(benchmarks, profile)
    live_ref = online_runners[0]["cann_bench_ref"]
    benchsite_refs = sorted(
        {
            runner.get("benchsite_ref")
            for runner in online_runners
            if runner.get("benchsite_ref")
        }
    )
    if len(benchsite_refs) != 1:
        raise RuntimeError(f"在线runner存在多个BenchSite revision，停止冻结批次: {benchsite_refs}")

    frozen_platform = dict(profile)
    runtime_probe = None
    runtime_source = "static_profile_not_runtime_verified"
    if probe_job is not None:
        environment, runtime_probe = extract_probe_environment(probe_job, profile, live_ref)
        frozen_platform["cann_version"] = str(environment["cann"])
        frozen_platform["pytorch_version"] = str(environment["pytorch"])
        frozen_platform["pytorch_reported_version"] = str(environment["pytorch"])
        frozen_platform["torch_npu_version"] = str(environment["torch_npu"])
        runtime_source = "benchsite_job_setup_info"

    snapshot = {
        "schema_version": 1,
        "captured_at": timestamp(),
        "platform_profile": profile_name,
        "platform_config_path": str(profile_path),
        "platform": frozen_platform,
        "runtime_source": runtime_source,
        "runtime_probe": runtime_probe,
        "live": {
            "target_hardware": device.get("hardware"),
            "hardware_label": device.get("label"),
            "online_runner_count": len(online_runners),
            "online_runner_ids": [runner.get("id") for runner in online_runners],
            "cann_bench_ref": live_ref,
            "benchsite_ref": benchsite_refs[0],
        },
        "benchmark": {
            "slug": benchmark.get("slug"),
            "submission_version": benchmark.get("submission_version"),
            "accepted_submission_versions": benchmark.get("accepted_submission_versions"),
            "operator_count": benchmark.get("operator_count"),
            "total_case_count": benchmark.get("total_case_count"),
        },
    }
    snapshot["snapshot_sha256"] = snapshot_digest(snapshot)
    return snapshot


def poll_job(
    client: StdioMcpClient,
    job_id: str,
    output: Path,
    interval_seconds: int,
    timeout_seconds: int,
) -> dict[str, Any]:
    if interval_seconds < 5 or interval_seconds > 60:
        raise ValueError("轮询间隔必须在 5 到 60 秒之间")
    if timeout_seconds < interval_seconds:
        raise ValueError("轮询超时必须大于轮询间隔")
    if output.exists():
        raise FileExistsError(f"结果文件已存在，为避免覆盖而停止: {output}")

    terminal = {"completed", "complete", "succeeded", "success", "failed", "error", "cancelled", "canceled"}
    started = time.monotonic()
    snapshots: list[dict[str, Any]] = []

    def call_with_transient_retry(tool_name: str, arguments: dict[str, Any]) -> Any:
        """Retry transport-level EOF/SSL resets without retrying a job submission."""
        retry_count = 0
        while True:
            try:
                value = client.call_tool(tool_name, arguments)
                return value
            except RuntimeError as error:
                message = str(error).lower()
                retryable = any(
                    marker in message
                    for marker in (
                        "unexpected_eof",
                        "ssl",
                        "connection reset",
                        "connection aborted",
                        "timed out",
                        "urlopen error",
                    )
                )
                if not retryable or retry_count >= 8:
                    raise
                retry_count += 1
                snapshots.append(
                    {
                        "checked_at": timestamp(),
                        "status": "poll_transport_retry",
                        "tool": tool_name,
                        "retry_number": retry_count,
                        "error": str(error),
                    }
                )
                elapsed = time.monotonic() - started
                remaining = max(1.0, timeout_seconds - elapsed)
                backoff = min(float(interval_seconds) * (2 ** min(retry_count - 1, 3)), 60.0)
                time.sleep(min(backoff, remaining))

    while True:
        job = call_with_transient_retry("get_job", {"job_id": job_id})
        status = find_job_status(job)
        snapshots.append({"checked_at": timestamp(), "status": status})
        if status in terminal or (status is not None and status.endswith("_failed")) or find_job_completed(job):
            logs = call_with_transient_retry("get_job_logs", {"job_id": job_id})
            result = {
                "job_id": job_id,
                "terminal_status": status,
                "job": job,
                "logs": logs,
                "poll_snapshots": snapshots,
            }
            write_json(output, result)
            return result
        if time.monotonic() - started >= timeout_seconds:
            result = {
                "job_id": job_id,
                "terminal_status": None,
                "timed_out": True,
                "last_job": job,
                "poll_snapshots": snapshots,
            }
            write_json(output, result)
            return result
        time.sleep(interval_seconds)


def main() -> None:
    args = parse_args()
    server = load_benchsite_server(args.config.resolve())
    platform_profile = None
    if args.action == "validate-submission":
        print(
            json.dumps(
                validate_submission_path(args.submission_path, args.operator),
                ensure_ascii=False,
                indent=2,
            )
        )
        return
    if args.action in {"submit", "verify-platform", "snapshot-platform"}:
        platform_profile = load_platform_profile(
            args.platform_config.resolve(), args.platform
        )
    if args.action == "submit":
        validate_submission(args)
        if not args.aggregation_token or not args.aggregation_token.strip():
            raise ValueError("BenchSite aggregation scheme 未配置；请传入已有 scheme 的 --aggregation-token")

    if args.action == "rerun-job":
        if not args.allow_submit:
            raise ValueError("创建新的 Rerun 任务必须显式添加 --allow-submit")
        request = {"selected_operators": args.operator}
        response = rerun_job_rest(server, args.job_id, args.operator)
        job = response.get("job") if isinstance(response, dict) else None
        if not isinstance(job, dict) or not job.get("id"):
            raise RuntimeError("BenchSite Rerun 响应缺少 job.id")
        receipt = {
            "submitted_at": timestamp(),
            "request": request,
            "response": response,
            "response_source": "benchsite_rest_rerun_job",
            "mcp_config_source": server["source"],
            "original_job_id": args.job_id,
        }
        write_json(args.receipt.resolve(), receipt)
        print(
            json.dumps(
                {
                    "original_job_id": args.job_id,
                    "job_id": job["id"],
                    "receipt": str(args.receipt.resolve()),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return

    with StdioMcpClient(server) as client:
        if args.action == "doctor":
            tools = client.list_tools()
            print(
                json.dumps(
                    {
                        "status": "ok",
                        "transport": "stdio",
                        "config_source": server["source"],
                        "server_command": server["command"],
                        "tool_names": [tool["name"] for tool in tools],
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return

        if args.action == "probe":
            identity = client.call_tool("whoami", {})
            runners = client.call_tool("list_runners", {})
            benchmarks = client.call_tool("list_benchmarks", {})
            print(
                json.dumps(
                    {
                        "status": "ok",
                        "authenticated": isinstance(identity, dict) and bool(identity),
                        "runners_count": collection_size(runners, ("runners", "items", "data")),
                        "benchmarks_count": collection_size(
                            benchmarks, ("benchmarks", "items", "data")
                        ),
                        "note": "只读探测成功；未创建提交任务。",
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return

        if args.action == "verify-platform":
            if platform_profile is None:
                raise AssertionError("缺少平台配置")
            verify_result = verify_live_runner_profile(
                client.call_tool("list_runners", {}), platform_profile
            )
            print(
                json.dumps(
                    {
                        "status": "ok",
                        "platform_profile": args.platform,
                        "target_hardware": platform_profile["target_hardware"],
                        "hardware_label": platform_profile.get("hardware_label"),
                        "cann_version": platform_profile.get("cann_version"),
                        "torch_npu_version": platform_profile.get("torch_npu_version"),
                        "benchmark": (
                            f"{platform_profile['benchmark_slug']} "
                            f"{platform_profile['benchmark_version']}"
                        ),
                        "submission_private": platform_profile["submission_private"],
                        "submission_tag": platform_profile["submission_tag"],
                        "runner_warnings": verify_result.get("warnings", []),
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return

        if args.action == "snapshot-catalog":
            output = args.output.resolve()
            if output.exists():
                raise FileExistsError(f"平台目录快照已存在，为避免覆盖而停止: {output}")
            runners = client.call_tool("list_runners", {})
            benchmarks = client.call_tool("list_benchmarks", {})
            snapshot = {
                "captured_at": timestamp(),
                "runners": runners,
                "benchmarks": benchmarks,
            }
            write_json(output, snapshot)
            print(
                json.dumps(
                    {
                        "status": "ok",
                        "output": str(output),
                        "runners_count": collection_size(runners, ("runners", "items", "data")),
                        "benchmarks_count": collection_size(
                            benchmarks, ("benchmarks", "items", "data")
                        ),
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return

        if args.action == "snapshot-platform":
            if platform_profile is None:
                raise AssertionError("缺少平台配置")
            output = args.output.resolve()
            if output.exists():
                raise FileExistsError(f"平台快照已存在，为避免覆盖而停止: {output}")
            runners = client.call_tool("list_runners", {})
            benchmarks = client.call_tool("list_benchmarks", {})
            probe_job = (
                client.call_tool("get_job", {"job_id": args.probe_job_id})
                if args.probe_job_id
                else None
            )
            snapshot = build_platform_snapshot(
                profile_name=args.platform,
                profile=platform_profile,
                profile_path=args.platform_config.resolve(),
                runners=runners,
                benchmarks=benchmarks,
                probe_job=probe_job,
            )
            write_json(output, snapshot)
            print(
                json.dumps(
                    {
                        "status": "ok",
                        "output": str(output),
                        "snapshot_sha256": snapshot["snapshot_sha256"],
                        "runtime_source": snapshot["runtime_source"],
                        "cann_version": snapshot["platform"].get("cann_version"),
                        "pytorch_version": snapshot["platform"].get("pytorch_version"),
                        "torch_npu_version": snapshot["platform"].get("torch_npu_version"),
                        "cann_bench_ref": snapshot["live"]["cann_bench_ref"],
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return

        if args.action == "whoami":
            result = client.call_tool("whoami", {})
        elif args.action == "get-credits":
            result = client.call_tool("get_credits", {})
        elif args.action == "list-runners":
            result = client.call_tool("list_runners", {})
        elif args.action == "list-benchmarks":
            result = client.call_tool("list_benchmarks", {})
        elif args.action == "list-jobs":
            result = client.call_tool("list_jobs", {"limit": args.limit, "status": args.status})
        elif args.action == "get-job":
            result = client.call_tool("get_job", {"job_id": args.job_id})
        elif args.action == "get-job-logs":
            result = client.call_tool("get_job_logs", {"job_id": args.job_id})
        elif args.action == "poll-job":
            result = poll_job(
                client,
                args.job_id,
                args.output.resolve(),
                args.interval_seconds,
                args.timeout_seconds,
            )
            job = result.get("job", {}) if isinstance(result, dict) else {}
            if isinstance(job, dict) and isinstance(job.get("job"), dict):
                job = job["job"]
            print(
                json.dumps(
                    {
                        "job_id": args.job_id,
                        "terminal_status": result.get("terminal_status"),
                        "result_score": job.get("result_score") if isinstance(job, dict) else None,
                        "passed_cases": job.get("passed_cases") if isinstance(job, dict) else None,
                        "total_cases": job.get("total_cases") if isinstance(job, dict) else None,
                        "output": str(args.output.resolve()),
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return
        elif args.action == "submit":
            if platform_profile is None:
                raise AssertionError("缺少平台配置")
            verify_live_runner_profile(client.call_tool("list_runners", {}), platform_profile)
            effective_private = bool(
                args.private_submission or platform_profile["submission_private"]
            )
            effective_tag = str(args.submission_tag or platform_profile["submission_tag"])
            request = {
                "submission_path": str(args.submission_path.resolve()),
                "target_hardware": platform_profile["target_hardware"],
                "selected_operators": args.operator,
                "benchmark_slug": platform_profile["benchmark_slug"],
                "benchmark_version": platform_profile["benchmark_version"],
                "submission_tag": effective_tag,
                "is_private": effective_private,
                "aggregation_token": args.aggregation_token.strip(),
            }
            select_benchmark(client.call_tool("list_benchmarks", {}), platform_profile)
            result = submit_kernel_rest(args.submission_path,
                {**platform_profile, "submission_private": effective_private, "submission_tag": effective_tag},
                args.operator, args.aggregation_token.strip(), server)
            write_json(
                args.receipt.resolve(),
                {
                    "submitted_at": timestamp(),
                    "request": request,
                    "response": result,
                    "mcp_config_source": server["source"],
                    "platform_profile": args.platform,
                    "expected_cann_bench_ref": platform_profile["cann_bench_ref"],
                },
            )
        else:
            raise AssertionError(args.action)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
