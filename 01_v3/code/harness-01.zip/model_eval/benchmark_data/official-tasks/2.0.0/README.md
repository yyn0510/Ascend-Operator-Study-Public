# official-tasks 2.0.0 公开任务材料

后续新实验固定使用此版本。来源：CANNBench 公开 reference 下载接口，2026-10-24 获取；只包含公开任务材料，不含隐藏用例、完整算子实现或额外公共参考资料。

- 共 60 个算子、1,200 个公开 case：Level 1/2/3/4/5 分别 2/13/27/13/5 个。
- Level 1 仅 `exp`、`swi_glu`；Level 2 保留 `softmax`、`scatter` 等 13 个算子。
- `tasks/<level>/<operator>/` 的 proto.yaml、desc.md、golden.py、cases.yaml 为下载原文，240 份文件均记录 SHA-256。不从旧 cases.csv 补充数据。
- `release.json` 固定平台版本 ID、公开包 SHA-256、任务集合、case 数和文件指纹。下载时核对平台 submission_version=2.0.0，并以目录任务集合与 case 数核对 reference 包；公开下载接口按当时默认版本提供文件，不能声称 URL 自身永久绑定版本。后续运行只读取本地冻结文件，不重复跟随在线默认包。
- `catalog.json` 是当时的目录快照；`local_legacy_comparison.json` 比较当前本地旧 tasks/，不代表服务器完整的 1.1.2 历史包差异。

原项目 tasks/ 和历史轨迹保持原样。下一版 Harness 自动使用本目录；提示词生成入口也会将同名任务解析到本目录，已移除任务直接拒绝。当前下一版 runner 的等级入口仍支持 Level 1/2；保存全部公开材料不等于已验证 Level 3–5 的完整运行流程。

后续平台出现新默认版本时，仍显式提交 2.0.0；2.0.0 不可用时停止，不自动切换。旧工作区无 2.0.0 契约时不能直接 resume 或创建新版本研究分支。

评分说明独立记录在 scoring_rules.json：5分编译／运行、20分基础正确性、5分全通过奖励、70分HAP性能，包含公开代码revision、来源指纹和与实际Runner源码不可完全对应的边界。任务原文与release.json不因评分说明同步而重写。
