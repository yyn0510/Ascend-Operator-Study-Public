from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
from pathlib import Path

import yaml

from modelscope_common import ROOT, timestamp, write_json


PROJECT_ROOT = ROOT.parent
DEFAULT_TEMPLATE = PROJECT_ROOT / "文档" / "提示词模板" / "算子生成提示词模板.md"
DEFAULT_PLATFORM_CONFIG = ROOT / "platform_profiles.yaml"
PLACEHOLDER_PATTERN = re.compile(r"\{\{[A-Z_]+\}\}")
PROMPT_TEMPLATE_ID = "canonical"
PROMPT_TEMPLATE_IDS = (
    "canonical",
    "one_shot_add",
    "one_shot_add_cann91_a3",
    "iterative_one_shot_add",
    "iterative_one_shot_add_v2",
    "iterative_one_shot_add_v3",
)
ONE_SHOT_FRAGMENT = (
    PROJECT_ROOT / "文档" / "提示词模板" / "算子生成提示词附加段-one-shot-add.md"
)
CANN91_A3_FRAGMENT = (
    PROJECT_ROOT / "文档" / "算子生成提示词附加段-CANN9.1-A3公共参考.md"
)
ADD_EXAMPLE_ROOT = PROJECT_ROOT / "examples" / "direct_launch_example"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="把固定提示词模板与一个 CannBench 任务目录拼成完整提示词。"
    )
    parser.add_argument("--task-dir", required=True, type=Path, help="任务材料目录")
    parser.add_argument(
        "--template",
        type=Path,
        default=DEFAULT_TEMPLATE,
        help="提示词模板路径",
    )
    parser.add_argument(
        "--template-version",
        choices=PROMPT_TEMPLATE_IDS,
        default=PROMPT_TEMPLATE_ID,
        help=(
            "canonical；加入完整 add one-shot 的 one_shot_add；"
            "或再加入统一 CANN 9.1/A3 公共参考的 one_shot_add_cann91_a3"
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="输出目录；默认 model_eval/prompts/<op_name>",
    )
    parser.add_argument(
        "--platform",
        required=True,
        help="平台配置名，例如 a3 或 950pr",
    )
    parser.add_argument(
        "--platform-config",
        type=Path,
        default=DEFAULT_PLATFORM_CONFIG,
        help="A3/950PR 环境配置 YAML",
    )
    parser.add_argument(
        "--platform-snapshot",
        type=Path,
        help="由snapshot-platform冻结的批次平台快照；提供后以其中已核验的运行时版本渲染",
    )
    parser.add_argument(
        "--iterative-rounds",
        type=int,
        default=10,
        help="仅用于 iterative 模板，冻结反馈迭代总轮数（默认10）",
    )
    return parser.parse_args()


def read_required(path: Path) -> str:
    if not path.is_file():
        raise FileNotFoundError(f"缺少任务材料: {path}")
    return path.read_text(encoding="utf-8-sig").rstrip() + "\n"


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def snapshot_digest(value: dict) -> str:
    unsigned = dict(value)
    unsigned.pop("snapshot_sha256", None)
    encoded = json.dumps(
        unsigned,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def strip_case_performance(path: Path, content: str) -> str:
    """Remove performance answers while preserving public functional cases."""
    hidden_fields = {"baseline_perf_us", "t_hw_us"}

    def strip_note(value):
        if not isinstance(value, str):
            return value
        return re.split(
            r"\s*\|\s*baseline_kernels\s*:", value, maxsplit=1,
            flags=re.IGNORECASE,
        )[0].rstrip()

    if path.suffix.lower() in {".yaml", ".yml"}:
        data = yaml.safe_load(content)
        cases = data.get("cases", []) if isinstance(data, dict) else []
        for case in cases:
            if isinstance(case, dict):
                for field in hidden_fields:
                    case.pop(field, None)
                if "note" in case:
                    case["note"] = strip_note(case["note"])
        return yaml.safe_dump(data, allow_unicode=True, sort_keys=False).rstrip()

    reader = csv.DictReader(io.StringIO(content))
    fieldnames = [name for name in (reader.fieldnames or []) if name not in hidden_fields]
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    for row in reader:
        if "note" in row:
            row["note"] = strip_note(row["note"])
        writer.writerow({name: row.get(name, "") for name in fieldnames})
    return output.getvalue().rstrip()


def main() -> None:
    args = parse_args()
    task_dir = args.task_dir.resolve()
    template_path = args.template.resolve()
    platform_config_path = args.platform_config.resolve()
    op_name = task_dir.name
    level = task_dir.parent.name

    platform_config = yaml.safe_load(
        platform_config_path.read_text(encoding="utf-8-sig")
    )
    profiles = platform_config.get("profiles", {})
    if args.platform not in profiles:
        raise ValueError(
            f"未知平台配置 {args.platform!r}，可用配置: {sorted(profiles)}"
        )
    platform = dict(profiles[args.platform])
    platform_snapshot_path = args.platform_snapshot.resolve() if args.platform_snapshot else None
    platform_snapshot = None
    if platform_snapshot_path is not None:
        platform_snapshot = json.loads(
            platform_snapshot_path.read_text(encoding="utf-8-sig")
        )
        if platform_snapshot.get("platform_profile") != args.platform:
            raise ValueError(
                "平台快照与--platform不匹配: "
                f"snapshot={platform_snapshot.get('platform_profile')}, requested={args.platform}"
            )
        stored_digest = platform_snapshot.get("snapshot_sha256")
        actual_digest = snapshot_digest(platform_snapshot)
        if not stored_digest or stored_digest != actual_digest:
            raise ValueError("平台快照哈希缺失或不匹配，拒绝渲染")
        snapshot_platform = platform_snapshot.get("platform")
        if not isinstance(snapshot_platform, dict):
            raise ValueError("平台快照缺少platform对象")
        platform = dict(snapshot_platform)
    required_platform_fields = (
        "target_hardware",
        "hardware_label",
        "soc_model",
        "npu_arch",
        "bisheng_npu_arch",
        "cann_version",
        "pytorch_version",
        "torch_npu_version",
        "benchmark_slug",
        "benchmark_version",
        "cann_bench_ref",
    )
    missing_platform_fields = [
        field for field in required_platform_fields if not platform.get(field)
    ]
    if missing_platform_fields:
        raise ValueError(f"平台配置缺少字段: {missing_platform_fields}")

    from next_harness.benchmark_release import BENCHMARK_VERSION, task_release
    if platform["benchmark_version"] != BENCHMARK_VERSION:
        raise ValueError("new prompts require official-tasks 2.0.0; do not reuse an old platform snapshot")
    task_dir, benchmark_release = task_release(level, op_name)
    cases_yaml = task_dir / "cases.yaml"
    cases_csv = task_dir / "cases.csv"
    if cases_yaml.is_file():
        cases_path = cases_yaml
    elif cases_csv.is_file():
        cases_path = cases_csv
    else:
        raise FileNotFoundError("任务目录中既没有 cases.yaml，也没有 cases.csv")

    template_text = read_required(template_path)
    source_paths = {
        "template": template_path,
        "proto.yaml": task_dir / "proto.yaml",
        "desc.md": task_dir / "desc.md",
        "golden.py": task_dir / "golden.py",
        cases_path.name: cases_path,
    }
    add_one_shot_versions = {
        "one_shot_add",
        "one_shot_add_cann91_a3",
        "iterative_one_shot_add",
        "iterative_one_shot_add_v2",
        "iterative_one_shot_add_v3",
    }
    if args.template_version in add_one_shot_versions:
        source_paths.update(
            {
                "one_shot_fragment": ONE_SHOT_FRAGMENT,
                "add_kernel.cpp": ADD_EXAMPLE_ROOT / "csrc" / "ops" / "add" / "op_kernel" / "add_kernel.cpp",
                "add_launch.h": ADD_EXAMPLE_ROOT / "csrc" / "ops" / "add" / "op_kernel" / "add_launch.h",
                "add_plugin.cpp": ADD_EXAMPLE_ROOT / "csrc" / "ops" / "add" / "op_plugin" / "add_plugin.cpp",
                "add_CMakeLists.txt": ADD_EXAMPLE_ROOT / "csrc" / "ops" / "add" / "CMakeLists.txt",
                "add_python_append": ROOT / "examples" / "add_one_shot" / "cann_bench__init__.py.append",
            }
        )
    if args.template_version == "one_shot_add_cann91_a3":
        if args.platform != "a3":
            raise ValueError(
                "one_shot_add_cann91_a3 只适用于 a3；其他平台需要独立核验并冻结参考"
            )
        source_paths["cann91_a3_fragment"] = CANN91_A3_FRAGMENT
    if platform_snapshot_path is not None:
        source_paths["platform_snapshot.json"] = platform_snapshot_path
    source_text = {name: read_required(path) for name, path in source_paths.items()}
    prompt_template_version = args.template_version
    cases_for_prompt = strip_case_performance(
        cases_path, source_text[cases_path.name]
    )

    replacements = {
        "{{OP_NAME}}": op_name,
        "{{LEVEL}}": level,
        "{{PROTO_YAML}}": source_text["proto.yaml"].rstrip(),
        "{{DESC_MD}}": source_text["desc.md"].rstrip(),
        "{{GOLDEN_PY}}": source_text["golden.py"].rstrip(),
        "{{CASES_FILENAME}}": cases_path.name,
        "{{CASES_CONTENT}}": cases_for_prompt,
        "{{TARGET_HARDWARE}}": str(platform["target_hardware"]),
        "{{HARDWARE_LABEL}}": str(platform["hardware_label"]),
        "{{SOC_MODEL}}": str(platform["soc_model"]),
        "{{NPU_ARCH}}": str(platform["npu_arch"]),
        "{{BISHENG_NPU_ARCH}}": str(platform["bisheng_npu_arch"]),
        "{{CANN_VERSION}}": str(platform["cann_version"]),
        "{{PYTORCH_VERSION}}": str(platform["pytorch_version"]),
        "{{TORCH_NPU_VERSION}}": str(platform["torch_npu_version"]),
        "{{BENCHMARK_SLUG}}": str(platform["benchmark_slug"]),
        "{{BENCHMARK_VERSION}}": str(platform["benchmark_version"]),
    }

    rendered = source_text["template"]
    for placeholder, value in replacements.items():
        rendered = rendered.replace(placeholder, value)

    if prompt_template_version in (
        "iterative_one_shot_add",
        "iterative_one_shot_add_v2",
        "iterative_one_shot_add_v3",
    ):
        if args.iterative_rounds < 2:
            raise ValueError("iterative_one_shot_add 的轮数必须至少为2")
        single_turn_intro = (
            "你必须在一次独立、无工具、无反馈的回答中，根据下方任务材料生成一个完整的 "
            "Ascend C Direct Launch 算子。你不能读取或修改本地文件，不能调用终端、编译器、"
            "测试程序、网络或评测平台，也不能获得生成后的编译日志、运行结果或评分反馈。"
        )
        iterative_intro = (
            f"这是固定{args.iterative_rounds}轮评测轨迹的第 1 轮。你必须在无工具条件下，根据下方任务材料生成一个完整的 "
            "Ascend C Direct Launch 算子。你不能读取或修改本地文件，不能调用终端、编译器、测试程序、"
            "网络或评测平台。外部 Harness 会机械提交本轮五文件；后续轮次只会向你提供上一轮完整源码和"
            "由同一规则生成的平台评测反馈。你应在每一轮都提交当前能完成的最佳实现，不得为等待反馈而"
            "故意保留问题。"
        )
        single_turn_task = (
            "一次性输出你能完成的最佳实现；不要请求第二轮修改，不要输出分析过程、构建命令、测试代码或"
            "提交说明。输出文件中不得包含 TODO、省略号、占位函数或空 kernel。"
        )
        iterative_task = (
            "本轮输出你能完成的最佳实现；不要请求额外信息，不要输出分析过程、构建命令、测试代码或提交"
            "说明。后续每轮即使只修改一个文件，也必须重新输出完整五文件快照。输出文件中不得包含 TODO、"
            "省略号、占位函数或空 kernel。"
        )
        if single_turn_intro not in rendered or single_turn_task not in rendered:
            raise RuntimeError("基础模板中的单轮声明发生变化，无法安全派生十轮初始提示词")
        rendered = rendered.replace(single_turn_intro, iterative_intro, 1)
        rendered = rendered.replace(single_turn_task, iterative_task, 1)
        rendered = rendered.replace(
            "# CANN-Bench 裸基模算子生成提示词模板（canonical）",
            f"# CANN-Bench {args.iterative_rounds}轮平台反馈迭代：第 1 轮提示词",
            1,
        )
        rendered = rendered.replace("## 6. 最终回答格式", "## 6. 每轮回答格式", 1)
        rendered = rendered.replace(
            "最终回答只能包含以下五个文件块",
            "本轮回答只能包含以下五个文件块",
            1,
        )
        if prompt_template_version in (
            "iterative_one_shot_add_v2",
            "iterative_one_shot_add_v3",
        ):
            change_summary_section = (
                "\n\n## 7. 每轮改动简述\n\n"
                "在五个文件块全部结束后，追加一个改动简述块：\n\n"
                "```text\n"
                "=== CHANGE SUMMARY ===\n"
                "<本轮改动简述>\n"
                "=== END CHANGE SUMMARY ===\n"
                "```\n\n"
                "规则：\n\n"
                "- 第 1 轮简述主要实现方案；后续轮次只写\"针对什么平台反馈，修改了什么\"；\n"
                "- 最多 300 个 Unicode 字符，一段话即可；不要求原因分析，不要求输出思维过程；\n"
                "- 该块不是第六个文件，Harness 只提取它用于历轮尝试记录；\n"
                "- 缺失或超长只记录格式违规，不影响五文件提交；\n"
                "- 每轮仍必须输出完整五文件快照，改动简述不能替代任何文件。\n"
            )
            rendered = rendered.rstrip() + change_summary_section

    insertion_blocks = []
    if prompt_template_version in add_one_shot_versions:
        one_shot = source_text["one_shot_fragment"]
        one_shot_replacements = {
            "{{ADD_KERNEL_CPP}}": source_text["add_kernel.cpp"].rstrip(),
            "{{ADD_LAUNCH_H}}": source_text["add_launch.h"].rstrip(),
            "{{ADD_PLUGIN_CPP}}": source_text["add_plugin.cpp"].rstrip(),
            "{{ADD_CMAKELISTS}}": source_text["add_CMakeLists.txt"].rstrip(),
            "{{ADD_PYTHON_APPEND}}": source_text["add_python_append"].rstrip(),
        }
        for placeholder, value in one_shot_replacements.items():
            one_shot = one_shot.replace(placeholder, value)
        insertion_blocks.append(one_shot.rstrip())
    if prompt_template_version == "one_shot_add_cann91_a3":
        insertion_blocks.append(source_text["cann91_a3_fragment"].rstrip())

    if insertion_blocks:
        insertion_anchor = "## 3. CANN-Bench 任务材料"
        if insertion_anchor not in rendered:
            raise RuntimeError(f"基础模板缺少附加段插入锚点: {insertion_anchor}")
        rendered = rendered.replace(
            insertion_anchor,
            "\n\n".join(insertion_blocks) + "\n\n" + insertion_anchor,
            1,
        )

    from next_harness.scoring_rules import scoring_guidance, scoring_contract
    rendered += "\n\n## 评测计分口径（official-tasks 2.0.0）\n\n" + scoring_guidance() + "\n"
    unresolved = sorted(set(PLACEHOLDER_PATTERN.findall(rendered)))
    if unresolved:
        raise RuntimeError(f"仍有未替换占位符: {unresolved}")

    output_dir = (
        args.output_dir.resolve()
        if args.output_dir
        else ROOT / "prompts" / op_name / args.platform / prompt_template_version
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    prompt_path = output_dir / "rendered_prompt.txt"
    metadata_path = output_dir / "render_metadata.json"
    prompt_path.write_text(rendered, encoding="utf-8")

    lower_rendered = rendered.lower()
    forbidden_markers = [
        marker
        for marker in (
            "api-inference.modelscope.cn",
            "modelscope_sdk_token",
            "benchsite",
        )
        if marker in lower_rendered
    ]
    desc_contains_golden = f"def {op_name}(" in source_text["desc.md"]
    metadata = {
        "benchmark_release": benchmark_release,
        "scoring_contract": scoring_contract(),
        "rendered_at": timestamp(),
        "task_dir": str(task_dir),
        "op_name": op_name,
        "level": level,
        "platform_profile": args.platform,
        "prompt_template_version": prompt_template_version,
        "implementation_example": (
            "complete_public_add_five_file_one_shot"
            if prompt_template_version in add_one_shot_versions
            else None
        ),
        "public_api_reference": (
            "cann_9_1_atlas_a3_static_compile_reference"
            if prompt_template_version == "one_shot_add_cann91_a3"
            else None
        ),
        "interaction_mode": (
            "ten_round_rolling_platform_feedback"
            if prompt_template_version == "iterative_one_shot_add"
            else (
                "iterative_rolling_platform_feedback_change_summary"
                if prompt_template_version == "iterative_one_shot_add_v2"
                else (
                    "iterative_rolling_platform_feedback_change_summary_v3"
                    if prompt_template_version == "iterative_one_shot_add_v3"
                    else "single_turn_no_feedback"
                )
            )
        ),
        "iterative_rounds": (
            args.iterative_rounds
            if prompt_template_version in (
                "iterative_one_shot_add",
                "iterative_one_shot_add_v2",
                "iterative_one_shot_add_v3",
            )
            else None
        ),
        "platform_config_path": str(platform_config_path),
        "platform_snapshot_path": str(platform_snapshot_path) if platform_snapshot_path else None,
        "platform_snapshot_sha256": (
            platform_snapshot.get("snapshot_sha256") if platform_snapshot else None
        ),
        "platform_runtime_source": (
            platform_snapshot.get("runtime_source") if platform_snapshot else "static_profile"
        ),
        "platform": platform,
        "cases_file": cases_path.name,
        "case_performance_fields_removed": [
            "baseline_perf_us", "t_hw_us", "note.baseline_kernels"
        ],
        "prompt_path": str(prompt_path),
        "prompt_characters": len(rendered),
        "prompt_utf8_bytes": len(rendered.encode("utf-8")),
        "prompt_lines": rendered.count("\n") + 1,
        "prompt_sha256": sha256_text(rendered),
        "unresolved_placeholders": unresolved,
        "forbidden_platform_markers": forbidden_markers,
        "desc_contains_embedded_golden_function": desc_contains_golden,
        "duplicate_material_note": (
            "desc.md 内含同名 Golden 函数，且 golden.py 仍按原始材料完整提供。"
            if desc_contains_golden
            else None
        ),
        "sources": {
            name: {
                "path": str(path),
                "sha256": sha256_text(source_text[name]),
                "characters": len(source_text[name]),
            }
            for name, path in source_paths.items()
        },
    }
    write_json(metadata_path, metadata)

    print(f"算子: {op_name}")
    print(f"等级: {level}")
    print(f"平台: {args.platform} ({platform['target_hardware']})")
    print(
        "平台来源: "
        + (
            f"冻结快照 {platform_snapshot_path}"
            if platform_snapshot_path
            else f"静态配置 {platform_config_path}"
        )
    )
    print(f"提示词版本: {prompt_template_version}")
    print(f"cases: {cases_path.name}")
    print(f"提示词字符数: {len(rendered)}")
    print(f"提示词 UTF-8 字节数: {len(rendered.encode('utf-8'))}")
    print(f"未替换占位符: {len(unresolved)}")
    print(f"平台敏感标记: {len(forbidden_markers)}")
    print(f"desc 内嵌 Golden: {'是' if desc_contains_golden else '否'}")
    print(f"提示词: {prompt_path}")
    print(f"元数据: {metadata_path}")


if __name__ == "__main__":
    main()
