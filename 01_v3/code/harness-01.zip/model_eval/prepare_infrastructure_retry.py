from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import yaml

from assemble_submission import configure_platform_build, tree_hash
from modelscope_common import timestamp, write_json


ROOT = Path(__file__).resolve().parent
DEFAULT_PLATFORM_CONFIG = ROOT / "platform_profiles.yaml"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="只修正统一工程骨架，不修改模型源码，准备可审计的基础设施重试。"
    )
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--retry-number", type=int, default=1)
    parser.add_argument("--platform-config", type=Path, default=DEFAULT_PLATFORM_CONFIG)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run_dir = args.run_dir.resolve()
    if args.retry_number < 1:
        raise ValueError("retry-number 必须大于 0")
    source_project = run_dir / "submission_project"
    retry_name = f"infrastructure_retry_{args.retry_number:03d}"
    retry_project = run_dir / f"submission_project_{retry_name}"
    manifest_path = run_dir / f"{retry_name}_manifest.json"
    if retry_project.exists() or manifest_path.exists():
        raise FileExistsError(f"基础设施重试产物已存在: {retry_name}")

    render_metadata = json.loads(
        (run_dir / "render_metadata.json").read_text(encoding="utf-8-sig")
    )
    profile_name = render_metadata["platform_profile"]
    config = yaml.safe_load(
        args.platform_config.resolve().read_text(encoding="utf-8-sig")
    )
    profile = config["profiles"][profile_name]

    shutil.copytree(source_project, retry_project)
    source_model_tree = source_project / "csrc" / "ops"
    retry_model_tree = retry_project / "csrc" / "ops"
    source_model_hash = tree_hash(source_model_tree)
    platform_build = configure_platform_build(retry_project, profile)
    retry_model_hash = tree_hash(retry_model_tree)
    if source_model_hash != retry_model_hash:
        raise RuntimeError("基础设施重试意外修改了模型算子源码")

    original_receipt = json.loads(
        (run_dir / "submission_receipt.json").read_text(encoding="utf-8-sig")
    )
    manifest = {
        "prepared_at": timestamp(),
        "classification": "invalid_infrastructure_retry",
        "reason": "fixed A3 skeleton used unsupported dav-2203; CANN 9.0.0 requires dav-2201",
        "original_job_id": original_receipt.get("response", {}).get("job", {}).get("id"),
        "source_project": str(source_project),
        "retry_project": str(retry_project),
        "platform_profile": profile_name,
        "platform_build": platform_build,
        "model_source_hash_before": source_model_hash,
        "model_source_hash_after": retry_model_hash,
        "model_source_unchanged": True,
    }
    write_json(manifest_path, manifest)
    print(f"基础设施重试工程: {retry_project}")
    print(f"模型源码未变化: {source_model_hash}")


if __name__ == "__main__":
    main()
