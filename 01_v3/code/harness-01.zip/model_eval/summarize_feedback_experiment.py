from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path
from typing import Any, Callable

from modelscope_common import timestamp, write_json


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    return value if isinstance(value, dict) else {}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="汇总多轮平台反馈实验。")
    parser.add_argument("--experiment-dir", required=True, type=Path)
    return parser.parse_args()


def first_round(
    rounds: list[dict[str, Any]], predicate: Callable[[dict[str, Any]], bool]
) -> int | None:
    for item in rounds:
        if predicate(item):
            return int(item["round"])
    return None


def best_so_far(rounds: list[dict[str, Any]], expected_rounds: int) -> list[float | None]:
    score_by_round = {
        int(item["round"]): float(item["score"])
        for item in rounds
        if item.get("status") == "round_completed" and item.get("score") is not None
    }
    running: float | None = None
    curve: list[float | None] = []
    for round_number in range(1, expected_rounds + 1):
        score = score_by_round.get(round_number)
        if score is not None:
            running = score if running is None else max(running, score)
        curve.append(running)
    return curve


def main() -> None:
    args = parse_args()
    root = args.experiment_dir.resolve()
    manifest = load_json(root / "experiment_manifest.json")
    expected_rounds = int(manifest.get("rounds_per_trajectory", 0))
    expected_trajectories = int(manifest.get("trajectories", 0))
    primary_metric = str(
        manifest.get("primary_metric") or "best_score_within_round_budget"
    )
    trajectories: list[dict[str, Any]] = []
    all_runner_warnings: list[str] = []

    for trajectory_dir in sorted(root.glob("trajectory_*")):
        if not trajectory_dir.is_dir():
            continue
        rounds: list[dict[str, Any]] = []
        for round_dir in sorted(trajectory_dir.glob("round_*")):
            status_path = round_dir / "status.json"
            if not status_path.is_file():
                continue
            status = load_json(status_path)
            generation = (
                load_json(round_dir / "generation_status.json")
                if (round_dir / "generation_status.json").is_file()
                else {}
            )
            raw = (
                load_json(round_dir / "raw_response.json")
                if (round_dir / "raw_response.json").is_file()
                else {}
            )
            parse_report = (
                load_json(round_dir / "parse_report.json")
                if (round_dir / "parse_report.json").is_file()
                else {}
            )
            usage = raw.get("usage", {}) if isinstance(raw.get("usage"), dict) else {}
            receipt = (
                load_json(round_dir / "submission_receipt.json")
                if (round_dir / "submission_receipt.json").is_file()
                else {}
            )
            runner_warnings = receipt.get("runner_warnings", [])
            if not isinstance(runner_warnings, list):
                runner_warnings = []
            for warning in runner_warnings:
                warning_text = str(warning)
                if warning_text not in all_runner_warnings:
                    all_runner_warnings.append(warning_text)
            environment_verification = (
                load_json(round_dir / "environment_verification.json")
                if (round_dir / "environment_verification.json").is_file()
                else {}
            )
            round_number = int(round_dir.name.split("_")[-1])
            rounds.append({
                "round": round_number,
                "status": status.get("status"),
                "outcome": status.get("outcome"),
                "submitted": bool(status.get("submitted")),
                "job_status": status.get("job_status"),
                "score": status.get("result_score"),
                "passed_cases": status.get("passed_cases"),
                "total_cases": status.get("total_cases"),
                "finish_reason": generation.get("finish_reason"),
                "system_fingerprint": generation.get("system_fingerprint"),
                "prompt_tokens": usage.get("prompt_tokens"),
                "completion_tokens": usage.get("completion_tokens"),
                "total_tokens": usage.get("total_tokens"),
                "runner_warnings": runner_warnings,
                "runner_verification_skipped": receipt.get(
                    "runner_verification_skipped"
                ),
                "environment_verification_status": environment_verification.get(
                    "status"
                ),
                "recoverable_parse_pass": bool(
                    parse_report.get("recoverable_parse_pass", status.get("recoverable_parse_pass"))
                ),
                "strict_protocol_pass": bool(
                    parse_report.get("strict_protocol_pass", status.get("strict_protocol_pass"))
                ),
                "format_recovered": bool(
                    parse_report.get("format_recovered", status.get("format_recovered"))
                ),
                "format_recovery_reasons": parse_report.get(
                    "format_recovery_reasons", status.get("format_recovery_reasons", [])
                ),
            })

        rounds.sort(key=lambda item: int(item["round"]))
        completed = [item for item in rounds if item.get("status") == "round_completed"]
        completed_numbers = {int(item["round"]) for item in completed}
        complete = completed_numbers == set(range(1, expected_rounds + 1))
        final_item = next(
            (item for item in completed if item["round"] == expected_rounds), None
        )
        best_item = max(
            (item for item in completed if item.get("score") is not None),
            key=lambda item: float(item["score"]),
            default=None,
        )
        full_correctness_round = first_round(
            completed,
            lambda item: item.get("total_cases") not in {None, 0}
            and item.get("passed_cases") == item.get("total_cases"),
        )
        score_curve = best_so_far(completed, expected_rounds)
        trajectories.append({
            "trajectory": trajectory_dir.name,
            "complete": complete,
            "completed_rounds": len(completed),
            "observed_status_records": len(rounds),
            "final_score": final_item.get("score") if final_item else None,
            "best_score": best_item.get("score") if best_item else None,
            "best_round": best_item.get("round") if best_item else None,
            "best_score_by_round": score_curve,
            "first_compile_success_round": first_round(
                completed,
                lambda item: item.get("job_status") not in {None, "compile_failed"}
                and item.get("outcome") == "platform_evaluated",
            ),
            "first_nonzero_score_round": first_round(
                completed,
                lambda item: item.get("score") is not None
                and float(item["score"]) > 0,
            ),
            "first_full_correctness_round": full_correctness_round,
            "ever_nonzero": any(
                item.get("score") is not None and float(item["score"]) > 0
                for item in completed
            ),
            "ever_full_correctness": full_correctness_round is not None,
            "submissions": sum(bool(item.get("submitted")) for item in completed),
            "format_or_assembly_failures": sum(
                item.get("outcome") in {"parse_failed", "assembly_failed"}
                for item in completed
            ),
            "score_by_round": [
                next(
                    (
                        item.get("score")
                        for item in completed
                        if int(item["round"]) == round_number
                    ),
                    None,
                )
                for round_number in range(1, expected_rounds + 1)
            ],
            "rounds": rounds,
        })

    complete_trajectories = [item for item in trajectories if item["complete"]]
    best_scores = [
        float(item["best_score"])
        for item in complete_trajectories
        if item.get("best_score") is not None
    ]
    final_scores = [
        float(item["final_score"])
        for item in complete_trajectories
        if item.get("final_score") is not None
    ]
    primary_scores = (
        best_scores
        if primary_metric.startswith("best_score_within_")
        else final_scores
    )
    mean_best_curve: list[float | None] = []
    for index in range(expected_rounds):
        values = [
            float(item["best_score_by_round"][index])
            for item in complete_trajectories
            if item["best_score_by_round"][index] is not None
        ]
        mean_best_curve.append(statistics.mean(values) if values else None)

    formal_complete = (
        len(complete_trajectories) == expected_trajectories
        and len(trajectories) == expected_trajectories
    )
    summary = {
        "summarized_at": timestamp(),
        "experiment_dir": str(root),
        "primary_metric": primary_metric,
        "expected_rounds_per_trajectory": expected_rounds,
        "expected_trajectory_count": expected_trajectories,
        "observed_trajectory_count": len(trajectories),
        "complete_trajectory_count": len(complete_trajectories),
        "formal_result_complete": formal_complete,
        "aggregate_scope": "complete_trajectories_only",
        "runner_warnings": all_runner_warnings,
        "primary_scores": primary_scores,
        "mean_primary_score": (
            statistics.mean(primary_scores) if primary_scores else None
        ),
        "median_primary_score": (
            statistics.median(primary_scores) if primary_scores else None
        ),
        "trajectory_best_scores": best_scores,
        "mean_trajectory_best_score": statistics.mean(best_scores) if best_scores else None,
        "median_trajectory_best_score": statistics.median(best_scores) if best_scores else None,
        "sample_stdev_trajectory_best_score": (
            statistics.stdev(best_scores) if len(best_scores) >= 2 else None
        ),
        "min_trajectory_best_score": min(best_scores) if best_scores else None,
        "max_trajectory_best_score": max(best_scores) if best_scores else None,
        "mean_best_score_by_round": mean_best_curve,
        "trajectory_nonzero_rate": (
            sum(bool(item["ever_nonzero"]) for item in complete_trajectories)
            / len(complete_trajectories)
            if complete_trajectories
            else None
        ),
        "trajectory_full_correctness_rate": (
            sum(bool(item["ever_full_correctness"]) for item in complete_trajectories)
            / len(complete_trajectories)
            if complete_trajectories
            else None
        ),
        "pass_at_trajectory_budget": (
            any(bool(item["ever_full_correctness"]) for item in complete_trajectories)
            if formal_complete
            else None
        ),
        "pass_all_trajectories": (
            all(bool(item["ever_full_correctness"]) for item in complete_trajectories)
            if formal_complete
            else None
        ),
        "final_scores_diagnostic_only": final_scores,
        "format_recovered_rounds": sum(
            bool(round_item.get("format_recovered"))
            for trajectory in trajectories
            for round_item in trajectory["rounds"]
        ),
        "strict_protocol_passes": sum(
            bool(round_item.get("strict_protocol_pass"))
            for trajectory in trajectories
            for round_item in trajectory["rounds"]
        ),
        "trajectories": trajectories,
    }
    write_json(root / "feedback_experiment_summary.json", summary)

    lines = [
        "# 多轮平台反馈实验汇总",
        "",
        f"- 主指标：{primary_metric}",
        f"- 轮数：{expected_rounds}",
        f"- 完整轨迹：{len(complete_trajectories)}/{expected_trajectories}",
        f"- 正式结果是否完整：{'是' if formal_complete else '否'}",
        f"- 主指标各轨迹值：{primary_scores}",
        f"- 主指标均值：{summary['mean_primary_score']}",
        f"- 各轨迹最高分：{best_scores}",
        f"- 平均轨迹最高分：{summary['mean_trajectory_best_score']}",
        f"- 中位轨迹最高分：{summary['median_trajectory_best_score']}",
        f"- 样本标准差：{summary['sample_stdev_trajectory_best_score']}",
        f"- 格式恢复轮次：{summary['format_recovered_rounds']}",
        f"- 严格格式通过：{summary['strict_protocol_passes']}",
        "",
        "| 轨迹 | 完整 | 完成轮数 | 轨迹最高分（轮次） | 最终轮分数 | 首次编译成功 | 首次非零 | 首次全正确 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for item in trajectories:
        lines.append(
            f"| {item['trajectory']} | {'是' if item['complete'] else '否'} | "
            f"{item['completed_rounds']} | {item['best_score']}（R{item['best_round']}） | "
            f"{item['final_score']} | {item['first_compile_success_round']} | "
            f"{item['first_nonzero_score_round']} | {item['first_full_correctness_round']} |"
        )
    (root / "feedback_experiment_summary.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(f"多轮实验汇总: {root / 'feedback_experiment_summary.json'}")


if __name__ == "__main__":
    main()
