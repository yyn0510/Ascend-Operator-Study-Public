from __future__ import annotations

import tempfile
import sys
import types
import unittest
from pathlib import Path

MODEL_EVAL = Path(__file__).resolve().parent
if str(MODEL_EVAL) not in sys.path:
    sys.path.insert(0, str(MODEL_EVAL))

try:
    import openai  # noqa: F401
except ModuleNotFoundError:
    openai_stub = types.ModuleType("openai")
    class _OpenAIError(Exception):
        pass

    openai_stub.OpenAI = object
    openai_stub.APIConnectionError = _OpenAIError
    openai_stub.APITimeoutError = _OpenAIError
    openai_stub.RateLimitError = _OpenAIError
    sys.modules["openai"] = openai_stub

from parse_output import expected_paths_for_op, parse_run


def render_blocks(op_name: str, paths: list[str]) -> str:
    chunks: list[str] = []
    for path in paths:
        chunks.append(f"=== FILE: {path} ===\n")
        chunks.append(f"source for {path}\n")
        chunks.append("=== END FILE ===\n")
    return "".join(chunks)


class ParseOutputTests(unittest.TestCase):
    def test_strict_five_file_output_remains_strict(self) -> None:
        op_name = "exp"
        paths = expected_paths_for_op(op_name)
        output = render_blocks(op_name, paths)
        output += "\n=== CHANGE SUMMARY ===\nimplemented\n=== END CHANGE SUMMARY ===\n"

        with tempfile.TemporaryDirectory() as directory:
            run_dir = Path(directory)
            (run_dir / "model_output.txt").write_text(output, encoding="utf-8")
            report = parse_run(run_dir, op_name)

            self.assertTrue(report["recoverable_parse_pass"])
            self.assertTrue(report["strict_protocol_pass"])
            self.assertFalse(report["format_recovered"])
            self.assertEqual(report["paths"], paths)

    def test_recovery_ignores_prose_inline_summary_and_order(self) -> None:
        op_name = "exp"
        paths = list(reversed(expected_paths_for_op(op_name)))
        output = "Here are the generated files:\n" + render_blocks(op_name, paths)
        output += "=== CHANGE SUMMARY ===\n本轮完成实现。=== END CHANGE SUMMARY ===\n"

        with tempfile.TemporaryDirectory() as directory:
            run_dir = Path(directory)
            (run_dir / "model_output.txt").write_text(output, encoding="utf-8")
            report = parse_run(run_dir, op_name)

            self.assertTrue(report["recoverable_parse_pass"])
            self.assertFalse(report["strict_protocol_pass"])
            self.assertTrue(report["format_recovered"])
            self.assertFalse(report["order_matches"])
            self.assertIn("residual_text_ignored", report["format_recovery_reasons"])
            self.assertTrue(
                (run_dir / "parsed" / "csrc" / "ops" / "exp" / "CMakeLists.txt").is_file()
            )

    def test_missing_file_is_not_recovered(self) -> None:
        op_name = "exp"
        paths = expected_paths_for_op(op_name)[:-1]
        output = render_blocks(op_name, paths)

        with tempfile.TemporaryDirectory() as directory:
            run_dir = Path(directory)
            (run_dir / "model_output.txt").write_text(output, encoding="utf-8")
            report = parse_run(run_dir, op_name)

            self.assertFalse(report["recoverable_parse_pass"])
            self.assertFalse(report["format_recovered"])
            self.assertIn("cann_bench/__init__.py.append", report["missing_paths"])


if __name__ == "__main__":
    unittest.main()
